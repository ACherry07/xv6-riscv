
user/_grind:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <do_rand>:
#include "kernel/riscv.h"

// from FreeBSD.
int
do_rand(unsigned long *ctx)
{
       0:	1141                	addi	sp,sp,-16
       2:	e422                	sd	s0,8(sp)
       4:	0800                	addi	s0,sp,16
 * October 1988, p. 1195.
 */
    long hi, lo, x;

    /* Transform to [1, 0x7ffffffe] range. */
    x = (*ctx % 0x7ffffffe) + 1;
       6:	611c                	ld	a5,0(a0)
       8:	80000737          	lui	a4,0x80000
       c:	ffe74713          	xori	a4,a4,-2
      10:	02e7f7b3          	remu	a5,a5,a4
      14:	0785                	addi	a5,a5,1
    hi = x / 127773;
    lo = x % 127773;
      16:	66fd                	lui	a3,0x1f
      18:	31d68693          	addi	a3,a3,797 # 1f31d <base+0x1cf15>
      1c:	02d7e733          	rem	a4,a5,a3
    x = 16807 * lo - 2836 * hi;
      20:	6611                	lui	a2,0x4
      22:	1a760613          	addi	a2,a2,423 # 41a7 <base+0x1d9f>
      26:	02c70733          	mul	a4,a4,a2
    hi = x / 127773;
      2a:	02d7c7b3          	div	a5,a5,a3
    x = 16807 * lo - 2836 * hi;
      2e:	76fd                	lui	a3,0xfffff
      30:	4ec68693          	addi	a3,a3,1260 # fffffffffffff4ec <base+0xffffffffffffd0e4>
      34:	02d787b3          	mul	a5,a5,a3
      38:	97ba                	add	a5,a5,a4
    if (x < 0)
      3a:	0007c963          	bltz	a5,4c <do_rand+0x4c>
        x += 0x7fffffff;
    /* Transform to [0, 0x7ffffffd] range. */
    x--;
      3e:	17fd                	addi	a5,a5,-1
    *ctx = x;
      40:	e11c                	sd	a5,0(a0)
    return (x);
}
      42:	0007851b          	sext.w	a0,a5
      46:	6422                	ld	s0,8(sp)
      48:	0141                	addi	sp,sp,16
      4a:	8082                	ret
        x += 0x7fffffff;
      4c:	80000737          	lui	a4,0x80000
      50:	fff74713          	not	a4,a4
      54:	97ba                	add	a5,a5,a4
      56:	b7e5                	j	3e <do_rand+0x3e>

0000000000000058 <rand>:

unsigned long rand_next = 1;

int
rand(void)
{
      58:	1141                	addi	sp,sp,-16
      5a:	e406                	sd	ra,8(sp)
      5c:	e022                	sd	s0,0(sp)
      5e:	0800                	addi	s0,sp,16
    return (do_rand(&rand_next));
      60:	00002517          	auipc	a0,0x2
      64:	fa050513          	addi	a0,a0,-96 # 2000 <rand_next>
      68:	f99ff0ef          	jal	ra,0 <do_rand>
}
      6c:	60a2                	ld	ra,8(sp)
      6e:	6402                	ld	s0,0(sp)
      70:	0141                	addi	sp,sp,16
      72:	8082                	ret

0000000000000074 <go>:

void
go(int which_child)
{
      74:	7119                	addi	sp,sp,-128
      76:	fc86                	sd	ra,120(sp)
      78:	f8a2                	sd	s0,112(sp)
      7a:	f4a6                	sd	s1,104(sp)
      7c:	f0ca                	sd	s2,96(sp)
      7e:	ecce                	sd	s3,88(sp)
      80:	e8d2                	sd	s4,80(sp)
      82:	e4d6                	sd	s5,72(sp)
      84:	e0da                	sd	s6,64(sp)
      86:	fc5e                	sd	s7,56(sp)
      88:	0100                	addi	s0,sp,128
      8a:	84aa                	mv	s1,a0
  int fd = -1;
  static char buf[999];
  char *break0 = sbrk(0);
      8c:	4501                	li	a0,0
      8e:	3ad000ef          	jal	ra,c3a <sbrk>
      92:	8aaa                	mv	s5,a0
  uint64 iters = 0;

  mkdir("grindir");
      94:	00001517          	auipc	a0,0x1
      98:	10c50513          	addi	a0,a0,268 # 11a0 <malloc+0xea>
      9c:	37f000ef          	jal	ra,c1a <mkdir>
  if(chdir("grindir") != 0){
      a0:	00001517          	auipc	a0,0x1
      a4:	10050513          	addi	a0,a0,256 # 11a0 <malloc+0xea>
      a8:	37b000ef          	jal	ra,c22 <chdir>
      ac:	c911                	beqz	a0,c0 <go+0x4c>
    printf("grind: chdir grindir failed\n");
      ae:	00001517          	auipc	a0,0x1
      b2:	0fa50513          	addi	a0,a0,250 # 11a8 <malloc+0xf2>
      b6:	747000ef          	jal	ra,ffc <printf>
    exit(1);
      ba:	4505                	li	a0,1
      bc:	2f7000ef          	jal	ra,bb2 <exit>
  }
  chdir("/");
      c0:	00001517          	auipc	a0,0x1
      c4:	10850513          	addi	a0,a0,264 # 11c8 <malloc+0x112>
      c8:	35b000ef          	jal	ra,c22 <chdir>
  
  while(1){
    iters++;
    if((iters % 500) == 0)
      cc:	00001997          	auipc	s3,0x1
      d0:	10c98993          	addi	s3,s3,268 # 11d8 <malloc+0x122>
      d4:	c489                	beqz	s1,de <go+0x6a>
      d6:	00001997          	auipc	s3,0x1
      da:	0fa98993          	addi	s3,s3,250 # 11d0 <malloc+0x11a>
    iters++;
      de:	4485                	li	s1,1
  int fd = -1;
      e0:	597d                	li	s2,-1
      close(fd);
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
    } else if(what == 7){
      write(fd, buf, sizeof(buf));
    } else if(what == 8){
      read(fd, buf, sizeof(buf));
      e2:	00002a17          	auipc	s4,0x2
      e6:	f3ea0a13          	addi	s4,s4,-194 # 2020 <buf.0>
      ea:	a035                	j	116 <go+0xa2>
      close(open("grindir/../a", O_CREATE|O_RDWR));
      ec:	20200593          	li	a1,514
      f0:	00001517          	auipc	a0,0x1
      f4:	0f050513          	addi	a0,a0,240 # 11e0 <malloc+0x12a>
      f8:	2fb000ef          	jal	ra,bf2 <open>
      fc:	2df000ef          	jal	ra,bda <close>
    iters++;
     100:	0485                	addi	s1,s1,1
    if((iters % 500) == 0)
     102:	1f400793          	li	a5,500
     106:	02f4f7b3          	remu	a5,s1,a5
     10a:	e791                	bnez	a5,116 <go+0xa2>
      write(1, which_child?"B":"A", 1);
     10c:	4605                	li	a2,1
     10e:	85ce                	mv	a1,s3
     110:	4505                	li	a0,1
     112:	2c1000ef          	jal	ra,bd2 <write>
    int what = rand() % 23;
     116:	f43ff0ef          	jal	ra,58 <rand>
     11a:	47dd                	li	a5,23
     11c:	02f5653b          	remw	a0,a0,a5
    if(what == 1){
     120:	4785                	li	a5,1
     122:	fcf505e3          	beq	a0,a5,ec <go+0x78>
    } else if(what == 2){
     126:	4789                	li	a5,2
     128:	14f50463          	beq	a0,a5,270 <go+0x1fc>
    } else if(what == 3){
     12c:	478d                	li	a5,3
     12e:	14f50c63          	beq	a0,a5,286 <go+0x212>
    } else if(what == 4){
     132:	4791                	li	a5,4
     134:	16f50063          	beq	a0,a5,294 <go+0x220>
    } else if(what == 5){
     138:	4795                	li	a5,5
     13a:	18f50a63          	beq	a0,a5,2ce <go+0x25a>
    } else if(what == 6){
     13e:	4799                	li	a5,6
     140:	1af50463          	beq	a0,a5,2e8 <go+0x274>
    } else if(what == 7){
     144:	479d                	li	a5,7
     146:	1af50e63          	beq	a0,a5,302 <go+0x28e>
    } else if(what == 8){
     14a:	47a1                	li	a5,8
     14c:	1cf50263          	beq	a0,a5,310 <go+0x29c>
    } else if(what == 9){
     150:	47a5                	li	a5,9
     152:	1cf50663          	beq	a0,a5,31e <go+0x2aa>
      mkdir("grindir/../a");
      close(open("a/../a/./a", O_CREATE|O_RDWR));
      unlink("a/a");
    } else if(what == 10){
     156:	47a9                	li	a5,10
     158:	1ef50a63          	beq	a0,a5,34c <go+0x2d8>
      mkdir("/../b");
      close(open("grindir/../b/b", O_CREATE|O_RDWR));
      unlink("b/b");
    } else if(what == 11){
     15c:	47ad                	li	a5,11
     15e:	20f50e63          	beq	a0,a5,37a <go+0x306>
      unlink("b");
      link("../grindir/./../a", "../b");
    } else if(what == 12){
     162:	47b1                	li	a5,12
     164:	22f50c63          	beq	a0,a5,39c <go+0x328>
      unlink("../grindir/../a");
      link(".././b", "/grindir/../a");
    } else if(what == 13){
     168:	47b5                	li	a5,13
     16a:	24f50a63          	beq	a0,a5,3be <go+0x34a>
      } else if(pid < 0){
        printf("grind: fork failed\n");
        exit(1);
      }
      wait(0);
    } else if(what == 14){
     16e:	47b9                	li	a5,14
     170:	26f50b63          	beq	a0,a5,3e6 <go+0x372>
      } else if(pid < 0){
        printf("grind: fork failed\n");
        exit(1);
      }
      wait(0);
    } else if(what == 15){
     174:	47bd                	li	a5,15
     176:	2af50163          	beq	a0,a5,418 <go+0x3a4>
      sbrk(6011);
    } else if(what == 16){
     17a:	47c1                	li	a5,16
     17c:	2af50463          	beq	a0,a5,424 <go+0x3b0>
      if(sbrk(0) > break0)
        sbrk(-(sbrk(0) - break0));
    } else if(what == 17){
     180:	47c5                	li	a5,17
     182:	2af50e63          	beq	a0,a5,43e <go+0x3ca>
        printf("grind: chdir failed\n");
        exit(1);
      }
      kill(pid);
      wait(0);
    } else if(what == 18){
     186:	47c9                	li	a5,18
     188:	30f50e63          	beq	a0,a5,4a4 <go+0x430>
      } else if(pid < 0){
        printf("grind: fork failed\n");
        exit(1);
      }
      wait(0);
    } else if(what == 19){
     18c:	47cd                	li	a5,19
     18e:	34f50463          	beq	a0,a5,4d6 <go+0x462>
        exit(1);
      }
      close(fds[0]);
      close(fds[1]);
      wait(0);
    } else if(what == 20){
     192:	47d1                	li	a5,20
     194:	3ef50563          	beq	a0,a5,57e <go+0x50a>
      } else if(pid < 0){
        printf("grind: fork failed\n");
        exit(1);
      }
      wait(0);
    } else if(what == 21){
     198:	47d5                	li	a5,21
     19a:	44f50d63          	beq	a0,a5,5f4 <go+0x580>
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
        exit(1);
      }
      close(fd1);
      unlink("c");
    } else if(what == 22){
     19e:	47d9                	li	a5,22
     1a0:	f6f510e3          	bne	a0,a5,100 <go+0x8c>
      // echo hi | cat
      int aa[2], bb[2];
      if(pipe(aa) < 0){
     1a4:	f8840513          	addi	a0,s0,-120
     1a8:	21b000ef          	jal	ra,bc2 <pipe>
     1ac:	50054863          	bltz	a0,6bc <go+0x648>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      if(pipe(bb) < 0){
     1b0:	f9040513          	addi	a0,s0,-112
     1b4:	20f000ef          	jal	ra,bc2 <pipe>
     1b8:	50054c63          	bltz	a0,6d0 <go+0x65c>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      int pid1 = fork();
     1bc:	1ef000ef          	jal	ra,baa <fork>
      if(pid1 == 0){
     1c0:	52050263          	beqz	a0,6e4 <go+0x670>
        close(aa[1]);
        char *args[3] = { "echo", "hi", 0 };
        exec("grindir/../echo", args);
        fprintf(2, "grind: echo: not found\n");
        exit(2);
      } else if(pid1 < 0){
     1c4:	5a054463          	bltz	a0,76c <go+0x6f8>
        fprintf(2, "grind: fork failed\n");
        exit(3);
      }
      int pid2 = fork();
     1c8:	1e3000ef          	jal	ra,baa <fork>
      if(pid2 == 0){
     1cc:	5a050a63          	beqz	a0,780 <go+0x70c>
        close(bb[1]);
        char *args[2] = { "cat", 0 };
        exec("/cat", args);
        fprintf(2, "grind: cat: not found\n");
        exit(6);
      } else if(pid2 < 0){
     1d0:	64054863          	bltz	a0,820 <go+0x7ac>
        fprintf(2, "grind: fork failed\n");
        exit(7);
      }
      close(aa[0]);
     1d4:	f8842503          	lw	a0,-120(s0)
     1d8:	203000ef          	jal	ra,bda <close>
      close(aa[1]);
     1dc:	f8c42503          	lw	a0,-116(s0)
     1e0:	1fb000ef          	jal	ra,bda <close>
      close(bb[1]);
     1e4:	f9442503          	lw	a0,-108(s0)
     1e8:	1f3000ef          	jal	ra,bda <close>
      char buf[4] = { 0, 0, 0, 0 };
     1ec:	f8042023          	sw	zero,-128(s0)
      read(bb[0], buf+0, 1);
     1f0:	4605                	li	a2,1
     1f2:	f8040593          	addi	a1,s0,-128
     1f6:	f9042503          	lw	a0,-112(s0)
     1fa:	1d1000ef          	jal	ra,bca <read>
      read(bb[0], buf+1, 1);
     1fe:	4605                	li	a2,1
     200:	f8140593          	addi	a1,s0,-127
     204:	f9042503          	lw	a0,-112(s0)
     208:	1c3000ef          	jal	ra,bca <read>
      read(bb[0], buf+2, 1);
     20c:	4605                	li	a2,1
     20e:	f8240593          	addi	a1,s0,-126
     212:	f9042503          	lw	a0,-112(s0)
     216:	1b5000ef          	jal	ra,bca <read>
      close(bb[0]);
     21a:	f9042503          	lw	a0,-112(s0)
     21e:	1bd000ef          	jal	ra,bda <close>
      int st1, st2;
      wait(&st1);
     222:	f8440513          	addi	a0,s0,-124
     226:	195000ef          	jal	ra,bba <wait>
      wait(&st2);
     22a:	f9840513          	addi	a0,s0,-104
     22e:	18d000ef          	jal	ra,bba <wait>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     232:	f8442583          	lw	a1,-124(s0)
     236:	f9842b03          	lw	s6,-104(s0)
     23a:	0165ebb3          	or	s7,a1,s6
     23e:	000b9d63          	bnez	s7,258 <go+0x1e4>
     242:	00001597          	auipc	a1,0x1
     246:	21658593          	addi	a1,a1,534 # 1458 <malloc+0x3a2>
     24a:	f8040513          	addi	a0,s0,-128
     24e:	710000ef          	jal	ra,95e <strcmp>
     252:	ea0507e3          	beqz	a0,100 <go+0x8c>
     256:	85de                	mv	a1,s7
        printf("grind: exec pipeline failed %d %d \"%s\"\n", st1, st2, buf);
     258:	f8040693          	addi	a3,s0,-128
     25c:	865a                	mv	a2,s6
     25e:	00001517          	auipc	a0,0x1
     262:	20250513          	addi	a0,a0,514 # 1460 <malloc+0x3aa>
     266:	597000ef          	jal	ra,ffc <printf>
        exit(1);
     26a:	4505                	li	a0,1
     26c:	147000ef          	jal	ra,bb2 <exit>
      close(open("grindir/../grindir/../b", O_CREATE|O_RDWR));
     270:	20200593          	li	a1,514
     274:	00001517          	auipc	a0,0x1
     278:	f7c50513          	addi	a0,a0,-132 # 11f0 <malloc+0x13a>
     27c:	177000ef          	jal	ra,bf2 <open>
     280:	15b000ef          	jal	ra,bda <close>
     284:	bdb5                	j	100 <go+0x8c>
      unlink("grindir/../a");
     286:	00001517          	auipc	a0,0x1
     28a:	f5a50513          	addi	a0,a0,-166 # 11e0 <malloc+0x12a>
     28e:	175000ef          	jal	ra,c02 <unlink>
     292:	b5bd                	j	100 <go+0x8c>
      if(chdir("grindir") != 0){
     294:	00001517          	auipc	a0,0x1
     298:	f0c50513          	addi	a0,a0,-244 # 11a0 <malloc+0xea>
     29c:	187000ef          	jal	ra,c22 <chdir>
     2a0:	ed11                	bnez	a0,2bc <go+0x248>
      unlink("../b");
     2a2:	00001517          	auipc	a0,0x1
     2a6:	f6650513          	addi	a0,a0,-154 # 1208 <malloc+0x152>
     2aa:	159000ef          	jal	ra,c02 <unlink>
      chdir("/");
     2ae:	00001517          	auipc	a0,0x1
     2b2:	f1a50513          	addi	a0,a0,-230 # 11c8 <malloc+0x112>
     2b6:	16d000ef          	jal	ra,c22 <chdir>
     2ba:	b599                	j	100 <go+0x8c>
        printf("grind: chdir grindir failed\n");
     2bc:	00001517          	auipc	a0,0x1
     2c0:	eec50513          	addi	a0,a0,-276 # 11a8 <malloc+0xf2>
     2c4:	539000ef          	jal	ra,ffc <printf>
        exit(1);
     2c8:	4505                	li	a0,1
     2ca:	0e9000ef          	jal	ra,bb2 <exit>
      close(fd);
     2ce:	854a                	mv	a0,s2
     2d0:	10b000ef          	jal	ra,bda <close>
      fd = open("/grindir/../a", O_CREATE|O_RDWR);
     2d4:	20200593          	li	a1,514
     2d8:	00001517          	auipc	a0,0x1
     2dc:	f3850513          	addi	a0,a0,-200 # 1210 <malloc+0x15a>
     2e0:	113000ef          	jal	ra,bf2 <open>
     2e4:	892a                	mv	s2,a0
     2e6:	bd29                	j	100 <go+0x8c>
      close(fd);
     2e8:	854a                	mv	a0,s2
     2ea:	0f1000ef          	jal	ra,bda <close>
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     2ee:	20200593          	li	a1,514
     2f2:	00001517          	auipc	a0,0x1
     2f6:	f2e50513          	addi	a0,a0,-210 # 1220 <malloc+0x16a>
     2fa:	0f9000ef          	jal	ra,bf2 <open>
     2fe:	892a                	mv	s2,a0
     300:	b501                	j	100 <go+0x8c>
      write(fd, buf, sizeof(buf));
     302:	3e700613          	li	a2,999
     306:	85d2                	mv	a1,s4
     308:	854a                	mv	a0,s2
     30a:	0c9000ef          	jal	ra,bd2 <write>
     30e:	bbcd                	j	100 <go+0x8c>
      read(fd, buf, sizeof(buf));
     310:	3e700613          	li	a2,999
     314:	85d2                	mv	a1,s4
     316:	854a                	mv	a0,s2
     318:	0b3000ef          	jal	ra,bca <read>
     31c:	b3d5                	j	100 <go+0x8c>
      mkdir("grindir/../a");
     31e:	00001517          	auipc	a0,0x1
     322:	ec250513          	addi	a0,a0,-318 # 11e0 <malloc+0x12a>
     326:	0f5000ef          	jal	ra,c1a <mkdir>
      close(open("a/../a/./a", O_CREATE|O_RDWR));
     32a:	20200593          	li	a1,514
     32e:	00001517          	auipc	a0,0x1
     332:	f0a50513          	addi	a0,a0,-246 # 1238 <malloc+0x182>
     336:	0bd000ef          	jal	ra,bf2 <open>
     33a:	0a1000ef          	jal	ra,bda <close>
      unlink("a/a");
     33e:	00001517          	auipc	a0,0x1
     342:	f0a50513          	addi	a0,a0,-246 # 1248 <malloc+0x192>
     346:	0bd000ef          	jal	ra,c02 <unlink>
     34a:	bb5d                	j	100 <go+0x8c>
      mkdir("/../b");
     34c:	00001517          	auipc	a0,0x1
     350:	f0450513          	addi	a0,a0,-252 # 1250 <malloc+0x19a>
     354:	0c7000ef          	jal	ra,c1a <mkdir>
      close(open("grindir/../b/b", O_CREATE|O_RDWR));
     358:	20200593          	li	a1,514
     35c:	00001517          	auipc	a0,0x1
     360:	efc50513          	addi	a0,a0,-260 # 1258 <malloc+0x1a2>
     364:	08f000ef          	jal	ra,bf2 <open>
     368:	073000ef          	jal	ra,bda <close>
      unlink("b/b");
     36c:	00001517          	auipc	a0,0x1
     370:	efc50513          	addi	a0,a0,-260 # 1268 <malloc+0x1b2>
     374:	08f000ef          	jal	ra,c02 <unlink>
     378:	b361                	j	100 <go+0x8c>
      unlink("b");
     37a:	00001517          	auipc	a0,0x1
     37e:	eb650513          	addi	a0,a0,-330 # 1230 <malloc+0x17a>
     382:	081000ef          	jal	ra,c02 <unlink>
      link("../grindir/./../a", "../b");
     386:	00001597          	auipc	a1,0x1
     38a:	e8258593          	addi	a1,a1,-382 # 1208 <malloc+0x152>
     38e:	00001517          	auipc	a0,0x1
     392:	ee250513          	addi	a0,a0,-286 # 1270 <malloc+0x1ba>
     396:	07d000ef          	jal	ra,c12 <link>
     39a:	b39d                	j	100 <go+0x8c>
      unlink("../grindir/../a");
     39c:	00001517          	auipc	a0,0x1
     3a0:	eec50513          	addi	a0,a0,-276 # 1288 <malloc+0x1d2>
     3a4:	05f000ef          	jal	ra,c02 <unlink>
      link(".././b", "/grindir/../a");
     3a8:	00001597          	auipc	a1,0x1
     3ac:	e6858593          	addi	a1,a1,-408 # 1210 <malloc+0x15a>
     3b0:	00001517          	auipc	a0,0x1
     3b4:	ee850513          	addi	a0,a0,-280 # 1298 <malloc+0x1e2>
     3b8:	05b000ef          	jal	ra,c12 <link>
     3bc:	b391                	j	100 <go+0x8c>
      int pid = fork();
     3be:	7ec000ef          	jal	ra,baa <fork>
      if(pid == 0){
     3c2:	c519                	beqz	a0,3d0 <go+0x35c>
      } else if(pid < 0){
     3c4:	00054863          	bltz	a0,3d4 <go+0x360>
      wait(0);
     3c8:	4501                	li	a0,0
     3ca:	7f0000ef          	jal	ra,bba <wait>
     3ce:	bb0d                	j	100 <go+0x8c>
        exit(0);
     3d0:	7e2000ef          	jal	ra,bb2 <exit>
        printf("grind: fork failed\n");
     3d4:	00001517          	auipc	a0,0x1
     3d8:	ecc50513          	addi	a0,a0,-308 # 12a0 <malloc+0x1ea>
     3dc:	421000ef          	jal	ra,ffc <printf>
        exit(1);
     3e0:	4505                	li	a0,1
     3e2:	7d0000ef          	jal	ra,bb2 <exit>
      int pid = fork();
     3e6:	7c4000ef          	jal	ra,baa <fork>
      if(pid == 0){
     3ea:	c519                	beqz	a0,3f8 <go+0x384>
      } else if(pid < 0){
     3ec:	00054d63          	bltz	a0,406 <go+0x392>
      wait(0);
     3f0:	4501                	li	a0,0
     3f2:	7c8000ef          	jal	ra,bba <wait>
     3f6:	b329                	j	100 <go+0x8c>
        fork();
     3f8:	7b2000ef          	jal	ra,baa <fork>
        fork();
     3fc:	7ae000ef          	jal	ra,baa <fork>
        exit(0);
     400:	4501                	li	a0,0
     402:	7b0000ef          	jal	ra,bb2 <exit>
        printf("grind: fork failed\n");
     406:	00001517          	auipc	a0,0x1
     40a:	e9a50513          	addi	a0,a0,-358 # 12a0 <malloc+0x1ea>
     40e:	3ef000ef          	jal	ra,ffc <printf>
        exit(1);
     412:	4505                	li	a0,1
     414:	79e000ef          	jal	ra,bb2 <exit>
      sbrk(6011);
     418:	6505                	lui	a0,0x1
     41a:	77b50513          	addi	a0,a0,1915 # 177b <digits+0x2eb>
     41e:	01d000ef          	jal	ra,c3a <sbrk>
     422:	b9f9                	j	100 <go+0x8c>
      if(sbrk(0) > break0)
     424:	4501                	li	a0,0
     426:	015000ef          	jal	ra,c3a <sbrk>
     42a:	ccaafbe3          	bgeu	s5,a0,100 <go+0x8c>
        sbrk(-(sbrk(0) - break0));
     42e:	4501                	li	a0,0
     430:	00b000ef          	jal	ra,c3a <sbrk>
     434:	40aa853b          	subw	a0,s5,a0
     438:	003000ef          	jal	ra,c3a <sbrk>
     43c:	b1d1                	j	100 <go+0x8c>
      int pid = fork();
     43e:	76c000ef          	jal	ra,baa <fork>
     442:	8b2a                	mv	s6,a0
      if(pid == 0){
     444:	c10d                	beqz	a0,466 <go+0x3f2>
      } else if(pid < 0){
     446:	02054d63          	bltz	a0,480 <go+0x40c>
      if(chdir("../grindir/..") != 0){
     44a:	00001517          	auipc	a0,0x1
     44e:	e6e50513          	addi	a0,a0,-402 # 12b8 <malloc+0x202>
     452:	7d0000ef          	jal	ra,c22 <chdir>
     456:	ed15                	bnez	a0,492 <go+0x41e>
      kill(pid);
     458:	855a                	mv	a0,s6
     45a:	788000ef          	jal	ra,be2 <kill>
      wait(0);
     45e:	4501                	li	a0,0
     460:	75a000ef          	jal	ra,bba <wait>
     464:	b971                	j	100 <go+0x8c>
        close(open("a", O_CREATE|O_RDWR));
     466:	20200593          	li	a1,514
     46a:	00001517          	auipc	a0,0x1
     46e:	e1650513          	addi	a0,a0,-490 # 1280 <malloc+0x1ca>
     472:	780000ef          	jal	ra,bf2 <open>
     476:	764000ef          	jal	ra,bda <close>
        exit(0);
     47a:	4501                	li	a0,0
     47c:	736000ef          	jal	ra,bb2 <exit>
        printf("grind: fork failed\n");
     480:	00001517          	auipc	a0,0x1
     484:	e2050513          	addi	a0,a0,-480 # 12a0 <malloc+0x1ea>
     488:	375000ef          	jal	ra,ffc <printf>
        exit(1);
     48c:	4505                	li	a0,1
     48e:	724000ef          	jal	ra,bb2 <exit>
        printf("grind: chdir failed\n");
     492:	00001517          	auipc	a0,0x1
     496:	e3650513          	addi	a0,a0,-458 # 12c8 <malloc+0x212>
     49a:	363000ef          	jal	ra,ffc <printf>
        exit(1);
     49e:	4505                	li	a0,1
     4a0:	712000ef          	jal	ra,bb2 <exit>
      int pid = fork();
     4a4:	706000ef          	jal	ra,baa <fork>
      if(pid == 0){
     4a8:	c519                	beqz	a0,4b6 <go+0x442>
      } else if(pid < 0){
     4aa:	00054d63          	bltz	a0,4c4 <go+0x450>
      wait(0);
     4ae:	4501                	li	a0,0
     4b0:	70a000ef          	jal	ra,bba <wait>
     4b4:	b1b1                	j	100 <go+0x8c>
        kill(getpid());
     4b6:	77c000ef          	jal	ra,c32 <getpid>
     4ba:	728000ef          	jal	ra,be2 <kill>
        exit(0);
     4be:	4501                	li	a0,0
     4c0:	6f2000ef          	jal	ra,bb2 <exit>
        printf("grind: fork failed\n");
     4c4:	00001517          	auipc	a0,0x1
     4c8:	ddc50513          	addi	a0,a0,-548 # 12a0 <malloc+0x1ea>
     4cc:	331000ef          	jal	ra,ffc <printf>
        exit(1);
     4d0:	4505                	li	a0,1
     4d2:	6e0000ef          	jal	ra,bb2 <exit>
      if(pipe(fds) < 0){
     4d6:	f9840513          	addi	a0,s0,-104
     4da:	6e8000ef          	jal	ra,bc2 <pipe>
     4de:	02054363          	bltz	a0,504 <go+0x490>
      int pid = fork();
     4e2:	6c8000ef          	jal	ra,baa <fork>
      if(pid == 0){
     4e6:	c905                	beqz	a0,516 <go+0x4a2>
      } else if(pid < 0){
     4e8:	08054263          	bltz	a0,56c <go+0x4f8>
      close(fds[0]);
     4ec:	f9842503          	lw	a0,-104(s0)
     4f0:	6ea000ef          	jal	ra,bda <close>
      close(fds[1]);
     4f4:	f9c42503          	lw	a0,-100(s0)
     4f8:	6e2000ef          	jal	ra,bda <close>
      wait(0);
     4fc:	4501                	li	a0,0
     4fe:	6bc000ef          	jal	ra,bba <wait>
     502:	befd                	j	100 <go+0x8c>
        printf("grind: pipe failed\n");
     504:	00001517          	auipc	a0,0x1
     508:	ddc50513          	addi	a0,a0,-548 # 12e0 <malloc+0x22a>
     50c:	2f1000ef          	jal	ra,ffc <printf>
        exit(1);
     510:	4505                	li	a0,1
     512:	6a0000ef          	jal	ra,bb2 <exit>
        fork();
     516:	694000ef          	jal	ra,baa <fork>
        fork();
     51a:	690000ef          	jal	ra,baa <fork>
        if(write(fds[1], "x", 1) != 1)
     51e:	4605                	li	a2,1
     520:	00001597          	auipc	a1,0x1
     524:	dd858593          	addi	a1,a1,-552 # 12f8 <malloc+0x242>
     528:	f9c42503          	lw	a0,-100(s0)
     52c:	6a6000ef          	jal	ra,bd2 <write>
     530:	4785                	li	a5,1
     532:	00f51f63          	bne	a0,a5,550 <go+0x4dc>
        if(read(fds[0], &c, 1) != 1)
     536:	4605                	li	a2,1
     538:	f9040593          	addi	a1,s0,-112
     53c:	f9842503          	lw	a0,-104(s0)
     540:	68a000ef          	jal	ra,bca <read>
     544:	4785                	li	a5,1
     546:	00f51c63          	bne	a0,a5,55e <go+0x4ea>
        exit(0);
     54a:	4501                	li	a0,0
     54c:	666000ef          	jal	ra,bb2 <exit>
          printf("grind: pipe write failed\n");
     550:	00001517          	auipc	a0,0x1
     554:	db050513          	addi	a0,a0,-592 # 1300 <malloc+0x24a>
     558:	2a5000ef          	jal	ra,ffc <printf>
     55c:	bfe9                	j	536 <go+0x4c2>
          printf("grind: pipe read failed\n");
     55e:	00001517          	auipc	a0,0x1
     562:	dc250513          	addi	a0,a0,-574 # 1320 <malloc+0x26a>
     566:	297000ef          	jal	ra,ffc <printf>
     56a:	b7c5                	j	54a <go+0x4d6>
        printf("grind: fork failed\n");
     56c:	00001517          	auipc	a0,0x1
     570:	d3450513          	addi	a0,a0,-716 # 12a0 <malloc+0x1ea>
     574:	289000ef          	jal	ra,ffc <printf>
        exit(1);
     578:	4505                	li	a0,1
     57a:	638000ef          	jal	ra,bb2 <exit>
      int pid = fork();
     57e:	62c000ef          	jal	ra,baa <fork>
      if(pid == 0){
     582:	c519                	beqz	a0,590 <go+0x51c>
      } else if(pid < 0){
     584:	04054f63          	bltz	a0,5e2 <go+0x56e>
      wait(0);
     588:	4501                	li	a0,0
     58a:	630000ef          	jal	ra,bba <wait>
     58e:	be8d                	j	100 <go+0x8c>
        unlink("a");
     590:	00001517          	auipc	a0,0x1
     594:	cf050513          	addi	a0,a0,-784 # 1280 <malloc+0x1ca>
     598:	66a000ef          	jal	ra,c02 <unlink>
        mkdir("a");
     59c:	00001517          	auipc	a0,0x1
     5a0:	ce450513          	addi	a0,a0,-796 # 1280 <malloc+0x1ca>
     5a4:	676000ef          	jal	ra,c1a <mkdir>
        chdir("a");
     5a8:	00001517          	auipc	a0,0x1
     5ac:	cd850513          	addi	a0,a0,-808 # 1280 <malloc+0x1ca>
     5b0:	672000ef          	jal	ra,c22 <chdir>
        unlink("../a");
     5b4:	00001517          	auipc	a0,0x1
     5b8:	c3450513          	addi	a0,a0,-972 # 11e8 <malloc+0x132>
     5bc:	646000ef          	jal	ra,c02 <unlink>
        fd = open("x", O_CREATE|O_RDWR);
     5c0:	20200593          	li	a1,514
     5c4:	00001517          	auipc	a0,0x1
     5c8:	d3450513          	addi	a0,a0,-716 # 12f8 <malloc+0x242>
     5cc:	626000ef          	jal	ra,bf2 <open>
        unlink("x");
     5d0:	00001517          	auipc	a0,0x1
     5d4:	d2850513          	addi	a0,a0,-728 # 12f8 <malloc+0x242>
     5d8:	62a000ef          	jal	ra,c02 <unlink>
        exit(0);
     5dc:	4501                	li	a0,0
     5de:	5d4000ef          	jal	ra,bb2 <exit>
        printf("grind: fork failed\n");
     5e2:	00001517          	auipc	a0,0x1
     5e6:	cbe50513          	addi	a0,a0,-834 # 12a0 <malloc+0x1ea>
     5ea:	213000ef          	jal	ra,ffc <printf>
        exit(1);
     5ee:	4505                	li	a0,1
     5f0:	5c2000ef          	jal	ra,bb2 <exit>
      unlink("c");
     5f4:	00001517          	auipc	a0,0x1
     5f8:	d4c50513          	addi	a0,a0,-692 # 1340 <malloc+0x28a>
     5fc:	606000ef          	jal	ra,c02 <unlink>
      int fd1 = open("c", O_CREATE|O_RDWR);
     600:	20200593          	li	a1,514
     604:	00001517          	auipc	a0,0x1
     608:	d3c50513          	addi	a0,a0,-708 # 1340 <malloc+0x28a>
     60c:	5e6000ef          	jal	ra,bf2 <open>
     610:	8b2a                	mv	s6,a0
      if(fd1 < 0){
     612:	04054763          	bltz	a0,660 <go+0x5ec>
      if(write(fd1, "x", 1) != 1){
     616:	4605                	li	a2,1
     618:	00001597          	auipc	a1,0x1
     61c:	ce058593          	addi	a1,a1,-800 # 12f8 <malloc+0x242>
     620:	5b2000ef          	jal	ra,bd2 <write>
     624:	4785                	li	a5,1
     626:	04f51663          	bne	a0,a5,672 <go+0x5fe>
      if(fstat(fd1, &st) != 0){
     62a:	f9840593          	addi	a1,s0,-104
     62e:	855a                	mv	a0,s6
     630:	5da000ef          	jal	ra,c0a <fstat>
     634:	e921                	bnez	a0,684 <go+0x610>
      if(st.size != 1){
     636:	fa843583          	ld	a1,-88(s0)
     63a:	4785                	li	a5,1
     63c:	04f59d63          	bne	a1,a5,696 <go+0x622>
      if(st.ino > 200){
     640:	f9c42583          	lw	a1,-100(s0)
     644:	0c800793          	li	a5,200
     648:	06b7e163          	bltu	a5,a1,6aa <go+0x636>
      close(fd1);
     64c:	855a                	mv	a0,s6
     64e:	58c000ef          	jal	ra,bda <close>
      unlink("c");
     652:	00001517          	auipc	a0,0x1
     656:	cee50513          	addi	a0,a0,-786 # 1340 <malloc+0x28a>
     65a:	5a8000ef          	jal	ra,c02 <unlink>
     65e:	b44d                	j	100 <go+0x8c>
        printf("grind: create c failed\n");
     660:	00001517          	auipc	a0,0x1
     664:	ce850513          	addi	a0,a0,-792 # 1348 <malloc+0x292>
     668:	195000ef          	jal	ra,ffc <printf>
        exit(1);
     66c:	4505                	li	a0,1
     66e:	544000ef          	jal	ra,bb2 <exit>
        printf("grind: write c failed\n");
     672:	00001517          	auipc	a0,0x1
     676:	cee50513          	addi	a0,a0,-786 # 1360 <malloc+0x2aa>
     67a:	183000ef          	jal	ra,ffc <printf>
        exit(1);
     67e:	4505                	li	a0,1
     680:	532000ef          	jal	ra,bb2 <exit>
        printf("grind: fstat failed\n");
     684:	00001517          	auipc	a0,0x1
     688:	cf450513          	addi	a0,a0,-780 # 1378 <malloc+0x2c2>
     68c:	171000ef          	jal	ra,ffc <printf>
        exit(1);
     690:	4505                	li	a0,1
     692:	520000ef          	jal	ra,bb2 <exit>
        printf("grind: fstat reports wrong size %d\n", (int)st.size);
     696:	2581                	sext.w	a1,a1
     698:	00001517          	auipc	a0,0x1
     69c:	cf850513          	addi	a0,a0,-776 # 1390 <malloc+0x2da>
     6a0:	15d000ef          	jal	ra,ffc <printf>
        exit(1);
     6a4:	4505                	li	a0,1
     6a6:	50c000ef          	jal	ra,bb2 <exit>
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     6aa:	00001517          	auipc	a0,0x1
     6ae:	d0e50513          	addi	a0,a0,-754 # 13b8 <malloc+0x302>
     6b2:	14b000ef          	jal	ra,ffc <printf>
        exit(1);
     6b6:	4505                	li	a0,1
     6b8:	4fa000ef          	jal	ra,bb2 <exit>
        fprintf(2, "grind: pipe failed\n");
     6bc:	00001597          	auipc	a1,0x1
     6c0:	c2458593          	addi	a1,a1,-988 # 12e0 <malloc+0x22a>
     6c4:	4509                	li	a0,2
     6c6:	10d000ef          	jal	ra,fd2 <fprintf>
        exit(1);
     6ca:	4505                	li	a0,1
     6cc:	4e6000ef          	jal	ra,bb2 <exit>
        fprintf(2, "grind: pipe failed\n");
     6d0:	00001597          	auipc	a1,0x1
     6d4:	c1058593          	addi	a1,a1,-1008 # 12e0 <malloc+0x22a>
     6d8:	4509                	li	a0,2
     6da:	0f9000ef          	jal	ra,fd2 <fprintf>
        exit(1);
     6de:	4505                	li	a0,1
     6e0:	4d2000ef          	jal	ra,bb2 <exit>
        close(bb[0]);
     6e4:	f9042503          	lw	a0,-112(s0)
     6e8:	4f2000ef          	jal	ra,bda <close>
        close(bb[1]);
     6ec:	f9442503          	lw	a0,-108(s0)
     6f0:	4ea000ef          	jal	ra,bda <close>
        close(aa[0]);
     6f4:	f8842503          	lw	a0,-120(s0)
     6f8:	4e2000ef          	jal	ra,bda <close>
        close(1);
     6fc:	4505                	li	a0,1
     6fe:	4dc000ef          	jal	ra,bda <close>
        if(dup(aa[1]) != 1){
     702:	f8c42503          	lw	a0,-116(s0)
     706:	524000ef          	jal	ra,c2a <dup>
     70a:	4785                	li	a5,1
     70c:	00f50c63          	beq	a0,a5,724 <go+0x6b0>
          fprintf(2, "grind: dup failed\n");
     710:	00001597          	auipc	a1,0x1
     714:	cd058593          	addi	a1,a1,-816 # 13e0 <malloc+0x32a>
     718:	4509                	li	a0,2
     71a:	0b9000ef          	jal	ra,fd2 <fprintf>
          exit(1);
     71e:	4505                	li	a0,1
     720:	492000ef          	jal	ra,bb2 <exit>
        close(aa[1]);
     724:	f8c42503          	lw	a0,-116(s0)
     728:	4b2000ef          	jal	ra,bda <close>
        char *args[3] = { "echo", "hi", 0 };
     72c:	00001797          	auipc	a5,0x1
     730:	ccc78793          	addi	a5,a5,-820 # 13f8 <malloc+0x342>
     734:	f8f43c23          	sd	a5,-104(s0)
     738:	00001797          	auipc	a5,0x1
     73c:	cc878793          	addi	a5,a5,-824 # 1400 <malloc+0x34a>
     740:	faf43023          	sd	a5,-96(s0)
     744:	fa043423          	sd	zero,-88(s0)
        exec("grindir/../echo", args);
     748:	f9840593          	addi	a1,s0,-104
     74c:	00001517          	auipc	a0,0x1
     750:	cbc50513          	addi	a0,a0,-836 # 1408 <malloc+0x352>
     754:	496000ef          	jal	ra,bea <exec>
        fprintf(2, "grind: echo: not found\n");
     758:	00001597          	auipc	a1,0x1
     75c:	cc058593          	addi	a1,a1,-832 # 1418 <malloc+0x362>
     760:	4509                	li	a0,2
     762:	071000ef          	jal	ra,fd2 <fprintf>
        exit(2);
     766:	4509                	li	a0,2
     768:	44a000ef          	jal	ra,bb2 <exit>
        fprintf(2, "grind: fork failed\n");
     76c:	00001597          	auipc	a1,0x1
     770:	b3458593          	addi	a1,a1,-1228 # 12a0 <malloc+0x1ea>
     774:	4509                	li	a0,2
     776:	05d000ef          	jal	ra,fd2 <fprintf>
        exit(3);
     77a:	450d                	li	a0,3
     77c:	436000ef          	jal	ra,bb2 <exit>
        close(aa[1]);
     780:	f8c42503          	lw	a0,-116(s0)
     784:	456000ef          	jal	ra,bda <close>
        close(bb[0]);
     788:	f9042503          	lw	a0,-112(s0)
     78c:	44e000ef          	jal	ra,bda <close>
        close(0);
     790:	4501                	li	a0,0
     792:	448000ef          	jal	ra,bda <close>
        if(dup(aa[0]) != 0){
     796:	f8842503          	lw	a0,-120(s0)
     79a:	490000ef          	jal	ra,c2a <dup>
     79e:	c919                	beqz	a0,7b4 <go+0x740>
          fprintf(2, "grind: dup failed\n");
     7a0:	00001597          	auipc	a1,0x1
     7a4:	c4058593          	addi	a1,a1,-960 # 13e0 <malloc+0x32a>
     7a8:	4509                	li	a0,2
     7aa:	029000ef          	jal	ra,fd2 <fprintf>
          exit(4);
     7ae:	4511                	li	a0,4
     7b0:	402000ef          	jal	ra,bb2 <exit>
        close(aa[0]);
     7b4:	f8842503          	lw	a0,-120(s0)
     7b8:	422000ef          	jal	ra,bda <close>
        close(1);
     7bc:	4505                	li	a0,1
     7be:	41c000ef          	jal	ra,bda <close>
        if(dup(bb[1]) != 1){
     7c2:	f9442503          	lw	a0,-108(s0)
     7c6:	464000ef          	jal	ra,c2a <dup>
     7ca:	4785                	li	a5,1
     7cc:	00f50c63          	beq	a0,a5,7e4 <go+0x770>
          fprintf(2, "grind: dup failed\n");
     7d0:	00001597          	auipc	a1,0x1
     7d4:	c1058593          	addi	a1,a1,-1008 # 13e0 <malloc+0x32a>
     7d8:	4509                	li	a0,2
     7da:	7f8000ef          	jal	ra,fd2 <fprintf>
          exit(5);
     7de:	4515                	li	a0,5
     7e0:	3d2000ef          	jal	ra,bb2 <exit>
        close(bb[1]);
     7e4:	f9442503          	lw	a0,-108(s0)
     7e8:	3f2000ef          	jal	ra,bda <close>
        char *args[2] = { "cat", 0 };
     7ec:	00001797          	auipc	a5,0x1
     7f0:	c4478793          	addi	a5,a5,-956 # 1430 <malloc+0x37a>
     7f4:	f8f43c23          	sd	a5,-104(s0)
     7f8:	fa043023          	sd	zero,-96(s0)
        exec("/cat", args);
     7fc:	f9840593          	addi	a1,s0,-104
     800:	00001517          	auipc	a0,0x1
     804:	c3850513          	addi	a0,a0,-968 # 1438 <malloc+0x382>
     808:	3e2000ef          	jal	ra,bea <exec>
        fprintf(2, "grind: cat: not found\n");
     80c:	00001597          	auipc	a1,0x1
     810:	c3458593          	addi	a1,a1,-972 # 1440 <malloc+0x38a>
     814:	4509                	li	a0,2
     816:	7bc000ef          	jal	ra,fd2 <fprintf>
        exit(6);
     81a:	4519                	li	a0,6
     81c:	396000ef          	jal	ra,bb2 <exit>
        fprintf(2, "grind: fork failed\n");
     820:	00001597          	auipc	a1,0x1
     824:	a8058593          	addi	a1,a1,-1408 # 12a0 <malloc+0x1ea>
     828:	4509                	li	a0,2
     82a:	7a8000ef          	jal	ra,fd2 <fprintf>
        exit(7);
     82e:	451d                	li	a0,7
     830:	382000ef          	jal	ra,bb2 <exit>

0000000000000834 <iter>:
  }
}

void
iter()
{
     834:	7179                	addi	sp,sp,-48
     836:	f406                	sd	ra,40(sp)
     838:	f022                	sd	s0,32(sp)
     83a:	ec26                	sd	s1,24(sp)
     83c:	e84a                	sd	s2,16(sp)
     83e:	1800                	addi	s0,sp,48
  unlink("a");
     840:	00001517          	auipc	a0,0x1
     844:	a4050513          	addi	a0,a0,-1472 # 1280 <malloc+0x1ca>
     848:	3ba000ef          	jal	ra,c02 <unlink>
  unlink("b");
     84c:	00001517          	auipc	a0,0x1
     850:	9e450513          	addi	a0,a0,-1564 # 1230 <malloc+0x17a>
     854:	3ae000ef          	jal	ra,c02 <unlink>
  
  int pid1 = fork();
     858:	352000ef          	jal	ra,baa <fork>
  if(pid1 < 0){
     85c:	00054f63          	bltz	a0,87a <iter+0x46>
     860:	84aa                	mv	s1,a0
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid1 == 0){
     862:	e50d                	bnez	a0,88c <iter+0x58>
    rand_next ^= 31;
     864:	00001717          	auipc	a4,0x1
     868:	79c70713          	addi	a4,a4,1948 # 2000 <rand_next>
     86c:	631c                	ld	a5,0(a4)
     86e:	01f7c793          	xori	a5,a5,31
     872:	e31c                	sd	a5,0(a4)
    go(0);
     874:	4501                	li	a0,0
     876:	ffeff0ef          	jal	ra,74 <go>
    printf("grind: fork failed\n");
     87a:	00001517          	auipc	a0,0x1
     87e:	a2650513          	addi	a0,a0,-1498 # 12a0 <malloc+0x1ea>
     882:	77a000ef          	jal	ra,ffc <printf>
    exit(1);
     886:	4505                	li	a0,1
     888:	32a000ef          	jal	ra,bb2 <exit>
    exit(0);
  }

  int pid2 = fork();
     88c:	31e000ef          	jal	ra,baa <fork>
     890:	892a                	mv	s2,a0
  if(pid2 < 0){
     892:	02054063          	bltz	a0,8b2 <iter+0x7e>
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid2 == 0){
     896:	e51d                	bnez	a0,8c4 <iter+0x90>
    rand_next ^= 7177;
     898:	00001697          	auipc	a3,0x1
     89c:	76868693          	addi	a3,a3,1896 # 2000 <rand_next>
     8a0:	629c                	ld	a5,0(a3)
     8a2:	6709                	lui	a4,0x2
     8a4:	c0970713          	addi	a4,a4,-1015 # 1c09 <digits+0x779>
     8a8:	8fb9                	xor	a5,a5,a4
     8aa:	e29c                	sd	a5,0(a3)
    go(1);
     8ac:	4505                	li	a0,1
     8ae:	fc6ff0ef          	jal	ra,74 <go>
    printf("grind: fork failed\n");
     8b2:	00001517          	auipc	a0,0x1
     8b6:	9ee50513          	addi	a0,a0,-1554 # 12a0 <malloc+0x1ea>
     8ba:	742000ef          	jal	ra,ffc <printf>
    exit(1);
     8be:	4505                	li	a0,1
     8c0:	2f2000ef          	jal	ra,bb2 <exit>
    exit(0);
  }

  int st1 = -1;
     8c4:	57fd                	li	a5,-1
     8c6:	fcf42e23          	sw	a5,-36(s0)
  wait(&st1);
     8ca:	fdc40513          	addi	a0,s0,-36
     8ce:	2ec000ef          	jal	ra,bba <wait>
  if(st1 != 0){
     8d2:	fdc42783          	lw	a5,-36(s0)
     8d6:	eb99                	bnez	a5,8ec <iter+0xb8>
    kill(pid1);
    kill(pid2);
  }
  int st2 = -1;
     8d8:	57fd                	li	a5,-1
     8da:	fcf42c23          	sw	a5,-40(s0)
  wait(&st2);
     8de:	fd840513          	addi	a0,s0,-40
     8e2:	2d8000ef          	jal	ra,bba <wait>

  exit(0);
     8e6:	4501                	li	a0,0
     8e8:	2ca000ef          	jal	ra,bb2 <exit>
    kill(pid1);
     8ec:	8526                	mv	a0,s1
     8ee:	2f4000ef          	jal	ra,be2 <kill>
    kill(pid2);
     8f2:	854a                	mv	a0,s2
     8f4:	2ee000ef          	jal	ra,be2 <kill>
     8f8:	b7c5                	j	8d8 <iter+0xa4>

00000000000008fa <main>:
}

int
main()
{
     8fa:	1101                	addi	sp,sp,-32
     8fc:	ec06                	sd	ra,24(sp)
     8fe:	e822                	sd	s0,16(sp)
     900:	e426                	sd	s1,8(sp)
     902:	1000                	addi	s0,sp,32
    }
    if(pid > 0){
      wait(0);
    }
    sleep(20);
    rand_next += 1;
     904:	00001497          	auipc	s1,0x1
     908:	6fc48493          	addi	s1,s1,1788 # 2000 <rand_next>
     90c:	a809                	j	91e <main+0x24>
      iter();
     90e:	f27ff0ef          	jal	ra,834 <iter>
    sleep(20);
     912:	4551                	li	a0,20
     914:	32e000ef          	jal	ra,c42 <sleep>
    rand_next += 1;
     918:	609c                	ld	a5,0(s1)
     91a:	0785                	addi	a5,a5,1
     91c:	e09c                	sd	a5,0(s1)
    int pid = fork();
     91e:	28c000ef          	jal	ra,baa <fork>
    if(pid == 0){
     922:	d575                	beqz	a0,90e <main+0x14>
    if(pid > 0){
     924:	fea057e3          	blez	a0,912 <main+0x18>
      wait(0);
     928:	4501                	li	a0,0
     92a:	290000ef          	jal	ra,bba <wait>
     92e:	b7d5                	j	912 <main+0x18>

0000000000000930 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
     930:	1141                	addi	sp,sp,-16
     932:	e406                	sd	ra,8(sp)
     934:	e022                	sd	s0,0(sp)
     936:	0800                	addi	s0,sp,16
  extern int main();
  main();
     938:	fc3ff0ef          	jal	ra,8fa <main>
  exit(0);
     93c:	4501                	li	a0,0
     93e:	274000ef          	jal	ra,bb2 <exit>

0000000000000942 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
     942:	1141                	addi	sp,sp,-16
     944:	e422                	sd	s0,8(sp)
     946:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     948:	87aa                	mv	a5,a0
     94a:	0585                	addi	a1,a1,1
     94c:	0785                	addi	a5,a5,1
     94e:	fff5c703          	lbu	a4,-1(a1)
     952:	fee78fa3          	sb	a4,-1(a5)
     956:	fb75                	bnez	a4,94a <strcpy+0x8>
    ;
  return os;
}
     958:	6422                	ld	s0,8(sp)
     95a:	0141                	addi	sp,sp,16
     95c:	8082                	ret

000000000000095e <strcmp>:

int
strcmp(const char *p, const char *q)
{
     95e:	1141                	addi	sp,sp,-16
     960:	e422                	sd	s0,8(sp)
     962:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
     964:	00054783          	lbu	a5,0(a0)
     968:	cb91                	beqz	a5,97c <strcmp+0x1e>
     96a:	0005c703          	lbu	a4,0(a1)
     96e:	00f71763          	bne	a4,a5,97c <strcmp+0x1e>
    p++, q++;
     972:	0505                	addi	a0,a0,1
     974:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
     976:	00054783          	lbu	a5,0(a0)
     97a:	fbe5                	bnez	a5,96a <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
     97c:	0005c503          	lbu	a0,0(a1)
}
     980:	40a7853b          	subw	a0,a5,a0
     984:	6422                	ld	s0,8(sp)
     986:	0141                	addi	sp,sp,16
     988:	8082                	ret

000000000000098a <strlen>:

uint
strlen(const char *s)
{
     98a:	1141                	addi	sp,sp,-16
     98c:	e422                	sd	s0,8(sp)
     98e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
     990:	00054783          	lbu	a5,0(a0)
     994:	cf91                	beqz	a5,9b0 <strlen+0x26>
     996:	0505                	addi	a0,a0,1
     998:	87aa                	mv	a5,a0
     99a:	4685                	li	a3,1
     99c:	9e89                	subw	a3,a3,a0
     99e:	00f6853b          	addw	a0,a3,a5
     9a2:	0785                	addi	a5,a5,1
     9a4:	fff7c703          	lbu	a4,-1(a5)
     9a8:	fb7d                	bnez	a4,99e <strlen+0x14>
    ;
  return n;
}
     9aa:	6422                	ld	s0,8(sp)
     9ac:	0141                	addi	sp,sp,16
     9ae:	8082                	ret
  for(n = 0; s[n]; n++)
     9b0:	4501                	li	a0,0
     9b2:	bfe5                	j	9aa <strlen+0x20>

00000000000009b4 <memset>:

void*
memset(void *dst, int c, uint n)
{
     9b4:	1141                	addi	sp,sp,-16
     9b6:	e422                	sd	s0,8(sp)
     9b8:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     9ba:	ca19                	beqz	a2,9d0 <memset+0x1c>
     9bc:	87aa                	mv	a5,a0
     9be:	1602                	slli	a2,a2,0x20
     9c0:	9201                	srli	a2,a2,0x20
     9c2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     9c6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
     9ca:	0785                	addi	a5,a5,1
     9cc:	fee79de3          	bne	a5,a4,9c6 <memset+0x12>
  }
  return dst;
}
     9d0:	6422                	ld	s0,8(sp)
     9d2:	0141                	addi	sp,sp,16
     9d4:	8082                	ret

00000000000009d6 <strchr>:

char*
strchr(const char *s, char c)
{
     9d6:	1141                	addi	sp,sp,-16
     9d8:	e422                	sd	s0,8(sp)
     9da:	0800                	addi	s0,sp,16
  for(; *s; s++)
     9dc:	00054783          	lbu	a5,0(a0)
     9e0:	cb99                	beqz	a5,9f6 <strchr+0x20>
    if(*s == c)
     9e2:	00f58763          	beq	a1,a5,9f0 <strchr+0x1a>
  for(; *s; s++)
     9e6:	0505                	addi	a0,a0,1
     9e8:	00054783          	lbu	a5,0(a0)
     9ec:	fbfd                	bnez	a5,9e2 <strchr+0xc>
      return (char*)s;
  return 0;
     9ee:	4501                	li	a0,0
}
     9f0:	6422                	ld	s0,8(sp)
     9f2:	0141                	addi	sp,sp,16
     9f4:	8082                	ret
  return 0;
     9f6:	4501                	li	a0,0
     9f8:	bfe5                	j	9f0 <strchr+0x1a>

00000000000009fa <gets>:

char*
gets(char *buf, int max)
{
     9fa:	711d                	addi	sp,sp,-96
     9fc:	ec86                	sd	ra,88(sp)
     9fe:	e8a2                	sd	s0,80(sp)
     a00:	e4a6                	sd	s1,72(sp)
     a02:	e0ca                	sd	s2,64(sp)
     a04:	fc4e                	sd	s3,56(sp)
     a06:	f852                	sd	s4,48(sp)
     a08:	f456                	sd	s5,40(sp)
     a0a:	f05a                	sd	s6,32(sp)
     a0c:	ec5e                	sd	s7,24(sp)
     a0e:	1080                	addi	s0,sp,96
     a10:	8baa                	mv	s7,a0
     a12:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     a14:	892a                	mv	s2,a0
     a16:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
     a18:	4aa9                	li	s5,10
     a1a:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
     a1c:	89a6                	mv	s3,s1
     a1e:	2485                	addiw	s1,s1,1
     a20:	0344d663          	bge	s1,s4,a4c <gets+0x52>
    cc = read(0, &c, 1);
     a24:	4605                	li	a2,1
     a26:	faf40593          	addi	a1,s0,-81
     a2a:	4501                	li	a0,0
     a2c:	19e000ef          	jal	ra,bca <read>
    if(cc < 1)
     a30:	00a05e63          	blez	a0,a4c <gets+0x52>
    buf[i++] = c;
     a34:	faf44783          	lbu	a5,-81(s0)
     a38:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
     a3c:	01578763          	beq	a5,s5,a4a <gets+0x50>
     a40:	0905                	addi	s2,s2,1
     a42:	fd679de3          	bne	a5,s6,a1c <gets+0x22>
  for(i=0; i+1 < max; ){
     a46:	89a6                	mv	s3,s1
     a48:	a011                	j	a4c <gets+0x52>
     a4a:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
     a4c:	99de                	add	s3,s3,s7
     a4e:	00098023          	sb	zero,0(s3)
  return buf;
}
     a52:	855e                	mv	a0,s7
     a54:	60e6                	ld	ra,88(sp)
     a56:	6446                	ld	s0,80(sp)
     a58:	64a6                	ld	s1,72(sp)
     a5a:	6906                	ld	s2,64(sp)
     a5c:	79e2                	ld	s3,56(sp)
     a5e:	7a42                	ld	s4,48(sp)
     a60:	7aa2                	ld	s5,40(sp)
     a62:	7b02                	ld	s6,32(sp)
     a64:	6be2                	ld	s7,24(sp)
     a66:	6125                	addi	sp,sp,96
     a68:	8082                	ret

0000000000000a6a <stat>:

int
stat(const char *n, struct stat *st)
{
     a6a:	1101                	addi	sp,sp,-32
     a6c:	ec06                	sd	ra,24(sp)
     a6e:	e822                	sd	s0,16(sp)
     a70:	e426                	sd	s1,8(sp)
     a72:	e04a                	sd	s2,0(sp)
     a74:	1000                	addi	s0,sp,32
     a76:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     a78:	4581                	li	a1,0
     a7a:	178000ef          	jal	ra,bf2 <open>
  if(fd < 0)
     a7e:	02054163          	bltz	a0,aa0 <stat+0x36>
     a82:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     a84:	85ca                	mv	a1,s2
     a86:	184000ef          	jal	ra,c0a <fstat>
     a8a:	892a                	mv	s2,a0
  close(fd);
     a8c:	8526                	mv	a0,s1
     a8e:	14c000ef          	jal	ra,bda <close>
  return r;
}
     a92:	854a                	mv	a0,s2
     a94:	60e2                	ld	ra,24(sp)
     a96:	6442                	ld	s0,16(sp)
     a98:	64a2                	ld	s1,8(sp)
     a9a:	6902                	ld	s2,0(sp)
     a9c:	6105                	addi	sp,sp,32
     a9e:	8082                	ret
    return -1;
     aa0:	597d                	li	s2,-1
     aa2:	bfc5                	j	a92 <stat+0x28>

0000000000000aa4 <atoi>:

int
atoi(const char *s)
{
     aa4:	1141                	addi	sp,sp,-16
     aa6:	e422                	sd	s0,8(sp)
     aa8:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     aaa:	00054603          	lbu	a2,0(a0)
     aae:	fd06079b          	addiw	a5,a2,-48
     ab2:	0ff7f793          	zext.b	a5,a5
     ab6:	4725                	li	a4,9
     ab8:	02f76963          	bltu	a4,a5,aea <atoi+0x46>
     abc:	86aa                	mv	a3,a0
  n = 0;
     abe:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
     ac0:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
     ac2:	0685                	addi	a3,a3,1
     ac4:	0025179b          	slliw	a5,a0,0x2
     ac8:	9fa9                	addw	a5,a5,a0
     aca:	0017979b          	slliw	a5,a5,0x1
     ace:	9fb1                	addw	a5,a5,a2
     ad0:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
     ad4:	0006c603          	lbu	a2,0(a3)
     ad8:	fd06071b          	addiw	a4,a2,-48
     adc:	0ff77713          	zext.b	a4,a4
     ae0:	fee5f1e3          	bgeu	a1,a4,ac2 <atoi+0x1e>
  return n;
}
     ae4:	6422                	ld	s0,8(sp)
     ae6:	0141                	addi	sp,sp,16
     ae8:	8082                	ret
  n = 0;
     aea:	4501                	li	a0,0
     aec:	bfe5                	j	ae4 <atoi+0x40>

0000000000000aee <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     aee:	1141                	addi	sp,sp,-16
     af0:	e422                	sd	s0,8(sp)
     af2:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     af4:	02b57463          	bgeu	a0,a1,b1c <memmove+0x2e>
    while(n-- > 0)
     af8:	00c05f63          	blez	a2,b16 <memmove+0x28>
     afc:	1602                	slli	a2,a2,0x20
     afe:	9201                	srli	a2,a2,0x20
     b00:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     b04:	872a                	mv	a4,a0
      *dst++ = *src++;
     b06:	0585                	addi	a1,a1,1
     b08:	0705                	addi	a4,a4,1
     b0a:	fff5c683          	lbu	a3,-1(a1)
     b0e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
     b12:	fee79ae3          	bne	a5,a4,b06 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     b16:	6422                	ld	s0,8(sp)
     b18:	0141                	addi	sp,sp,16
     b1a:	8082                	ret
    dst += n;
     b1c:	00c50733          	add	a4,a0,a2
    src += n;
     b20:	95b2                	add	a1,a1,a2
    while(n-- > 0)
     b22:	fec05ae3          	blez	a2,b16 <memmove+0x28>
     b26:	fff6079b          	addiw	a5,a2,-1
     b2a:	1782                	slli	a5,a5,0x20
     b2c:	9381                	srli	a5,a5,0x20
     b2e:	fff7c793          	not	a5,a5
     b32:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     b34:	15fd                	addi	a1,a1,-1
     b36:	177d                	addi	a4,a4,-1
     b38:	0005c683          	lbu	a3,0(a1)
     b3c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
     b40:	fee79ae3          	bne	a5,a4,b34 <memmove+0x46>
     b44:	bfc9                	j	b16 <memmove+0x28>

0000000000000b46 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     b46:	1141                	addi	sp,sp,-16
     b48:	e422                	sd	s0,8(sp)
     b4a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     b4c:	ca05                	beqz	a2,b7c <memcmp+0x36>
     b4e:	fff6069b          	addiw	a3,a2,-1
     b52:	1682                	slli	a3,a3,0x20
     b54:	9281                	srli	a3,a3,0x20
     b56:	0685                	addi	a3,a3,1
     b58:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
     b5a:	00054783          	lbu	a5,0(a0)
     b5e:	0005c703          	lbu	a4,0(a1)
     b62:	00e79863          	bne	a5,a4,b72 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
     b66:	0505                	addi	a0,a0,1
    p2++;
     b68:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     b6a:	fed518e3          	bne	a0,a3,b5a <memcmp+0x14>
  }
  return 0;
     b6e:	4501                	li	a0,0
     b70:	a019                	j	b76 <memcmp+0x30>
      return *p1 - *p2;
     b72:	40e7853b          	subw	a0,a5,a4
}
     b76:	6422                	ld	s0,8(sp)
     b78:	0141                	addi	sp,sp,16
     b7a:	8082                	ret
  return 0;
     b7c:	4501                	li	a0,0
     b7e:	bfe5                	j	b76 <memcmp+0x30>

0000000000000b80 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     b80:	1141                	addi	sp,sp,-16
     b82:	e406                	sd	ra,8(sp)
     b84:	e022                	sd	s0,0(sp)
     b86:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     b88:	f67ff0ef          	jal	ra,aee <memmove>
}
     b8c:	60a2                	ld	ra,8(sp)
     b8e:	6402                	ld	s0,0(sp)
     b90:	0141                	addi	sp,sp,16
     b92:	8082                	ret

0000000000000b94 <ugetpid>:

#ifdef LAB_PGTBL
int
ugetpid(void)
{
     b94:	1141                	addi	sp,sp,-16
     b96:	e422                	sd	s0,8(sp)
     b98:	0800                	addi	s0,sp,16
  struct usyscall *u = (struct usyscall *)USYSCALL;
  return u->pid;
     b9a:	040007b7          	lui	a5,0x4000
}
     b9e:	17f5                	addi	a5,a5,-3
     ba0:	07b2                	slli	a5,a5,0xc
     ba2:	4388                	lw	a0,0(a5)
     ba4:	6422                	ld	s0,8(sp)
     ba6:	0141                	addi	sp,sp,16
     ba8:	8082                	ret

0000000000000baa <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     baa:	4885                	li	a7,1
 ecall
     bac:	00000073          	ecall
 ret
     bb0:	8082                	ret

0000000000000bb2 <exit>:
.global exit
exit:
 li a7, SYS_exit
     bb2:	4889                	li	a7,2
 ecall
     bb4:	00000073          	ecall
 ret
     bb8:	8082                	ret

0000000000000bba <wait>:
.global wait
wait:
 li a7, SYS_wait
     bba:	488d                	li	a7,3
 ecall
     bbc:	00000073          	ecall
 ret
     bc0:	8082                	ret

0000000000000bc2 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     bc2:	4891                	li	a7,4
 ecall
     bc4:	00000073          	ecall
 ret
     bc8:	8082                	ret

0000000000000bca <read>:
.global read
read:
 li a7, SYS_read
     bca:	4895                	li	a7,5
 ecall
     bcc:	00000073          	ecall
 ret
     bd0:	8082                	ret

0000000000000bd2 <write>:
.global write
write:
 li a7, SYS_write
     bd2:	48c1                	li	a7,16
 ecall
     bd4:	00000073          	ecall
 ret
     bd8:	8082                	ret

0000000000000bda <close>:
.global close
close:
 li a7, SYS_close
     bda:	48d5                	li	a7,21
 ecall
     bdc:	00000073          	ecall
 ret
     be0:	8082                	ret

0000000000000be2 <kill>:
.global kill
kill:
 li a7, SYS_kill
     be2:	4899                	li	a7,6
 ecall
     be4:	00000073          	ecall
 ret
     be8:	8082                	ret

0000000000000bea <exec>:
.global exec
exec:
 li a7, SYS_exec
     bea:	489d                	li	a7,7
 ecall
     bec:	00000073          	ecall
 ret
     bf0:	8082                	ret

0000000000000bf2 <open>:
.global open
open:
 li a7, SYS_open
     bf2:	48bd                	li	a7,15
 ecall
     bf4:	00000073          	ecall
 ret
     bf8:	8082                	ret

0000000000000bfa <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     bfa:	48c5                	li	a7,17
 ecall
     bfc:	00000073          	ecall
 ret
     c00:	8082                	ret

0000000000000c02 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     c02:	48c9                	li	a7,18
 ecall
     c04:	00000073          	ecall
 ret
     c08:	8082                	ret

0000000000000c0a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     c0a:	48a1                	li	a7,8
 ecall
     c0c:	00000073          	ecall
 ret
     c10:	8082                	ret

0000000000000c12 <link>:
.global link
link:
 li a7, SYS_link
     c12:	48cd                	li	a7,19
 ecall
     c14:	00000073          	ecall
 ret
     c18:	8082                	ret

0000000000000c1a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     c1a:	48d1                	li	a7,20
 ecall
     c1c:	00000073          	ecall
 ret
     c20:	8082                	ret

0000000000000c22 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     c22:	48a5                	li	a7,9
 ecall
     c24:	00000073          	ecall
 ret
     c28:	8082                	ret

0000000000000c2a <dup>:
.global dup
dup:
 li a7, SYS_dup
     c2a:	48a9                	li	a7,10
 ecall
     c2c:	00000073          	ecall
 ret
     c30:	8082                	ret

0000000000000c32 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     c32:	48ad                	li	a7,11
 ecall
     c34:	00000073          	ecall
 ret
     c38:	8082                	ret

0000000000000c3a <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
     c3a:	48b1                	li	a7,12
 ecall
     c3c:	00000073          	ecall
 ret
     c40:	8082                	ret

0000000000000c42 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
     c42:	48b5                	li	a7,13
 ecall
     c44:	00000073          	ecall
 ret
     c48:	8082                	ret

0000000000000c4a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
     c4a:	48b9                	li	a7,14
 ecall
     c4c:	00000073          	ecall
 ret
     c50:	8082                	ret

0000000000000c52 <bind>:
.global bind
bind:
 li a7, SYS_bind
     c52:	48f5                	li	a7,29
 ecall
     c54:	00000073          	ecall
 ret
     c58:	8082                	ret

0000000000000c5a <unbind>:
.global unbind
unbind:
 li a7, SYS_unbind
     c5a:	48f9                	li	a7,30
 ecall
     c5c:	00000073          	ecall
 ret
     c60:	8082                	ret

0000000000000c62 <send>:
.global send
send:
 li a7, SYS_send
     c62:	48fd                	li	a7,31
 ecall
     c64:	00000073          	ecall
 ret
     c68:	8082                	ret

0000000000000c6a <recv>:
.global recv
recv:
 li a7, SYS_recv
     c6a:	02000893          	li	a7,32
 ecall
     c6e:	00000073          	ecall
 ret
     c72:	8082                	ret

0000000000000c74 <pgpte>:
.global pgpte
pgpte:
 li a7, SYS_pgpte
     c74:	02100893          	li	a7,33
 ecall
     c78:	00000073          	ecall
 ret
     c7c:	8082                	ret

0000000000000c7e <kpgtbl>:
.global kpgtbl
kpgtbl:
 li a7, SYS_kpgtbl
     c7e:	02200893          	li	a7,34
 ecall
     c82:	00000073          	ecall
 ret
     c86:	8082                	ret

0000000000000c88 <pgaccess>:
.global pgaccess
pgaccess:
 li a7, SYS_pgaccess
     c88:	02300893          	li	a7,35
 ecall
     c8c:	00000073          	ecall
 ret
     c90:	8082                	ret

0000000000000c92 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
     c92:	1101                	addi	sp,sp,-32
     c94:	ec06                	sd	ra,24(sp)
     c96:	e822                	sd	s0,16(sp)
     c98:	1000                	addi	s0,sp,32
     c9a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
     c9e:	4605                	li	a2,1
     ca0:	fef40593          	addi	a1,s0,-17
     ca4:	f2fff0ef          	jal	ra,bd2 <write>
}
     ca8:	60e2                	ld	ra,24(sp)
     caa:	6442                	ld	s0,16(sp)
     cac:	6105                	addi	sp,sp,32
     cae:	8082                	ret

0000000000000cb0 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
     cb0:	7139                	addi	sp,sp,-64
     cb2:	fc06                	sd	ra,56(sp)
     cb4:	f822                	sd	s0,48(sp)
     cb6:	f426                	sd	s1,40(sp)
     cb8:	f04a                	sd	s2,32(sp)
     cba:	ec4e                	sd	s3,24(sp)
     cbc:	0080                	addi	s0,sp,64
     cbe:	84aa                	mv	s1,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     cc0:	c299                	beqz	a3,cc6 <printint+0x16>
     cc2:	0805c663          	bltz	a1,d4e <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
     cc6:	2581                	sext.w	a1,a1
  neg = 0;
     cc8:	4881                	li	a7,0
     cca:	fc040693          	addi	a3,s0,-64
  }

  i = 0;
     cce:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
     cd0:	2601                	sext.w	a2,a2
     cd2:	00000517          	auipc	a0,0x0
     cd6:	7be50513          	addi	a0,a0,1982 # 1490 <digits>
     cda:	883a                	mv	a6,a4
     cdc:	2705                	addiw	a4,a4,1
     cde:	02c5f7bb          	remuw	a5,a1,a2
     ce2:	1782                	slli	a5,a5,0x20
     ce4:	9381                	srli	a5,a5,0x20
     ce6:	97aa                	add	a5,a5,a0
     ce8:	0007c783          	lbu	a5,0(a5) # 4000000 <base+0x3ffdbf8>
     cec:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
     cf0:	0005879b          	sext.w	a5,a1
     cf4:	02c5d5bb          	divuw	a1,a1,a2
     cf8:	0685                	addi	a3,a3,1
     cfa:	fec7f0e3          	bgeu	a5,a2,cda <printint+0x2a>
  if(neg)
     cfe:	00088b63          	beqz	a7,d14 <printint+0x64>
    buf[i++] = '-';
     d02:	fd040793          	addi	a5,s0,-48
     d06:	973e                	add	a4,a4,a5
     d08:	02d00793          	li	a5,45
     d0c:	fef70823          	sb	a5,-16(a4)
     d10:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
     d14:	02e05663          	blez	a4,d40 <printint+0x90>
     d18:	fc040793          	addi	a5,s0,-64
     d1c:	00e78933          	add	s2,a5,a4
     d20:	fff78993          	addi	s3,a5,-1
     d24:	99ba                	add	s3,s3,a4
     d26:	377d                	addiw	a4,a4,-1
     d28:	1702                	slli	a4,a4,0x20
     d2a:	9301                	srli	a4,a4,0x20
     d2c:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
     d30:	fff94583          	lbu	a1,-1(s2)
     d34:	8526                	mv	a0,s1
     d36:	f5dff0ef          	jal	ra,c92 <putc>
  while(--i >= 0)
     d3a:	197d                	addi	s2,s2,-1
     d3c:	ff391ae3          	bne	s2,s3,d30 <printint+0x80>
}
     d40:	70e2                	ld	ra,56(sp)
     d42:	7442                	ld	s0,48(sp)
     d44:	74a2                	ld	s1,40(sp)
     d46:	7902                	ld	s2,32(sp)
     d48:	69e2                	ld	s3,24(sp)
     d4a:	6121                	addi	sp,sp,64
     d4c:	8082                	ret
    x = -xx;
     d4e:	40b005bb          	negw	a1,a1
    neg = 1;
     d52:	4885                	li	a7,1
    x = -xx;
     d54:	bf9d                	j	cca <printint+0x1a>

0000000000000d56 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
     d56:	7119                	addi	sp,sp,-128
     d58:	fc86                	sd	ra,120(sp)
     d5a:	f8a2                	sd	s0,112(sp)
     d5c:	f4a6                	sd	s1,104(sp)
     d5e:	f0ca                	sd	s2,96(sp)
     d60:	ecce                	sd	s3,88(sp)
     d62:	e8d2                	sd	s4,80(sp)
     d64:	e4d6                	sd	s5,72(sp)
     d66:	e0da                	sd	s6,64(sp)
     d68:	fc5e                	sd	s7,56(sp)
     d6a:	f862                	sd	s8,48(sp)
     d6c:	f466                	sd	s9,40(sp)
     d6e:	f06a                	sd	s10,32(sp)
     d70:	ec6e                	sd	s11,24(sp)
     d72:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
     d74:	0005c903          	lbu	s2,0(a1)
     d78:	22090e63          	beqz	s2,fb4 <vprintf+0x25e>
     d7c:	8b2a                	mv	s6,a0
     d7e:	8a2e                	mv	s4,a1
     d80:	8bb2                	mv	s7,a2
  state = 0;
     d82:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
     d84:	4481                	li	s1,0
     d86:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
     d88:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
     d8c:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
     d90:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
     d94:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     d98:	00000c97          	auipc	s9,0x0
     d9c:	6f8c8c93          	addi	s9,s9,1784 # 1490 <digits>
     da0:	a005                	j	dc0 <vprintf+0x6a>
        putc(fd, c0);
     da2:	85ca                	mv	a1,s2
     da4:	855a                	mv	a0,s6
     da6:	eedff0ef          	jal	ra,c92 <putc>
     daa:	a019                	j	db0 <vprintf+0x5a>
    } else if(state == '%'){
     dac:	03598263          	beq	s3,s5,dd0 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
     db0:	2485                	addiw	s1,s1,1
     db2:	8726                	mv	a4,s1
     db4:	009a07b3          	add	a5,s4,s1
     db8:	0007c903          	lbu	s2,0(a5)
     dbc:	1e090c63          	beqz	s2,fb4 <vprintf+0x25e>
    c0 = fmt[i] & 0xff;
     dc0:	0009079b          	sext.w	a5,s2
    if(state == 0){
     dc4:	fe0994e3          	bnez	s3,dac <vprintf+0x56>
      if(c0 == '%'){
     dc8:	fd579de3          	bne	a5,s5,da2 <vprintf+0x4c>
        state = '%';
     dcc:	89be                	mv	s3,a5
     dce:	b7cd                	j	db0 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
     dd0:	cfa5                	beqz	a5,e48 <vprintf+0xf2>
     dd2:	00ea06b3          	add	a3,s4,a4
     dd6:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
     dda:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
     ddc:	c681                	beqz	a3,de4 <vprintf+0x8e>
     dde:	9752                	add	a4,a4,s4
     de0:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
     de4:	03878a63          	beq	a5,s8,e18 <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
     de8:	05a78463          	beq	a5,s10,e30 <vprintf+0xda>
      } else if(c0 == 'u'){
     dec:	0db78763          	beq	a5,s11,eba <vprintf+0x164>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
     df0:	07800713          	li	a4,120
     df4:	10e78963          	beq	a5,a4,f06 <vprintf+0x1b0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
     df8:	07000713          	li	a4,112
     dfc:	12e78e63          	beq	a5,a4,f38 <vprintf+0x1e2>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
     e00:	07300713          	li	a4,115
     e04:	16e78b63          	beq	a5,a4,f7a <vprintf+0x224>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
     e08:	05579063          	bne	a5,s5,e48 <vprintf+0xf2>
        putc(fd, '%');
     e0c:	85d6                	mv	a1,s5
     e0e:	855a                	mv	a0,s6
     e10:	e83ff0ef          	jal	ra,c92 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
     e14:	4981                	li	s3,0
     e16:	bf69                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
     e18:	008b8913          	addi	s2,s7,8
     e1c:	4685                	li	a3,1
     e1e:	4629                	li	a2,10
     e20:	000ba583          	lw	a1,0(s7)
     e24:	855a                	mv	a0,s6
     e26:	e8bff0ef          	jal	ra,cb0 <printint>
     e2a:	8bca                	mv	s7,s2
      state = 0;
     e2c:	4981                	li	s3,0
     e2e:	b749                	j	db0 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
     e30:	03868663          	beq	a3,s8,e5c <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     e34:	05a68163          	beq	a3,s10,e76 <vprintf+0x120>
      } else if(c0 == 'l' && c1 == 'u'){
     e38:	09b68d63          	beq	a3,s11,ed2 <vprintf+0x17c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
     e3c:	03a68f63          	beq	a3,s10,e7a <vprintf+0x124>
      } else if(c0 == 'l' && c1 == 'x'){
     e40:	07800793          	li	a5,120
     e44:	0cf68d63          	beq	a3,a5,f1e <vprintf+0x1c8>
        putc(fd, '%');
     e48:	85d6                	mv	a1,s5
     e4a:	855a                	mv	a0,s6
     e4c:	e47ff0ef          	jal	ra,c92 <putc>
        putc(fd, c0);
     e50:	85ca                	mv	a1,s2
     e52:	855a                	mv	a0,s6
     e54:	e3fff0ef          	jal	ra,c92 <putc>
      state = 0;
     e58:	4981                	li	s3,0
     e5a:	bf99                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
     e5c:	008b8913          	addi	s2,s7,8
     e60:	4685                	li	a3,1
     e62:	4629                	li	a2,10
     e64:	000ba583          	lw	a1,0(s7)
     e68:	855a                	mv	a0,s6
     e6a:	e47ff0ef          	jal	ra,cb0 <printint>
        i += 1;
     e6e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
     e70:	8bca                	mv	s7,s2
      state = 0;
     e72:	4981                	li	s3,0
        i += 1;
     e74:	bf35                	j	db0 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     e76:	03860563          	beq	a2,s8,ea0 <vprintf+0x14a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
     e7a:	07b60963          	beq	a2,s11,eec <vprintf+0x196>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
     e7e:	07800793          	li	a5,120
     e82:	fcf613e3          	bne	a2,a5,e48 <vprintf+0xf2>
        printint(fd, va_arg(ap, uint64), 16, 0);
     e86:	008b8913          	addi	s2,s7,8
     e8a:	4681                	li	a3,0
     e8c:	4641                	li	a2,16
     e8e:	000ba583          	lw	a1,0(s7)
     e92:	855a                	mv	a0,s6
     e94:	e1dff0ef          	jal	ra,cb0 <printint>
        i += 2;
     e98:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
     e9a:	8bca                	mv	s7,s2
      state = 0;
     e9c:	4981                	li	s3,0
        i += 2;
     e9e:	bf09                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
     ea0:	008b8913          	addi	s2,s7,8
     ea4:	4685                	li	a3,1
     ea6:	4629                	li	a2,10
     ea8:	000ba583          	lw	a1,0(s7)
     eac:	855a                	mv	a0,s6
     eae:	e03ff0ef          	jal	ra,cb0 <printint>
        i += 2;
     eb2:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
     eb4:	8bca                	mv	s7,s2
      state = 0;
     eb6:	4981                	li	s3,0
        i += 2;
     eb8:	bde5                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 0);
     eba:	008b8913          	addi	s2,s7,8
     ebe:	4681                	li	a3,0
     ec0:	4629                	li	a2,10
     ec2:	000ba583          	lw	a1,0(s7)
     ec6:	855a                	mv	a0,s6
     ec8:	de9ff0ef          	jal	ra,cb0 <printint>
     ecc:	8bca                	mv	s7,s2
      state = 0;
     ece:	4981                	li	s3,0
     ed0:	b5c5                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
     ed2:	008b8913          	addi	s2,s7,8
     ed6:	4681                	li	a3,0
     ed8:	4629                	li	a2,10
     eda:	000ba583          	lw	a1,0(s7)
     ede:	855a                	mv	a0,s6
     ee0:	dd1ff0ef          	jal	ra,cb0 <printint>
        i += 1;
     ee4:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
     ee6:	8bca                	mv	s7,s2
      state = 0;
     ee8:	4981                	li	s3,0
        i += 1;
     eea:	b5d9                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
     eec:	008b8913          	addi	s2,s7,8
     ef0:	4681                	li	a3,0
     ef2:	4629                	li	a2,10
     ef4:	000ba583          	lw	a1,0(s7)
     ef8:	855a                	mv	a0,s6
     efa:	db7ff0ef          	jal	ra,cb0 <printint>
        i += 2;
     efe:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
     f00:	8bca                	mv	s7,s2
      state = 0;
     f02:	4981                	li	s3,0
        i += 2;
     f04:	b575                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 16, 0);
     f06:	008b8913          	addi	s2,s7,8
     f0a:	4681                	li	a3,0
     f0c:	4641                	li	a2,16
     f0e:	000ba583          	lw	a1,0(s7)
     f12:	855a                	mv	a0,s6
     f14:	d9dff0ef          	jal	ra,cb0 <printint>
     f18:	8bca                	mv	s7,s2
      state = 0;
     f1a:	4981                	li	s3,0
     f1c:	bd51                	j	db0 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f1e:	008b8913          	addi	s2,s7,8
     f22:	4681                	li	a3,0
     f24:	4641                	li	a2,16
     f26:	000ba583          	lw	a1,0(s7)
     f2a:	855a                	mv	a0,s6
     f2c:	d85ff0ef          	jal	ra,cb0 <printint>
        i += 1;
     f30:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
     f32:	8bca                	mv	s7,s2
      state = 0;
     f34:	4981                	li	s3,0
        i += 1;
     f36:	bdad                	j	db0 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
     f38:	008b8793          	addi	a5,s7,8
     f3c:	f8f43423          	sd	a5,-120(s0)
     f40:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
     f44:	03000593          	li	a1,48
     f48:	855a                	mv	a0,s6
     f4a:	d49ff0ef          	jal	ra,c92 <putc>
  putc(fd, 'x');
     f4e:	07800593          	li	a1,120
     f52:	855a                	mv	a0,s6
     f54:	d3fff0ef          	jal	ra,c92 <putc>
     f58:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     f5a:	03c9d793          	srli	a5,s3,0x3c
     f5e:	97e6                	add	a5,a5,s9
     f60:	0007c583          	lbu	a1,0(a5)
     f64:	855a                	mv	a0,s6
     f66:	d2dff0ef          	jal	ra,c92 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     f6a:	0992                	slli	s3,s3,0x4
     f6c:	397d                	addiw	s2,s2,-1
     f6e:	fe0916e3          	bnez	s2,f5a <vprintf+0x204>
        printptr(fd, va_arg(ap, uint64));
     f72:	f8843b83          	ld	s7,-120(s0)
      state = 0;
     f76:	4981                	li	s3,0
     f78:	bd25                	j	db0 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
     f7a:	008b8993          	addi	s3,s7,8
     f7e:	000bb903          	ld	s2,0(s7)
     f82:	00090f63          	beqz	s2,fa0 <vprintf+0x24a>
        for(; *s; s++)
     f86:	00094583          	lbu	a1,0(s2)
     f8a:	c195                	beqz	a1,fae <vprintf+0x258>
          putc(fd, *s);
     f8c:	855a                	mv	a0,s6
     f8e:	d05ff0ef          	jal	ra,c92 <putc>
        for(; *s; s++)
     f92:	0905                	addi	s2,s2,1
     f94:	00094583          	lbu	a1,0(s2)
     f98:	f9f5                	bnez	a1,f8c <vprintf+0x236>
        if((s = va_arg(ap, char*)) == 0)
     f9a:	8bce                	mv	s7,s3
      state = 0;
     f9c:	4981                	li	s3,0
     f9e:	bd09                	j	db0 <vprintf+0x5a>
          s = "(null)";
     fa0:	00000917          	auipc	s2,0x0
     fa4:	4e890913          	addi	s2,s2,1256 # 1488 <malloc+0x3d2>
        for(; *s; s++)
     fa8:	02800593          	li	a1,40
     fac:	b7c5                	j	f8c <vprintf+0x236>
        if((s = va_arg(ap, char*)) == 0)
     fae:	8bce                	mv	s7,s3
      state = 0;
     fb0:	4981                	li	s3,0
     fb2:	bbfd                	j	db0 <vprintf+0x5a>
    }
  }
}
     fb4:	70e6                	ld	ra,120(sp)
     fb6:	7446                	ld	s0,112(sp)
     fb8:	74a6                	ld	s1,104(sp)
     fba:	7906                	ld	s2,96(sp)
     fbc:	69e6                	ld	s3,88(sp)
     fbe:	6a46                	ld	s4,80(sp)
     fc0:	6aa6                	ld	s5,72(sp)
     fc2:	6b06                	ld	s6,64(sp)
     fc4:	7be2                	ld	s7,56(sp)
     fc6:	7c42                	ld	s8,48(sp)
     fc8:	7ca2                	ld	s9,40(sp)
     fca:	7d02                	ld	s10,32(sp)
     fcc:	6de2                	ld	s11,24(sp)
     fce:	6109                	addi	sp,sp,128
     fd0:	8082                	ret

0000000000000fd2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
     fd2:	715d                	addi	sp,sp,-80
     fd4:	ec06                	sd	ra,24(sp)
     fd6:	e822                	sd	s0,16(sp)
     fd8:	1000                	addi	s0,sp,32
     fda:	e010                	sd	a2,0(s0)
     fdc:	e414                	sd	a3,8(s0)
     fde:	e818                	sd	a4,16(s0)
     fe0:	ec1c                	sd	a5,24(s0)
     fe2:	03043023          	sd	a6,32(s0)
     fe6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
     fea:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
     fee:	8622                	mv	a2,s0
     ff0:	d67ff0ef          	jal	ra,d56 <vprintf>
}
     ff4:	60e2                	ld	ra,24(sp)
     ff6:	6442                	ld	s0,16(sp)
     ff8:	6161                	addi	sp,sp,80
     ffa:	8082                	ret

0000000000000ffc <printf>:

void
printf(const char *fmt, ...)
{
     ffc:	711d                	addi	sp,sp,-96
     ffe:	ec06                	sd	ra,24(sp)
    1000:	e822                	sd	s0,16(sp)
    1002:	1000                	addi	s0,sp,32
    1004:	e40c                	sd	a1,8(s0)
    1006:	e810                	sd	a2,16(s0)
    1008:	ec14                	sd	a3,24(s0)
    100a:	f018                	sd	a4,32(s0)
    100c:	f41c                	sd	a5,40(s0)
    100e:	03043823          	sd	a6,48(s0)
    1012:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    1016:	00840613          	addi	a2,s0,8
    101a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    101e:	85aa                	mv	a1,a0
    1020:	4505                	li	a0,1
    1022:	d35ff0ef          	jal	ra,d56 <vprintf>
}
    1026:	60e2                	ld	ra,24(sp)
    1028:	6442                	ld	s0,16(sp)
    102a:	6125                	addi	sp,sp,96
    102c:	8082                	ret

000000000000102e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    102e:	1141                	addi	sp,sp,-16
    1030:	e422                	sd	s0,8(sp)
    1032:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    1034:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1038:	00001797          	auipc	a5,0x1
    103c:	fd87b783          	ld	a5,-40(a5) # 2010 <freep>
    1040:	a805                	j	1070 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
    1042:	4618                	lw	a4,8(a2)
    1044:	9db9                	addw	a1,a1,a4
    1046:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    104a:	6398                	ld	a4,0(a5)
    104c:	6318                	ld	a4,0(a4)
    104e:	fee53823          	sd	a4,-16(a0)
    1052:	a091                	j	1096 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
    1054:	ff852703          	lw	a4,-8(a0)
    1058:	9e39                	addw	a2,a2,a4
    105a:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
    105c:	ff053703          	ld	a4,-16(a0)
    1060:	e398                	sd	a4,0(a5)
    1062:	a099                	j	10a8 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1064:	6398                	ld	a4,0(a5)
    1066:	00e7e463          	bltu	a5,a4,106e <free+0x40>
    106a:	00e6ea63          	bltu	a3,a4,107e <free+0x50>
{
    106e:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1070:	fed7fae3          	bgeu	a5,a3,1064 <free+0x36>
    1074:	6398                	ld	a4,0(a5)
    1076:	00e6e463          	bltu	a3,a4,107e <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    107a:	fee7eae3          	bltu	a5,a4,106e <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
    107e:	ff852583          	lw	a1,-8(a0)
    1082:	6390                	ld	a2,0(a5)
    1084:	02059813          	slli	a6,a1,0x20
    1088:	01c85713          	srli	a4,a6,0x1c
    108c:	9736                	add	a4,a4,a3
    108e:	fae60ae3          	beq	a2,a4,1042 <free+0x14>
    bp->s.ptr = p->s.ptr;
    1092:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
    1096:	4790                	lw	a2,8(a5)
    1098:	02061593          	slli	a1,a2,0x20
    109c:	01c5d713          	srli	a4,a1,0x1c
    10a0:	973e                	add	a4,a4,a5
    10a2:	fae689e3          	beq	a3,a4,1054 <free+0x26>
  } else
    p->s.ptr = bp;
    10a6:	e394                	sd	a3,0(a5)
  freep = p;
    10a8:	00001717          	auipc	a4,0x1
    10ac:	f6f73423          	sd	a5,-152(a4) # 2010 <freep>
}
    10b0:	6422                	ld	s0,8(sp)
    10b2:	0141                	addi	sp,sp,16
    10b4:	8082                	ret

00000000000010b6 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    10b6:	7139                	addi	sp,sp,-64
    10b8:	fc06                	sd	ra,56(sp)
    10ba:	f822                	sd	s0,48(sp)
    10bc:	f426                	sd	s1,40(sp)
    10be:	f04a                	sd	s2,32(sp)
    10c0:	ec4e                	sd	s3,24(sp)
    10c2:	e852                	sd	s4,16(sp)
    10c4:	e456                	sd	s5,8(sp)
    10c6:	e05a                	sd	s6,0(sp)
    10c8:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    10ca:	02051493          	slli	s1,a0,0x20
    10ce:	9081                	srli	s1,s1,0x20
    10d0:	04bd                	addi	s1,s1,15
    10d2:	8091                	srli	s1,s1,0x4
    10d4:	0014899b          	addiw	s3,s1,1
    10d8:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
    10da:	00001517          	auipc	a0,0x1
    10de:	f3653503          	ld	a0,-202(a0) # 2010 <freep>
    10e2:	c515                	beqz	a0,110e <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    10e4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    10e6:	4798                	lw	a4,8(a5)
    10e8:	02977f63          	bgeu	a4,s1,1126 <malloc+0x70>
    10ec:	8a4e                	mv	s4,s3
    10ee:	0009871b          	sext.w	a4,s3
    10f2:	6685                	lui	a3,0x1
    10f4:	00d77363          	bgeu	a4,a3,10fa <malloc+0x44>
    10f8:	6a05                	lui	s4,0x1
    10fa:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    10fe:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    1102:	00001917          	auipc	s2,0x1
    1106:	f0e90913          	addi	s2,s2,-242 # 2010 <freep>
  if(p == (char*)-1)
    110a:	5afd                	li	s5,-1
    110c:	a885                	j	117c <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
    110e:	00001797          	auipc	a5,0x1
    1112:	2fa78793          	addi	a5,a5,762 # 2408 <base>
    1116:	00001717          	auipc	a4,0x1
    111a:	eef73d23          	sd	a5,-262(a4) # 2010 <freep>
    111e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    1120:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    1124:	b7e1                	j	10ec <malloc+0x36>
      if(p->s.size == nunits)
    1126:	02e48c63          	beq	s1,a4,115e <malloc+0xa8>
        p->s.size -= nunits;
    112a:	4137073b          	subw	a4,a4,s3
    112e:	c798                	sw	a4,8(a5)
        p += p->s.size;
    1130:	02071693          	slli	a3,a4,0x20
    1134:	01c6d713          	srli	a4,a3,0x1c
    1138:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    113a:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    113e:	00001717          	auipc	a4,0x1
    1142:	eca73923          	sd	a0,-302(a4) # 2010 <freep>
      return (void*)(p + 1);
    1146:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
    114a:	70e2                	ld	ra,56(sp)
    114c:	7442                	ld	s0,48(sp)
    114e:	74a2                	ld	s1,40(sp)
    1150:	7902                	ld	s2,32(sp)
    1152:	69e2                	ld	s3,24(sp)
    1154:	6a42                	ld	s4,16(sp)
    1156:	6aa2                	ld	s5,8(sp)
    1158:	6b02                	ld	s6,0(sp)
    115a:	6121                	addi	sp,sp,64
    115c:	8082                	ret
        prevp->s.ptr = p->s.ptr;
    115e:	6398                	ld	a4,0(a5)
    1160:	e118                	sd	a4,0(a0)
    1162:	bff1                	j	113e <malloc+0x88>
  hp->s.size = nu;
    1164:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    1168:	0541                	addi	a0,a0,16
    116a:	ec5ff0ef          	jal	ra,102e <free>
  return freep;
    116e:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
    1172:	dd61                	beqz	a0,114a <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1174:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    1176:	4798                	lw	a4,8(a5)
    1178:	fa9777e3          	bgeu	a4,s1,1126 <malloc+0x70>
    if(p == freep)
    117c:	00093703          	ld	a4,0(s2)
    1180:	853e                	mv	a0,a5
    1182:	fef719e3          	bne	a4,a5,1174 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
    1186:	8552                	mv	a0,s4
    1188:	ab3ff0ef          	jal	ra,c3a <sbrk>
  if(p == (char*)-1)
    118c:	fd551ce3          	bne	a0,s5,1164 <malloc+0xae>
        return 0;
    1190:	4501                	li	a0,0
    1192:	bf65                	j	114a <malloc+0x94>
