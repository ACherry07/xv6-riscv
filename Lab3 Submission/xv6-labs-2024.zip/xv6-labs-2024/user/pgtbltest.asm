
user/_pgtbltest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <err>:

char *testname = "???";

void
err(char *why)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	e04a                	sd	s2,0(sp)
   a:	1000                	addi	s0,sp,32
   c:	84aa                	mv	s1,a0
  printf("pgtbltest: %s failed: %s, pid=%d\n", testname, why, getpid());
   e:	00001917          	auipc	s2,0x1
  12:	ff293903          	ld	s2,-14(s2) # 1000 <testname>
  16:	67e000ef          	jal	ra,694 <getpid>
  1a:	86aa                	mv	a3,a0
  1c:	8626                	mv	a2,s1
  1e:	85ca                	mv	a1,s2
  20:	00001517          	auipc	a0,0x1
  24:	be050513          	addi	a0,a0,-1056 # c00 <malloc+0xe8>
  28:	237000ef          	jal	ra,a5e <printf>
  exit(1);
  2c:	4505                	li	a0,1
  2e:	5e6000ef          	jal	ra,614 <exit>

0000000000000032 <pgaccess_test>:
}

// Page Table Lab - Q3
void
pgaccess_test()
{
  32:	7179                	addi	sp,sp,-48
  34:	f406                	sd	ra,40(sp)
  36:	f022                	sd	s0,32(sp)
  38:	ec26                	sd	s1,24(sp)
  3a:	1800                	addi	s0,sp,48
  char *buf;
  unsigned int abits;
  printf("pgaccess_test starting\n");
  3c:	00001517          	auipc	a0,0x1
  40:	bec50513          	addi	a0,a0,-1044 # c28 <malloc+0x110>
  44:	21b000ef          	jal	ra,a5e <printf>
  testname = "pgaccess_test";
  48:	00001797          	auipc	a5,0x1
  4c:	bf878793          	addi	a5,a5,-1032 # c40 <malloc+0x128>
  50:	00001717          	auipc	a4,0x1
  54:	faf73823          	sd	a5,-80(a4) # 1000 <testname>
  buf = malloc(32 * PGSIZE);
  58:	00020537          	lui	a0,0x20
  5c:	2bd000ef          	jal	ra,b18 <malloc>
  60:	84aa                	mv	s1,a0
  if (pgaccess(buf, 32, &abits) < 0)
  62:	fdc40613          	addi	a2,s0,-36
  66:	02000593          	li	a1,32
  6a:	680000ef          	jal	ra,6ea <pgaccess>
  6e:	06054563          	bltz	a0,d8 <pgaccess_test+0xa6>
    err("pgaccess failed");
  buf[PGSIZE * 1] += 1;
  72:	6785                	lui	a5,0x1
  74:	97a6                	add	a5,a5,s1
  76:	0007c703          	lbu	a4,0(a5) # 1000 <testname>
  7a:	2705                	addiw	a4,a4,1
  7c:	00e78023          	sb	a4,0(a5)
  buf[PGSIZE * 2] += 1;
  80:	6789                	lui	a5,0x2
  82:	97a6                	add	a5,a5,s1
  84:	0007c703          	lbu	a4,0(a5) # 2000 <base+0xfe0>
  88:	2705                	addiw	a4,a4,1
  8a:	00e78023          	sb	a4,0(a5)
  buf[PGSIZE * 30] += 1;
  8e:	67f9                	lui	a5,0x1e
  90:	97a6                	add	a5,a5,s1
  92:	0007c703          	lbu	a4,0(a5) # 1e000 <base+0x1cfe0>
  96:	2705                	addiw	a4,a4,1
  98:	00e78023          	sb	a4,0(a5)
  if (pgaccess(buf, 32, &abits) < 0)
  9c:	fdc40613          	addi	a2,s0,-36
  a0:	02000593          	li	a1,32
  a4:	8526                	mv	a0,s1
  a6:	644000ef          	jal	ra,6ea <pgaccess>
  aa:	02054d63          	bltz	a0,e4 <pgaccess_test+0xb2>
    err("pgaccess failed");
  if (abits != ((1 << 1) | (1 << 2) | (1 << 30)))
  ae:	fdc42703          	lw	a4,-36(s0)
  b2:	400007b7          	lui	a5,0x40000
  b6:	0799                	addi	a5,a5,6
  b8:	02f71c63          	bne	a4,a5,f0 <pgaccess_test+0xbe>
    err("incorrect access bits set");
  free(buf);
  bc:	8526                	mv	a0,s1
  be:	1d3000ef          	jal	ra,a90 <free>
  printf("pgaccess_test: OK\n");
  c2:	00001517          	auipc	a0,0x1
  c6:	bbe50513          	addi	a0,a0,-1090 # c80 <malloc+0x168>
  ca:	195000ef          	jal	ra,a5e <printf>
}
  ce:	70a2                	ld	ra,40(sp)
  d0:	7402                	ld	s0,32(sp)
  d2:	64e2                	ld	s1,24(sp)
  d4:	6145                	addi	sp,sp,48
  d6:	8082                	ret
    err("pgaccess failed");
  d8:	00001517          	auipc	a0,0x1
  dc:	b7850513          	addi	a0,a0,-1160 # c50 <malloc+0x138>
  e0:	f21ff0ef          	jal	ra,0 <err>
    err("pgaccess failed");
  e4:	00001517          	auipc	a0,0x1
  e8:	b6c50513          	addi	a0,a0,-1172 # c50 <malloc+0x138>
  ec:	f15ff0ef          	jal	ra,0 <err>
    err("incorrect access bits set");
  f0:	00001517          	auipc	a0,0x1
  f4:	b7050513          	addi	a0,a0,-1168 # c60 <malloc+0x148>
  f8:	f09ff0ef          	jal	ra,0 <err>

00000000000000fc <print_pte>:

void
print_pte(uint64 va)
{
  fc:	1101                	addi	sp,sp,-32
  fe:	ec06                	sd	ra,24(sp)
 100:	e822                	sd	s0,16(sp)
 102:	e426                	sd	s1,8(sp)
 104:	1000                	addi	s0,sp,32
 106:	84aa                	mv	s1,a0
    pte_t pte = (pte_t) pgpte((void *) va);
 108:	5ce000ef          	jal	ra,6d6 <pgpte>
 10c:	862a                	mv	a2,a0
    printf("va 0x%lx pte 0x%lx pa 0x%lx perm 0x%lx\n", va, pte, PTE2PA(pte), PTE_FLAGS(pte));
 10e:	00a55693          	srli	a3,a0,0xa
 112:	3ff57713          	andi	a4,a0,1023
 116:	06b2                	slli	a3,a3,0xc
 118:	85a6                	mv	a1,s1
 11a:	00001517          	auipc	a0,0x1
 11e:	b7e50513          	addi	a0,a0,-1154 # c98 <malloc+0x180>
 122:	13d000ef          	jal	ra,a5e <printf>
}
 126:	60e2                	ld	ra,24(sp)
 128:	6442                	ld	s0,16(sp)
 12a:	64a2                	ld	s1,8(sp)
 12c:	6105                	addi	sp,sp,32
 12e:	8082                	ret

0000000000000130 <print_pgtbl>:

void
print_pgtbl()
{
 130:	7179                	addi	sp,sp,-48
 132:	f406                	sd	ra,40(sp)
 134:	f022                	sd	s0,32(sp)
 136:	ec26                	sd	s1,24(sp)
 138:	e84a                	sd	s2,16(sp)
 13a:	e44e                	sd	s3,8(sp)
 13c:	1800                	addi	s0,sp,48
  printf("print_pgtbl starting\n");
 13e:	00001517          	auipc	a0,0x1
 142:	b8250513          	addi	a0,a0,-1150 # cc0 <malloc+0x1a8>
 146:	119000ef          	jal	ra,a5e <printf>
 14a:	4481                	li	s1,0
  for (uint64 i = 0; i < 10; i++) {
 14c:	6985                	lui	s3,0x1
 14e:	6929                	lui	s2,0xa
    print_pte(i * PGSIZE);
 150:	8526                	mv	a0,s1
 152:	fabff0ef          	jal	ra,fc <print_pte>
  for (uint64 i = 0; i < 10; i++) {
 156:	94ce                	add	s1,s1,s3
 158:	ff249ce3          	bne	s1,s2,150 <print_pgtbl+0x20>
 15c:	020004b7          	lui	s1,0x2000
 160:	14ed                	addi	s1,s1,-5
 162:	04b6                	slli	s1,s1,0xd
  }
  uint64 top = MAXVA/PGSIZE;
  for (uint64 i = top-10; i < top; i++) {
 164:	6985                	lui	s3,0x1
 166:	4905                	li	s2,1
 168:	191a                	slli	s2,s2,0x26
    print_pte(i * PGSIZE);
 16a:	8526                	mv	a0,s1
 16c:	f91ff0ef          	jal	ra,fc <print_pte>
  for (uint64 i = top-10; i < top; i++) {
 170:	94ce                	add	s1,s1,s3
 172:	ff249ce3          	bne	s1,s2,16a <print_pgtbl+0x3a>
  }
  printf("print_pgtbl: OK\n");
 176:	00001517          	auipc	a0,0x1
 17a:	b6250513          	addi	a0,a0,-1182 # cd8 <malloc+0x1c0>
 17e:	0e1000ef          	jal	ra,a5e <printf>
}
 182:	70a2                	ld	ra,40(sp)
 184:	7402                	ld	s0,32(sp)
 186:	64e2                	ld	s1,24(sp)
 188:	6942                	ld	s2,16(sp)
 18a:	69a2                	ld	s3,8(sp)
 18c:	6145                	addi	sp,sp,48
 18e:	8082                	ret

0000000000000190 <ugetpid_test>:

void
ugetpid_test()
{
 190:	7179                	addi	sp,sp,-48
 192:	f406                	sd	ra,40(sp)
 194:	f022                	sd	s0,32(sp)
 196:	ec26                	sd	s1,24(sp)
 198:	1800                	addi	s0,sp,48
  int i;

  printf("ugetpid_test starting\n");
 19a:	00001517          	auipc	a0,0x1
 19e:	b5650513          	addi	a0,a0,-1194 # cf0 <malloc+0x1d8>
 1a2:	0bd000ef          	jal	ra,a5e <printf>
  testname = "ugetpid_test";
 1a6:	00001797          	auipc	a5,0x1
 1aa:	b6278793          	addi	a5,a5,-1182 # d08 <malloc+0x1f0>
 1ae:	00001717          	auipc	a4,0x1
 1b2:	e4f73923          	sd	a5,-430(a4) # 1000 <testname>
 1b6:	04000493          	li	s1,64

  for (i = 0; i < 64; i++) {
    int ret = fork();
 1ba:	452000ef          	jal	ra,60c <fork>
 1be:	fca42e23          	sw	a0,-36(s0)
    if (ret != 0) {
 1c2:	c905                	beqz	a0,1f2 <ugetpid_test+0x62>
      wait(&ret);
 1c4:	fdc40513          	addi	a0,s0,-36
 1c8:	454000ef          	jal	ra,61c <wait>
      if (ret != 0)
 1cc:	fdc42783          	lw	a5,-36(s0)
 1d0:	ef91                	bnez	a5,1ec <ugetpid_test+0x5c>
  for (i = 0; i < 64; i++) {
 1d2:	34fd                	addiw	s1,s1,-1
 1d4:	f0fd                	bnez	s1,1ba <ugetpid_test+0x2a>
    }
    if (getpid() != ugetpid())
      err("missmatched PID");
    exit(0);
  }
  printf("ugetpid_test: OK\n");
 1d6:	00001517          	auipc	a0,0x1
 1da:	b5250513          	addi	a0,a0,-1198 # d28 <malloc+0x210>
 1de:	081000ef          	jal	ra,a5e <printf>
}
 1e2:	70a2                	ld	ra,40(sp)
 1e4:	7402                	ld	s0,32(sp)
 1e6:	64e2                	ld	s1,24(sp)
 1e8:	6145                	addi	sp,sp,48
 1ea:	8082                	ret
        exit(1);
 1ec:	4505                	li	a0,1
 1ee:	426000ef          	jal	ra,614 <exit>
    if (getpid() != ugetpid())
 1f2:	4a2000ef          	jal	ra,694 <getpid>
 1f6:	84aa                	mv	s1,a0
 1f8:	3fe000ef          	jal	ra,5f6 <ugetpid>
 1fc:	00a48863          	beq	s1,a0,20c <ugetpid_test+0x7c>
      err("missmatched PID");
 200:	00001517          	auipc	a0,0x1
 204:	b1850513          	addi	a0,a0,-1256 # d18 <malloc+0x200>
 208:	df9ff0ef          	jal	ra,0 <err>
    exit(0);
 20c:	4501                	li	a0,0
 20e:	406000ef          	jal	ra,614 <exit>

0000000000000212 <print_kpgtbl>:

void
print_kpgtbl()
{
 212:	1141                	addi	sp,sp,-16
 214:	e406                	sd	ra,8(sp)
 216:	e022                	sd	s0,0(sp)
 218:	0800                	addi	s0,sp,16
  printf("print_kpgtbl starting\n");
 21a:	00001517          	auipc	a0,0x1
 21e:	b2650513          	addi	a0,a0,-1242 # d40 <malloc+0x228>
 222:	03d000ef          	jal	ra,a5e <printf>
  kpgtbl();
 226:	4ba000ef          	jal	ra,6e0 <kpgtbl>
  printf("print_kpgtbl: OK\n");
 22a:	00001517          	auipc	a0,0x1
 22e:	b2e50513          	addi	a0,a0,-1234 # d58 <malloc+0x240>
 232:	02d000ef          	jal	ra,a5e <printf>
}
 236:	60a2                	ld	ra,8(sp)
 238:	6402                	ld	s0,0(sp)
 23a:	0141                	addi	sp,sp,16
 23c:	8082                	ret

000000000000023e <main>:
{
 23e:	1141                	addi	sp,sp,-16
 240:	e406                	sd	ra,8(sp)
 242:	e022                	sd	s0,0(sp)
 244:	0800                	addi	s0,sp,16
  print_pgtbl();
 246:	eebff0ef          	jal	ra,130 <print_pgtbl>
  ugetpid_test();
 24a:	f47ff0ef          	jal	ra,190 <ugetpid_test>
  print_kpgtbl();
 24e:	fc5ff0ef          	jal	ra,212 <print_kpgtbl>
  pgaccess_test();
 252:	de1ff0ef          	jal	ra,32 <pgaccess_test>
  printf("pgtbltest: all tests succeeded\n");
 256:	00001517          	auipc	a0,0x1
 25a:	b1a50513          	addi	a0,a0,-1254 # d70 <malloc+0x258>
 25e:	001000ef          	jal	ra,a5e <printf>
  exit(0);
 262:	4501                	li	a0,0
 264:	3b0000ef          	jal	ra,614 <exit>

0000000000000268 <supercheck>:


void
supercheck(uint64 s)
{
 268:	7139                	addi	sp,sp,-64
 26a:	fc06                	sd	ra,56(sp)
 26c:	f822                	sd	s0,48(sp)
 26e:	f426                	sd	s1,40(sp)
 270:	f04a                	sd	s2,32(sp)
 272:	ec4e                	sd	s3,24(sp)
 274:	e852                	sd	s4,16(sp)
 276:	e456                	sd	s5,8(sp)
 278:	e05a                	sd	s6,0(sp)
 27a:	0080                	addi	s0,sp,64
 27c:	8b2a                	mv	s6,a0
  pte_t last_pte = 0;

  for (uint64 p = s;  p < s + 512 * PGSIZE; p += PGSIZE) {
 27e:	002009b7          	lui	s3,0x200
 282:	99aa                	add	s3,s3,a0
 284:	05357963          	bgeu	a0,s3,2d6 <supercheck+0x6e>
 288:	84aa                	mv	s1,a0
  pte_t last_pte = 0;
 28a:	4501                	li	a0,0
    if(pte == 0)
      err("no pte");
    if ((uint64) last_pte != 0 && pte != last_pte) {
        err("pte different");
    }
    if((pte & PTE_V) == 0 || (pte & PTE_R) == 0 || (pte & PTE_W) == 0){
 28c:	4a9d                	li	s5,7
  for (uint64 p = s;  p < s + 512 * PGSIZE; p += PGSIZE) {
 28e:	6a05                	lui	s4,0x1
 290:	a831                	j	2ac <supercheck+0x44>
      err("no pte");
 292:	00001517          	auipc	a0,0x1
 296:	afe50513          	addi	a0,a0,-1282 # d90 <malloc+0x278>
 29a:	d67ff0ef          	jal	ra,0 <err>
    if((pte & PTE_V) == 0 || (pte & PTE_R) == 0 || (pte & PTE_W) == 0){
 29e:	00757793          	andi	a5,a0,7
 2a2:	03579463          	bne	a5,s5,2ca <supercheck+0x62>
  for (uint64 p = s;  p < s + 512 * PGSIZE; p += PGSIZE) {
 2a6:	94d2                	add	s1,s1,s4
 2a8:	0334f763          	bgeu	s1,s3,2d6 <supercheck+0x6e>
    pte_t pte = (pte_t) pgpte((void *) p);
 2ac:	892a                	mv	s2,a0
 2ae:	8526                	mv	a0,s1
 2b0:	426000ef          	jal	ra,6d6 <pgpte>
    if(pte == 0)
 2b4:	dd79                	beqz	a0,292 <supercheck+0x2a>
    if ((uint64) last_pte != 0 && pte != last_pte) {
 2b6:	fe0904e3          	beqz	s2,29e <supercheck+0x36>
 2ba:	ff2502e3          	beq	a0,s2,29e <supercheck+0x36>
        err("pte different");
 2be:	00001517          	auipc	a0,0x1
 2c2:	ada50513          	addi	a0,a0,-1318 # d98 <malloc+0x280>
 2c6:	d3bff0ef          	jal	ra,0 <err>
      err("pte wrong");
 2ca:	00001517          	auipc	a0,0x1
 2ce:	ade50513          	addi	a0,a0,-1314 # da8 <malloc+0x290>
 2d2:	d2fff0ef          	jal	ra,0 <err>
    }
    last_pte = pte;
  }

  for(int i = 0; i < 512; i += PGSIZE){
    *(int*)(s+i) = i;
 2d6:	000b2023          	sw	zero,0(s6)

  for(int i = 0; i < 512; i += PGSIZE){
    if(*(int*)(s+i) != i)
      err("wrong value");
  }
}
 2da:	70e2                	ld	ra,56(sp)
 2dc:	7442                	ld	s0,48(sp)
 2de:	74a2                	ld	s1,40(sp)
 2e0:	7902                	ld	s2,32(sp)
 2e2:	69e2                	ld	s3,24(sp)
 2e4:	6a42                	ld	s4,16(sp)
 2e6:	6aa2                	ld	s5,8(sp)
 2e8:	6b02                	ld	s6,0(sp)
 2ea:	6121                	addi	sp,sp,64
 2ec:	8082                	ret

00000000000002ee <superpg_test>:

void
superpg_test()
{
 2ee:	7179                	addi	sp,sp,-48
 2f0:	f406                	sd	ra,40(sp)
 2f2:	f022                	sd	s0,32(sp)
 2f4:	ec26                	sd	s1,24(sp)
 2f6:	1800                	addi	s0,sp,48
  int pid;
  
  printf("superpg_test starting\n");
 2f8:	00001517          	auipc	a0,0x1
 2fc:	ac050513          	addi	a0,a0,-1344 # db8 <malloc+0x2a0>
 300:	75e000ef          	jal	ra,a5e <printf>
  testname = "superpg_test";
 304:	00001797          	auipc	a5,0x1
 308:	acc78793          	addi	a5,a5,-1332 # dd0 <malloc+0x2b8>
 30c:	00001717          	auipc	a4,0x1
 310:	cef73a23          	sd	a5,-780(a4) # 1000 <testname>
  
  char *end = sbrk(N);
 314:	00800537          	lui	a0,0x800
 318:	384000ef          	jal	ra,69c <sbrk>
  if (end == 0 || end == (char*)0xffffffffffffffff)
 31c:	fff50713          	addi	a4,a0,-1 # 7fffff <base+0x7fefdf>
 320:	57f5                	li	a5,-3
 322:	04e7e363          	bltu	a5,a4,368 <superpg_test+0x7a>
    err("sbrk failed");
  
  uint64 s = SUPERPGROUNDUP((uint64) end);
 326:	002004b7          	lui	s1,0x200
 32a:	14fd                	addi	s1,s1,-1
 32c:	9526                	add	a0,a0,s1
 32e:	ffe004b7          	lui	s1,0xffe00
 332:	8ce9                	and	s1,s1,a0
  supercheck(s);
 334:	8526                	mv	a0,s1
 336:	f33ff0ef          	jal	ra,268 <supercheck>
  if((pid = fork()) < 0) {
 33a:	2d2000ef          	jal	ra,60c <fork>
 33e:	02054b63          	bltz	a0,374 <superpg_test+0x86>
    err("fork");
  } else if(pid == 0) {
 342:	cd1d                	beqz	a0,380 <superpg_test+0x92>
    supercheck(s);
    exit(0);
  } else {
    int status;
    wait(&status);
 344:	fdc40513          	addi	a0,s0,-36
 348:	2d4000ef          	jal	ra,61c <wait>
    if (status != 0) {
 34c:	fdc42783          	lw	a5,-36(s0)
 350:	ef95                	bnez	a5,38c <superpg_test+0x9e>
      exit(0);
    }
  }
  printf("superpg_test: OK\n");  
 352:	00001517          	auipc	a0,0x1
 356:	aa650513          	addi	a0,a0,-1370 # df8 <malloc+0x2e0>
 35a:	704000ef          	jal	ra,a5e <printf>
}
 35e:	70a2                	ld	ra,40(sp)
 360:	7402                	ld	s0,32(sp)
 362:	64e2                	ld	s1,24(sp)
 364:	6145                	addi	sp,sp,48
 366:	8082                	ret
    err("sbrk failed");
 368:	00001517          	auipc	a0,0x1
 36c:	a7850513          	addi	a0,a0,-1416 # de0 <malloc+0x2c8>
 370:	c91ff0ef          	jal	ra,0 <err>
    err("fork");
 374:	00001517          	auipc	a0,0x1
 378:	a7c50513          	addi	a0,a0,-1412 # df0 <malloc+0x2d8>
 37c:	c85ff0ef          	jal	ra,0 <err>
    supercheck(s);
 380:	8526                	mv	a0,s1
 382:	ee7ff0ef          	jal	ra,268 <supercheck>
    exit(0);
 386:	4501                	li	a0,0
 388:	28c000ef          	jal	ra,614 <exit>
      exit(0);
 38c:	4501                	li	a0,0
 38e:	286000ef          	jal	ra,614 <exit>

0000000000000392 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 392:	1141                	addi	sp,sp,-16
 394:	e406                	sd	ra,8(sp)
 396:	e022                	sd	s0,0(sp)
 398:	0800                	addi	s0,sp,16
  extern int main();
  main();
 39a:	ea5ff0ef          	jal	ra,23e <main>
  exit(0);
 39e:	4501                	li	a0,0
 3a0:	274000ef          	jal	ra,614 <exit>

00000000000003a4 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 3a4:	1141                	addi	sp,sp,-16
 3a6:	e422                	sd	s0,8(sp)
 3a8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 3aa:	87aa                	mv	a5,a0
 3ac:	0585                	addi	a1,a1,1
 3ae:	0785                	addi	a5,a5,1
 3b0:	fff5c703          	lbu	a4,-1(a1)
 3b4:	fee78fa3          	sb	a4,-1(a5)
 3b8:	fb75                	bnez	a4,3ac <strcpy+0x8>
    ;
  return os;
}
 3ba:	6422                	ld	s0,8(sp)
 3bc:	0141                	addi	sp,sp,16
 3be:	8082                	ret

00000000000003c0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 3c0:	1141                	addi	sp,sp,-16
 3c2:	e422                	sd	s0,8(sp)
 3c4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 3c6:	00054783          	lbu	a5,0(a0)
 3ca:	cb91                	beqz	a5,3de <strcmp+0x1e>
 3cc:	0005c703          	lbu	a4,0(a1)
 3d0:	00f71763          	bne	a4,a5,3de <strcmp+0x1e>
    p++, q++;
 3d4:	0505                	addi	a0,a0,1
 3d6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 3d8:	00054783          	lbu	a5,0(a0)
 3dc:	fbe5                	bnez	a5,3cc <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 3de:	0005c503          	lbu	a0,0(a1)
}
 3e2:	40a7853b          	subw	a0,a5,a0
 3e6:	6422                	ld	s0,8(sp)
 3e8:	0141                	addi	sp,sp,16
 3ea:	8082                	ret

00000000000003ec <strlen>:

uint
strlen(const char *s)
{
 3ec:	1141                	addi	sp,sp,-16
 3ee:	e422                	sd	s0,8(sp)
 3f0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 3f2:	00054783          	lbu	a5,0(a0)
 3f6:	cf91                	beqz	a5,412 <strlen+0x26>
 3f8:	0505                	addi	a0,a0,1
 3fa:	87aa                	mv	a5,a0
 3fc:	4685                	li	a3,1
 3fe:	9e89                	subw	a3,a3,a0
 400:	00f6853b          	addw	a0,a3,a5
 404:	0785                	addi	a5,a5,1
 406:	fff7c703          	lbu	a4,-1(a5)
 40a:	fb7d                	bnez	a4,400 <strlen+0x14>
    ;
  return n;
}
 40c:	6422                	ld	s0,8(sp)
 40e:	0141                	addi	sp,sp,16
 410:	8082                	ret
  for(n = 0; s[n]; n++)
 412:	4501                	li	a0,0
 414:	bfe5                	j	40c <strlen+0x20>

0000000000000416 <memset>:

void*
memset(void *dst, int c, uint n)
{
 416:	1141                	addi	sp,sp,-16
 418:	e422                	sd	s0,8(sp)
 41a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 41c:	ca19                	beqz	a2,432 <memset+0x1c>
 41e:	87aa                	mv	a5,a0
 420:	1602                	slli	a2,a2,0x20
 422:	9201                	srli	a2,a2,0x20
 424:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 428:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 42c:	0785                	addi	a5,a5,1
 42e:	fee79de3          	bne	a5,a4,428 <memset+0x12>
  }
  return dst;
}
 432:	6422                	ld	s0,8(sp)
 434:	0141                	addi	sp,sp,16
 436:	8082                	ret

0000000000000438 <strchr>:

char*
strchr(const char *s, char c)
{
 438:	1141                	addi	sp,sp,-16
 43a:	e422                	sd	s0,8(sp)
 43c:	0800                	addi	s0,sp,16
  for(; *s; s++)
 43e:	00054783          	lbu	a5,0(a0)
 442:	cb99                	beqz	a5,458 <strchr+0x20>
    if(*s == c)
 444:	00f58763          	beq	a1,a5,452 <strchr+0x1a>
  for(; *s; s++)
 448:	0505                	addi	a0,a0,1
 44a:	00054783          	lbu	a5,0(a0)
 44e:	fbfd                	bnez	a5,444 <strchr+0xc>
      return (char*)s;
  return 0;
 450:	4501                	li	a0,0
}
 452:	6422                	ld	s0,8(sp)
 454:	0141                	addi	sp,sp,16
 456:	8082                	ret
  return 0;
 458:	4501                	li	a0,0
 45a:	bfe5                	j	452 <strchr+0x1a>

000000000000045c <gets>:

char*
gets(char *buf, int max)
{
 45c:	711d                	addi	sp,sp,-96
 45e:	ec86                	sd	ra,88(sp)
 460:	e8a2                	sd	s0,80(sp)
 462:	e4a6                	sd	s1,72(sp)
 464:	e0ca                	sd	s2,64(sp)
 466:	fc4e                	sd	s3,56(sp)
 468:	f852                	sd	s4,48(sp)
 46a:	f456                	sd	s5,40(sp)
 46c:	f05a                	sd	s6,32(sp)
 46e:	ec5e                	sd	s7,24(sp)
 470:	1080                	addi	s0,sp,96
 472:	8baa                	mv	s7,a0
 474:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 476:	892a                	mv	s2,a0
 478:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 47a:	4aa9                	li	s5,10
 47c:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 47e:	89a6                	mv	s3,s1
 480:	2485                	addiw	s1,s1,1
 482:	0344d663          	bge	s1,s4,4ae <gets+0x52>
    cc = read(0, &c, 1);
 486:	4605                	li	a2,1
 488:	faf40593          	addi	a1,s0,-81
 48c:	4501                	li	a0,0
 48e:	19e000ef          	jal	ra,62c <read>
    if(cc < 1)
 492:	00a05e63          	blez	a0,4ae <gets+0x52>
    buf[i++] = c;
 496:	faf44783          	lbu	a5,-81(s0)
 49a:	00f90023          	sb	a5,0(s2) # a000 <base+0x8fe0>
    if(c == '\n' || c == '\r')
 49e:	01578763          	beq	a5,s5,4ac <gets+0x50>
 4a2:	0905                	addi	s2,s2,1
 4a4:	fd679de3          	bne	a5,s6,47e <gets+0x22>
  for(i=0; i+1 < max; ){
 4a8:	89a6                	mv	s3,s1
 4aa:	a011                	j	4ae <gets+0x52>
 4ac:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 4ae:	99de                	add	s3,s3,s7
 4b0:	00098023          	sb	zero,0(s3) # 200000 <base+0x1fefe0>
  return buf;
}
 4b4:	855e                	mv	a0,s7
 4b6:	60e6                	ld	ra,88(sp)
 4b8:	6446                	ld	s0,80(sp)
 4ba:	64a6                	ld	s1,72(sp)
 4bc:	6906                	ld	s2,64(sp)
 4be:	79e2                	ld	s3,56(sp)
 4c0:	7a42                	ld	s4,48(sp)
 4c2:	7aa2                	ld	s5,40(sp)
 4c4:	7b02                	ld	s6,32(sp)
 4c6:	6be2                	ld	s7,24(sp)
 4c8:	6125                	addi	sp,sp,96
 4ca:	8082                	ret

00000000000004cc <stat>:

int
stat(const char *n, struct stat *st)
{
 4cc:	1101                	addi	sp,sp,-32
 4ce:	ec06                	sd	ra,24(sp)
 4d0:	e822                	sd	s0,16(sp)
 4d2:	e426                	sd	s1,8(sp)
 4d4:	e04a                	sd	s2,0(sp)
 4d6:	1000                	addi	s0,sp,32
 4d8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4da:	4581                	li	a1,0
 4dc:	178000ef          	jal	ra,654 <open>
  if(fd < 0)
 4e0:	02054163          	bltz	a0,502 <stat+0x36>
 4e4:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 4e6:	85ca                	mv	a1,s2
 4e8:	184000ef          	jal	ra,66c <fstat>
 4ec:	892a                	mv	s2,a0
  close(fd);
 4ee:	8526                	mv	a0,s1
 4f0:	14c000ef          	jal	ra,63c <close>
  return r;
}
 4f4:	854a                	mv	a0,s2
 4f6:	60e2                	ld	ra,24(sp)
 4f8:	6442                	ld	s0,16(sp)
 4fa:	64a2                	ld	s1,8(sp)
 4fc:	6902                	ld	s2,0(sp)
 4fe:	6105                	addi	sp,sp,32
 500:	8082                	ret
    return -1;
 502:	597d                	li	s2,-1
 504:	bfc5                	j	4f4 <stat+0x28>

0000000000000506 <atoi>:

int
atoi(const char *s)
{
 506:	1141                	addi	sp,sp,-16
 508:	e422                	sd	s0,8(sp)
 50a:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 50c:	00054603          	lbu	a2,0(a0)
 510:	fd06079b          	addiw	a5,a2,-48
 514:	0ff7f793          	zext.b	a5,a5
 518:	4725                	li	a4,9
 51a:	02f76963          	bltu	a4,a5,54c <atoi+0x46>
 51e:	86aa                	mv	a3,a0
  n = 0;
 520:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 522:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 524:	0685                	addi	a3,a3,1
 526:	0025179b          	slliw	a5,a0,0x2
 52a:	9fa9                	addw	a5,a5,a0
 52c:	0017979b          	slliw	a5,a5,0x1
 530:	9fb1                	addw	a5,a5,a2
 532:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 536:	0006c603          	lbu	a2,0(a3)
 53a:	fd06071b          	addiw	a4,a2,-48
 53e:	0ff77713          	zext.b	a4,a4
 542:	fee5f1e3          	bgeu	a1,a4,524 <atoi+0x1e>
  return n;
}
 546:	6422                	ld	s0,8(sp)
 548:	0141                	addi	sp,sp,16
 54a:	8082                	ret
  n = 0;
 54c:	4501                	li	a0,0
 54e:	bfe5                	j	546 <atoi+0x40>

0000000000000550 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 550:	1141                	addi	sp,sp,-16
 552:	e422                	sd	s0,8(sp)
 554:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 556:	02b57463          	bgeu	a0,a1,57e <memmove+0x2e>
    while(n-- > 0)
 55a:	00c05f63          	blez	a2,578 <memmove+0x28>
 55e:	1602                	slli	a2,a2,0x20
 560:	9201                	srli	a2,a2,0x20
 562:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 566:	872a                	mv	a4,a0
      *dst++ = *src++;
 568:	0585                	addi	a1,a1,1
 56a:	0705                	addi	a4,a4,1
 56c:	fff5c683          	lbu	a3,-1(a1)
 570:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 574:	fee79ae3          	bne	a5,a4,568 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 578:	6422                	ld	s0,8(sp)
 57a:	0141                	addi	sp,sp,16
 57c:	8082                	ret
    dst += n;
 57e:	00c50733          	add	a4,a0,a2
    src += n;
 582:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 584:	fec05ae3          	blez	a2,578 <memmove+0x28>
 588:	fff6079b          	addiw	a5,a2,-1
 58c:	1782                	slli	a5,a5,0x20
 58e:	9381                	srli	a5,a5,0x20
 590:	fff7c793          	not	a5,a5
 594:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 596:	15fd                	addi	a1,a1,-1
 598:	177d                	addi	a4,a4,-1
 59a:	0005c683          	lbu	a3,0(a1)
 59e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 5a2:	fee79ae3          	bne	a5,a4,596 <memmove+0x46>
 5a6:	bfc9                	j	578 <memmove+0x28>

00000000000005a8 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 5a8:	1141                	addi	sp,sp,-16
 5aa:	e422                	sd	s0,8(sp)
 5ac:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 5ae:	ca05                	beqz	a2,5de <memcmp+0x36>
 5b0:	fff6069b          	addiw	a3,a2,-1
 5b4:	1682                	slli	a3,a3,0x20
 5b6:	9281                	srli	a3,a3,0x20
 5b8:	0685                	addi	a3,a3,1
 5ba:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 5bc:	00054783          	lbu	a5,0(a0)
 5c0:	0005c703          	lbu	a4,0(a1)
 5c4:	00e79863          	bne	a5,a4,5d4 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 5c8:	0505                	addi	a0,a0,1
    p2++;
 5ca:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 5cc:	fed518e3          	bne	a0,a3,5bc <memcmp+0x14>
  }
  return 0;
 5d0:	4501                	li	a0,0
 5d2:	a019                	j	5d8 <memcmp+0x30>
      return *p1 - *p2;
 5d4:	40e7853b          	subw	a0,a5,a4
}
 5d8:	6422                	ld	s0,8(sp)
 5da:	0141                	addi	sp,sp,16
 5dc:	8082                	ret
  return 0;
 5de:	4501                	li	a0,0
 5e0:	bfe5                	j	5d8 <memcmp+0x30>

00000000000005e2 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 5e2:	1141                	addi	sp,sp,-16
 5e4:	e406                	sd	ra,8(sp)
 5e6:	e022                	sd	s0,0(sp)
 5e8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 5ea:	f67ff0ef          	jal	ra,550 <memmove>
}
 5ee:	60a2                	ld	ra,8(sp)
 5f0:	6402                	ld	s0,0(sp)
 5f2:	0141                	addi	sp,sp,16
 5f4:	8082                	ret

00000000000005f6 <ugetpid>:

#ifdef LAB_PGTBL
int
ugetpid(void)
{
 5f6:	1141                	addi	sp,sp,-16
 5f8:	e422                	sd	s0,8(sp)
 5fa:	0800                	addi	s0,sp,16
  struct usyscall *u = (struct usyscall *)USYSCALL;
  return u->pid;
 5fc:	040007b7          	lui	a5,0x4000
}
 600:	17f5                	addi	a5,a5,-3
 602:	07b2                	slli	a5,a5,0xc
 604:	4388                	lw	a0,0(a5)
 606:	6422                	ld	s0,8(sp)
 608:	0141                	addi	sp,sp,16
 60a:	8082                	ret

000000000000060c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 60c:	4885                	li	a7,1
 ecall
 60e:	00000073          	ecall
 ret
 612:	8082                	ret

0000000000000614 <exit>:
.global exit
exit:
 li a7, SYS_exit
 614:	4889                	li	a7,2
 ecall
 616:	00000073          	ecall
 ret
 61a:	8082                	ret

000000000000061c <wait>:
.global wait
wait:
 li a7, SYS_wait
 61c:	488d                	li	a7,3
 ecall
 61e:	00000073          	ecall
 ret
 622:	8082                	ret

0000000000000624 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 624:	4891                	li	a7,4
 ecall
 626:	00000073          	ecall
 ret
 62a:	8082                	ret

000000000000062c <read>:
.global read
read:
 li a7, SYS_read
 62c:	4895                	li	a7,5
 ecall
 62e:	00000073          	ecall
 ret
 632:	8082                	ret

0000000000000634 <write>:
.global write
write:
 li a7, SYS_write
 634:	48c1                	li	a7,16
 ecall
 636:	00000073          	ecall
 ret
 63a:	8082                	ret

000000000000063c <close>:
.global close
close:
 li a7, SYS_close
 63c:	48d5                	li	a7,21
 ecall
 63e:	00000073          	ecall
 ret
 642:	8082                	ret

0000000000000644 <kill>:
.global kill
kill:
 li a7, SYS_kill
 644:	4899                	li	a7,6
 ecall
 646:	00000073          	ecall
 ret
 64a:	8082                	ret

000000000000064c <exec>:
.global exec
exec:
 li a7, SYS_exec
 64c:	489d                	li	a7,7
 ecall
 64e:	00000073          	ecall
 ret
 652:	8082                	ret

0000000000000654 <open>:
.global open
open:
 li a7, SYS_open
 654:	48bd                	li	a7,15
 ecall
 656:	00000073          	ecall
 ret
 65a:	8082                	ret

000000000000065c <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 65c:	48c5                	li	a7,17
 ecall
 65e:	00000073          	ecall
 ret
 662:	8082                	ret

0000000000000664 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 664:	48c9                	li	a7,18
 ecall
 666:	00000073          	ecall
 ret
 66a:	8082                	ret

000000000000066c <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 66c:	48a1                	li	a7,8
 ecall
 66e:	00000073          	ecall
 ret
 672:	8082                	ret

0000000000000674 <link>:
.global link
link:
 li a7, SYS_link
 674:	48cd                	li	a7,19
 ecall
 676:	00000073          	ecall
 ret
 67a:	8082                	ret

000000000000067c <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 67c:	48d1                	li	a7,20
 ecall
 67e:	00000073          	ecall
 ret
 682:	8082                	ret

0000000000000684 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 684:	48a5                	li	a7,9
 ecall
 686:	00000073          	ecall
 ret
 68a:	8082                	ret

000000000000068c <dup>:
.global dup
dup:
 li a7, SYS_dup
 68c:	48a9                	li	a7,10
 ecall
 68e:	00000073          	ecall
 ret
 692:	8082                	ret

0000000000000694 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 694:	48ad                	li	a7,11
 ecall
 696:	00000073          	ecall
 ret
 69a:	8082                	ret

000000000000069c <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 69c:	48b1                	li	a7,12
 ecall
 69e:	00000073          	ecall
 ret
 6a2:	8082                	ret

00000000000006a4 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 6a4:	48b5                	li	a7,13
 ecall
 6a6:	00000073          	ecall
 ret
 6aa:	8082                	ret

00000000000006ac <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 6ac:	48b9                	li	a7,14
 ecall
 6ae:	00000073          	ecall
 ret
 6b2:	8082                	ret

00000000000006b4 <bind>:
.global bind
bind:
 li a7, SYS_bind
 6b4:	48f5                	li	a7,29
 ecall
 6b6:	00000073          	ecall
 ret
 6ba:	8082                	ret

00000000000006bc <unbind>:
.global unbind
unbind:
 li a7, SYS_unbind
 6bc:	48f9                	li	a7,30
 ecall
 6be:	00000073          	ecall
 ret
 6c2:	8082                	ret

00000000000006c4 <send>:
.global send
send:
 li a7, SYS_send
 6c4:	48fd                	li	a7,31
 ecall
 6c6:	00000073          	ecall
 ret
 6ca:	8082                	ret

00000000000006cc <recv>:
.global recv
recv:
 li a7, SYS_recv
 6cc:	02000893          	li	a7,32
 ecall
 6d0:	00000073          	ecall
 ret
 6d4:	8082                	ret

00000000000006d6 <pgpte>:
.global pgpte
pgpte:
 li a7, SYS_pgpte
 6d6:	02100893          	li	a7,33
 ecall
 6da:	00000073          	ecall
 ret
 6de:	8082                	ret

00000000000006e0 <kpgtbl>:
.global kpgtbl
kpgtbl:
 li a7, SYS_kpgtbl
 6e0:	02200893          	li	a7,34
 ecall
 6e4:	00000073          	ecall
 ret
 6e8:	8082                	ret

00000000000006ea <pgaccess>:
.global pgaccess
pgaccess:
 li a7, SYS_pgaccess
 6ea:	02300893          	li	a7,35
 ecall
 6ee:	00000073          	ecall
 ret
 6f2:	8082                	ret

00000000000006f4 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 6f4:	1101                	addi	sp,sp,-32
 6f6:	ec06                	sd	ra,24(sp)
 6f8:	e822                	sd	s0,16(sp)
 6fa:	1000                	addi	s0,sp,32
 6fc:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 700:	4605                	li	a2,1
 702:	fef40593          	addi	a1,s0,-17
 706:	f2fff0ef          	jal	ra,634 <write>
}
 70a:	60e2                	ld	ra,24(sp)
 70c:	6442                	ld	s0,16(sp)
 70e:	6105                	addi	sp,sp,32
 710:	8082                	ret

0000000000000712 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 712:	7139                	addi	sp,sp,-64
 714:	fc06                	sd	ra,56(sp)
 716:	f822                	sd	s0,48(sp)
 718:	f426                	sd	s1,40(sp)
 71a:	f04a                	sd	s2,32(sp)
 71c:	ec4e                	sd	s3,24(sp)
 71e:	0080                	addi	s0,sp,64
 720:	84aa                	mv	s1,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 722:	c299                	beqz	a3,728 <printint+0x16>
 724:	0805c663          	bltz	a1,7b0 <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 728:	2581                	sext.w	a1,a1
  neg = 0;
 72a:	4881                	li	a7,0
 72c:	fc040693          	addi	a3,s0,-64
  }

  i = 0;
 730:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 732:	2601                	sext.w	a2,a2
 734:	00000517          	auipc	a0,0x0
 738:	6ec50513          	addi	a0,a0,1772 # e20 <digits>
 73c:	883a                	mv	a6,a4
 73e:	2705                	addiw	a4,a4,1
 740:	02c5f7bb          	remuw	a5,a1,a2
 744:	1782                	slli	a5,a5,0x20
 746:	9381                	srli	a5,a5,0x20
 748:	97aa                	add	a5,a5,a0
 74a:	0007c783          	lbu	a5,0(a5) # 4000000 <base+0x3ffefe0>
 74e:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 752:	0005879b          	sext.w	a5,a1
 756:	02c5d5bb          	divuw	a1,a1,a2
 75a:	0685                	addi	a3,a3,1
 75c:	fec7f0e3          	bgeu	a5,a2,73c <printint+0x2a>
  if(neg)
 760:	00088b63          	beqz	a7,776 <printint+0x64>
    buf[i++] = '-';
 764:	fd040793          	addi	a5,s0,-48
 768:	973e                	add	a4,a4,a5
 76a:	02d00793          	li	a5,45
 76e:	fef70823          	sb	a5,-16(a4)
 772:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 776:	02e05663          	blez	a4,7a2 <printint+0x90>
 77a:	fc040793          	addi	a5,s0,-64
 77e:	00e78933          	add	s2,a5,a4
 782:	fff78993          	addi	s3,a5,-1
 786:	99ba                	add	s3,s3,a4
 788:	377d                	addiw	a4,a4,-1
 78a:	1702                	slli	a4,a4,0x20
 78c:	9301                	srli	a4,a4,0x20
 78e:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 792:	fff94583          	lbu	a1,-1(s2)
 796:	8526                	mv	a0,s1
 798:	f5dff0ef          	jal	ra,6f4 <putc>
  while(--i >= 0)
 79c:	197d                	addi	s2,s2,-1
 79e:	ff391ae3          	bne	s2,s3,792 <printint+0x80>
}
 7a2:	70e2                	ld	ra,56(sp)
 7a4:	7442                	ld	s0,48(sp)
 7a6:	74a2                	ld	s1,40(sp)
 7a8:	7902                	ld	s2,32(sp)
 7aa:	69e2                	ld	s3,24(sp)
 7ac:	6121                	addi	sp,sp,64
 7ae:	8082                	ret
    x = -xx;
 7b0:	40b005bb          	negw	a1,a1
    neg = 1;
 7b4:	4885                	li	a7,1
    x = -xx;
 7b6:	bf9d                	j	72c <printint+0x1a>

00000000000007b8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 7b8:	7119                	addi	sp,sp,-128
 7ba:	fc86                	sd	ra,120(sp)
 7bc:	f8a2                	sd	s0,112(sp)
 7be:	f4a6                	sd	s1,104(sp)
 7c0:	f0ca                	sd	s2,96(sp)
 7c2:	ecce                	sd	s3,88(sp)
 7c4:	e8d2                	sd	s4,80(sp)
 7c6:	e4d6                	sd	s5,72(sp)
 7c8:	e0da                	sd	s6,64(sp)
 7ca:	fc5e                	sd	s7,56(sp)
 7cc:	f862                	sd	s8,48(sp)
 7ce:	f466                	sd	s9,40(sp)
 7d0:	f06a                	sd	s10,32(sp)
 7d2:	ec6e                	sd	s11,24(sp)
 7d4:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 7d6:	0005c903          	lbu	s2,0(a1)
 7da:	22090e63          	beqz	s2,a16 <vprintf+0x25e>
 7de:	8b2a                	mv	s6,a0
 7e0:	8a2e                	mv	s4,a1
 7e2:	8bb2                	mv	s7,a2
  state = 0;
 7e4:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 7e6:	4481                	li	s1,0
 7e8:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 7ea:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 7ee:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 7f2:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 7f6:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7fa:	00000c97          	auipc	s9,0x0
 7fe:	626c8c93          	addi	s9,s9,1574 # e20 <digits>
 802:	a005                	j	822 <vprintf+0x6a>
        putc(fd, c0);
 804:	85ca                	mv	a1,s2
 806:	855a                	mv	a0,s6
 808:	eedff0ef          	jal	ra,6f4 <putc>
 80c:	a019                	j	812 <vprintf+0x5a>
    } else if(state == '%'){
 80e:	03598263          	beq	s3,s5,832 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 812:	2485                	addiw	s1,s1,1
 814:	8726                	mv	a4,s1
 816:	009a07b3          	add	a5,s4,s1
 81a:	0007c903          	lbu	s2,0(a5)
 81e:	1e090c63          	beqz	s2,a16 <vprintf+0x25e>
    c0 = fmt[i] & 0xff;
 822:	0009079b          	sext.w	a5,s2
    if(state == 0){
 826:	fe0994e3          	bnez	s3,80e <vprintf+0x56>
      if(c0 == '%'){
 82a:	fd579de3          	bne	a5,s5,804 <vprintf+0x4c>
        state = '%';
 82e:	89be                	mv	s3,a5
 830:	b7cd                	j	812 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 832:	cfa5                	beqz	a5,8aa <vprintf+0xf2>
 834:	00ea06b3          	add	a3,s4,a4
 838:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 83c:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 83e:	c681                	beqz	a3,846 <vprintf+0x8e>
 840:	9752                	add	a4,a4,s4
 842:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 846:	03878a63          	beq	a5,s8,87a <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 84a:	05a78463          	beq	a5,s10,892 <vprintf+0xda>
      } else if(c0 == 'u'){
 84e:	0db78763          	beq	a5,s11,91c <vprintf+0x164>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 852:	07800713          	li	a4,120
 856:	10e78963          	beq	a5,a4,968 <vprintf+0x1b0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 85a:	07000713          	li	a4,112
 85e:	12e78e63          	beq	a5,a4,99a <vprintf+0x1e2>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 862:	07300713          	li	a4,115
 866:	16e78b63          	beq	a5,a4,9dc <vprintf+0x224>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 86a:	05579063          	bne	a5,s5,8aa <vprintf+0xf2>
        putc(fd, '%');
 86e:	85d6                	mv	a1,s5
 870:	855a                	mv	a0,s6
 872:	e83ff0ef          	jal	ra,6f4 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 876:	4981                	li	s3,0
 878:	bf69                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 87a:	008b8913          	addi	s2,s7,8
 87e:	4685                	li	a3,1
 880:	4629                	li	a2,10
 882:	000ba583          	lw	a1,0(s7)
 886:	855a                	mv	a0,s6
 888:	e8bff0ef          	jal	ra,712 <printint>
 88c:	8bca                	mv	s7,s2
      state = 0;
 88e:	4981                	li	s3,0
 890:	b749                	j	812 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 892:	03868663          	beq	a3,s8,8be <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 896:	05a68163          	beq	a3,s10,8d8 <vprintf+0x120>
      } else if(c0 == 'l' && c1 == 'u'){
 89a:	09b68d63          	beq	a3,s11,934 <vprintf+0x17c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 89e:	03a68f63          	beq	a3,s10,8dc <vprintf+0x124>
      } else if(c0 == 'l' && c1 == 'x'){
 8a2:	07800793          	li	a5,120
 8a6:	0cf68d63          	beq	a3,a5,980 <vprintf+0x1c8>
        putc(fd, '%');
 8aa:	85d6                	mv	a1,s5
 8ac:	855a                	mv	a0,s6
 8ae:	e47ff0ef          	jal	ra,6f4 <putc>
        putc(fd, c0);
 8b2:	85ca                	mv	a1,s2
 8b4:	855a                	mv	a0,s6
 8b6:	e3fff0ef          	jal	ra,6f4 <putc>
      state = 0;
 8ba:	4981                	li	s3,0
 8bc:	bf99                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8be:	008b8913          	addi	s2,s7,8
 8c2:	4685                	li	a3,1
 8c4:	4629                	li	a2,10
 8c6:	000ba583          	lw	a1,0(s7)
 8ca:	855a                	mv	a0,s6
 8cc:	e47ff0ef          	jal	ra,712 <printint>
        i += 1;
 8d0:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 8d2:	8bca                	mv	s7,s2
      state = 0;
 8d4:	4981                	li	s3,0
        i += 1;
 8d6:	bf35                	j	812 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8d8:	03860563          	beq	a2,s8,902 <vprintf+0x14a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 8dc:	07b60963          	beq	a2,s11,94e <vprintf+0x196>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 8e0:	07800793          	li	a5,120
 8e4:	fcf613e3          	bne	a2,a5,8aa <vprintf+0xf2>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8e8:	008b8913          	addi	s2,s7,8
 8ec:	4681                	li	a3,0
 8ee:	4641                	li	a2,16
 8f0:	000ba583          	lw	a1,0(s7)
 8f4:	855a                	mv	a0,s6
 8f6:	e1dff0ef          	jal	ra,712 <printint>
        i += 2;
 8fa:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 8fc:	8bca                	mv	s7,s2
      state = 0;
 8fe:	4981                	li	s3,0
        i += 2;
 900:	bf09                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 902:	008b8913          	addi	s2,s7,8
 906:	4685                	li	a3,1
 908:	4629                	li	a2,10
 90a:	000ba583          	lw	a1,0(s7)
 90e:	855a                	mv	a0,s6
 910:	e03ff0ef          	jal	ra,712 <printint>
        i += 2;
 914:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 916:	8bca                	mv	s7,s2
      state = 0;
 918:	4981                	li	s3,0
        i += 2;
 91a:	bde5                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 0);
 91c:	008b8913          	addi	s2,s7,8
 920:	4681                	li	a3,0
 922:	4629                	li	a2,10
 924:	000ba583          	lw	a1,0(s7)
 928:	855a                	mv	a0,s6
 92a:	de9ff0ef          	jal	ra,712 <printint>
 92e:	8bca                	mv	s7,s2
      state = 0;
 930:	4981                	li	s3,0
 932:	b5c5                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 934:	008b8913          	addi	s2,s7,8
 938:	4681                	li	a3,0
 93a:	4629                	li	a2,10
 93c:	000ba583          	lw	a1,0(s7)
 940:	855a                	mv	a0,s6
 942:	dd1ff0ef          	jal	ra,712 <printint>
        i += 1;
 946:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 948:	8bca                	mv	s7,s2
      state = 0;
 94a:	4981                	li	s3,0
        i += 1;
 94c:	b5d9                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 94e:	008b8913          	addi	s2,s7,8
 952:	4681                	li	a3,0
 954:	4629                	li	a2,10
 956:	000ba583          	lw	a1,0(s7)
 95a:	855a                	mv	a0,s6
 95c:	db7ff0ef          	jal	ra,712 <printint>
        i += 2;
 960:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 962:	8bca                	mv	s7,s2
      state = 0;
 964:	4981                	li	s3,0
        i += 2;
 966:	b575                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 16, 0);
 968:	008b8913          	addi	s2,s7,8
 96c:	4681                	li	a3,0
 96e:	4641                	li	a2,16
 970:	000ba583          	lw	a1,0(s7)
 974:	855a                	mv	a0,s6
 976:	d9dff0ef          	jal	ra,712 <printint>
 97a:	8bca                	mv	s7,s2
      state = 0;
 97c:	4981                	li	s3,0
 97e:	bd51                	j	812 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 980:	008b8913          	addi	s2,s7,8
 984:	4681                	li	a3,0
 986:	4641                	li	a2,16
 988:	000ba583          	lw	a1,0(s7)
 98c:	855a                	mv	a0,s6
 98e:	d85ff0ef          	jal	ra,712 <printint>
        i += 1;
 992:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 994:	8bca                	mv	s7,s2
      state = 0;
 996:	4981                	li	s3,0
        i += 1;
 998:	bdad                	j	812 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 99a:	008b8793          	addi	a5,s7,8
 99e:	f8f43423          	sd	a5,-120(s0)
 9a2:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 9a6:	03000593          	li	a1,48
 9aa:	855a                	mv	a0,s6
 9ac:	d49ff0ef          	jal	ra,6f4 <putc>
  putc(fd, 'x');
 9b0:	07800593          	li	a1,120
 9b4:	855a                	mv	a0,s6
 9b6:	d3fff0ef          	jal	ra,6f4 <putc>
 9ba:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 9bc:	03c9d793          	srli	a5,s3,0x3c
 9c0:	97e6                	add	a5,a5,s9
 9c2:	0007c583          	lbu	a1,0(a5)
 9c6:	855a                	mv	a0,s6
 9c8:	d2dff0ef          	jal	ra,6f4 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 9cc:	0992                	slli	s3,s3,0x4
 9ce:	397d                	addiw	s2,s2,-1
 9d0:	fe0916e3          	bnez	s2,9bc <vprintf+0x204>
        printptr(fd, va_arg(ap, uint64));
 9d4:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 9d8:	4981                	li	s3,0
 9da:	bd25                	j	812 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 9dc:	008b8993          	addi	s3,s7,8
 9e0:	000bb903          	ld	s2,0(s7)
 9e4:	00090f63          	beqz	s2,a02 <vprintf+0x24a>
        for(; *s; s++)
 9e8:	00094583          	lbu	a1,0(s2)
 9ec:	c195                	beqz	a1,a10 <vprintf+0x258>
          putc(fd, *s);
 9ee:	855a                	mv	a0,s6
 9f0:	d05ff0ef          	jal	ra,6f4 <putc>
        for(; *s; s++)
 9f4:	0905                	addi	s2,s2,1
 9f6:	00094583          	lbu	a1,0(s2)
 9fa:	f9f5                	bnez	a1,9ee <vprintf+0x236>
        if((s = va_arg(ap, char*)) == 0)
 9fc:	8bce                	mv	s7,s3
      state = 0;
 9fe:	4981                	li	s3,0
 a00:	bd09                	j	812 <vprintf+0x5a>
          s = "(null)";
 a02:	00000917          	auipc	s2,0x0
 a06:	41690913          	addi	s2,s2,1046 # e18 <malloc+0x300>
        for(; *s; s++)
 a0a:	02800593          	li	a1,40
 a0e:	b7c5                	j	9ee <vprintf+0x236>
        if((s = va_arg(ap, char*)) == 0)
 a10:	8bce                	mv	s7,s3
      state = 0;
 a12:	4981                	li	s3,0
 a14:	bbfd                	j	812 <vprintf+0x5a>
    }
  }
}
 a16:	70e6                	ld	ra,120(sp)
 a18:	7446                	ld	s0,112(sp)
 a1a:	74a6                	ld	s1,104(sp)
 a1c:	7906                	ld	s2,96(sp)
 a1e:	69e6                	ld	s3,88(sp)
 a20:	6a46                	ld	s4,80(sp)
 a22:	6aa6                	ld	s5,72(sp)
 a24:	6b06                	ld	s6,64(sp)
 a26:	7be2                	ld	s7,56(sp)
 a28:	7c42                	ld	s8,48(sp)
 a2a:	7ca2                	ld	s9,40(sp)
 a2c:	7d02                	ld	s10,32(sp)
 a2e:	6de2                	ld	s11,24(sp)
 a30:	6109                	addi	sp,sp,128
 a32:	8082                	ret

0000000000000a34 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 a34:	715d                	addi	sp,sp,-80
 a36:	ec06                	sd	ra,24(sp)
 a38:	e822                	sd	s0,16(sp)
 a3a:	1000                	addi	s0,sp,32
 a3c:	e010                	sd	a2,0(s0)
 a3e:	e414                	sd	a3,8(s0)
 a40:	e818                	sd	a4,16(s0)
 a42:	ec1c                	sd	a5,24(s0)
 a44:	03043023          	sd	a6,32(s0)
 a48:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 a4c:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 a50:	8622                	mv	a2,s0
 a52:	d67ff0ef          	jal	ra,7b8 <vprintf>
}
 a56:	60e2                	ld	ra,24(sp)
 a58:	6442                	ld	s0,16(sp)
 a5a:	6161                	addi	sp,sp,80
 a5c:	8082                	ret

0000000000000a5e <printf>:

void
printf(const char *fmt, ...)
{
 a5e:	711d                	addi	sp,sp,-96
 a60:	ec06                	sd	ra,24(sp)
 a62:	e822                	sd	s0,16(sp)
 a64:	1000                	addi	s0,sp,32
 a66:	e40c                	sd	a1,8(s0)
 a68:	e810                	sd	a2,16(s0)
 a6a:	ec14                	sd	a3,24(s0)
 a6c:	f018                	sd	a4,32(s0)
 a6e:	f41c                	sd	a5,40(s0)
 a70:	03043823          	sd	a6,48(s0)
 a74:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 a78:	00840613          	addi	a2,s0,8
 a7c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a80:	85aa                	mv	a1,a0
 a82:	4505                	li	a0,1
 a84:	d35ff0ef          	jal	ra,7b8 <vprintf>
}
 a88:	60e2                	ld	ra,24(sp)
 a8a:	6442                	ld	s0,16(sp)
 a8c:	6125                	addi	sp,sp,96
 a8e:	8082                	ret

0000000000000a90 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a90:	1141                	addi	sp,sp,-16
 a92:	e422                	sd	s0,8(sp)
 a94:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a96:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a9a:	00000797          	auipc	a5,0x0
 a9e:	5767b783          	ld	a5,1398(a5) # 1010 <freep>
 aa2:	a805                	j	ad2 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 aa4:	4618                	lw	a4,8(a2)
 aa6:	9db9                	addw	a1,a1,a4
 aa8:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 aac:	6398                	ld	a4,0(a5)
 aae:	6318                	ld	a4,0(a4)
 ab0:	fee53823          	sd	a4,-16(a0)
 ab4:	a091                	j	af8 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 ab6:	ff852703          	lw	a4,-8(a0)
 aba:	9e39                	addw	a2,a2,a4
 abc:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 abe:	ff053703          	ld	a4,-16(a0)
 ac2:	e398                	sd	a4,0(a5)
 ac4:	a099                	j	b0a <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ac6:	6398                	ld	a4,0(a5)
 ac8:	00e7e463          	bltu	a5,a4,ad0 <free+0x40>
 acc:	00e6ea63          	bltu	a3,a4,ae0 <free+0x50>
{
 ad0:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ad2:	fed7fae3          	bgeu	a5,a3,ac6 <free+0x36>
 ad6:	6398                	ld	a4,0(a5)
 ad8:	00e6e463          	bltu	a3,a4,ae0 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 adc:	fee7eae3          	bltu	a5,a4,ad0 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 ae0:	ff852583          	lw	a1,-8(a0)
 ae4:	6390                	ld	a2,0(a5)
 ae6:	02059813          	slli	a6,a1,0x20
 aea:	01c85713          	srli	a4,a6,0x1c
 aee:	9736                	add	a4,a4,a3
 af0:	fae60ae3          	beq	a2,a4,aa4 <free+0x14>
    bp->s.ptr = p->s.ptr;
 af4:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 af8:	4790                	lw	a2,8(a5)
 afa:	02061593          	slli	a1,a2,0x20
 afe:	01c5d713          	srli	a4,a1,0x1c
 b02:	973e                	add	a4,a4,a5
 b04:	fae689e3          	beq	a3,a4,ab6 <free+0x26>
  } else
    p->s.ptr = bp;
 b08:	e394                	sd	a3,0(a5)
  freep = p;
 b0a:	00000717          	auipc	a4,0x0
 b0e:	50f73323          	sd	a5,1286(a4) # 1010 <freep>
}
 b12:	6422                	ld	s0,8(sp)
 b14:	0141                	addi	sp,sp,16
 b16:	8082                	ret

0000000000000b18 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 b18:	7139                	addi	sp,sp,-64
 b1a:	fc06                	sd	ra,56(sp)
 b1c:	f822                	sd	s0,48(sp)
 b1e:	f426                	sd	s1,40(sp)
 b20:	f04a                	sd	s2,32(sp)
 b22:	ec4e                	sd	s3,24(sp)
 b24:	e852                	sd	s4,16(sp)
 b26:	e456                	sd	s5,8(sp)
 b28:	e05a                	sd	s6,0(sp)
 b2a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 b2c:	02051493          	slli	s1,a0,0x20
 b30:	9081                	srli	s1,s1,0x20
 b32:	04bd                	addi	s1,s1,15
 b34:	8091                	srli	s1,s1,0x4
 b36:	0014899b          	addiw	s3,s1,1
 b3a:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 b3c:	00000517          	auipc	a0,0x0
 b40:	4d453503          	ld	a0,1236(a0) # 1010 <freep>
 b44:	c515                	beqz	a0,b70 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b46:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b48:	4798                	lw	a4,8(a5)
 b4a:	02977f63          	bgeu	a4,s1,b88 <malloc+0x70>
 b4e:	8a4e                	mv	s4,s3
 b50:	0009871b          	sext.w	a4,s3
 b54:	6685                	lui	a3,0x1
 b56:	00d77363          	bgeu	a4,a3,b5c <malloc+0x44>
 b5a:	6a05                	lui	s4,0x1
 b5c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 b60:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 b64:	00000917          	auipc	s2,0x0
 b68:	4ac90913          	addi	s2,s2,1196 # 1010 <freep>
  if(p == (char*)-1)
 b6c:	5afd                	li	s5,-1
 b6e:	a885                	j	bde <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 b70:	00000797          	auipc	a5,0x0
 b74:	4b078793          	addi	a5,a5,1200 # 1020 <base>
 b78:	00000717          	auipc	a4,0x0
 b7c:	48f73c23          	sd	a5,1176(a4) # 1010 <freep>
 b80:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b82:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b86:	b7e1                	j	b4e <malloc+0x36>
      if(p->s.size == nunits)
 b88:	02e48c63          	beq	s1,a4,bc0 <malloc+0xa8>
        p->s.size -= nunits;
 b8c:	4137073b          	subw	a4,a4,s3
 b90:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b92:	02071693          	slli	a3,a4,0x20
 b96:	01c6d713          	srli	a4,a3,0x1c
 b9a:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 b9c:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 ba0:	00000717          	auipc	a4,0x0
 ba4:	46a73823          	sd	a0,1136(a4) # 1010 <freep>
      return (void*)(p + 1);
 ba8:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 bac:	70e2                	ld	ra,56(sp)
 bae:	7442                	ld	s0,48(sp)
 bb0:	74a2                	ld	s1,40(sp)
 bb2:	7902                	ld	s2,32(sp)
 bb4:	69e2                	ld	s3,24(sp)
 bb6:	6a42                	ld	s4,16(sp)
 bb8:	6aa2                	ld	s5,8(sp)
 bba:	6b02                	ld	s6,0(sp)
 bbc:	6121                	addi	sp,sp,64
 bbe:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 bc0:	6398                	ld	a4,0(a5)
 bc2:	e118                	sd	a4,0(a0)
 bc4:	bff1                	j	ba0 <malloc+0x88>
  hp->s.size = nu;
 bc6:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 bca:	0541                	addi	a0,a0,16
 bcc:	ec5ff0ef          	jal	ra,a90 <free>
  return freep;
 bd0:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 bd4:	dd61                	beqz	a0,bac <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 bd6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 bd8:	4798                	lw	a4,8(a5)
 bda:	fa9777e3          	bgeu	a4,s1,b88 <malloc+0x70>
    if(p == freep)
 bde:	00093703          	ld	a4,0(s2)
 be2:	853e                	mv	a0,a5
 be4:	fef719e3          	bne	a4,a5,bd6 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 be8:	8552                	mv	a0,s4
 bea:	ab3ff0ef          	jal	ra,69c <sbrk>
  if(p == (char*)-1)
 bee:	fd551ce3          	bne	a0,s5,bc6 <malloc+0xae>
        return 0;
 bf2:	4501                	li	a0,0
 bf4:	bf65                	j	bac <malloc+0x94>
