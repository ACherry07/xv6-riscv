
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	de010113          	addi	sp,sp,-544 # 80018de0 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	60b040ef          	jal	ra,80004e20 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	03451793          	slli	a5,a0,0x34
    8000002c:	e7a9                	bnez	a5,80000076 <kfree+0x5a>
    8000002e:	84aa                	mv	s1,a0
    80000030:	00021797          	auipc	a5,0x21
    80000034:	eb078793          	addi	a5,a5,-336 # 80020ee0 <end>
    80000038:	02f56f63          	bltu	a0,a5,80000076 <kfree+0x5a>
    8000003c:	47c5                	li	a5,17
    8000003e:	07ee                	slli	a5,a5,0x1b
    80000040:	02f57b63          	bgeu	a0,a5,80000076 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000044:	6605                	lui	a2,0x1
    80000046:	4585                	li	a1,1
    80000048:	104000ef          	jal	ra,8000014c <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    8000004c:	00008917          	auipc	s2,0x8
    80000050:	96490913          	addi	s2,s2,-1692 # 800079b0 <kmem>
    80000054:	854a                	mv	a0,s2
    80000056:	7d4050ef          	jal	ra,8000582a <acquire>
  r->next = kmem.freelist;
    8000005a:	01893783          	ld	a5,24(s2)
    8000005e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000060:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000064:	854a                	mv	a0,s2
    80000066:	05d050ef          	jal	ra,800058c2 <release>
}
    8000006a:	60e2                	ld	ra,24(sp)
    8000006c:	6442                	ld	s0,16(sp)
    8000006e:	64a2                	ld	s1,8(sp)
    80000070:	6902                	ld	s2,0(sp)
    80000072:	6105                	addi	sp,sp,32
    80000074:	8082                	ret
    panic("kfree");
    80000076:	00007517          	auipc	a0,0x7
    8000007a:	f9a50513          	addi	a0,a0,-102 # 80007010 <etext+0x10>
    8000007e:	498050ef          	jal	ra,80005516 <panic>

0000000080000082 <freerange>:
{
    80000082:	7179                	addi	sp,sp,-48
    80000084:	f406                	sd	ra,40(sp)
    80000086:	f022                	sd	s0,32(sp)
    80000088:	ec26                	sd	s1,24(sp)
    8000008a:	e84a                	sd	s2,16(sp)
    8000008c:	e44e                	sd	s3,8(sp)
    8000008e:	e052                	sd	s4,0(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	94aa                	add	s1,s1,a0
    8000009a:	757d                	lui	a0,0xfffff
    8000009c:	8ce9                	and	s1,s1,a0
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    8000009e:	94be                	add	s1,s1,a5
    800000a0:	0095ec63          	bltu	a1,s1,800000b8 <freerange+0x36>
    800000a4:	892e                	mv	s2,a1
    kfree(p);
    800000a6:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a8:	6985                	lui	s3,0x1
    kfree(p);
    800000aa:	01448533          	add	a0,s1,s4
    800000ae:	f6fff0ef          	jal	ra,8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b2:	94ce                	add	s1,s1,s3
    800000b4:	fe997be3          	bgeu	s2,s1,800000aa <freerange+0x28>
}
    800000b8:	70a2                	ld	ra,40(sp)
    800000ba:	7402                	ld	s0,32(sp)
    800000bc:	64e2                	ld	s1,24(sp)
    800000be:	6942                	ld	s2,16(sp)
    800000c0:	69a2                	ld	s3,8(sp)
    800000c2:	6a02                	ld	s4,0(sp)
    800000c4:	6145                	addi	sp,sp,48
    800000c6:	8082                	ret

00000000800000c8 <kinit>:
{
    800000c8:	1141                	addi	sp,sp,-16
    800000ca:	e406                	sd	ra,8(sp)
    800000cc:	e022                	sd	s0,0(sp)
    800000ce:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d0:	00007597          	auipc	a1,0x7
    800000d4:	f4858593          	addi	a1,a1,-184 # 80007018 <etext+0x18>
    800000d8:	00008517          	auipc	a0,0x8
    800000dc:	8d850513          	addi	a0,a0,-1832 # 800079b0 <kmem>
    800000e0:	6ca050ef          	jal	ra,800057aa <initlock>
  freerange(end, (void*)PHYSTOP);
    800000e4:	45c5                	li	a1,17
    800000e6:	05ee                	slli	a1,a1,0x1b
    800000e8:	00021517          	auipc	a0,0x21
    800000ec:	df850513          	addi	a0,a0,-520 # 80020ee0 <end>
    800000f0:	f93ff0ef          	jal	ra,80000082 <freerange>
}
    800000f4:	60a2                	ld	ra,8(sp)
    800000f6:	6402                	ld	s0,0(sp)
    800000f8:	0141                	addi	sp,sp,16
    800000fa:	8082                	ret

00000000800000fc <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    800000fc:	1101                	addi	sp,sp,-32
    800000fe:	ec06                	sd	ra,24(sp)
    80000100:	e822                	sd	s0,16(sp)
    80000102:	e426                	sd	s1,8(sp)
    80000104:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000106:	00008497          	auipc	s1,0x8
    8000010a:	8aa48493          	addi	s1,s1,-1878 # 800079b0 <kmem>
    8000010e:	8526                	mv	a0,s1
    80000110:	71a050ef          	jal	ra,8000582a <acquire>
  r = kmem.freelist;
    80000114:	6c84                	ld	s1,24(s1)
  if(r)
    80000116:	c485                	beqz	s1,8000013e <kalloc+0x42>
    kmem.freelist = r->next;
    80000118:	609c                	ld	a5,0(s1)
    8000011a:	00008517          	auipc	a0,0x8
    8000011e:	89650513          	addi	a0,a0,-1898 # 800079b0 <kmem>
    80000122:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000124:	79e050ef          	jal	ra,800058c2 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000128:	6605                	lui	a2,0x1
    8000012a:	4595                	li	a1,5
    8000012c:	8526                	mv	a0,s1
    8000012e:	01e000ef          	jal	ra,8000014c <memset>
  return (void*)r;
}
    80000132:	8526                	mv	a0,s1
    80000134:	60e2                	ld	ra,24(sp)
    80000136:	6442                	ld	s0,16(sp)
    80000138:	64a2                	ld	s1,8(sp)
    8000013a:	6105                	addi	sp,sp,32
    8000013c:	8082                	ret
  release(&kmem.lock);
    8000013e:	00008517          	auipc	a0,0x8
    80000142:	87250513          	addi	a0,a0,-1934 # 800079b0 <kmem>
    80000146:	77c050ef          	jal	ra,800058c2 <release>
  if(r)
    8000014a:	b7e5                	j	80000132 <kalloc+0x36>

000000008000014c <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000014c:	1141                	addi	sp,sp,-16
    8000014e:	e422                	sd	s0,8(sp)
    80000150:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000152:	ca19                	beqz	a2,80000168 <memset+0x1c>
    80000154:	87aa                	mv	a5,a0
    80000156:	1602                	slli	a2,a2,0x20
    80000158:	9201                	srli	a2,a2,0x20
    8000015a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    8000015e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000162:	0785                	addi	a5,a5,1
    80000164:	fee79de3          	bne	a5,a4,8000015e <memset+0x12>
  }
  return dst;
}
    80000168:	6422                	ld	s0,8(sp)
    8000016a:	0141                	addi	sp,sp,16
    8000016c:	8082                	ret

000000008000016e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    8000016e:	1141                	addi	sp,sp,-16
    80000170:	e422                	sd	s0,8(sp)
    80000172:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000174:	ca05                	beqz	a2,800001a4 <memcmp+0x36>
    80000176:	fff6069b          	addiw	a3,a2,-1
    8000017a:	1682                	slli	a3,a3,0x20
    8000017c:	9281                	srli	a3,a3,0x20
    8000017e:	0685                	addi	a3,a3,1
    80000180:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000182:	00054783          	lbu	a5,0(a0)
    80000186:	0005c703          	lbu	a4,0(a1)
    8000018a:	00e79863          	bne	a5,a4,8000019a <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    8000018e:	0505                	addi	a0,a0,1
    80000190:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000192:	fed518e3          	bne	a0,a3,80000182 <memcmp+0x14>
  }

  return 0;
    80000196:	4501                	li	a0,0
    80000198:	a019                	j	8000019e <memcmp+0x30>
      return *s1 - *s2;
    8000019a:	40e7853b          	subw	a0,a5,a4
}
    8000019e:	6422                	ld	s0,8(sp)
    800001a0:	0141                	addi	sp,sp,16
    800001a2:	8082                	ret
  return 0;
    800001a4:	4501                	li	a0,0
    800001a6:	bfe5                	j	8000019e <memcmp+0x30>

00000000800001a8 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001a8:	1141                	addi	sp,sp,-16
    800001aa:	e422                	sd	s0,8(sp)
    800001ac:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001ae:	c205                	beqz	a2,800001ce <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001b0:	02a5e263          	bltu	a1,a0,800001d4 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001b4:	1602                	slli	a2,a2,0x20
    800001b6:	9201                	srli	a2,a2,0x20
    800001b8:	00c587b3          	add	a5,a1,a2
{
    800001bc:	872a                	mv	a4,a0
      *d++ = *s++;
    800001be:	0585                	addi	a1,a1,1
    800001c0:	0705                	addi	a4,a4,1
    800001c2:	fff5c683          	lbu	a3,-1(a1)
    800001c6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001ca:	fef59ae3          	bne	a1,a5,800001be <memmove+0x16>

  return dst;
}
    800001ce:	6422                	ld	s0,8(sp)
    800001d0:	0141                	addi	sp,sp,16
    800001d2:	8082                	ret
  if(s < d && s + n > d){
    800001d4:	02061693          	slli	a3,a2,0x20
    800001d8:	9281                	srli	a3,a3,0x20
    800001da:	00d58733          	add	a4,a1,a3
    800001de:	fce57be3          	bgeu	a0,a4,800001b4 <memmove+0xc>
    d += n;
    800001e2:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001e4:	fff6079b          	addiw	a5,a2,-1
    800001e8:	1782                	slli	a5,a5,0x20
    800001ea:	9381                	srli	a5,a5,0x20
    800001ec:	fff7c793          	not	a5,a5
    800001f0:	97ba                	add	a5,a5,a4
      *--d = *--s;
    800001f2:	177d                	addi	a4,a4,-1
    800001f4:	16fd                	addi	a3,a3,-1
    800001f6:	00074603          	lbu	a2,0(a4)
    800001fa:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    800001fe:	fee79ae3          	bne	a5,a4,800001f2 <memmove+0x4a>
    80000202:	b7f1                	j	800001ce <memmove+0x26>

0000000080000204 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000204:	1141                	addi	sp,sp,-16
    80000206:	e406                	sd	ra,8(sp)
    80000208:	e022                	sd	s0,0(sp)
    8000020a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    8000020c:	f9dff0ef          	jal	ra,800001a8 <memmove>
}
    80000210:	60a2                	ld	ra,8(sp)
    80000212:	6402                	ld	s0,0(sp)
    80000214:	0141                	addi	sp,sp,16
    80000216:	8082                	ret

0000000080000218 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000218:	1141                	addi	sp,sp,-16
    8000021a:	e422                	sd	s0,8(sp)
    8000021c:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000021e:	ce11                	beqz	a2,8000023a <strncmp+0x22>
    80000220:	00054783          	lbu	a5,0(a0)
    80000224:	cf89                	beqz	a5,8000023e <strncmp+0x26>
    80000226:	0005c703          	lbu	a4,0(a1)
    8000022a:	00f71a63          	bne	a4,a5,8000023e <strncmp+0x26>
    n--, p++, q++;
    8000022e:	367d                	addiw	a2,a2,-1
    80000230:	0505                	addi	a0,a0,1
    80000232:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000234:	f675                	bnez	a2,80000220 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000236:	4501                	li	a0,0
    80000238:	a809                	j	8000024a <strncmp+0x32>
    8000023a:	4501                	li	a0,0
    8000023c:	a039                	j	8000024a <strncmp+0x32>
  if(n == 0)
    8000023e:	ca09                	beqz	a2,80000250 <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000240:	00054503          	lbu	a0,0(a0)
    80000244:	0005c783          	lbu	a5,0(a1)
    80000248:	9d1d                	subw	a0,a0,a5
}
    8000024a:	6422                	ld	s0,8(sp)
    8000024c:	0141                	addi	sp,sp,16
    8000024e:	8082                	ret
    return 0;
    80000250:	4501                	li	a0,0
    80000252:	bfe5                	j	8000024a <strncmp+0x32>

0000000080000254 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000254:	1141                	addi	sp,sp,-16
    80000256:	e422                	sd	s0,8(sp)
    80000258:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    8000025a:	872a                	mv	a4,a0
    8000025c:	8832                	mv	a6,a2
    8000025e:	367d                	addiw	a2,a2,-1
    80000260:	01005963          	blez	a6,80000272 <strncpy+0x1e>
    80000264:	0705                	addi	a4,a4,1
    80000266:	0005c783          	lbu	a5,0(a1)
    8000026a:	fef70fa3          	sb	a5,-1(a4)
    8000026e:	0585                	addi	a1,a1,1
    80000270:	f7f5                	bnez	a5,8000025c <strncpy+0x8>
    ;
  while(n-- > 0)
    80000272:	86ba                	mv	a3,a4
    80000274:	00c05c63          	blez	a2,8000028c <strncpy+0x38>
    *s++ = 0;
    80000278:	0685                	addi	a3,a3,1
    8000027a:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    8000027e:	fff6c793          	not	a5,a3
    80000282:	9fb9                	addw	a5,a5,a4
    80000284:	010787bb          	addw	a5,a5,a6
    80000288:	fef048e3          	bgtz	a5,80000278 <strncpy+0x24>
  return os;
}
    8000028c:	6422                	ld	s0,8(sp)
    8000028e:	0141                	addi	sp,sp,16
    80000290:	8082                	ret

0000000080000292 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000292:	1141                	addi	sp,sp,-16
    80000294:	e422                	sd	s0,8(sp)
    80000296:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000298:	02c05363          	blez	a2,800002be <safestrcpy+0x2c>
    8000029c:	fff6069b          	addiw	a3,a2,-1
    800002a0:	1682                	slli	a3,a3,0x20
    800002a2:	9281                	srli	a3,a3,0x20
    800002a4:	96ae                	add	a3,a3,a1
    800002a6:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002a8:	00d58963          	beq	a1,a3,800002ba <safestrcpy+0x28>
    800002ac:	0585                	addi	a1,a1,1
    800002ae:	0785                	addi	a5,a5,1
    800002b0:	fff5c703          	lbu	a4,-1(a1)
    800002b4:	fee78fa3          	sb	a4,-1(a5)
    800002b8:	fb65                	bnez	a4,800002a8 <safestrcpy+0x16>
    ;
  *s = 0;
    800002ba:	00078023          	sb	zero,0(a5)
  return os;
}
    800002be:	6422                	ld	s0,8(sp)
    800002c0:	0141                	addi	sp,sp,16
    800002c2:	8082                	ret

00000000800002c4 <strlen>:

int
strlen(const char *s)
{
    800002c4:	1141                	addi	sp,sp,-16
    800002c6:	e422                	sd	s0,8(sp)
    800002c8:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002ca:	00054783          	lbu	a5,0(a0)
    800002ce:	cf91                	beqz	a5,800002ea <strlen+0x26>
    800002d0:	0505                	addi	a0,a0,1
    800002d2:	87aa                	mv	a5,a0
    800002d4:	4685                	li	a3,1
    800002d6:	9e89                	subw	a3,a3,a0
    800002d8:	00f6853b          	addw	a0,a3,a5
    800002dc:	0785                	addi	a5,a5,1
    800002de:	fff7c703          	lbu	a4,-1(a5)
    800002e2:	fb7d                	bnez	a4,800002d8 <strlen+0x14>
    ;
  return n;
}
    800002e4:	6422                	ld	s0,8(sp)
    800002e6:	0141                	addi	sp,sp,16
    800002e8:	8082                	ret
  for(n = 0; s[n]; n++)
    800002ea:	4501                	li	a0,0
    800002ec:	bfe5                	j	800002e4 <strlen+0x20>

00000000800002ee <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    800002ee:	1141                	addi	sp,sp,-16
    800002f0:	e406                	sd	ra,8(sp)
    800002f2:	e022                	sd	s0,0(sp)
    800002f4:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800002f6:	2f9000ef          	jal	ra,80000dee <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    800002fa:	00007717          	auipc	a4,0x7
    800002fe:	68670713          	addi	a4,a4,1670 # 80007980 <started>
  if(cpuid() == 0){
    80000302:	c51d                	beqz	a0,80000330 <main+0x42>
    while(started == 0)
    80000304:	431c                	lw	a5,0(a4)
    80000306:	2781                	sext.w	a5,a5
    80000308:	dff5                	beqz	a5,80000304 <main+0x16>
      ;
    __sync_synchronize();
    8000030a:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    8000030e:	2e1000ef          	jal	ra,80000dee <cpuid>
    80000312:	85aa                	mv	a1,a0
    80000314:	00007517          	auipc	a0,0x7
    80000318:	d2450513          	addi	a0,a0,-732 # 80007038 <etext+0x38>
    8000031c:	747040ef          	jal	ra,80005262 <printf>
    kvminithart();    // turn on paging
    80000320:	080000ef          	jal	ra,800003a0 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000324:	66e010ef          	jal	ra,80001992 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000328:	54c040ef          	jal	ra,80004874 <plicinithart>
  }

  scheduler();        
    8000032c:	7ab000ef          	jal	ra,800012d6 <scheduler>
    consoleinit();
    80000330:	65b040ef          	jal	ra,8000518a <consoleinit>
    printfinit();
    80000334:	21c050ef          	jal	ra,80005550 <printfinit>
    printf("\n");
    80000338:	00007517          	auipc	a0,0x7
    8000033c:	d1050513          	addi	a0,a0,-752 # 80007048 <etext+0x48>
    80000340:	723040ef          	jal	ra,80005262 <printf>
    printf("xv6 kernel is booting\n");
    80000344:	00007517          	auipc	a0,0x7
    80000348:	cdc50513          	addi	a0,a0,-804 # 80007020 <etext+0x20>
    8000034c:	717040ef          	jal	ra,80005262 <printf>
    printf("\n");
    80000350:	00007517          	auipc	a0,0x7
    80000354:	cf850513          	addi	a0,a0,-776 # 80007048 <etext+0x48>
    80000358:	70b040ef          	jal	ra,80005262 <printf>
    kinit();         // physical page allocator
    8000035c:	d6dff0ef          	jal	ra,800000c8 <kinit>
    kvminit();       // create kernel page table
    80000360:	2d2000ef          	jal	ra,80000632 <kvminit>
    kvminithart();   // turn on paging
    80000364:	03c000ef          	jal	ra,800003a0 <kvminithart>
    procinit();      // process table
    80000368:	1e1000ef          	jal	ra,80000d48 <procinit>
    trapinit();      // trap vectors
    8000036c:	602010ef          	jal	ra,8000196e <trapinit>
    trapinithart();  // install kernel trap vector
    80000370:	622010ef          	jal	ra,80001992 <trapinithart>
    plicinit();      // set up interrupt controller
    80000374:	4ea040ef          	jal	ra,8000485e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000378:	4fc040ef          	jal	ra,80004874 <plicinithart>
    binit();         // buffer cache
    8000037c:	563010ef          	jal	ra,800020de <binit>
    iinit();         // inode table
    80000380:	344020ef          	jal	ra,800026c4 <iinit>
    fileinit();      // file table
    80000384:	0e2030ef          	jal	ra,80003466 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000388:	5dc040ef          	jal	ra,80004964 <virtio_disk_init>
    userinit();      // first user process
    8000038c:	581000ef          	jal	ra,8000110c <userinit>
    __sync_synchronize();
    80000390:	0ff0000f          	fence
    started = 1;
    80000394:	4785                	li	a5,1
    80000396:	00007717          	auipc	a4,0x7
    8000039a:	5ef72523          	sw	a5,1514(a4) # 80007980 <started>
    8000039e:	b779                	j	8000032c <main+0x3e>

00000000800003a0 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    800003a0:	1141                	addi	sp,sp,-16
    800003a2:	e422                	sd	s0,8(sp)
    800003a4:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800003a6:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800003aa:	00007797          	auipc	a5,0x7
    800003ae:	5de7b783          	ld	a5,1502(a5) # 80007988 <kernel_pagetable>
    800003b2:	83b1                	srli	a5,a5,0xc
    800003b4:	577d                	li	a4,-1
    800003b6:	177e                	slli	a4,a4,0x3f
    800003b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800003ba:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800003be:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800003c2:	6422                	ld	s0,8(sp)
    800003c4:	0141                	addi	sp,sp,16
    800003c6:	8082                	ret

00000000800003c8 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800003c8:	7139                	addi	sp,sp,-64
    800003ca:	fc06                	sd	ra,56(sp)
    800003cc:	f822                	sd	s0,48(sp)
    800003ce:	f426                	sd	s1,40(sp)
    800003d0:	f04a                	sd	s2,32(sp)
    800003d2:	ec4e                	sd	s3,24(sp)
    800003d4:	e852                	sd	s4,16(sp)
    800003d6:	e456                	sd	s5,8(sp)
    800003d8:	e05a                	sd	s6,0(sp)
    800003da:	0080                	addi	s0,sp,64
    800003dc:	892a                	mv	s2,a0
    800003de:	89ae                	mv	s3,a1
    800003e0:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    800003e2:	57fd                	li	a5,-1
    800003e4:	83e9                	srli	a5,a5,0x1a
    800003e6:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    800003e8:	4b31                	li	s6,12
  if(va >= MAXVA)
    800003ea:	02b7fb63          	bgeu	a5,a1,80000420 <walk+0x58>
    panic("walk");
    800003ee:	00007517          	auipc	a0,0x7
    800003f2:	c6250513          	addi	a0,a0,-926 # 80007050 <etext+0x50>
    800003f6:	120050ef          	jal	ra,80005516 <panic>
      if(PTE_LEAF(*pte)) {
        return pte;
      }
#endif
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    800003fa:	060a8463          	beqz	s5,80000462 <walk+0x9a>
    800003fe:	cffff0ef          	jal	ra,800000fc <kalloc>
    80000402:	892a                	mv	s2,a0
    80000404:	c12d                	beqz	a0,80000466 <walk+0x9e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000406:	6605                	lui	a2,0x1
    80000408:	4581                	li	a1,0
    8000040a:	d43ff0ef          	jal	ra,8000014c <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000040e:	00c95793          	srli	a5,s2,0xc
    80000412:	07aa                	slli	a5,a5,0xa
    80000414:	0017e793          	ori	a5,a5,1
    80000418:	e09c                	sd	a5,0(s1)
  for(int level = 2; level > 0; level--) {
    8000041a:	3a5d                	addiw	s4,s4,-9
    8000041c:	036a0263          	beq	s4,s6,80000440 <walk+0x78>
    pte_t *pte = &pagetable[PX(level, va)];
    80000420:	0149d4b3          	srl	s1,s3,s4
    80000424:	1ff4f493          	andi	s1,s1,511
    80000428:	048e                	slli	s1,s1,0x3
    8000042a:	94ca                	add	s1,s1,s2
    if(*pte & PTE_V) {
    8000042c:	609c                	ld	a5,0(s1)
    8000042e:	0017f713          	andi	a4,a5,1
    80000432:	d761                	beqz	a4,800003fa <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000434:	00a7d913          	srli	s2,a5,0xa
    80000438:	0932                	slli	s2,s2,0xc
      if(PTE_LEAF(*pte)) {
    8000043a:	8bb9                	andi	a5,a5,14
    8000043c:	dff9                	beqz	a5,8000041a <walk+0x52>
    8000043e:	a039                	j	8000044c <walk+0x84>
    }
  }
  return &pagetable[PX(0, va)];
    80000440:	00c9d493          	srli	s1,s3,0xc
    80000444:	1ff4f493          	andi	s1,s1,511
    80000448:	048e                	slli	s1,s1,0x3
    8000044a:	94ca                	add	s1,s1,s2
}
    8000044c:	8526                	mv	a0,s1
    8000044e:	70e2                	ld	ra,56(sp)
    80000450:	7442                	ld	s0,48(sp)
    80000452:	74a2                	ld	s1,40(sp)
    80000454:	7902                	ld	s2,32(sp)
    80000456:	69e2                	ld	s3,24(sp)
    80000458:	6a42                	ld	s4,16(sp)
    8000045a:	6aa2                	ld	s5,8(sp)
    8000045c:	6b02                	ld	s6,0(sp)
    8000045e:	6121                	addi	sp,sp,64
    80000460:	8082                	ret
        return 0;
    80000462:	4481                	li	s1,0
    80000464:	b7e5                	j	8000044c <walk+0x84>
    80000466:	84aa                	mv	s1,a0
    80000468:	b7d5                	j	8000044c <walk+0x84>

000000008000046a <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000046a:	57fd                	li	a5,-1
    8000046c:	83e9                	srli	a5,a5,0x1a
    8000046e:	00b7f463          	bgeu	a5,a1,80000476 <walkaddr+0xc>
    return 0;
    80000472:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000474:	8082                	ret
{
    80000476:	1141                	addi	sp,sp,-16
    80000478:	e406                	sd	ra,8(sp)
    8000047a:	e022                	sd	s0,0(sp)
    8000047c:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000047e:	4601                	li	a2,0
    80000480:	f49ff0ef          	jal	ra,800003c8 <walk>
  if(pte == 0)
    80000484:	c105                	beqz	a0,800004a4 <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000486:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000488:	0117f693          	andi	a3,a5,17
    8000048c:	4745                	li	a4,17
    return 0;
    8000048e:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000490:	00e68663          	beq	a3,a4,8000049c <walkaddr+0x32>
}
    80000494:	60a2                	ld	ra,8(sp)
    80000496:	6402                	ld	s0,0(sp)
    80000498:	0141                	addi	sp,sp,16
    8000049a:	8082                	ret
  pa = PTE2PA(*pte);
    8000049c:	00a7d513          	srli	a0,a5,0xa
    800004a0:	0532                	slli	a0,a0,0xc
  return pa;
    800004a2:	bfcd                	j	80000494 <walkaddr+0x2a>
    return 0;
    800004a4:	4501                	li	a0,0
    800004a6:	b7fd                	j	80000494 <walkaddr+0x2a>

00000000800004a8 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800004a8:	715d                	addi	sp,sp,-80
    800004aa:	e486                	sd	ra,72(sp)
    800004ac:	e0a2                	sd	s0,64(sp)
    800004ae:	fc26                	sd	s1,56(sp)
    800004b0:	f84a                	sd	s2,48(sp)
    800004b2:	f44e                	sd	s3,40(sp)
    800004b4:	f052                	sd	s4,32(sp)
    800004b6:	ec56                	sd	s5,24(sp)
    800004b8:	e85a                	sd	s6,16(sp)
    800004ba:	e45e                	sd	s7,8(sp)
    800004bc:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800004be:	03459793          	slli	a5,a1,0x34
    800004c2:	e7a9                	bnez	a5,8000050c <mappages+0x64>
    800004c4:	8aaa                	mv	s5,a0
    800004c6:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800004c8:	03461793          	slli	a5,a2,0x34
    800004cc:	e7b1                	bnez	a5,80000518 <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    800004ce:	ca39                	beqz	a2,80000524 <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800004d0:	79fd                	lui	s3,0xfffff
    800004d2:	964e                	add	a2,a2,s3
    800004d4:	00b609b3          	add	s3,a2,a1
  a = va;
    800004d8:	892e                	mv	s2,a1
    800004da:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800004de:	6b85                	lui	s7,0x1
    800004e0:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    800004e4:	4605                	li	a2,1
    800004e6:	85ca                	mv	a1,s2
    800004e8:	8556                	mv	a0,s5
    800004ea:	edfff0ef          	jal	ra,800003c8 <walk>
    800004ee:	c539                	beqz	a0,8000053c <mappages+0x94>
    if(*pte & PTE_V)
    800004f0:	611c                	ld	a5,0(a0)
    800004f2:	8b85                	andi	a5,a5,1
    800004f4:	ef95                	bnez	a5,80000530 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800004f6:	80b1                	srli	s1,s1,0xc
    800004f8:	04aa                	slli	s1,s1,0xa
    800004fa:	0164e4b3          	or	s1,s1,s6
    800004fe:	0014e493          	ori	s1,s1,1
    80000502:	e104                	sd	s1,0(a0)
    if(a == last)
    80000504:	05390863          	beq	s2,s3,80000554 <mappages+0xac>
    a += PGSIZE;
    80000508:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    8000050a:	bfd9                	j	800004e0 <mappages+0x38>
    panic("mappages: va not aligned");
    8000050c:	00007517          	auipc	a0,0x7
    80000510:	b4c50513          	addi	a0,a0,-1204 # 80007058 <etext+0x58>
    80000514:	002050ef          	jal	ra,80005516 <panic>
    panic("mappages: size not aligned");
    80000518:	00007517          	auipc	a0,0x7
    8000051c:	b6050513          	addi	a0,a0,-1184 # 80007078 <etext+0x78>
    80000520:	7f7040ef          	jal	ra,80005516 <panic>
    panic("mappages: size");
    80000524:	00007517          	auipc	a0,0x7
    80000528:	b7450513          	addi	a0,a0,-1164 # 80007098 <etext+0x98>
    8000052c:	7eb040ef          	jal	ra,80005516 <panic>
      panic("mappages: remap");
    80000530:	00007517          	auipc	a0,0x7
    80000534:	b7850513          	addi	a0,a0,-1160 # 800070a8 <etext+0xa8>
    80000538:	7df040ef          	jal	ra,80005516 <panic>
      return -1;
    8000053c:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000053e:	60a6                	ld	ra,72(sp)
    80000540:	6406                	ld	s0,64(sp)
    80000542:	74e2                	ld	s1,56(sp)
    80000544:	7942                	ld	s2,48(sp)
    80000546:	79a2                	ld	s3,40(sp)
    80000548:	7a02                	ld	s4,32(sp)
    8000054a:	6ae2                	ld	s5,24(sp)
    8000054c:	6b42                	ld	s6,16(sp)
    8000054e:	6ba2                	ld	s7,8(sp)
    80000550:	6161                	addi	sp,sp,80
    80000552:	8082                	ret
  return 0;
    80000554:	4501                	li	a0,0
    80000556:	b7e5                	j	8000053e <mappages+0x96>

0000000080000558 <kvmmap>:
{
    80000558:	1141                	addi	sp,sp,-16
    8000055a:	e406                	sd	ra,8(sp)
    8000055c:	e022                	sd	s0,0(sp)
    8000055e:	0800                	addi	s0,sp,16
    80000560:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000562:	86b2                	mv	a3,a2
    80000564:	863e                	mv	a2,a5
    80000566:	f43ff0ef          	jal	ra,800004a8 <mappages>
    8000056a:	e509                	bnez	a0,80000574 <kvmmap+0x1c>
}
    8000056c:	60a2                	ld	ra,8(sp)
    8000056e:	6402                	ld	s0,0(sp)
    80000570:	0141                	addi	sp,sp,16
    80000572:	8082                	ret
    panic("kvmmap");
    80000574:	00007517          	auipc	a0,0x7
    80000578:	b4450513          	addi	a0,a0,-1212 # 800070b8 <etext+0xb8>
    8000057c:	79b040ef          	jal	ra,80005516 <panic>

0000000080000580 <kvmmake>:
{
    80000580:	1101                	addi	sp,sp,-32
    80000582:	ec06                	sd	ra,24(sp)
    80000584:	e822                	sd	s0,16(sp)
    80000586:	e426                	sd	s1,8(sp)
    80000588:	e04a                	sd	s2,0(sp)
    8000058a:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000058c:	b71ff0ef          	jal	ra,800000fc <kalloc>
    80000590:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000592:	6605                	lui	a2,0x1
    80000594:	4581                	li	a1,0
    80000596:	bb7ff0ef          	jal	ra,8000014c <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000059a:	4719                	li	a4,6
    8000059c:	6685                	lui	a3,0x1
    8000059e:	10000637          	lui	a2,0x10000
    800005a2:	100005b7          	lui	a1,0x10000
    800005a6:	8526                	mv	a0,s1
    800005a8:	fb1ff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800005ac:	4719                	li	a4,6
    800005ae:	6685                	lui	a3,0x1
    800005b0:	10001637          	lui	a2,0x10001
    800005b4:	100015b7          	lui	a1,0x10001
    800005b8:	8526                	mv	a0,s1
    800005ba:	f9fff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800005be:	4719                	li	a4,6
    800005c0:	040006b7          	lui	a3,0x4000
    800005c4:	0c000637          	lui	a2,0xc000
    800005c8:	0c0005b7          	lui	a1,0xc000
    800005cc:	8526                	mv	a0,s1
    800005ce:	f8bff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800005d2:	00007917          	auipc	s2,0x7
    800005d6:	a2e90913          	addi	s2,s2,-1490 # 80007000 <etext>
    800005da:	4729                	li	a4,10
    800005dc:	80007697          	auipc	a3,0x80007
    800005e0:	a2468693          	addi	a3,a3,-1500 # 7000 <_entry-0x7fff9000>
    800005e4:	4605                	li	a2,1
    800005e6:	067e                	slli	a2,a2,0x1f
    800005e8:	85b2                	mv	a1,a2
    800005ea:	8526                	mv	a0,s1
    800005ec:	f6dff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800005f0:	4719                	li	a4,6
    800005f2:	46c5                	li	a3,17
    800005f4:	06ee                	slli	a3,a3,0x1b
    800005f6:	412686b3          	sub	a3,a3,s2
    800005fa:	864a                	mv	a2,s2
    800005fc:	85ca                	mv	a1,s2
    800005fe:	8526                	mv	a0,s1
    80000600:	f59ff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80000604:	4729                	li	a4,10
    80000606:	6685                	lui	a3,0x1
    80000608:	00006617          	auipc	a2,0x6
    8000060c:	9f860613          	addi	a2,a2,-1544 # 80006000 <_trampoline>
    80000610:	040005b7          	lui	a1,0x4000
    80000614:	15fd                	addi	a1,a1,-1
    80000616:	05b2                	slli	a1,a1,0xc
    80000618:	8526                	mv	a0,s1
    8000061a:	f3fff0ef          	jal	ra,80000558 <kvmmap>
  proc_mapstacks(kpgtbl);
    8000061e:	8526                	mv	a0,s1
    80000620:	6a0000ef          	jal	ra,80000cc0 <proc_mapstacks>
}
    80000624:	8526                	mv	a0,s1
    80000626:	60e2                	ld	ra,24(sp)
    80000628:	6442                	ld	s0,16(sp)
    8000062a:	64a2                	ld	s1,8(sp)
    8000062c:	6902                	ld	s2,0(sp)
    8000062e:	6105                	addi	sp,sp,32
    80000630:	8082                	ret

0000000080000632 <kvminit>:
{
    80000632:	1141                	addi	sp,sp,-16
    80000634:	e406                	sd	ra,8(sp)
    80000636:	e022                	sd	s0,0(sp)
    80000638:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000063a:	f47ff0ef          	jal	ra,80000580 <kvmmake>
    8000063e:	00007797          	auipc	a5,0x7
    80000642:	34a7b523          	sd	a0,842(a5) # 80007988 <kernel_pagetable>
}
    80000646:	60a2                	ld	ra,8(sp)
    80000648:	6402                	ld	s0,0(sp)
    8000064a:	0141                	addi	sp,sp,16
    8000064c:	8082                	ret

000000008000064e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000064e:	715d                	addi	sp,sp,-80
    80000650:	e486                	sd	ra,72(sp)
    80000652:	e0a2                	sd	s0,64(sp)
    80000654:	fc26                	sd	s1,56(sp)
    80000656:	f84a                	sd	s2,48(sp)
    80000658:	f44e                	sd	s3,40(sp)
    8000065a:	f052                	sd	s4,32(sp)
    8000065c:	ec56                	sd	s5,24(sp)
    8000065e:	e85a                	sd	s6,16(sp)
    80000660:	e45e                	sd	s7,8(sp)
    80000662:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;
  int sz;

  if((va % PGSIZE) != 0)
    80000664:	03459793          	slli	a5,a1,0x34
    80000668:	e795                	bnez	a5,80000694 <uvmunmap+0x46>
    8000066a:	8a2a                	mv	s4,a0
    8000066c:	892e                	mv	s2,a1
    8000066e:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000670:	0632                	slli	a2,a2,0xc
    80000672:	00b609b3          	add	s3,a2,a1
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0) {
      printf("va=%ld pte=%ld\n", a, *pte);
      panic("uvmunmap: not mapped");
    }
    if(PTE_FLAGS(*pte) == PTE_V)
    80000676:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000678:	6b05                	lui	s6,0x1
    8000067a:	0735e163          	bltu	a1,s3,800006dc <uvmunmap+0x8e>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    8000067e:	60a6                	ld	ra,72(sp)
    80000680:	6406                	ld	s0,64(sp)
    80000682:	74e2                	ld	s1,56(sp)
    80000684:	7942                	ld	s2,48(sp)
    80000686:	79a2                	ld	s3,40(sp)
    80000688:	7a02                	ld	s4,32(sp)
    8000068a:	6ae2                	ld	s5,24(sp)
    8000068c:	6b42                	ld	s6,16(sp)
    8000068e:	6ba2                	ld	s7,8(sp)
    80000690:	6161                	addi	sp,sp,80
    80000692:	8082                	ret
    panic("uvmunmap: not aligned");
    80000694:	00007517          	auipc	a0,0x7
    80000698:	a2c50513          	addi	a0,a0,-1492 # 800070c0 <etext+0xc0>
    8000069c:	67b040ef          	jal	ra,80005516 <panic>
      panic("uvmunmap: walk");
    800006a0:	00007517          	auipc	a0,0x7
    800006a4:	a3850513          	addi	a0,a0,-1480 # 800070d8 <etext+0xd8>
    800006a8:	66f040ef          	jal	ra,80005516 <panic>
      printf("va=%ld pte=%ld\n", a, *pte);
    800006ac:	85ca                	mv	a1,s2
    800006ae:	00007517          	auipc	a0,0x7
    800006b2:	a3a50513          	addi	a0,a0,-1478 # 800070e8 <etext+0xe8>
    800006b6:	3ad040ef          	jal	ra,80005262 <printf>
      panic("uvmunmap: not mapped");
    800006ba:	00007517          	auipc	a0,0x7
    800006be:	a3e50513          	addi	a0,a0,-1474 # 800070f8 <etext+0xf8>
    800006c2:	655040ef          	jal	ra,80005516 <panic>
      panic("uvmunmap: not a leaf");
    800006c6:	00007517          	auipc	a0,0x7
    800006ca:	a4a50513          	addi	a0,a0,-1462 # 80007110 <etext+0x110>
    800006ce:	649040ef          	jal	ra,80005516 <panic>
    *pte = 0;
    800006d2:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += sz){
    800006d6:	995a                	add	s2,s2,s6
    800006d8:	fb3973e3          	bgeu	s2,s3,8000067e <uvmunmap+0x30>
    if((pte = walk(pagetable, a, 0)) == 0)
    800006dc:	4601                	li	a2,0
    800006de:	85ca                	mv	a1,s2
    800006e0:	8552                	mv	a0,s4
    800006e2:	ce7ff0ef          	jal	ra,800003c8 <walk>
    800006e6:	84aa                	mv	s1,a0
    800006e8:	dd45                	beqz	a0,800006a0 <uvmunmap+0x52>
    if((*pte & PTE_V) == 0) {
    800006ea:	6110                	ld	a2,0(a0)
    800006ec:	00167793          	andi	a5,a2,1
    800006f0:	dfd5                	beqz	a5,800006ac <uvmunmap+0x5e>
    if(PTE_FLAGS(*pte) == PTE_V)
    800006f2:	3ff67793          	andi	a5,a2,1023
    800006f6:	fd7788e3          	beq	a5,s7,800006c6 <uvmunmap+0x78>
    if(do_free){
    800006fa:	fc0a8ce3          	beqz	s5,800006d2 <uvmunmap+0x84>
      uint64 pa = PTE2PA(*pte);
    800006fe:	8229                	srli	a2,a2,0xa
      kfree((void*)pa);
    80000700:	00c61513          	slli	a0,a2,0xc
    80000704:	919ff0ef          	jal	ra,8000001c <kfree>
    80000708:	b7e9                	j	800006d2 <uvmunmap+0x84>

000000008000070a <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000070a:	1101                	addi	sp,sp,-32
    8000070c:	ec06                	sd	ra,24(sp)
    8000070e:	e822                	sd	s0,16(sp)
    80000710:	e426                	sd	s1,8(sp)
    80000712:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000714:	9e9ff0ef          	jal	ra,800000fc <kalloc>
    80000718:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000071a:	c509                	beqz	a0,80000724 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000071c:	6605                	lui	a2,0x1
    8000071e:	4581                	li	a1,0
    80000720:	a2dff0ef          	jal	ra,8000014c <memset>
  return pagetable;
}
    80000724:	8526                	mv	a0,s1
    80000726:	60e2                	ld	ra,24(sp)
    80000728:	6442                	ld	s0,16(sp)
    8000072a:	64a2                	ld	s1,8(sp)
    8000072c:	6105                	addi	sp,sp,32
    8000072e:	8082                	ret

0000000080000730 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80000730:	7179                	addi	sp,sp,-48
    80000732:	f406                	sd	ra,40(sp)
    80000734:	f022                	sd	s0,32(sp)
    80000736:	ec26                	sd	s1,24(sp)
    80000738:	e84a                	sd	s2,16(sp)
    8000073a:	e44e                	sd	s3,8(sp)
    8000073c:	e052                	sd	s4,0(sp)
    8000073e:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80000740:	6785                	lui	a5,0x1
    80000742:	04f67063          	bgeu	a2,a5,80000782 <uvmfirst+0x52>
    80000746:	8a2a                	mv	s4,a0
    80000748:	89ae                	mv	s3,a1
    8000074a:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    8000074c:	9b1ff0ef          	jal	ra,800000fc <kalloc>
    80000750:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000752:	6605                	lui	a2,0x1
    80000754:	4581                	li	a1,0
    80000756:	9f7ff0ef          	jal	ra,8000014c <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    8000075a:	4779                	li	a4,30
    8000075c:	86ca                	mv	a3,s2
    8000075e:	6605                	lui	a2,0x1
    80000760:	4581                	li	a1,0
    80000762:	8552                	mv	a0,s4
    80000764:	d45ff0ef          	jal	ra,800004a8 <mappages>
  memmove(mem, src, sz);
    80000768:	8626                	mv	a2,s1
    8000076a:	85ce                	mv	a1,s3
    8000076c:	854a                	mv	a0,s2
    8000076e:	a3bff0ef          	jal	ra,800001a8 <memmove>
}
    80000772:	70a2                	ld	ra,40(sp)
    80000774:	7402                	ld	s0,32(sp)
    80000776:	64e2                	ld	s1,24(sp)
    80000778:	6942                	ld	s2,16(sp)
    8000077a:	69a2                	ld	s3,8(sp)
    8000077c:	6a02                	ld	s4,0(sp)
    8000077e:	6145                	addi	sp,sp,48
    80000780:	8082                	ret
    panic("uvmfirst: more than a page");
    80000782:	00007517          	auipc	a0,0x7
    80000786:	9a650513          	addi	a0,a0,-1626 # 80007128 <etext+0x128>
    8000078a:	58d040ef          	jal	ra,80005516 <panic>

000000008000078e <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000078e:	1101                	addi	sp,sp,-32
    80000790:	ec06                	sd	ra,24(sp)
    80000792:	e822                	sd	s0,16(sp)
    80000794:	e426                	sd	s1,8(sp)
    80000796:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80000798:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000079a:	00b67d63          	bgeu	a2,a1,800007b4 <uvmdealloc+0x26>
    8000079e:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800007a0:	6785                	lui	a5,0x1
    800007a2:	17fd                	addi	a5,a5,-1
    800007a4:	00f60733          	add	a4,a2,a5
    800007a8:	767d                	lui	a2,0xfffff
    800007aa:	8f71                	and	a4,a4,a2
    800007ac:	97ae                	add	a5,a5,a1
    800007ae:	8ff1                	and	a5,a5,a2
    800007b0:	00f76863          	bltu	a4,a5,800007c0 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800007b4:	8526                	mv	a0,s1
    800007b6:	60e2                	ld	ra,24(sp)
    800007b8:	6442                	ld	s0,16(sp)
    800007ba:	64a2                	ld	s1,8(sp)
    800007bc:	6105                	addi	sp,sp,32
    800007be:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800007c0:	8f99                	sub	a5,a5,a4
    800007c2:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800007c4:	4685                	li	a3,1
    800007c6:	0007861b          	sext.w	a2,a5
    800007ca:	85ba                	mv	a1,a4
    800007cc:	e83ff0ef          	jal	ra,8000064e <uvmunmap>
    800007d0:	b7d5                	j	800007b4 <uvmdealloc+0x26>

00000000800007d2 <uvmalloc>:
  if(newsz < oldsz)
    800007d2:	08b66963          	bltu	a2,a1,80000864 <uvmalloc+0x92>
{
    800007d6:	7139                	addi	sp,sp,-64
    800007d8:	fc06                	sd	ra,56(sp)
    800007da:	f822                	sd	s0,48(sp)
    800007dc:	f426                	sd	s1,40(sp)
    800007de:	f04a                	sd	s2,32(sp)
    800007e0:	ec4e                	sd	s3,24(sp)
    800007e2:	e852                	sd	s4,16(sp)
    800007e4:	e456                	sd	s5,8(sp)
    800007e6:	e05a                	sd	s6,0(sp)
    800007e8:	0080                	addi	s0,sp,64
    800007ea:	8aaa                	mv	s5,a0
    800007ec:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800007ee:	6985                	lui	s3,0x1
    800007f0:	19fd                	addi	s3,s3,-1
    800007f2:	95ce                	add	a1,a1,s3
    800007f4:	79fd                	lui	s3,0xfffff
    800007f6:	0135f9b3          	and	s3,a1,s3
  for(a = oldsz; a < newsz; a += sz){
    800007fa:	06c9f763          	bgeu	s3,a2,80000868 <uvmalloc+0x96>
    800007fe:	894e                	mv	s2,s3
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000800:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000804:	8f9ff0ef          	jal	ra,800000fc <kalloc>
    80000808:	84aa                	mv	s1,a0
    if(mem == 0){
    8000080a:	c11d                	beqz	a0,80000830 <uvmalloc+0x5e>
    memset(mem, 0, sz);
    8000080c:	6605                	lui	a2,0x1
    8000080e:	4581                	li	a1,0
    80000810:	93dff0ef          	jal	ra,8000014c <memset>
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000814:	875a                	mv	a4,s6
    80000816:	86a6                	mv	a3,s1
    80000818:	6605                	lui	a2,0x1
    8000081a:	85ca                	mv	a1,s2
    8000081c:	8556                	mv	a0,s5
    8000081e:	c8bff0ef          	jal	ra,800004a8 <mappages>
    80000822:	e51d                	bnez	a0,80000850 <uvmalloc+0x7e>
  for(a = oldsz; a < newsz; a += sz){
    80000824:	6785                	lui	a5,0x1
    80000826:	993e                	add	s2,s2,a5
    80000828:	fd496ee3          	bltu	s2,s4,80000804 <uvmalloc+0x32>
  return newsz;
    8000082c:	8552                	mv	a0,s4
    8000082e:	a039                	j	8000083c <uvmalloc+0x6a>
      uvmdealloc(pagetable, a, oldsz);
    80000830:	864e                	mv	a2,s3
    80000832:	85ca                	mv	a1,s2
    80000834:	8556                	mv	a0,s5
    80000836:	f59ff0ef          	jal	ra,8000078e <uvmdealloc>
      return 0;
    8000083a:	4501                	li	a0,0
}
    8000083c:	70e2                	ld	ra,56(sp)
    8000083e:	7442                	ld	s0,48(sp)
    80000840:	74a2                	ld	s1,40(sp)
    80000842:	7902                	ld	s2,32(sp)
    80000844:	69e2                	ld	s3,24(sp)
    80000846:	6a42                	ld	s4,16(sp)
    80000848:	6aa2                	ld	s5,8(sp)
    8000084a:	6b02                	ld	s6,0(sp)
    8000084c:	6121                	addi	sp,sp,64
    8000084e:	8082                	ret
      kfree(mem);
    80000850:	8526                	mv	a0,s1
    80000852:	fcaff0ef          	jal	ra,8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000856:	864e                	mv	a2,s3
    80000858:	85ca                	mv	a1,s2
    8000085a:	8556                	mv	a0,s5
    8000085c:	f33ff0ef          	jal	ra,8000078e <uvmdealloc>
      return 0;
    80000860:	4501                	li	a0,0
    80000862:	bfe9                	j	8000083c <uvmalloc+0x6a>
    return oldsz;
    80000864:	852e                	mv	a0,a1
}
    80000866:	8082                	ret
  return newsz;
    80000868:	8532                	mv	a0,a2
    8000086a:	bfc9                	j	8000083c <uvmalloc+0x6a>

000000008000086c <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000086c:	7179                	addi	sp,sp,-48
    8000086e:	f406                	sd	ra,40(sp)
    80000870:	f022                	sd	s0,32(sp)
    80000872:	ec26                	sd	s1,24(sp)
    80000874:	e84a                	sd	s2,16(sp)
    80000876:	e44e                	sd	s3,8(sp)
    80000878:	e052                	sd	s4,0(sp)
    8000087a:	1800                	addi	s0,sp,48
    8000087c:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000087e:	84aa                	mv	s1,a0
    80000880:	6905                	lui	s2,0x1
    80000882:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000884:	4985                	li	s3,1
    80000886:	a811                	j	8000089a <freewalk+0x2e>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80000888:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    8000088a:	0532                	slli	a0,a0,0xc
    8000088c:	fe1ff0ef          	jal	ra,8000086c <freewalk>
      pagetable[i] = 0;
    80000890:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80000894:	04a1                	addi	s1,s1,8
    80000896:	01248f63          	beq	s1,s2,800008b4 <freewalk+0x48>
    pte_t pte = pagetable[i];
    8000089a:	6088                	ld	a0,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000089c:	00f57793          	andi	a5,a0,15
    800008a0:	ff3784e3          	beq	a5,s3,80000888 <freewalk+0x1c>
    } else if(pte & PTE_V){
    800008a4:	8905                	andi	a0,a0,1
    800008a6:	d57d                	beqz	a0,80000894 <freewalk+0x28>
      panic("freewalk: leaf");
    800008a8:	00007517          	auipc	a0,0x7
    800008ac:	8a050513          	addi	a0,a0,-1888 # 80007148 <etext+0x148>
    800008b0:	467040ef          	jal	ra,80005516 <panic>
    }
  }
  kfree((void*)pagetable);
    800008b4:	8552                	mv	a0,s4
    800008b6:	f66ff0ef          	jal	ra,8000001c <kfree>
}
    800008ba:	70a2                	ld	ra,40(sp)
    800008bc:	7402                	ld	s0,32(sp)
    800008be:	64e2                	ld	s1,24(sp)
    800008c0:	6942                	ld	s2,16(sp)
    800008c2:	69a2                	ld	s3,8(sp)
    800008c4:	6a02                	ld	s4,0(sp)
    800008c6:	6145                	addi	sp,sp,48
    800008c8:	8082                	ret

00000000800008ca <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800008ca:	1101                	addi	sp,sp,-32
    800008cc:	ec06                	sd	ra,24(sp)
    800008ce:	e822                	sd	s0,16(sp)
    800008d0:	e426                	sd	s1,8(sp)
    800008d2:	1000                	addi	s0,sp,32
    800008d4:	84aa                	mv	s1,a0
  if(sz > 0)
    800008d6:	e989                	bnez	a1,800008e8 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800008d8:	8526                	mv	a0,s1
    800008da:	f93ff0ef          	jal	ra,8000086c <freewalk>
}
    800008de:	60e2                	ld	ra,24(sp)
    800008e0:	6442                	ld	s0,16(sp)
    800008e2:	64a2                	ld	s1,8(sp)
    800008e4:	6105                	addi	sp,sp,32
    800008e6:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800008e8:	6605                	lui	a2,0x1
    800008ea:	167d                	addi	a2,a2,-1
    800008ec:	962e                	add	a2,a2,a1
    800008ee:	4685                	li	a3,1
    800008f0:	8231                	srli	a2,a2,0xc
    800008f2:	4581                	li	a1,0
    800008f4:	d5bff0ef          	jal	ra,8000064e <uvmunmap>
    800008f8:	b7c5                	j	800008d8 <uvmfree+0xe>

00000000800008fa <uvmcopy>:
  uint64 pa, i;
  uint flags;
  char *mem;
  int szinc;

  for(i = 0; i < sz; i += szinc){
    800008fa:	c65d                	beqz	a2,800009a8 <uvmcopy+0xae>
{
    800008fc:	715d                	addi	sp,sp,-80
    800008fe:	e486                	sd	ra,72(sp)
    80000900:	e0a2                	sd	s0,64(sp)
    80000902:	fc26                	sd	s1,56(sp)
    80000904:	f84a                	sd	s2,48(sp)
    80000906:	f44e                	sd	s3,40(sp)
    80000908:	f052                	sd	s4,32(sp)
    8000090a:	ec56                	sd	s5,24(sp)
    8000090c:	e85a                	sd	s6,16(sp)
    8000090e:	e45e                	sd	s7,8(sp)
    80000910:	0880                	addi	s0,sp,80
    80000912:	8b2a                	mv	s6,a0
    80000914:	8aae                	mv	s5,a1
    80000916:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += szinc){
    80000918:	4981                	li	s3,0
    szinc = PGSIZE;
    szinc = PGSIZE;
    if((pte = walk(old, i, 0)) == 0)
    8000091a:	4601                	li	a2,0
    8000091c:	85ce                	mv	a1,s3
    8000091e:	855a                	mv	a0,s6
    80000920:	aa9ff0ef          	jal	ra,800003c8 <walk>
    80000924:	c121                	beqz	a0,80000964 <uvmcopy+0x6a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    80000926:	6118                	ld	a4,0(a0)
    80000928:	00177793          	andi	a5,a4,1
    8000092c:	c3b1                	beqz	a5,80000970 <uvmcopy+0x76>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    8000092e:	00a75593          	srli	a1,a4,0xa
    80000932:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80000936:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    8000093a:	fc2ff0ef          	jal	ra,800000fc <kalloc>
    8000093e:	892a                	mv	s2,a0
    80000940:	c129                	beqz	a0,80000982 <uvmcopy+0x88>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80000942:	6605                	lui	a2,0x1
    80000944:	85de                	mv	a1,s7
    80000946:	863ff0ef          	jal	ra,800001a8 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000094a:	8726                	mv	a4,s1
    8000094c:	86ca                	mv	a3,s2
    8000094e:	6605                	lui	a2,0x1
    80000950:	85ce                	mv	a1,s3
    80000952:	8556                	mv	a0,s5
    80000954:	b55ff0ef          	jal	ra,800004a8 <mappages>
    80000958:	e115                	bnez	a0,8000097c <uvmcopy+0x82>
  for(i = 0; i < sz; i += szinc){
    8000095a:	6785                	lui	a5,0x1
    8000095c:	99be                	add	s3,s3,a5
    8000095e:	fb49eee3          	bltu	s3,s4,8000091a <uvmcopy+0x20>
    80000962:	a805                	j	80000992 <uvmcopy+0x98>
      panic("uvmcopy: pte should exist");
    80000964:	00006517          	auipc	a0,0x6
    80000968:	7f450513          	addi	a0,a0,2036 # 80007158 <etext+0x158>
    8000096c:	3ab040ef          	jal	ra,80005516 <panic>
      panic("uvmcopy: page not present");
    80000970:	00007517          	auipc	a0,0x7
    80000974:	80850513          	addi	a0,a0,-2040 # 80007178 <etext+0x178>
    80000978:	39f040ef          	jal	ra,80005516 <panic>
      kfree(mem);
    8000097c:	854a                	mv	a0,s2
    8000097e:	e9eff0ef          	jal	ra,8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000982:	4685                	li	a3,1
    80000984:	00c9d613          	srli	a2,s3,0xc
    80000988:	4581                	li	a1,0
    8000098a:	8556                	mv	a0,s5
    8000098c:	cc3ff0ef          	jal	ra,8000064e <uvmunmap>
  return -1;
    80000990:	557d                	li	a0,-1
}
    80000992:	60a6                	ld	ra,72(sp)
    80000994:	6406                	ld	s0,64(sp)
    80000996:	74e2                	ld	s1,56(sp)
    80000998:	7942                	ld	s2,48(sp)
    8000099a:	79a2                	ld	s3,40(sp)
    8000099c:	7a02                	ld	s4,32(sp)
    8000099e:	6ae2                	ld	s5,24(sp)
    800009a0:	6b42                	ld	s6,16(sp)
    800009a2:	6ba2                	ld	s7,8(sp)
    800009a4:	6161                	addi	sp,sp,80
    800009a6:	8082                	ret
  return 0;
    800009a8:	4501                	li	a0,0
}
    800009aa:	8082                	ret

00000000800009ac <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800009ac:	1141                	addi	sp,sp,-16
    800009ae:	e406                	sd	ra,8(sp)
    800009b0:	e022                	sd	s0,0(sp)
    800009b2:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800009b4:	4601                	li	a2,0
    800009b6:	a13ff0ef          	jal	ra,800003c8 <walk>
  if(pte == 0)
    800009ba:	c901                	beqz	a0,800009ca <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800009bc:	611c                	ld	a5,0(a0)
    800009be:	9bbd                	andi	a5,a5,-17
    800009c0:	e11c                	sd	a5,0(a0)
}
    800009c2:	60a2                	ld	ra,8(sp)
    800009c4:	6402                	ld	s0,0(sp)
    800009c6:	0141                	addi	sp,sp,16
    800009c8:	8082                	ret
    panic("uvmclear");
    800009ca:	00006517          	auipc	a0,0x6
    800009ce:	7ce50513          	addi	a0,a0,1998 # 80007198 <etext+0x198>
    800009d2:	345040ef          	jal	ra,80005516 <panic>

00000000800009d6 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    800009d6:	c6c1                	beqz	a3,80000a5e <copyout+0x88>
{
    800009d8:	711d                	addi	sp,sp,-96
    800009da:	ec86                	sd	ra,88(sp)
    800009dc:	e8a2                	sd	s0,80(sp)
    800009de:	e4a6                	sd	s1,72(sp)
    800009e0:	e0ca                	sd	s2,64(sp)
    800009e2:	fc4e                	sd	s3,56(sp)
    800009e4:	f852                	sd	s4,48(sp)
    800009e6:	f456                	sd	s5,40(sp)
    800009e8:	f05a                	sd	s6,32(sp)
    800009ea:	ec5e                	sd	s7,24(sp)
    800009ec:	e862                	sd	s8,16(sp)
    800009ee:	e466                	sd	s9,8(sp)
    800009f0:	1080                	addi	s0,sp,96
    800009f2:	8b2a                	mv	s6,a0
    800009f4:	8a2e                	mv	s4,a1
    800009f6:	8ab2                	mv	s5,a2
    800009f8:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    800009fa:	74fd                	lui	s1,0xfffff
    800009fc:	8ced                	and	s1,s1,a1
    if (va0 >= MAXVA)
    800009fe:	57fd                	li	a5,-1
    80000a00:	83e9                	srli	a5,a5,0x1a
    80000a02:	0697e063          	bltu	a5,s1,80000a62 <copyout+0x8c>
    80000a06:	6c05                	lui	s8,0x1
    80000a08:	8bbe                	mv	s7,a5
    80000a0a:	a015                	j	80000a2e <copyout+0x58>
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000a0c:	409a04b3          	sub	s1,s4,s1
    80000a10:	0009061b          	sext.w	a2,s2
    80000a14:	85d6                	mv	a1,s5
    80000a16:	9526                	add	a0,a0,s1
    80000a18:	f90ff0ef          	jal	ra,800001a8 <memmove>

    len -= n;
    80000a1c:	412989b3          	sub	s3,s3,s2
    src += n;
    80000a20:	9aca                	add	s5,s5,s2
  while(len > 0){
    80000a22:	02098c63          	beqz	s3,80000a5a <copyout+0x84>
    if (va0 >= MAXVA)
    80000a26:	059be063          	bltu	s7,s9,80000a66 <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    80000a2a:	84e6                	mv	s1,s9
    dstva = va0 + PGSIZE;
    80000a2c:	8a66                	mv	s4,s9
    if((pte = walk(pagetable, va0, 0)) == 0) {
    80000a2e:	4601                	li	a2,0
    80000a30:	85a6                	mv	a1,s1
    80000a32:	855a                	mv	a0,s6
    80000a34:	995ff0ef          	jal	ra,800003c8 <walk>
    80000a38:	c90d                	beqz	a0,80000a6a <copyout+0x94>
    if((*pte & PTE_W) == 0)
    80000a3a:	611c                	ld	a5,0(a0)
    80000a3c:	8b91                	andi	a5,a5,4
    80000a3e:	c7a1                	beqz	a5,80000a86 <copyout+0xb0>
    pa0 = walkaddr(pagetable, va0);
    80000a40:	85a6                	mv	a1,s1
    80000a42:	855a                	mv	a0,s6
    80000a44:	a27ff0ef          	jal	ra,8000046a <walkaddr>
    if(pa0 == 0)
    80000a48:	c129                	beqz	a0,80000a8a <copyout+0xb4>
    n = PGSIZE - (dstva - va0);
    80000a4a:	01848cb3          	add	s9,s1,s8
    80000a4e:	414c8933          	sub	s2,s9,s4
    if(n > len)
    80000a52:	fb29fde3          	bgeu	s3,s2,80000a0c <copyout+0x36>
    80000a56:	894e                	mv	s2,s3
    80000a58:	bf55                	j	80000a0c <copyout+0x36>
  }
  return 0;
    80000a5a:	4501                	li	a0,0
    80000a5c:	a801                	j	80000a6c <copyout+0x96>
    80000a5e:	4501                	li	a0,0
}
    80000a60:	8082                	ret
      return -1;
    80000a62:	557d                	li	a0,-1
    80000a64:	a021                	j	80000a6c <copyout+0x96>
    80000a66:	557d                	li	a0,-1
    80000a68:	a011                	j	80000a6c <copyout+0x96>
      return -1;
    80000a6a:	557d                	li	a0,-1
}
    80000a6c:	60e6                	ld	ra,88(sp)
    80000a6e:	6446                	ld	s0,80(sp)
    80000a70:	64a6                	ld	s1,72(sp)
    80000a72:	6906                	ld	s2,64(sp)
    80000a74:	79e2                	ld	s3,56(sp)
    80000a76:	7a42                	ld	s4,48(sp)
    80000a78:	7aa2                	ld	s5,40(sp)
    80000a7a:	7b02                	ld	s6,32(sp)
    80000a7c:	6be2                	ld	s7,24(sp)
    80000a7e:	6c42                	ld	s8,16(sp)
    80000a80:	6ca2                	ld	s9,8(sp)
    80000a82:	6125                	addi	sp,sp,96
    80000a84:	8082                	ret
      return -1;
    80000a86:	557d                	li	a0,-1
    80000a88:	b7d5                	j	80000a6c <copyout+0x96>
      return -1;
    80000a8a:	557d                	li	a0,-1
    80000a8c:	b7c5                	j	80000a6c <copyout+0x96>

0000000080000a8e <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;
  
  while(len > 0){
    80000a8e:	c6a5                	beqz	a3,80000af6 <copyin+0x68>
{
    80000a90:	715d                	addi	sp,sp,-80
    80000a92:	e486                	sd	ra,72(sp)
    80000a94:	e0a2                	sd	s0,64(sp)
    80000a96:	fc26                	sd	s1,56(sp)
    80000a98:	f84a                	sd	s2,48(sp)
    80000a9a:	f44e                	sd	s3,40(sp)
    80000a9c:	f052                	sd	s4,32(sp)
    80000a9e:	ec56                	sd	s5,24(sp)
    80000aa0:	e85a                	sd	s6,16(sp)
    80000aa2:	e45e                	sd	s7,8(sp)
    80000aa4:	e062                	sd	s8,0(sp)
    80000aa6:	0880                	addi	s0,sp,80
    80000aa8:	8b2a                	mv	s6,a0
    80000aaa:	8a2e                	mv	s4,a1
    80000aac:	8c32                	mv	s8,a2
    80000aae:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000ab0:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000ab2:	6a85                	lui	s5,0x1
    80000ab4:	a00d                	j	80000ad6 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000ab6:	018505b3          	add	a1,a0,s8
    80000aba:	0004861b          	sext.w	a2,s1
    80000abe:	412585b3          	sub	a1,a1,s2
    80000ac2:	8552                	mv	a0,s4
    80000ac4:	ee4ff0ef          	jal	ra,800001a8 <memmove>

    len -= n;
    80000ac8:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000acc:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000ace:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000ad2:	02098063          	beqz	s3,80000af2 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000ad6:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000ada:	85ca                	mv	a1,s2
    80000adc:	855a                	mv	a0,s6
    80000ade:	98dff0ef          	jal	ra,8000046a <walkaddr>
    if(pa0 == 0)
    80000ae2:	cd01                	beqz	a0,80000afa <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000ae4:	418904b3          	sub	s1,s2,s8
    80000ae8:	94d6                	add	s1,s1,s5
    if(n > len)
    80000aea:	fc99f6e3          	bgeu	s3,s1,80000ab6 <copyin+0x28>
    80000aee:	84ce                	mv	s1,s3
    80000af0:	b7d9                	j	80000ab6 <copyin+0x28>
  }
  return 0;
    80000af2:	4501                	li	a0,0
    80000af4:	a021                	j	80000afc <copyin+0x6e>
    80000af6:	4501                	li	a0,0
}
    80000af8:	8082                	ret
      return -1;
    80000afa:	557d                	li	a0,-1
}
    80000afc:	60a6                	ld	ra,72(sp)
    80000afe:	6406                	ld	s0,64(sp)
    80000b00:	74e2                	ld	s1,56(sp)
    80000b02:	7942                	ld	s2,48(sp)
    80000b04:	79a2                	ld	s3,40(sp)
    80000b06:	7a02                	ld	s4,32(sp)
    80000b08:	6ae2                	ld	s5,24(sp)
    80000b0a:	6b42                	ld	s6,16(sp)
    80000b0c:	6ba2                	ld	s7,8(sp)
    80000b0e:	6c02                	ld	s8,0(sp)
    80000b10:	6161                	addi	sp,sp,80
    80000b12:	8082                	ret

0000000080000b14 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000b14:	c2d5                	beqz	a3,80000bb8 <copyinstr+0xa4>
{
    80000b16:	715d                	addi	sp,sp,-80
    80000b18:	e486                	sd	ra,72(sp)
    80000b1a:	e0a2                	sd	s0,64(sp)
    80000b1c:	fc26                	sd	s1,56(sp)
    80000b1e:	f84a                	sd	s2,48(sp)
    80000b20:	f44e                	sd	s3,40(sp)
    80000b22:	f052                	sd	s4,32(sp)
    80000b24:	ec56                	sd	s5,24(sp)
    80000b26:	e85a                	sd	s6,16(sp)
    80000b28:	e45e                	sd	s7,8(sp)
    80000b2a:	0880                	addi	s0,sp,80
    80000b2c:	8a2a                	mv	s4,a0
    80000b2e:	8b2e                	mv	s6,a1
    80000b30:	8bb2                	mv	s7,a2
    80000b32:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    80000b34:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b36:	6985                	lui	s3,0x1
    80000b38:	a035                	j	80000b64 <copyinstr+0x50>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000b3a:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80000b3e:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000b40:	0017b793          	seqz	a5,a5
    80000b44:	40f00533          	neg	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000b48:	60a6                	ld	ra,72(sp)
    80000b4a:	6406                	ld	s0,64(sp)
    80000b4c:	74e2                	ld	s1,56(sp)
    80000b4e:	7942                	ld	s2,48(sp)
    80000b50:	79a2                	ld	s3,40(sp)
    80000b52:	7a02                	ld	s4,32(sp)
    80000b54:	6ae2                	ld	s5,24(sp)
    80000b56:	6b42                	ld	s6,16(sp)
    80000b58:	6ba2                	ld	s7,8(sp)
    80000b5a:	6161                	addi	sp,sp,80
    80000b5c:	8082                	ret
    srcva = va0 + PGSIZE;
    80000b5e:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    80000b62:	c4b9                	beqz	s1,80000bb0 <copyinstr+0x9c>
    va0 = PGROUNDDOWN(srcva);
    80000b64:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    80000b68:	85ca                	mv	a1,s2
    80000b6a:	8552                	mv	a0,s4
    80000b6c:	8ffff0ef          	jal	ra,8000046a <walkaddr>
    if(pa0 == 0)
    80000b70:	c131                	beqz	a0,80000bb4 <copyinstr+0xa0>
    n = PGSIZE - (srcva - va0);
    80000b72:	41790833          	sub	a6,s2,s7
    80000b76:	984e                	add	a6,a6,s3
    if(n > max)
    80000b78:	0104f363          	bgeu	s1,a6,80000b7e <copyinstr+0x6a>
    80000b7c:	8826                	mv	a6,s1
    char *p = (char *) (pa0 + (srcva - va0));
    80000b7e:	955e                	add	a0,a0,s7
    80000b80:	41250533          	sub	a0,a0,s2
    while(n > 0){
    80000b84:	fc080de3          	beqz	a6,80000b5e <copyinstr+0x4a>
    80000b88:	985a                	add	a6,a6,s6
    80000b8a:	87da                	mv	a5,s6
      if(*p == '\0'){
    80000b8c:	41650633          	sub	a2,a0,s6
    80000b90:	14fd                	addi	s1,s1,-1
    80000b92:	9b26                	add	s6,s6,s1
    80000b94:	00f60733          	add	a4,a2,a5
    80000b98:	00074703          	lbu	a4,0(a4)
    80000b9c:	df59                	beqz	a4,80000b3a <copyinstr+0x26>
        *dst = *p;
    80000b9e:	00e78023          	sb	a4,0(a5)
      --max;
    80000ba2:	40fb04b3          	sub	s1,s6,a5
      dst++;
    80000ba6:	0785                	addi	a5,a5,1
    while(n > 0){
    80000ba8:	ff0796e3          	bne	a5,a6,80000b94 <copyinstr+0x80>
      dst++;
    80000bac:	8b42                	mv	s6,a6
    80000bae:	bf45                	j	80000b5e <copyinstr+0x4a>
    80000bb0:	4781                	li	a5,0
    80000bb2:	b779                	j	80000b40 <copyinstr+0x2c>
      return -1;
    80000bb4:	557d                	li	a0,-1
    80000bb6:	bf49                	j	80000b48 <copyinstr+0x34>
  int got_null = 0;
    80000bb8:	4781                	li	a5,0
  if(got_null){
    80000bba:	0017b793          	seqz	a5,a5
    80000bbe:	40f00533          	neg	a0,a5
}
    80000bc2:	8082                	ret

0000000080000bc4 <printindent>:


#ifdef LAB_PGTBL
//This code was added by Ashish CS23B099
void printindent(int level){
  for(int i = 0; i < level; i++)
    80000bc4:	02a05c63          	blez	a0,80000bfc <printindent+0x38>
void printindent(int level){
    80000bc8:	7179                	addi	sp,sp,-48
    80000bca:	f406                	sd	ra,40(sp)
    80000bcc:	f022                	sd	s0,32(sp)
    80000bce:	ec26                	sd	s1,24(sp)
    80000bd0:	e84a                	sd	s2,16(sp)
    80000bd2:	e44e                	sd	s3,8(sp)
    80000bd4:	1800                	addi	s0,sp,48
    80000bd6:	892a                	mv	s2,a0
  for(int i = 0; i < level; i++)
    80000bd8:	4481                	li	s1,0
    printf(" ..");
    80000bda:	00006997          	auipc	s3,0x6
    80000bde:	5ce98993          	addi	s3,s3,1486 # 800071a8 <etext+0x1a8>
    80000be2:	854e                	mv	a0,s3
    80000be4:	67e040ef          	jal	ra,80005262 <printf>
  for(int i = 0; i < level; i++)
    80000be8:	2485                	addiw	s1,s1,1
    80000bea:	fe991ce3          	bne	s2,s1,80000be2 <printindent+0x1e>
}
    80000bee:	70a2                	ld	ra,40(sp)
    80000bf0:	7402                	ld	s0,32(sp)
    80000bf2:	64e2                	ld	s1,24(sp)
    80000bf4:	6942                	ld	s2,16(sp)
    80000bf6:	69a2                	ld	s3,8(sp)
    80000bf8:	6145                	addi	sp,sp,48
    80000bfa:	8082                	ret
    80000bfc:	8082                	ret

0000000080000bfe <vmprintwalk>:

void vmprintwalk(pagetable_t pagetable, int level){
    80000bfe:	715d                	addi	sp,sp,-80
    80000c00:	e486                	sd	ra,72(sp)
    80000c02:	e0a2                	sd	s0,64(sp)
    80000c04:	fc26                	sd	s1,56(sp)
    80000c06:	f84a                	sd	s2,48(sp)
    80000c08:	f44e                	sd	s3,40(sp)
    80000c0a:	f052                	sd	s4,32(sp)
    80000c0c:	ec56                	sd	s5,24(sp)
    80000c0e:	e85a                	sd	s6,16(sp)
    80000c10:	e45e                	sd	s7,8(sp)
    80000c12:	e062                	sd	s8,0(sp)
    80000c14:	0880                	addi	s0,sp,80
    80000c16:	8b2e                	mv	s6,a1
  for(int i = 0; i < 512; i++){
    80000c18:	89aa                	mv	s3,a0
    80000c1a:	4901                	li	s2,0
    pte_t pte = pagetable[i];
    if(pte & PTE_V){
      printindent(level);
      printf("%d: pte %p pa %p\n", i, (void*)pte, (void*)PTE2PA(pte));
    80000c1c:	00006b97          	auipc	s7,0x6
    80000c20:	594b8b93          	addi	s7,s7,1428 # 800071b0 <etext+0x1b0>
      if((pte & (PTE_R|PTE_W|PTE_X)) == 0){
        // this PTE points to a lower-level page table.
        uint64 child = PTE2PA(pte);
        vmprintwalk((pagetable_t)child, level+1);
    80000c24:	00158c1b          	addiw	s8,a1,1
  for(int i = 0; i < 512; i++){
    80000c28:	20000a93          	li	s5,512
    80000c2c:	a029                	j	80000c36 <vmprintwalk+0x38>
    80000c2e:	2905                	addiw	s2,s2,1
    80000c30:	09a1                	addi	s3,s3,8
    80000c32:	03590a63          	beq	s2,s5,80000c66 <vmprintwalk+0x68>
    pte_t pte = pagetable[i];
    80000c36:	0009b483          	ld	s1,0(s3)
    if(pte & PTE_V){
    80000c3a:	0014f793          	andi	a5,s1,1
    80000c3e:	dbe5                	beqz	a5,80000c2e <vmprintwalk+0x30>
      printindent(level);
    80000c40:	855a                	mv	a0,s6
    80000c42:	f83ff0ef          	jal	ra,80000bc4 <printindent>
      printf("%d: pte %p pa %p\n", i, (void*)pte, (void*)PTE2PA(pte));
    80000c46:	00a4da13          	srli	s4,s1,0xa
    80000c4a:	0a32                	slli	s4,s4,0xc
    80000c4c:	86d2                	mv	a3,s4
    80000c4e:	8626                	mv	a2,s1
    80000c50:	85ca                	mv	a1,s2
    80000c52:	855e                	mv	a0,s7
    80000c54:	60e040ef          	jal	ra,80005262 <printf>
      if((pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000c58:	88b9                	andi	s1,s1,14
    80000c5a:	f8f1                	bnez	s1,80000c2e <vmprintwalk+0x30>
        vmprintwalk((pagetable_t)child, level+1);
    80000c5c:	85e2                	mv	a1,s8
    80000c5e:	8552                	mv	a0,s4
    80000c60:	f9fff0ef          	jal	ra,80000bfe <vmprintwalk>
    80000c64:	b7e9                	j	80000c2e <vmprintwalk+0x30>
      }
    }
  }
}
    80000c66:	60a6                	ld	ra,72(sp)
    80000c68:	6406                	ld	s0,64(sp)
    80000c6a:	74e2                	ld	s1,56(sp)
    80000c6c:	7942                	ld	s2,48(sp)
    80000c6e:	79a2                	ld	s3,40(sp)
    80000c70:	7a02                	ld	s4,32(sp)
    80000c72:	6ae2                	ld	s5,24(sp)
    80000c74:	6b42                	ld	s6,16(sp)
    80000c76:	6ba2                	ld	s7,8(sp)
    80000c78:	6c02                	ld	s8,0(sp)
    80000c7a:	6161                	addi	sp,sp,80
    80000c7c:	8082                	ret

0000000080000c7e <vmprint>:

void
vmprint(pagetable_t pagetable) {
    80000c7e:	1101                	addi	sp,sp,-32
    80000c80:	ec06                	sd	ra,24(sp)
    80000c82:	e822                	sd	s0,16(sp)
    80000c84:	e426                	sd	s1,8(sp)
    80000c86:	1000                	addi	s0,sp,32
    80000c88:	84aa                	mv	s1,a0
  // your code here
  printf("page table %p\n", (void*)pagetable);
    80000c8a:	85aa                	mv	a1,a0
    80000c8c:	00006517          	auipc	a0,0x6
    80000c90:	53c50513          	addi	a0,a0,1340 # 800071c8 <etext+0x1c8>
    80000c94:	5ce040ef          	jal	ra,80005262 <printf>
  vmprintwalk(pagetable, 1);
    80000c98:	4585                	li	a1,1
    80000c9a:	8526                	mv	a0,s1
    80000c9c:	f63ff0ef          	jal	ra,80000bfe <vmprintwalk>
}
    80000ca0:	60e2                	ld	ra,24(sp)
    80000ca2:	6442                	ld	s0,16(sp)
    80000ca4:	64a2                	ld	s1,8(sp)
    80000ca6:	6105                	addi	sp,sp,32
    80000ca8:	8082                	ret

0000000080000caa <pgpte>:



#ifdef LAB_PGTBL
pte_t*
pgpte(pagetable_t pagetable, uint64 va) {
    80000caa:	1141                	addi	sp,sp,-16
    80000cac:	e406                	sd	ra,8(sp)
    80000cae:	e022                	sd	s0,0(sp)
    80000cb0:	0800                	addi	s0,sp,16
  return walk(pagetable, va, 0);
    80000cb2:	4601                	li	a2,0
    80000cb4:	f14ff0ef          	jal	ra,800003c8 <walk>
}
    80000cb8:	60a2                	ld	ra,8(sp)
    80000cba:	6402                	ld	s0,0(sp)
    80000cbc:	0141                	addi	sp,sp,16
    80000cbe:	8082                	ret

0000000080000cc0 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000cc0:	7139                	addi	sp,sp,-64
    80000cc2:	fc06                	sd	ra,56(sp)
    80000cc4:	f822                	sd	s0,48(sp)
    80000cc6:	f426                	sd	s1,40(sp)
    80000cc8:	f04a                	sd	s2,32(sp)
    80000cca:	ec4e                	sd	s3,24(sp)
    80000ccc:	e852                	sd	s4,16(sp)
    80000cce:	e456                	sd	s5,8(sp)
    80000cd0:	e05a                	sd	s6,0(sp)
    80000cd2:	0080                	addi	s0,sp,64
    80000cd4:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cd6:	00007497          	auipc	s1,0x7
    80000cda:	12a48493          	addi	s1,s1,298 # 80007e00 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000cde:	8b26                	mv	s6,s1
    80000ce0:	00006a97          	auipc	s5,0x6
    80000ce4:	320a8a93          	addi	s5,s5,800 # 80007000 <etext>
    80000ce8:	01000937          	lui	s2,0x1000
    80000cec:	197d                	addi	s2,s2,-1
    80000cee:	093a                	slli	s2,s2,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cf0:	0000da17          	auipc	s4,0xd
    80000cf4:	d10a0a13          	addi	s4,s4,-752 # 8000da00 <tickslock>
    char *pa = kalloc();
    80000cf8:	c04ff0ef          	jal	ra,800000fc <kalloc>
    80000cfc:	862a                	mv	a2,a0
    if(pa == 0)
    80000cfe:	cd1d                	beqz	a0,80000d3c <proc_mapstacks+0x7c>
    uint64 va = KSTACK((int) (p - proc));
    80000d00:	416485b3          	sub	a1,s1,s6
    80000d04:	8591                	srai	a1,a1,0x4
    80000d06:	000ab783          	ld	a5,0(s5)
    80000d0a:	02f585b3          	mul	a1,a1,a5
    80000d0e:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000d12:	4719                	li	a4,6
    80000d14:	6685                	lui	a3,0x1
    80000d16:	40b905b3          	sub	a1,s2,a1
    80000d1a:	854e                	mv	a0,s3
    80000d1c:	83dff0ef          	jal	ra,80000558 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d20:	17048493          	addi	s1,s1,368
    80000d24:	fd449ae3          	bne	s1,s4,80000cf8 <proc_mapstacks+0x38>
  }
}
    80000d28:	70e2                	ld	ra,56(sp)
    80000d2a:	7442                	ld	s0,48(sp)
    80000d2c:	74a2                	ld	s1,40(sp)
    80000d2e:	7902                	ld	s2,32(sp)
    80000d30:	69e2                	ld	s3,24(sp)
    80000d32:	6a42                	ld	s4,16(sp)
    80000d34:	6aa2                	ld	s5,8(sp)
    80000d36:	6b02                	ld	s6,0(sp)
    80000d38:	6121                	addi	sp,sp,64
    80000d3a:	8082                	ret
      panic("kalloc");
    80000d3c:	00006517          	auipc	a0,0x6
    80000d40:	49c50513          	addi	a0,a0,1180 # 800071d8 <etext+0x1d8>
    80000d44:	7d2040ef          	jal	ra,80005516 <panic>

0000000080000d48 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000d48:	7139                	addi	sp,sp,-64
    80000d4a:	fc06                	sd	ra,56(sp)
    80000d4c:	f822                	sd	s0,48(sp)
    80000d4e:	f426                	sd	s1,40(sp)
    80000d50:	f04a                	sd	s2,32(sp)
    80000d52:	ec4e                	sd	s3,24(sp)
    80000d54:	e852                	sd	s4,16(sp)
    80000d56:	e456                	sd	s5,8(sp)
    80000d58:	e05a                	sd	s6,0(sp)
    80000d5a:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000d5c:	00006597          	auipc	a1,0x6
    80000d60:	48458593          	addi	a1,a1,1156 # 800071e0 <etext+0x1e0>
    80000d64:	00007517          	auipc	a0,0x7
    80000d68:	c6c50513          	addi	a0,a0,-916 # 800079d0 <pid_lock>
    80000d6c:	23f040ef          	jal	ra,800057aa <initlock>
  initlock(&wait_lock, "wait_lock");
    80000d70:	00006597          	auipc	a1,0x6
    80000d74:	47858593          	addi	a1,a1,1144 # 800071e8 <etext+0x1e8>
    80000d78:	00007517          	auipc	a0,0x7
    80000d7c:	c7050513          	addi	a0,a0,-912 # 800079e8 <wait_lock>
    80000d80:	22b040ef          	jal	ra,800057aa <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d84:	00007497          	auipc	s1,0x7
    80000d88:	07c48493          	addi	s1,s1,124 # 80007e00 <proc>
      initlock(&p->lock, "proc");
    80000d8c:	00006b17          	auipc	s6,0x6
    80000d90:	46cb0b13          	addi	s6,s6,1132 # 800071f8 <etext+0x1f8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000d94:	8aa6                	mv	s5,s1
    80000d96:	00006a17          	auipc	s4,0x6
    80000d9a:	26aa0a13          	addi	s4,s4,618 # 80007000 <etext>
    80000d9e:	01000937          	lui	s2,0x1000
    80000da2:	197d                	addi	s2,s2,-1
    80000da4:	093a                	slli	s2,s2,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000da6:	0000d997          	auipc	s3,0xd
    80000daa:	c5a98993          	addi	s3,s3,-934 # 8000da00 <tickslock>
      initlock(&p->lock, "proc");
    80000dae:	85da                	mv	a1,s6
    80000db0:	8526                	mv	a0,s1
    80000db2:	1f9040ef          	jal	ra,800057aa <initlock>
      p->state = UNUSED;
    80000db6:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000dba:	415487b3          	sub	a5,s1,s5
    80000dbe:	8791                	srai	a5,a5,0x4
    80000dc0:	000a3703          	ld	a4,0(s4)
    80000dc4:	02e787b3          	mul	a5,a5,a4
    80000dc8:	00d7979b          	slliw	a5,a5,0xd
    80000dcc:	40f907b3          	sub	a5,s2,a5
    80000dd0:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000dd2:	17048493          	addi	s1,s1,368
    80000dd6:	fd349ce3          	bne	s1,s3,80000dae <procinit+0x66>
  }
}
    80000dda:	70e2                	ld	ra,56(sp)
    80000ddc:	7442                	ld	s0,48(sp)
    80000dde:	74a2                	ld	s1,40(sp)
    80000de0:	7902                	ld	s2,32(sp)
    80000de2:	69e2                	ld	s3,24(sp)
    80000de4:	6a42                	ld	s4,16(sp)
    80000de6:	6aa2                	ld	s5,8(sp)
    80000de8:	6b02                	ld	s6,0(sp)
    80000dea:	6121                	addi	sp,sp,64
    80000dec:	8082                	ret

0000000080000dee <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000dee:	1141                	addi	sp,sp,-16
    80000df0:	e422                	sd	s0,8(sp)
    80000df2:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000df4:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000df6:	2501                	sext.w	a0,a0
    80000df8:	6422                	ld	s0,8(sp)
    80000dfa:	0141                	addi	sp,sp,16
    80000dfc:	8082                	ret

0000000080000dfe <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000dfe:	1141                	addi	sp,sp,-16
    80000e00:	e422                	sd	s0,8(sp)
    80000e02:	0800                	addi	s0,sp,16
    80000e04:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000e06:	2781                	sext.w	a5,a5
    80000e08:	079e                	slli	a5,a5,0x7
  return c;
}
    80000e0a:	00007517          	auipc	a0,0x7
    80000e0e:	bf650513          	addi	a0,a0,-1034 # 80007a00 <cpus>
    80000e12:	953e                	add	a0,a0,a5
    80000e14:	6422                	ld	s0,8(sp)
    80000e16:	0141                	addi	sp,sp,16
    80000e18:	8082                	ret

0000000080000e1a <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000e1a:	1101                	addi	sp,sp,-32
    80000e1c:	ec06                	sd	ra,24(sp)
    80000e1e:	e822                	sd	s0,16(sp)
    80000e20:	e426                	sd	s1,8(sp)
    80000e22:	1000                	addi	s0,sp,32
  push_off();
    80000e24:	1c7040ef          	jal	ra,800057ea <push_off>
    80000e28:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000e2a:	2781                	sext.w	a5,a5
    80000e2c:	079e                	slli	a5,a5,0x7
    80000e2e:	00007717          	auipc	a4,0x7
    80000e32:	ba270713          	addi	a4,a4,-1118 # 800079d0 <pid_lock>
    80000e36:	97ba                	add	a5,a5,a4
    80000e38:	7b84                	ld	s1,48(a5)
  pop_off();
    80000e3a:	235040ef          	jal	ra,8000586e <pop_off>
  return p;
}
    80000e3e:	8526                	mv	a0,s1
    80000e40:	60e2                	ld	ra,24(sp)
    80000e42:	6442                	ld	s0,16(sp)
    80000e44:	64a2                	ld	s1,8(sp)
    80000e46:	6105                	addi	sp,sp,32
    80000e48:	8082                	ret

0000000080000e4a <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000e4a:	1141                	addi	sp,sp,-16
    80000e4c:	e406                	sd	ra,8(sp)
    80000e4e:	e022                	sd	s0,0(sp)
    80000e50:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000e52:	fc9ff0ef          	jal	ra,80000e1a <myproc>
    80000e56:	26d040ef          	jal	ra,800058c2 <release>

  if (first) {
    80000e5a:	00007797          	auipc	a5,0x7
    80000e5e:	ad67a783          	lw	a5,-1322(a5) # 80007930 <first.1>
    80000e62:	e799                	bnez	a5,80000e70 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000e64:	347000ef          	jal	ra,800019aa <usertrapret>
}
    80000e68:	60a2                	ld	ra,8(sp)
    80000e6a:	6402                	ld	s0,0(sp)
    80000e6c:	0141                	addi	sp,sp,16
    80000e6e:	8082                	ret
    fsinit(ROOTDEV);
    80000e70:	4505                	li	a0,1
    80000e72:	7e6010ef          	jal	ra,80002658 <fsinit>
    first = 0;
    80000e76:	00007797          	auipc	a5,0x7
    80000e7a:	aa07ad23          	sw	zero,-1350(a5) # 80007930 <first.1>
    __sync_synchronize();
    80000e7e:	0ff0000f          	fence
    80000e82:	b7cd                	j	80000e64 <forkret+0x1a>

0000000080000e84 <allocpid>:
{
    80000e84:	1101                	addi	sp,sp,-32
    80000e86:	ec06                	sd	ra,24(sp)
    80000e88:	e822                	sd	s0,16(sp)
    80000e8a:	e426                	sd	s1,8(sp)
    80000e8c:	e04a                	sd	s2,0(sp)
    80000e8e:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000e90:	00007917          	auipc	s2,0x7
    80000e94:	b4090913          	addi	s2,s2,-1216 # 800079d0 <pid_lock>
    80000e98:	854a                	mv	a0,s2
    80000e9a:	191040ef          	jal	ra,8000582a <acquire>
  pid = nextpid;
    80000e9e:	00007797          	auipc	a5,0x7
    80000ea2:	a9678793          	addi	a5,a5,-1386 # 80007934 <nextpid>
    80000ea6:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000ea8:	0014871b          	addiw	a4,s1,1
    80000eac:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000eae:	854a                	mv	a0,s2
    80000eb0:	213040ef          	jal	ra,800058c2 <release>
}
    80000eb4:	8526                	mv	a0,s1
    80000eb6:	60e2                	ld	ra,24(sp)
    80000eb8:	6442                	ld	s0,16(sp)
    80000eba:	64a2                	ld	s1,8(sp)
    80000ebc:	6902                	ld	s2,0(sp)
    80000ebe:	6105                	addi	sp,sp,32
    80000ec0:	8082                	ret

0000000080000ec2 <proc_pagetable>:
{
    80000ec2:	1101                	addi	sp,sp,-32
    80000ec4:	ec06                	sd	ra,24(sp)
    80000ec6:	e822                	sd	s0,16(sp)
    80000ec8:	e426                	sd	s1,8(sp)
    80000eca:	e04a                	sd	s2,0(sp)
    80000ecc:	1000                	addi	s0,sp,32
    80000ece:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000ed0:	83bff0ef          	jal	ra,8000070a <uvmcreate>
    80000ed4:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000ed6:	c929                	beqz	a0,80000f28 <proc_pagetable+0x66>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000ed8:	4729                	li	a4,10
    80000eda:	00005697          	auipc	a3,0x5
    80000ede:	12668693          	addi	a3,a3,294 # 80006000 <_trampoline>
    80000ee2:	6605                	lui	a2,0x1
    80000ee4:	040005b7          	lui	a1,0x4000
    80000ee8:	15fd                	addi	a1,a1,-1
    80000eea:	05b2                	slli	a1,a1,0xc
    80000eec:	dbcff0ef          	jal	ra,800004a8 <mappages>
    80000ef0:	04054363          	bltz	a0,80000f36 <proc_pagetable+0x74>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000ef4:	4719                	li	a4,6
    80000ef6:	05893683          	ld	a3,88(s2)
    80000efa:	6605                	lui	a2,0x1
    80000efc:	020005b7          	lui	a1,0x2000
    80000f00:	15fd                	addi	a1,a1,-1
    80000f02:	05b6                	slli	a1,a1,0xd
    80000f04:	8526                	mv	a0,s1
    80000f06:	da2ff0ef          	jal	ra,800004a8 <mappages>
    80000f0a:	02054c63          	bltz	a0,80000f42 <proc_pagetable+0x80>
    if(mappages(pagetable, USYSCALL, PGSIZE,
    80000f0e:	4749                	li	a4,18
    80000f10:	06093683          	ld	a3,96(s2)
    80000f14:	6605                	lui	a2,0x1
    80000f16:	040005b7          	lui	a1,0x4000
    80000f1a:	15f5                	addi	a1,a1,-3
    80000f1c:	05b2                	slli	a1,a1,0xc
    80000f1e:	8526                	mv	a0,s1
    80000f20:	d88ff0ef          	jal	ra,800004a8 <mappages>
    80000f24:	02054e63          	bltz	a0,80000f60 <proc_pagetable+0x9e>
}
    80000f28:	8526                	mv	a0,s1
    80000f2a:	60e2                	ld	ra,24(sp)
    80000f2c:	6442                	ld	s0,16(sp)
    80000f2e:	64a2                	ld	s1,8(sp)
    80000f30:	6902                	ld	s2,0(sp)
    80000f32:	6105                	addi	sp,sp,32
    80000f34:	8082                	ret
    uvmfree(pagetable, 0);
    80000f36:	4581                	li	a1,0
    80000f38:	8526                	mv	a0,s1
    80000f3a:	991ff0ef          	jal	ra,800008ca <uvmfree>
    return 0;
    80000f3e:	4481                	li	s1,0
    80000f40:	b7e5                	j	80000f28 <proc_pagetable+0x66>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000f42:	4681                	li	a3,0
    80000f44:	4605                	li	a2,1
    80000f46:	040005b7          	lui	a1,0x4000
    80000f4a:	15fd                	addi	a1,a1,-1
    80000f4c:	05b2                	slli	a1,a1,0xc
    80000f4e:	8526                	mv	a0,s1
    80000f50:	efeff0ef          	jal	ra,8000064e <uvmunmap>
    uvmfree(pagetable, 0);
    80000f54:	4581                	li	a1,0
    80000f56:	8526                	mv	a0,s1
    80000f58:	973ff0ef          	jal	ra,800008ca <uvmfree>
    return 0;
    80000f5c:	4481                	li	s1,0
    80000f5e:	b7e9                	j	80000f28 <proc_pagetable+0x66>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000f60:	4681                	li	a3,0
    80000f62:	4605                	li	a2,1
    80000f64:	040005b7          	lui	a1,0x4000
    80000f68:	15fd                	addi	a1,a1,-1
    80000f6a:	05b2                	slli	a1,a1,0xc
    80000f6c:	8526                	mv	a0,s1
    80000f6e:	ee0ff0ef          	jal	ra,8000064e <uvmunmap>
    uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000f72:	4681                	li	a3,0
    80000f74:	4605                	li	a2,1
    80000f76:	020005b7          	lui	a1,0x2000
    80000f7a:	15fd                	addi	a1,a1,-1
    80000f7c:	05b6                	slli	a1,a1,0xd
    80000f7e:	8526                	mv	a0,s1
    80000f80:	eceff0ef          	jal	ra,8000064e <uvmunmap>
    uvmfree(pagetable, 0);
    80000f84:	4581                	li	a1,0
    80000f86:	8526                	mv	a0,s1
    80000f88:	943ff0ef          	jal	ra,800008ca <uvmfree>
    return 0;
    80000f8c:	4481                	li	s1,0
    80000f8e:	bf69                	j	80000f28 <proc_pagetable+0x66>

0000000080000f90 <proc_freepagetable>:
{
    80000f90:	7179                	addi	sp,sp,-48
    80000f92:	f406                	sd	ra,40(sp)
    80000f94:	f022                	sd	s0,32(sp)
    80000f96:	ec26                	sd	s1,24(sp)
    80000f98:	e84a                	sd	s2,16(sp)
    80000f9a:	e44e                	sd	s3,8(sp)
    80000f9c:	1800                	addi	s0,sp,48
    80000f9e:	84aa                	mv	s1,a0
    80000fa0:	89ae                	mv	s3,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000fa2:	4681                	li	a3,0
    80000fa4:	4605                	li	a2,1
    80000fa6:	04000937          	lui	s2,0x4000
    80000faa:	fff90593          	addi	a1,s2,-1 # 3ffffff <_entry-0x7c000001>
    80000fae:	05b2                	slli	a1,a1,0xc
    80000fb0:	e9eff0ef          	jal	ra,8000064e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000fb4:	4681                	li	a3,0
    80000fb6:	4605                	li	a2,1
    80000fb8:	020005b7          	lui	a1,0x2000
    80000fbc:	15fd                	addi	a1,a1,-1
    80000fbe:	05b6                	slli	a1,a1,0xd
    80000fc0:	8526                	mv	a0,s1
    80000fc2:	e8cff0ef          	jal	ra,8000064e <uvmunmap>
  uvmunmap(pagetable, USYSCALL, 1, 0); // This line was added by Ashish CS23B099
    80000fc6:	4681                	li	a3,0
    80000fc8:	4605                	li	a2,1
    80000fca:	1975                	addi	s2,s2,-3
    80000fcc:	00c91593          	slli	a1,s2,0xc
    80000fd0:	8526                	mv	a0,s1
    80000fd2:	e7cff0ef          	jal	ra,8000064e <uvmunmap>
  uvmfree(pagetable, sz);
    80000fd6:	85ce                	mv	a1,s3
    80000fd8:	8526                	mv	a0,s1
    80000fda:	8f1ff0ef          	jal	ra,800008ca <uvmfree>
}
    80000fde:	70a2                	ld	ra,40(sp)
    80000fe0:	7402                	ld	s0,32(sp)
    80000fe2:	64e2                	ld	s1,24(sp)
    80000fe4:	6942                	ld	s2,16(sp)
    80000fe6:	69a2                	ld	s3,8(sp)
    80000fe8:	6145                	addi	sp,sp,48
    80000fea:	8082                	ret

0000000080000fec <freeproc>:
{
    80000fec:	1101                	addi	sp,sp,-32
    80000fee:	ec06                	sd	ra,24(sp)
    80000ff0:	e822                	sd	s0,16(sp)
    80000ff2:	e426                	sd	s1,8(sp)
    80000ff4:	1000                	addi	s0,sp,32
    80000ff6:	84aa                	mv	s1,a0
  if(p->trapframe)
    80000ff8:	6d28                	ld	a0,88(a0)
    80000ffa:	c119                	beqz	a0,80001000 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80000ffc:	820ff0ef          	jal	ra,8000001c <kfree>
  p->trapframe = 0;
    80001000:	0404bc23          	sd	zero,88(s1)
  if(p->usyscall)
    80001004:	70a8                	ld	a0,96(s1)
    80001006:	c119                	beqz	a0,8000100c <freeproc+0x20>
    kfree((void*)p->usyscall);
    80001008:	814ff0ef          	jal	ra,8000001c <kfree>
  p->usyscall = 0;
    8000100c:	0604b023          	sd	zero,96(s1)
  if(p->pagetable)
    80001010:	68a8                	ld	a0,80(s1)
    80001012:	c501                	beqz	a0,8000101a <freeproc+0x2e>
    proc_freepagetable(p->pagetable, p->sz);
    80001014:	64ac                	ld	a1,72(s1)
    80001016:	f7bff0ef          	jal	ra,80000f90 <proc_freepagetable>
  p->pagetable = 0;
    8000101a:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    8000101e:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001022:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001026:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    8000102a:	16048023          	sb	zero,352(s1)
  p->chan = 0;
    8000102e:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001032:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001036:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    8000103a:	0004ac23          	sw	zero,24(s1)
}
    8000103e:	60e2                	ld	ra,24(sp)
    80001040:	6442                	ld	s0,16(sp)
    80001042:	64a2                	ld	s1,8(sp)
    80001044:	6105                	addi	sp,sp,32
    80001046:	8082                	ret

0000000080001048 <allocproc>:
{
    80001048:	1101                	addi	sp,sp,-32
    8000104a:	ec06                	sd	ra,24(sp)
    8000104c:	e822                	sd	s0,16(sp)
    8000104e:	e426                	sd	s1,8(sp)
    80001050:	e04a                	sd	s2,0(sp)
    80001052:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001054:	00007497          	auipc	s1,0x7
    80001058:	dac48493          	addi	s1,s1,-596 # 80007e00 <proc>
    8000105c:	0000d917          	auipc	s2,0xd
    80001060:	9a490913          	addi	s2,s2,-1628 # 8000da00 <tickslock>
    acquire(&p->lock);
    80001064:	8526                	mv	a0,s1
    80001066:	7c4040ef          	jal	ra,8000582a <acquire>
    if(p->state == UNUSED) {
    8000106a:	4c9c                	lw	a5,24(s1)
    8000106c:	cb91                	beqz	a5,80001080 <allocproc+0x38>
      release(&p->lock);
    8000106e:	8526                	mv	a0,s1
    80001070:	053040ef          	jal	ra,800058c2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001074:	17048493          	addi	s1,s1,368
    80001078:	ff2496e3          	bne	s1,s2,80001064 <allocproc+0x1c>
  return 0;
    8000107c:	4481                	li	s1,0
    8000107e:	a881                	j	800010ce <allocproc+0x86>
  p->pid = allocpid();
    80001080:	e05ff0ef          	jal	ra,80000e84 <allocpid>
    80001084:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001086:	4785                	li	a5,1
    80001088:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    8000108a:	872ff0ef          	jal	ra,800000fc <kalloc>
    8000108e:	892a                	mv	s2,a0
    80001090:	eca8                	sd	a0,88(s1)
    80001092:	c529                	beqz	a0,800010dc <allocproc+0x94>
  if((p->usyscall = (struct usyscall *)kalloc()) == 0){
    80001094:	868ff0ef          	jal	ra,800000fc <kalloc>
    80001098:	892a                	mv	s2,a0
    8000109a:	f0a8                	sd	a0,96(s1)
    8000109c:	c921                	beqz	a0,800010ec <allocproc+0xa4>
  p->usyscall->pid = p->pid;
    8000109e:	589c                	lw	a5,48(s1)
    800010a0:	c11c                	sw	a5,0(a0)
  p->pagetable = proc_pagetable(p);
    800010a2:	8526                	mv	a0,s1
    800010a4:	e1fff0ef          	jal	ra,80000ec2 <proc_pagetable>
    800010a8:	892a                	mv	s2,a0
    800010aa:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    800010ac:	c921                	beqz	a0,800010fc <allocproc+0xb4>
  memset(&p->context, 0, sizeof(p->context));
    800010ae:	07000613          	li	a2,112
    800010b2:	4581                	li	a1,0
    800010b4:	06848513          	addi	a0,s1,104
    800010b8:	894ff0ef          	jal	ra,8000014c <memset>
  p->context.ra = (uint64)forkret;
    800010bc:	00000797          	auipc	a5,0x0
    800010c0:	d8e78793          	addi	a5,a5,-626 # 80000e4a <forkret>
    800010c4:	f4bc                	sd	a5,104(s1)
  p->context.sp = p->kstack + PGSIZE;
    800010c6:	60bc                	ld	a5,64(s1)
    800010c8:	6705                	lui	a4,0x1
    800010ca:	97ba                	add	a5,a5,a4
    800010cc:	f8bc                	sd	a5,112(s1)
}
    800010ce:	8526                	mv	a0,s1
    800010d0:	60e2                	ld	ra,24(sp)
    800010d2:	6442                	ld	s0,16(sp)
    800010d4:	64a2                	ld	s1,8(sp)
    800010d6:	6902                	ld	s2,0(sp)
    800010d8:	6105                	addi	sp,sp,32
    800010da:	8082                	ret
    freeproc(p);
    800010dc:	8526                	mv	a0,s1
    800010de:	f0fff0ef          	jal	ra,80000fec <freeproc>
    release(&p->lock);
    800010e2:	8526                	mv	a0,s1
    800010e4:	7de040ef          	jal	ra,800058c2 <release>
    return 0;
    800010e8:	84ca                	mv	s1,s2
    800010ea:	b7d5                	j	800010ce <allocproc+0x86>
    freeproc(p);
    800010ec:	8526                	mv	a0,s1
    800010ee:	effff0ef          	jal	ra,80000fec <freeproc>
    release(&p->lock);
    800010f2:	8526                	mv	a0,s1
    800010f4:	7ce040ef          	jal	ra,800058c2 <release>
    return 0;
    800010f8:	84ca                	mv	s1,s2
    800010fa:	bfd1                	j	800010ce <allocproc+0x86>
    freeproc(p);
    800010fc:	8526                	mv	a0,s1
    800010fe:	eefff0ef          	jal	ra,80000fec <freeproc>
    release(&p->lock);
    80001102:	8526                	mv	a0,s1
    80001104:	7be040ef          	jal	ra,800058c2 <release>
    return 0;
    80001108:	84ca                	mv	s1,s2
    8000110a:	b7d1                	j	800010ce <allocproc+0x86>

000000008000110c <userinit>:
{
    8000110c:	1101                	addi	sp,sp,-32
    8000110e:	ec06                	sd	ra,24(sp)
    80001110:	e822                	sd	s0,16(sp)
    80001112:	e426                	sd	s1,8(sp)
    80001114:	1000                	addi	s0,sp,32
  p = allocproc();
    80001116:	f33ff0ef          	jal	ra,80001048 <allocproc>
    8000111a:	84aa                	mv	s1,a0
  initproc = p;
    8000111c:	00007797          	auipc	a5,0x7
    80001120:	86a7ba23          	sd	a0,-1932(a5) # 80007990 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001124:	03400613          	li	a2,52
    80001128:	00007597          	auipc	a1,0x7
    8000112c:	81858593          	addi	a1,a1,-2024 # 80007940 <initcode>
    80001130:	6928                	ld	a0,80(a0)
    80001132:	dfeff0ef          	jal	ra,80000730 <uvmfirst>
  p->sz = PGSIZE;
    80001136:	6785                	lui	a5,0x1
    80001138:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    8000113a:	6cb8                	ld	a4,88(s1)
    8000113c:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001140:	6cb8                	ld	a4,88(s1)
    80001142:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001144:	4641                	li	a2,16
    80001146:	00006597          	auipc	a1,0x6
    8000114a:	0ba58593          	addi	a1,a1,186 # 80007200 <etext+0x200>
    8000114e:	16048513          	addi	a0,s1,352
    80001152:	940ff0ef          	jal	ra,80000292 <safestrcpy>
  p->cwd = namei("/");
    80001156:	00006517          	auipc	a0,0x6
    8000115a:	0ba50513          	addi	a0,a0,186 # 80007210 <etext+0x210>
    8000115e:	5d9010ef          	jal	ra,80002f36 <namei>
    80001162:	14a4bc23          	sd	a0,344(s1)
  p->state = RUNNABLE;
    80001166:	478d                	li	a5,3
    80001168:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    8000116a:	8526                	mv	a0,s1
    8000116c:	756040ef          	jal	ra,800058c2 <release>
}
    80001170:	60e2                	ld	ra,24(sp)
    80001172:	6442                	ld	s0,16(sp)
    80001174:	64a2                	ld	s1,8(sp)
    80001176:	6105                	addi	sp,sp,32
    80001178:	8082                	ret

000000008000117a <growproc>:
{
    8000117a:	1101                	addi	sp,sp,-32
    8000117c:	ec06                	sd	ra,24(sp)
    8000117e:	e822                	sd	s0,16(sp)
    80001180:	e426                	sd	s1,8(sp)
    80001182:	e04a                	sd	s2,0(sp)
    80001184:	1000                	addi	s0,sp,32
    80001186:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001188:	c93ff0ef          	jal	ra,80000e1a <myproc>
    8000118c:	84aa                	mv	s1,a0
  sz = p->sz;
    8000118e:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001190:	01204c63          	bgtz	s2,800011a8 <growproc+0x2e>
  } else if(n < 0){
    80001194:	02094463          	bltz	s2,800011bc <growproc+0x42>
  p->sz = sz;
    80001198:	e4ac                	sd	a1,72(s1)
  return 0;
    8000119a:	4501                	li	a0,0
}
    8000119c:	60e2                	ld	ra,24(sp)
    8000119e:	6442                	ld	s0,16(sp)
    800011a0:	64a2                	ld	s1,8(sp)
    800011a2:	6902                	ld	s2,0(sp)
    800011a4:	6105                	addi	sp,sp,32
    800011a6:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    800011a8:	4691                	li	a3,4
    800011aa:	00b90633          	add	a2,s2,a1
    800011ae:	6928                	ld	a0,80(a0)
    800011b0:	e22ff0ef          	jal	ra,800007d2 <uvmalloc>
    800011b4:	85aa                	mv	a1,a0
    800011b6:	f16d                	bnez	a0,80001198 <growproc+0x1e>
      return -1;
    800011b8:	557d                	li	a0,-1
    800011ba:	b7cd                	j	8000119c <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    800011bc:	00b90633          	add	a2,s2,a1
    800011c0:	6928                	ld	a0,80(a0)
    800011c2:	dccff0ef          	jal	ra,8000078e <uvmdealloc>
    800011c6:	85aa                	mv	a1,a0
    800011c8:	bfc1                	j	80001198 <growproc+0x1e>

00000000800011ca <fork>:
{
    800011ca:	7139                	addi	sp,sp,-64
    800011cc:	fc06                	sd	ra,56(sp)
    800011ce:	f822                	sd	s0,48(sp)
    800011d0:	f426                	sd	s1,40(sp)
    800011d2:	f04a                	sd	s2,32(sp)
    800011d4:	ec4e                	sd	s3,24(sp)
    800011d6:	e852                	sd	s4,16(sp)
    800011d8:	e456                	sd	s5,8(sp)
    800011da:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    800011dc:	c3fff0ef          	jal	ra,80000e1a <myproc>
    800011e0:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    800011e2:	e67ff0ef          	jal	ra,80001048 <allocproc>
    800011e6:	0e050663          	beqz	a0,800012d2 <fork+0x108>
    800011ea:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    800011ec:	048ab603          	ld	a2,72(s5)
    800011f0:	692c                	ld	a1,80(a0)
    800011f2:	050ab503          	ld	a0,80(s5)
    800011f6:	f04ff0ef          	jal	ra,800008fa <uvmcopy>
    800011fa:	04054863          	bltz	a0,8000124a <fork+0x80>
  np->sz = p->sz;
    800011fe:	048ab783          	ld	a5,72(s5)
    80001202:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001206:	058ab683          	ld	a3,88(s5)
    8000120a:	87b6                	mv	a5,a3
    8000120c:	058a3703          	ld	a4,88(s4)
    80001210:	12068693          	addi	a3,a3,288
    80001214:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80001218:	6788                	ld	a0,8(a5)
    8000121a:	6b8c                	ld	a1,16(a5)
    8000121c:	6f90                	ld	a2,24(a5)
    8000121e:	01073023          	sd	a6,0(a4)
    80001222:	e708                	sd	a0,8(a4)
    80001224:	eb0c                	sd	a1,16(a4)
    80001226:	ef10                	sd	a2,24(a4)
    80001228:	02078793          	addi	a5,a5,32
    8000122c:	02070713          	addi	a4,a4,32
    80001230:	fed792e3          	bne	a5,a3,80001214 <fork+0x4a>
  np->trapframe->a0 = 0;
    80001234:	058a3783          	ld	a5,88(s4)
    80001238:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    8000123c:	0d8a8493          	addi	s1,s5,216
    80001240:	0d8a0913          	addi	s2,s4,216
    80001244:	158a8993          	addi	s3,s5,344
    80001248:	a829                	j	80001262 <fork+0x98>
    freeproc(np);
    8000124a:	8552                	mv	a0,s4
    8000124c:	da1ff0ef          	jal	ra,80000fec <freeproc>
    release(&np->lock);
    80001250:	8552                	mv	a0,s4
    80001252:	670040ef          	jal	ra,800058c2 <release>
    return -1;
    80001256:	597d                	li	s2,-1
    80001258:	a09d                	j	800012be <fork+0xf4>
  for(i = 0; i < NOFILE; i++)
    8000125a:	04a1                	addi	s1,s1,8
    8000125c:	0921                	addi	s2,s2,8
    8000125e:	01348963          	beq	s1,s3,80001270 <fork+0xa6>
    if(p->ofile[i])
    80001262:	6088                	ld	a0,0(s1)
    80001264:	d97d                	beqz	a0,8000125a <fork+0x90>
      np->ofile[i] = filedup(p->ofile[i]);
    80001266:	282020ef          	jal	ra,800034e8 <filedup>
    8000126a:	00a93023          	sd	a0,0(s2)
    8000126e:	b7f5                	j	8000125a <fork+0x90>
  np->cwd = idup(p->cwd);
    80001270:	158ab503          	ld	a0,344(s5)
    80001274:	5da010ef          	jal	ra,8000284e <idup>
    80001278:	14aa3c23          	sd	a0,344(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    8000127c:	4641                	li	a2,16
    8000127e:	160a8593          	addi	a1,s5,352
    80001282:	160a0513          	addi	a0,s4,352
    80001286:	80cff0ef          	jal	ra,80000292 <safestrcpy>
  pid = np->pid;
    8000128a:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    8000128e:	8552                	mv	a0,s4
    80001290:	632040ef          	jal	ra,800058c2 <release>
  acquire(&wait_lock);
    80001294:	00006497          	auipc	s1,0x6
    80001298:	75448493          	addi	s1,s1,1876 # 800079e8 <wait_lock>
    8000129c:	8526                	mv	a0,s1
    8000129e:	58c040ef          	jal	ra,8000582a <acquire>
  np->parent = p;
    800012a2:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    800012a6:	8526                	mv	a0,s1
    800012a8:	61a040ef          	jal	ra,800058c2 <release>
  acquire(&np->lock);
    800012ac:	8552                	mv	a0,s4
    800012ae:	57c040ef          	jal	ra,8000582a <acquire>
  np->state = RUNNABLE;
    800012b2:	478d                	li	a5,3
    800012b4:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    800012b8:	8552                	mv	a0,s4
    800012ba:	608040ef          	jal	ra,800058c2 <release>
}
    800012be:	854a                	mv	a0,s2
    800012c0:	70e2                	ld	ra,56(sp)
    800012c2:	7442                	ld	s0,48(sp)
    800012c4:	74a2                	ld	s1,40(sp)
    800012c6:	7902                	ld	s2,32(sp)
    800012c8:	69e2                	ld	s3,24(sp)
    800012ca:	6a42                	ld	s4,16(sp)
    800012cc:	6aa2                	ld	s5,8(sp)
    800012ce:	6121                	addi	sp,sp,64
    800012d0:	8082                	ret
    return -1;
    800012d2:	597d                	li	s2,-1
    800012d4:	b7ed                	j	800012be <fork+0xf4>

00000000800012d6 <scheduler>:
{
    800012d6:	715d                	addi	sp,sp,-80
    800012d8:	e486                	sd	ra,72(sp)
    800012da:	e0a2                	sd	s0,64(sp)
    800012dc:	fc26                	sd	s1,56(sp)
    800012de:	f84a                	sd	s2,48(sp)
    800012e0:	f44e                	sd	s3,40(sp)
    800012e2:	f052                	sd	s4,32(sp)
    800012e4:	ec56                	sd	s5,24(sp)
    800012e6:	e85a                	sd	s6,16(sp)
    800012e8:	e45e                	sd	s7,8(sp)
    800012ea:	e062                	sd	s8,0(sp)
    800012ec:	0880                	addi	s0,sp,80
    800012ee:	8792                	mv	a5,tp
  int id = r_tp();
    800012f0:	2781                	sext.w	a5,a5
  c->proc = 0;
    800012f2:	00779b13          	slli	s6,a5,0x7
    800012f6:	00006717          	auipc	a4,0x6
    800012fa:	6da70713          	addi	a4,a4,1754 # 800079d0 <pid_lock>
    800012fe:	975a                	add	a4,a4,s6
    80001300:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001304:	00006717          	auipc	a4,0x6
    80001308:	70470713          	addi	a4,a4,1796 # 80007a08 <cpus+0x8>
    8000130c:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    8000130e:	4c11                	li	s8,4
        c->proc = p;
    80001310:	079e                	slli	a5,a5,0x7
    80001312:	00006a17          	auipc	s4,0x6
    80001316:	6bea0a13          	addi	s4,s4,1726 # 800079d0 <pid_lock>
    8000131a:	9a3e                	add	s4,s4,a5
        found = 1;
    8000131c:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    8000131e:	0000c997          	auipc	s3,0xc
    80001322:	6e298993          	addi	s3,s3,1762 # 8000da00 <tickslock>
    80001326:	a0a9                	j	80001370 <scheduler+0x9a>
      release(&p->lock);
    80001328:	8526                	mv	a0,s1
    8000132a:	598040ef          	jal	ra,800058c2 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    8000132e:	17048493          	addi	s1,s1,368
    80001332:	03348563          	beq	s1,s3,8000135c <scheduler+0x86>
      acquire(&p->lock);
    80001336:	8526                	mv	a0,s1
    80001338:	4f2040ef          	jal	ra,8000582a <acquire>
      if(p->state == RUNNABLE) {
    8000133c:	4c9c                	lw	a5,24(s1)
    8000133e:	ff2795e3          	bne	a5,s2,80001328 <scheduler+0x52>
        p->state = RUNNING;
    80001342:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001346:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    8000134a:	06848593          	addi	a1,s1,104
    8000134e:	855a                	mv	a0,s6
    80001350:	5b4000ef          	jal	ra,80001904 <swtch>
        c->proc = 0;
    80001354:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001358:	8ade                	mv	s5,s7
    8000135a:	b7f9                	j	80001328 <scheduler+0x52>
    if(found == 0) {
    8000135c:	000a9a63          	bnez	s5,80001370 <scheduler+0x9a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001360:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001364:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001368:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    8000136c:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001370:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001374:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001378:	10079073          	csrw	sstatus,a5
    int found = 0;
    8000137c:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    8000137e:	00007497          	auipc	s1,0x7
    80001382:	a8248493          	addi	s1,s1,-1406 # 80007e00 <proc>
      if(p->state == RUNNABLE) {
    80001386:	490d                	li	s2,3
    80001388:	b77d                	j	80001336 <scheduler+0x60>

000000008000138a <sched>:
{
    8000138a:	7179                	addi	sp,sp,-48
    8000138c:	f406                	sd	ra,40(sp)
    8000138e:	f022                	sd	s0,32(sp)
    80001390:	ec26                	sd	s1,24(sp)
    80001392:	e84a                	sd	s2,16(sp)
    80001394:	e44e                	sd	s3,8(sp)
    80001396:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001398:	a83ff0ef          	jal	ra,80000e1a <myproc>
    8000139c:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    8000139e:	422040ef          	jal	ra,800057c0 <holding>
    800013a2:	c92d                	beqz	a0,80001414 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    800013a4:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800013a6:	2781                	sext.w	a5,a5
    800013a8:	079e                	slli	a5,a5,0x7
    800013aa:	00006717          	auipc	a4,0x6
    800013ae:	62670713          	addi	a4,a4,1574 # 800079d0 <pid_lock>
    800013b2:	97ba                	add	a5,a5,a4
    800013b4:	0a87a703          	lw	a4,168(a5)
    800013b8:	4785                	li	a5,1
    800013ba:	06f71363          	bne	a4,a5,80001420 <sched+0x96>
  if(p->state == RUNNING)
    800013be:	4c98                	lw	a4,24(s1)
    800013c0:	4791                	li	a5,4
    800013c2:	06f70563          	beq	a4,a5,8000142c <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800013c6:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800013ca:	8b89                	andi	a5,a5,2
  if(intr_get())
    800013cc:	e7b5                	bnez	a5,80001438 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    800013ce:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800013d0:	00006917          	auipc	s2,0x6
    800013d4:	60090913          	addi	s2,s2,1536 # 800079d0 <pid_lock>
    800013d8:	2781                	sext.w	a5,a5
    800013da:	079e                	slli	a5,a5,0x7
    800013dc:	97ca                	add	a5,a5,s2
    800013de:	0ac7a983          	lw	s3,172(a5)
    800013e2:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800013e4:	2781                	sext.w	a5,a5
    800013e6:	079e                	slli	a5,a5,0x7
    800013e8:	00006597          	auipc	a1,0x6
    800013ec:	62058593          	addi	a1,a1,1568 # 80007a08 <cpus+0x8>
    800013f0:	95be                	add	a1,a1,a5
    800013f2:	06848513          	addi	a0,s1,104
    800013f6:	50e000ef          	jal	ra,80001904 <swtch>
    800013fa:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    800013fc:	2781                	sext.w	a5,a5
    800013fe:	079e                	slli	a5,a5,0x7
    80001400:	97ca                	add	a5,a5,s2
    80001402:	0b37a623          	sw	s3,172(a5)
}
    80001406:	70a2                	ld	ra,40(sp)
    80001408:	7402                	ld	s0,32(sp)
    8000140a:	64e2                	ld	s1,24(sp)
    8000140c:	6942                	ld	s2,16(sp)
    8000140e:	69a2                	ld	s3,8(sp)
    80001410:	6145                	addi	sp,sp,48
    80001412:	8082                	ret
    panic("sched p->lock");
    80001414:	00006517          	auipc	a0,0x6
    80001418:	e0450513          	addi	a0,a0,-508 # 80007218 <etext+0x218>
    8000141c:	0fa040ef          	jal	ra,80005516 <panic>
    panic("sched locks");
    80001420:	00006517          	auipc	a0,0x6
    80001424:	e0850513          	addi	a0,a0,-504 # 80007228 <etext+0x228>
    80001428:	0ee040ef          	jal	ra,80005516 <panic>
    panic("sched running");
    8000142c:	00006517          	auipc	a0,0x6
    80001430:	e0c50513          	addi	a0,a0,-500 # 80007238 <etext+0x238>
    80001434:	0e2040ef          	jal	ra,80005516 <panic>
    panic("sched interruptible");
    80001438:	00006517          	auipc	a0,0x6
    8000143c:	e1050513          	addi	a0,a0,-496 # 80007248 <etext+0x248>
    80001440:	0d6040ef          	jal	ra,80005516 <panic>

0000000080001444 <yield>:
{
    80001444:	1101                	addi	sp,sp,-32
    80001446:	ec06                	sd	ra,24(sp)
    80001448:	e822                	sd	s0,16(sp)
    8000144a:	e426                	sd	s1,8(sp)
    8000144c:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    8000144e:	9cdff0ef          	jal	ra,80000e1a <myproc>
    80001452:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001454:	3d6040ef          	jal	ra,8000582a <acquire>
  p->state = RUNNABLE;
    80001458:	478d                	li	a5,3
    8000145a:	cc9c                	sw	a5,24(s1)
  sched();
    8000145c:	f2fff0ef          	jal	ra,8000138a <sched>
  release(&p->lock);
    80001460:	8526                	mv	a0,s1
    80001462:	460040ef          	jal	ra,800058c2 <release>
}
    80001466:	60e2                	ld	ra,24(sp)
    80001468:	6442                	ld	s0,16(sp)
    8000146a:	64a2                	ld	s1,8(sp)
    8000146c:	6105                	addi	sp,sp,32
    8000146e:	8082                	ret

0000000080001470 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001470:	7179                	addi	sp,sp,-48
    80001472:	f406                	sd	ra,40(sp)
    80001474:	f022                	sd	s0,32(sp)
    80001476:	ec26                	sd	s1,24(sp)
    80001478:	e84a                	sd	s2,16(sp)
    8000147a:	e44e                	sd	s3,8(sp)
    8000147c:	1800                	addi	s0,sp,48
    8000147e:	89aa                	mv	s3,a0
    80001480:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001482:	999ff0ef          	jal	ra,80000e1a <myproc>
    80001486:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001488:	3a2040ef          	jal	ra,8000582a <acquire>
  release(lk);
    8000148c:	854a                	mv	a0,s2
    8000148e:	434040ef          	jal	ra,800058c2 <release>

  // Go to sleep.
  p->chan = chan;
    80001492:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001496:	4789                	li	a5,2
    80001498:	cc9c                	sw	a5,24(s1)

  sched();
    8000149a:	ef1ff0ef          	jal	ra,8000138a <sched>

  // Tidy up.
  p->chan = 0;
    8000149e:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800014a2:	8526                	mv	a0,s1
    800014a4:	41e040ef          	jal	ra,800058c2 <release>
  acquire(lk);
    800014a8:	854a                	mv	a0,s2
    800014aa:	380040ef          	jal	ra,8000582a <acquire>
}
    800014ae:	70a2                	ld	ra,40(sp)
    800014b0:	7402                	ld	s0,32(sp)
    800014b2:	64e2                	ld	s1,24(sp)
    800014b4:	6942                	ld	s2,16(sp)
    800014b6:	69a2                	ld	s3,8(sp)
    800014b8:	6145                	addi	sp,sp,48
    800014ba:	8082                	ret

00000000800014bc <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800014bc:	7139                	addi	sp,sp,-64
    800014be:	fc06                	sd	ra,56(sp)
    800014c0:	f822                	sd	s0,48(sp)
    800014c2:	f426                	sd	s1,40(sp)
    800014c4:	f04a                	sd	s2,32(sp)
    800014c6:	ec4e                	sd	s3,24(sp)
    800014c8:	e852                	sd	s4,16(sp)
    800014ca:	e456                	sd	s5,8(sp)
    800014cc:	0080                	addi	s0,sp,64
    800014ce:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800014d0:	00007497          	auipc	s1,0x7
    800014d4:	93048493          	addi	s1,s1,-1744 # 80007e00 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800014d8:	4989                	li	s3,2
        p->state = RUNNABLE;
    800014da:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800014dc:	0000c917          	auipc	s2,0xc
    800014e0:	52490913          	addi	s2,s2,1316 # 8000da00 <tickslock>
    800014e4:	a801                	j	800014f4 <wakeup+0x38>
      }
      release(&p->lock);
    800014e6:	8526                	mv	a0,s1
    800014e8:	3da040ef          	jal	ra,800058c2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800014ec:	17048493          	addi	s1,s1,368
    800014f0:	03248263          	beq	s1,s2,80001514 <wakeup+0x58>
    if(p != myproc()){
    800014f4:	927ff0ef          	jal	ra,80000e1a <myproc>
    800014f8:	fea48ae3          	beq	s1,a0,800014ec <wakeup+0x30>
      acquire(&p->lock);
    800014fc:	8526                	mv	a0,s1
    800014fe:	32c040ef          	jal	ra,8000582a <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001502:	4c9c                	lw	a5,24(s1)
    80001504:	ff3791e3          	bne	a5,s3,800014e6 <wakeup+0x2a>
    80001508:	709c                	ld	a5,32(s1)
    8000150a:	fd479ee3          	bne	a5,s4,800014e6 <wakeup+0x2a>
        p->state = RUNNABLE;
    8000150e:	0154ac23          	sw	s5,24(s1)
    80001512:	bfd1                	j	800014e6 <wakeup+0x2a>
    }
  }
}
    80001514:	70e2                	ld	ra,56(sp)
    80001516:	7442                	ld	s0,48(sp)
    80001518:	74a2                	ld	s1,40(sp)
    8000151a:	7902                	ld	s2,32(sp)
    8000151c:	69e2                	ld	s3,24(sp)
    8000151e:	6a42                	ld	s4,16(sp)
    80001520:	6aa2                	ld	s5,8(sp)
    80001522:	6121                	addi	sp,sp,64
    80001524:	8082                	ret

0000000080001526 <reparent>:
{
    80001526:	7179                	addi	sp,sp,-48
    80001528:	f406                	sd	ra,40(sp)
    8000152a:	f022                	sd	s0,32(sp)
    8000152c:	ec26                	sd	s1,24(sp)
    8000152e:	e84a                	sd	s2,16(sp)
    80001530:	e44e                	sd	s3,8(sp)
    80001532:	e052                	sd	s4,0(sp)
    80001534:	1800                	addi	s0,sp,48
    80001536:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001538:	00007497          	auipc	s1,0x7
    8000153c:	8c848493          	addi	s1,s1,-1848 # 80007e00 <proc>
      pp->parent = initproc;
    80001540:	00006a17          	auipc	s4,0x6
    80001544:	450a0a13          	addi	s4,s4,1104 # 80007990 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001548:	0000c997          	auipc	s3,0xc
    8000154c:	4b898993          	addi	s3,s3,1208 # 8000da00 <tickslock>
    80001550:	a029                	j	8000155a <reparent+0x34>
    80001552:	17048493          	addi	s1,s1,368
    80001556:	01348b63          	beq	s1,s3,8000156c <reparent+0x46>
    if(pp->parent == p){
    8000155a:	7c9c                	ld	a5,56(s1)
    8000155c:	ff279be3          	bne	a5,s2,80001552 <reparent+0x2c>
      pp->parent = initproc;
    80001560:	000a3503          	ld	a0,0(s4)
    80001564:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001566:	f57ff0ef          	jal	ra,800014bc <wakeup>
    8000156a:	b7e5                	j	80001552 <reparent+0x2c>
}
    8000156c:	70a2                	ld	ra,40(sp)
    8000156e:	7402                	ld	s0,32(sp)
    80001570:	64e2                	ld	s1,24(sp)
    80001572:	6942                	ld	s2,16(sp)
    80001574:	69a2                	ld	s3,8(sp)
    80001576:	6a02                	ld	s4,0(sp)
    80001578:	6145                	addi	sp,sp,48
    8000157a:	8082                	ret

000000008000157c <exit>:
{
    8000157c:	7179                	addi	sp,sp,-48
    8000157e:	f406                	sd	ra,40(sp)
    80001580:	f022                	sd	s0,32(sp)
    80001582:	ec26                	sd	s1,24(sp)
    80001584:	e84a                	sd	s2,16(sp)
    80001586:	e44e                	sd	s3,8(sp)
    80001588:	e052                	sd	s4,0(sp)
    8000158a:	1800                	addi	s0,sp,48
    8000158c:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000158e:	88dff0ef          	jal	ra,80000e1a <myproc>
    80001592:	89aa                	mv	s3,a0
  if(p == initproc)
    80001594:	00006797          	auipc	a5,0x6
    80001598:	3fc7b783          	ld	a5,1020(a5) # 80007990 <initproc>
    8000159c:	0d850493          	addi	s1,a0,216
    800015a0:	15850913          	addi	s2,a0,344
    800015a4:	00a79f63          	bne	a5,a0,800015c2 <exit+0x46>
    panic("init exiting");
    800015a8:	00006517          	auipc	a0,0x6
    800015ac:	cb850513          	addi	a0,a0,-840 # 80007260 <etext+0x260>
    800015b0:	767030ef          	jal	ra,80005516 <panic>
      fileclose(f);
    800015b4:	77b010ef          	jal	ra,8000352e <fileclose>
      p->ofile[fd] = 0;
    800015b8:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    800015bc:	04a1                	addi	s1,s1,8
    800015be:	01248563          	beq	s1,s2,800015c8 <exit+0x4c>
    if(p->ofile[fd]){
    800015c2:	6088                	ld	a0,0(s1)
    800015c4:	f965                	bnez	a0,800015b4 <exit+0x38>
    800015c6:	bfdd                	j	800015bc <exit+0x40>
  begin_op();
    800015c8:	34b010ef          	jal	ra,80003112 <begin_op>
  iput(p->cwd);
    800015cc:	1589b503          	ld	a0,344(s3)
    800015d0:	432010ef          	jal	ra,80002a02 <iput>
  end_op();
    800015d4:	3af010ef          	jal	ra,80003182 <end_op>
  p->cwd = 0;
    800015d8:	1409bc23          	sd	zero,344(s3)
  acquire(&wait_lock);
    800015dc:	00006497          	auipc	s1,0x6
    800015e0:	40c48493          	addi	s1,s1,1036 # 800079e8 <wait_lock>
    800015e4:	8526                	mv	a0,s1
    800015e6:	244040ef          	jal	ra,8000582a <acquire>
  reparent(p);
    800015ea:	854e                	mv	a0,s3
    800015ec:	f3bff0ef          	jal	ra,80001526 <reparent>
  wakeup(p->parent);
    800015f0:	0389b503          	ld	a0,56(s3)
    800015f4:	ec9ff0ef          	jal	ra,800014bc <wakeup>
  acquire(&p->lock);
    800015f8:	854e                	mv	a0,s3
    800015fa:	230040ef          	jal	ra,8000582a <acquire>
  p->xstate = status;
    800015fe:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80001602:	4795                	li	a5,5
    80001604:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80001608:	8526                	mv	a0,s1
    8000160a:	2b8040ef          	jal	ra,800058c2 <release>
  sched();
    8000160e:	d7dff0ef          	jal	ra,8000138a <sched>
  panic("zombie exit");
    80001612:	00006517          	auipc	a0,0x6
    80001616:	c5e50513          	addi	a0,a0,-930 # 80007270 <etext+0x270>
    8000161a:	6fd030ef          	jal	ra,80005516 <panic>

000000008000161e <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    8000161e:	7179                	addi	sp,sp,-48
    80001620:	f406                	sd	ra,40(sp)
    80001622:	f022                	sd	s0,32(sp)
    80001624:	ec26                	sd	s1,24(sp)
    80001626:	e84a                	sd	s2,16(sp)
    80001628:	e44e                	sd	s3,8(sp)
    8000162a:	1800                	addi	s0,sp,48
    8000162c:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    8000162e:	00006497          	auipc	s1,0x6
    80001632:	7d248493          	addi	s1,s1,2002 # 80007e00 <proc>
    80001636:	0000c997          	auipc	s3,0xc
    8000163a:	3ca98993          	addi	s3,s3,970 # 8000da00 <tickslock>
    acquire(&p->lock);
    8000163e:	8526                	mv	a0,s1
    80001640:	1ea040ef          	jal	ra,8000582a <acquire>
    if(p->pid == pid){
    80001644:	589c                	lw	a5,48(s1)
    80001646:	01278b63          	beq	a5,s2,8000165c <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000164a:	8526                	mv	a0,s1
    8000164c:	276040ef          	jal	ra,800058c2 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80001650:	17048493          	addi	s1,s1,368
    80001654:	ff3495e3          	bne	s1,s3,8000163e <kill+0x20>
  }
  return -1;
    80001658:	557d                	li	a0,-1
    8000165a:	a819                	j	80001670 <kill+0x52>
      p->killed = 1;
    8000165c:	4785                	li	a5,1
    8000165e:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80001660:	4c98                	lw	a4,24(s1)
    80001662:	4789                	li	a5,2
    80001664:	00f70d63          	beq	a4,a5,8000167e <kill+0x60>
      release(&p->lock);
    80001668:	8526                	mv	a0,s1
    8000166a:	258040ef          	jal	ra,800058c2 <release>
      return 0;
    8000166e:	4501                	li	a0,0
}
    80001670:	70a2                	ld	ra,40(sp)
    80001672:	7402                	ld	s0,32(sp)
    80001674:	64e2                	ld	s1,24(sp)
    80001676:	6942                	ld	s2,16(sp)
    80001678:	69a2                	ld	s3,8(sp)
    8000167a:	6145                	addi	sp,sp,48
    8000167c:	8082                	ret
        p->state = RUNNABLE;
    8000167e:	478d                	li	a5,3
    80001680:	cc9c                	sw	a5,24(s1)
    80001682:	b7dd                	j	80001668 <kill+0x4a>

0000000080001684 <setkilled>:

void
setkilled(struct proc *p)
{
    80001684:	1101                	addi	sp,sp,-32
    80001686:	ec06                	sd	ra,24(sp)
    80001688:	e822                	sd	s0,16(sp)
    8000168a:	e426                	sd	s1,8(sp)
    8000168c:	1000                	addi	s0,sp,32
    8000168e:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001690:	19a040ef          	jal	ra,8000582a <acquire>
  p->killed = 1;
    80001694:	4785                	li	a5,1
    80001696:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80001698:	8526                	mv	a0,s1
    8000169a:	228040ef          	jal	ra,800058c2 <release>
}
    8000169e:	60e2                	ld	ra,24(sp)
    800016a0:	6442                	ld	s0,16(sp)
    800016a2:	64a2                	ld	s1,8(sp)
    800016a4:	6105                	addi	sp,sp,32
    800016a6:	8082                	ret

00000000800016a8 <killed>:

int
killed(struct proc *p)
{
    800016a8:	1101                	addi	sp,sp,-32
    800016aa:	ec06                	sd	ra,24(sp)
    800016ac:	e822                	sd	s0,16(sp)
    800016ae:	e426                	sd	s1,8(sp)
    800016b0:	e04a                	sd	s2,0(sp)
    800016b2:	1000                	addi	s0,sp,32
    800016b4:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800016b6:	174040ef          	jal	ra,8000582a <acquire>
  k = p->killed;
    800016ba:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800016be:	8526                	mv	a0,s1
    800016c0:	202040ef          	jal	ra,800058c2 <release>
  return k;
}
    800016c4:	854a                	mv	a0,s2
    800016c6:	60e2                	ld	ra,24(sp)
    800016c8:	6442                	ld	s0,16(sp)
    800016ca:	64a2                	ld	s1,8(sp)
    800016cc:	6902                	ld	s2,0(sp)
    800016ce:	6105                	addi	sp,sp,32
    800016d0:	8082                	ret

00000000800016d2 <wait>:
{
    800016d2:	715d                	addi	sp,sp,-80
    800016d4:	e486                	sd	ra,72(sp)
    800016d6:	e0a2                	sd	s0,64(sp)
    800016d8:	fc26                	sd	s1,56(sp)
    800016da:	f84a                	sd	s2,48(sp)
    800016dc:	f44e                	sd	s3,40(sp)
    800016de:	f052                	sd	s4,32(sp)
    800016e0:	ec56                	sd	s5,24(sp)
    800016e2:	e85a                	sd	s6,16(sp)
    800016e4:	e45e                	sd	s7,8(sp)
    800016e6:	e062                	sd	s8,0(sp)
    800016e8:	0880                	addi	s0,sp,80
    800016ea:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800016ec:	f2eff0ef          	jal	ra,80000e1a <myproc>
    800016f0:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800016f2:	00006517          	auipc	a0,0x6
    800016f6:	2f650513          	addi	a0,a0,758 # 800079e8 <wait_lock>
    800016fa:	130040ef          	jal	ra,8000582a <acquire>
    havekids = 0;
    800016fe:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    80001700:	4a15                	li	s4,5
        havekids = 1;
    80001702:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001704:	0000c997          	auipc	s3,0xc
    80001708:	2fc98993          	addi	s3,s3,764 # 8000da00 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000170c:	00006c17          	auipc	s8,0x6
    80001710:	2dcc0c13          	addi	s8,s8,732 # 800079e8 <wait_lock>
    havekids = 0;
    80001714:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001716:	00006497          	auipc	s1,0x6
    8000171a:	6ea48493          	addi	s1,s1,1770 # 80007e00 <proc>
    8000171e:	a899                	j	80001774 <wait+0xa2>
          pid = pp->pid;
    80001720:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80001724:	000b0c63          	beqz	s6,8000173c <wait+0x6a>
    80001728:	4691                	li	a3,4
    8000172a:	02c48613          	addi	a2,s1,44
    8000172e:	85da                	mv	a1,s6
    80001730:	05093503          	ld	a0,80(s2)
    80001734:	aa2ff0ef          	jal	ra,800009d6 <copyout>
    80001738:	00054f63          	bltz	a0,80001756 <wait+0x84>
          freeproc(pp);
    8000173c:	8526                	mv	a0,s1
    8000173e:	8afff0ef          	jal	ra,80000fec <freeproc>
          release(&pp->lock);
    80001742:	8526                	mv	a0,s1
    80001744:	17e040ef          	jal	ra,800058c2 <release>
          release(&wait_lock);
    80001748:	00006517          	auipc	a0,0x6
    8000174c:	2a050513          	addi	a0,a0,672 # 800079e8 <wait_lock>
    80001750:	172040ef          	jal	ra,800058c2 <release>
          return pid;
    80001754:	a891                	j	800017a8 <wait+0xd6>
            release(&pp->lock);
    80001756:	8526                	mv	a0,s1
    80001758:	16a040ef          	jal	ra,800058c2 <release>
            release(&wait_lock);
    8000175c:	00006517          	auipc	a0,0x6
    80001760:	28c50513          	addi	a0,a0,652 # 800079e8 <wait_lock>
    80001764:	15e040ef          	jal	ra,800058c2 <release>
            return -1;
    80001768:	59fd                	li	s3,-1
    8000176a:	a83d                	j	800017a8 <wait+0xd6>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000176c:	17048493          	addi	s1,s1,368
    80001770:	03348063          	beq	s1,s3,80001790 <wait+0xbe>
      if(pp->parent == p){
    80001774:	7c9c                	ld	a5,56(s1)
    80001776:	ff279be3          	bne	a5,s2,8000176c <wait+0x9a>
        acquire(&pp->lock);
    8000177a:	8526                	mv	a0,s1
    8000177c:	0ae040ef          	jal	ra,8000582a <acquire>
        if(pp->state == ZOMBIE){
    80001780:	4c9c                	lw	a5,24(s1)
    80001782:	f9478fe3          	beq	a5,s4,80001720 <wait+0x4e>
        release(&pp->lock);
    80001786:	8526                	mv	a0,s1
    80001788:	13a040ef          	jal	ra,800058c2 <release>
        havekids = 1;
    8000178c:	8756                	mv	a4,s5
    8000178e:	bff9                	j	8000176c <wait+0x9a>
    if(!havekids || killed(p)){
    80001790:	c709                	beqz	a4,8000179a <wait+0xc8>
    80001792:	854a                	mv	a0,s2
    80001794:	f15ff0ef          	jal	ra,800016a8 <killed>
    80001798:	c50d                	beqz	a0,800017c2 <wait+0xf0>
      release(&wait_lock);
    8000179a:	00006517          	auipc	a0,0x6
    8000179e:	24e50513          	addi	a0,a0,590 # 800079e8 <wait_lock>
    800017a2:	120040ef          	jal	ra,800058c2 <release>
      return -1;
    800017a6:	59fd                	li	s3,-1
}
    800017a8:	854e                	mv	a0,s3
    800017aa:	60a6                	ld	ra,72(sp)
    800017ac:	6406                	ld	s0,64(sp)
    800017ae:	74e2                	ld	s1,56(sp)
    800017b0:	7942                	ld	s2,48(sp)
    800017b2:	79a2                	ld	s3,40(sp)
    800017b4:	7a02                	ld	s4,32(sp)
    800017b6:	6ae2                	ld	s5,24(sp)
    800017b8:	6b42                	ld	s6,16(sp)
    800017ba:	6ba2                	ld	s7,8(sp)
    800017bc:	6c02                	ld	s8,0(sp)
    800017be:	6161                	addi	sp,sp,80
    800017c0:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800017c2:	85e2                	mv	a1,s8
    800017c4:	854a                	mv	a0,s2
    800017c6:	cabff0ef          	jal	ra,80001470 <sleep>
    havekids = 0;
    800017ca:	b7a9                	j	80001714 <wait+0x42>

00000000800017cc <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800017cc:	7179                	addi	sp,sp,-48
    800017ce:	f406                	sd	ra,40(sp)
    800017d0:	f022                	sd	s0,32(sp)
    800017d2:	ec26                	sd	s1,24(sp)
    800017d4:	e84a                	sd	s2,16(sp)
    800017d6:	e44e                	sd	s3,8(sp)
    800017d8:	e052                	sd	s4,0(sp)
    800017da:	1800                	addi	s0,sp,48
    800017dc:	84aa                	mv	s1,a0
    800017de:	892e                	mv	s2,a1
    800017e0:	89b2                	mv	s3,a2
    800017e2:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800017e4:	e36ff0ef          	jal	ra,80000e1a <myproc>
  if(user_dst){
    800017e8:	cc99                	beqz	s1,80001806 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800017ea:	86d2                	mv	a3,s4
    800017ec:	864e                	mv	a2,s3
    800017ee:	85ca                	mv	a1,s2
    800017f0:	6928                	ld	a0,80(a0)
    800017f2:	9e4ff0ef          	jal	ra,800009d6 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800017f6:	70a2                	ld	ra,40(sp)
    800017f8:	7402                	ld	s0,32(sp)
    800017fa:	64e2                	ld	s1,24(sp)
    800017fc:	6942                	ld	s2,16(sp)
    800017fe:	69a2                	ld	s3,8(sp)
    80001800:	6a02                	ld	s4,0(sp)
    80001802:	6145                	addi	sp,sp,48
    80001804:	8082                	ret
    memmove((char *)dst, src, len);
    80001806:	000a061b          	sext.w	a2,s4
    8000180a:	85ce                	mv	a1,s3
    8000180c:	854a                	mv	a0,s2
    8000180e:	99bfe0ef          	jal	ra,800001a8 <memmove>
    return 0;
    80001812:	8526                	mv	a0,s1
    80001814:	b7cd                	j	800017f6 <either_copyout+0x2a>

0000000080001816 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80001816:	7179                	addi	sp,sp,-48
    80001818:	f406                	sd	ra,40(sp)
    8000181a:	f022                	sd	s0,32(sp)
    8000181c:	ec26                	sd	s1,24(sp)
    8000181e:	e84a                	sd	s2,16(sp)
    80001820:	e44e                	sd	s3,8(sp)
    80001822:	e052                	sd	s4,0(sp)
    80001824:	1800                	addi	s0,sp,48
    80001826:	892a                	mv	s2,a0
    80001828:	84ae                	mv	s1,a1
    8000182a:	89b2                	mv	s3,a2
    8000182c:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000182e:	decff0ef          	jal	ra,80000e1a <myproc>
  if(user_src){
    80001832:	cc99                	beqz	s1,80001850 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80001834:	86d2                	mv	a3,s4
    80001836:	864e                	mv	a2,s3
    80001838:	85ca                	mv	a1,s2
    8000183a:	6928                	ld	a0,80(a0)
    8000183c:	a52ff0ef          	jal	ra,80000a8e <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80001840:	70a2                	ld	ra,40(sp)
    80001842:	7402                	ld	s0,32(sp)
    80001844:	64e2                	ld	s1,24(sp)
    80001846:	6942                	ld	s2,16(sp)
    80001848:	69a2                	ld	s3,8(sp)
    8000184a:	6a02                	ld	s4,0(sp)
    8000184c:	6145                	addi	sp,sp,48
    8000184e:	8082                	ret
    memmove(dst, (char*)src, len);
    80001850:	000a061b          	sext.w	a2,s4
    80001854:	85ce                	mv	a1,s3
    80001856:	854a                	mv	a0,s2
    80001858:	951fe0ef          	jal	ra,800001a8 <memmove>
    return 0;
    8000185c:	8526                	mv	a0,s1
    8000185e:	b7cd                	j	80001840 <either_copyin+0x2a>

0000000080001860 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80001860:	715d                	addi	sp,sp,-80
    80001862:	e486                	sd	ra,72(sp)
    80001864:	e0a2                	sd	s0,64(sp)
    80001866:	fc26                	sd	s1,56(sp)
    80001868:	f84a                	sd	s2,48(sp)
    8000186a:	f44e                	sd	s3,40(sp)
    8000186c:	f052                	sd	s4,32(sp)
    8000186e:	ec56                	sd	s5,24(sp)
    80001870:	e85a                	sd	s6,16(sp)
    80001872:	e45e                	sd	s7,8(sp)
    80001874:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001876:	00005517          	auipc	a0,0x5
    8000187a:	7d250513          	addi	a0,a0,2002 # 80007048 <etext+0x48>
    8000187e:	1e5030ef          	jal	ra,80005262 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80001882:	00006497          	auipc	s1,0x6
    80001886:	6de48493          	addi	s1,s1,1758 # 80007f60 <proc+0x160>
    8000188a:	0000c917          	auipc	s2,0xc
    8000188e:	2d690913          	addi	s2,s2,726 # 8000db60 <bcache+0x148>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80001892:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80001894:	00006997          	auipc	s3,0x6
    80001898:	9ec98993          	addi	s3,s3,-1556 # 80007280 <etext+0x280>
    printf("%d %s %s", p->pid, state, p->name);
    8000189c:	00006a97          	auipc	s5,0x6
    800018a0:	9eca8a93          	addi	s5,s5,-1556 # 80007288 <etext+0x288>
    printf("\n");
    800018a4:	00005a17          	auipc	s4,0x5
    800018a8:	7a4a0a13          	addi	s4,s4,1956 # 80007048 <etext+0x48>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018ac:	00006b97          	auipc	s7,0x6
    800018b0:	a1cb8b93          	addi	s7,s7,-1508 # 800072c8 <states.0>
    800018b4:	a829                	j	800018ce <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800018b6:	ed06a583          	lw	a1,-304(a3)
    800018ba:	8556                	mv	a0,s5
    800018bc:	1a7030ef          	jal	ra,80005262 <printf>
    printf("\n");
    800018c0:	8552                	mv	a0,s4
    800018c2:	1a1030ef          	jal	ra,80005262 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800018c6:	17048493          	addi	s1,s1,368
    800018ca:	03248263          	beq	s1,s2,800018ee <procdump+0x8e>
    if(p->state == UNUSED)
    800018ce:	86a6                	mv	a3,s1
    800018d0:	eb84a783          	lw	a5,-328(s1)
    800018d4:	dbed                	beqz	a5,800018c6 <procdump+0x66>
      state = "???";
    800018d6:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018d8:	fcfb6fe3          	bltu	s6,a5,800018b6 <procdump+0x56>
    800018dc:	02079713          	slli	a4,a5,0x20
    800018e0:	01d75793          	srli	a5,a4,0x1d
    800018e4:	97de                	add	a5,a5,s7
    800018e6:	6390                	ld	a2,0(a5)
    800018e8:	f679                	bnez	a2,800018b6 <procdump+0x56>
      state = "???";
    800018ea:	864e                	mv	a2,s3
    800018ec:	b7e9                	j	800018b6 <procdump+0x56>
  }
}
    800018ee:	60a6                	ld	ra,72(sp)
    800018f0:	6406                	ld	s0,64(sp)
    800018f2:	74e2                	ld	s1,56(sp)
    800018f4:	7942                	ld	s2,48(sp)
    800018f6:	79a2                	ld	s3,40(sp)
    800018f8:	7a02                	ld	s4,32(sp)
    800018fa:	6ae2                	ld	s5,24(sp)
    800018fc:	6b42                	ld	s6,16(sp)
    800018fe:	6ba2                	ld	s7,8(sp)
    80001900:	6161                	addi	sp,sp,80
    80001902:	8082                	ret

0000000080001904 <swtch>:
    80001904:	00153023          	sd	ra,0(a0)
    80001908:	00253423          	sd	sp,8(a0)
    8000190c:	e900                	sd	s0,16(a0)
    8000190e:	ed04                	sd	s1,24(a0)
    80001910:	03253023          	sd	s2,32(a0)
    80001914:	03353423          	sd	s3,40(a0)
    80001918:	03453823          	sd	s4,48(a0)
    8000191c:	03553c23          	sd	s5,56(a0)
    80001920:	05653023          	sd	s6,64(a0)
    80001924:	05753423          	sd	s7,72(a0)
    80001928:	05853823          	sd	s8,80(a0)
    8000192c:	05953c23          	sd	s9,88(a0)
    80001930:	07a53023          	sd	s10,96(a0)
    80001934:	07b53423          	sd	s11,104(a0)
    80001938:	0005b083          	ld	ra,0(a1)
    8000193c:	0085b103          	ld	sp,8(a1)
    80001940:	6980                	ld	s0,16(a1)
    80001942:	6d84                	ld	s1,24(a1)
    80001944:	0205b903          	ld	s2,32(a1)
    80001948:	0285b983          	ld	s3,40(a1)
    8000194c:	0305ba03          	ld	s4,48(a1)
    80001950:	0385ba83          	ld	s5,56(a1)
    80001954:	0405bb03          	ld	s6,64(a1)
    80001958:	0485bb83          	ld	s7,72(a1)
    8000195c:	0505bc03          	ld	s8,80(a1)
    80001960:	0585bc83          	ld	s9,88(a1)
    80001964:	0605bd03          	ld	s10,96(a1)
    80001968:	0685bd83          	ld	s11,104(a1)
    8000196c:	8082                	ret

000000008000196e <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000196e:	1141                	addi	sp,sp,-16
    80001970:	e406                	sd	ra,8(sp)
    80001972:	e022                	sd	s0,0(sp)
    80001974:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001976:	00006597          	auipc	a1,0x6
    8000197a:	98258593          	addi	a1,a1,-1662 # 800072f8 <states.0+0x30>
    8000197e:	0000c517          	auipc	a0,0xc
    80001982:	08250513          	addi	a0,a0,130 # 8000da00 <tickslock>
    80001986:	625030ef          	jal	ra,800057aa <initlock>
}
    8000198a:	60a2                	ld	ra,8(sp)
    8000198c:	6402                	ld	s0,0(sp)
    8000198e:	0141                	addi	sp,sp,16
    80001990:	8082                	ret

0000000080001992 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80001992:	1141                	addi	sp,sp,-16
    80001994:	e422                	sd	s0,8(sp)
    80001996:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001998:	00003797          	auipc	a5,0x3
    8000199c:	e6878793          	addi	a5,a5,-408 # 80004800 <kernelvec>
    800019a0:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800019a4:	6422                	ld	s0,8(sp)
    800019a6:	0141                	addi	sp,sp,16
    800019a8:	8082                	ret

00000000800019aa <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    800019aa:	1141                	addi	sp,sp,-16
    800019ac:	e406                	sd	ra,8(sp)
    800019ae:	e022                	sd	s0,0(sp)
    800019b0:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800019b2:	c68ff0ef          	jal	ra,80000e1a <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800019b6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800019ba:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800019bc:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800019c0:	00004617          	auipc	a2,0x4
    800019c4:	64060613          	addi	a2,a2,1600 # 80006000 <_trampoline>
    800019c8:	00004697          	auipc	a3,0x4
    800019cc:	63868693          	addi	a3,a3,1592 # 80006000 <_trampoline>
    800019d0:	8e91                	sub	a3,a3,a2
    800019d2:	040007b7          	lui	a5,0x4000
    800019d6:	17fd                	addi	a5,a5,-1
    800019d8:	07b2                	slli	a5,a5,0xc
    800019da:	96be                	add	a3,a3,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    800019dc:	10569073          	csrw	stvec,a3
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800019e0:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800019e2:	180026f3          	csrr	a3,satp
    800019e6:	e314                	sd	a3,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800019e8:	6d38                	ld	a4,88(a0)
    800019ea:	6134                	ld	a3,64(a0)
    800019ec:	6585                	lui	a1,0x1
    800019ee:	96ae                	add	a3,a3,a1
    800019f0:	e714                	sd	a3,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800019f2:	6d38                	ld	a4,88(a0)
    800019f4:	00000697          	auipc	a3,0x0
    800019f8:	10c68693          	addi	a3,a3,268 # 80001b00 <usertrap>
    800019fc:	eb14                	sd	a3,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800019fe:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001a00:	8692                	mv	a3,tp
    80001a02:	f314                	sd	a3,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a04:	100026f3          	csrr	a3,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001a08:	eff6f693          	andi	a3,a3,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001a0c:	0206e693          	ori	a3,a3,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001a10:	10069073          	csrw	sstatus,a3
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001a14:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001a16:	6f18                	ld	a4,24(a4)
    80001a18:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001a1c:	6928                	ld	a0,80(a0)
    80001a1e:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001a20:	00004717          	auipc	a4,0x4
    80001a24:	67c70713          	addi	a4,a4,1660 # 8000609c <userret>
    80001a28:	8f11                	sub	a4,a4,a2
    80001a2a:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001a2c:	577d                	li	a4,-1
    80001a2e:	177e                	slli	a4,a4,0x3f
    80001a30:	8d59                	or	a0,a0,a4
    80001a32:	9782                	jalr	a5
}
    80001a34:	60a2                	ld	ra,8(sp)
    80001a36:	6402                	ld	s0,0(sp)
    80001a38:	0141                	addi	sp,sp,16
    80001a3a:	8082                	ret

0000000080001a3c <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001a3c:	1101                	addi	sp,sp,-32
    80001a3e:	ec06                	sd	ra,24(sp)
    80001a40:	e822                	sd	s0,16(sp)
    80001a42:	e426                	sd	s1,8(sp)
    80001a44:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    80001a46:	ba8ff0ef          	jal	ra,80000dee <cpuid>
    80001a4a:	cd19                	beqz	a0,80001a68 <clockintr+0x2c>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001a4c:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001a50:	000f4737          	lui	a4,0xf4
    80001a54:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001a58:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001a5a:	14d79073          	csrw	0x14d,a5
}
    80001a5e:	60e2                	ld	ra,24(sp)
    80001a60:	6442                	ld	s0,16(sp)
    80001a62:	64a2                	ld	s1,8(sp)
    80001a64:	6105                	addi	sp,sp,32
    80001a66:	8082                	ret
    acquire(&tickslock);
    80001a68:	0000c497          	auipc	s1,0xc
    80001a6c:	f9848493          	addi	s1,s1,-104 # 8000da00 <tickslock>
    80001a70:	8526                	mv	a0,s1
    80001a72:	5b9030ef          	jal	ra,8000582a <acquire>
    ticks++;
    80001a76:	00006517          	auipc	a0,0x6
    80001a7a:	f2250513          	addi	a0,a0,-222 # 80007998 <ticks>
    80001a7e:	411c                	lw	a5,0(a0)
    80001a80:	2785                	addiw	a5,a5,1
    80001a82:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    80001a84:	a39ff0ef          	jal	ra,800014bc <wakeup>
    release(&tickslock);
    80001a88:	8526                	mv	a0,s1
    80001a8a:	639030ef          	jal	ra,800058c2 <release>
    80001a8e:	bf7d                	j	80001a4c <clockintr+0x10>

0000000080001a90 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001a90:	1101                	addi	sp,sp,-32
    80001a92:	ec06                	sd	ra,24(sp)
    80001a94:	e822                	sd	s0,16(sp)
    80001a96:	e426                	sd	s1,8(sp)
    80001a98:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001a9a:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001a9e:	57fd                	li	a5,-1
    80001aa0:	17fe                	slli	a5,a5,0x3f
    80001aa2:	07a5                	addi	a5,a5,9
    80001aa4:	00f70d63          	beq	a4,a5,80001abe <devintr+0x2e>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001aa8:	57fd                	li	a5,-1
    80001aaa:	17fe                	slli	a5,a5,0x3f
    80001aac:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001aae:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001ab0:	04f70463          	beq	a4,a5,80001af8 <devintr+0x68>
  }
}
    80001ab4:	60e2                	ld	ra,24(sp)
    80001ab6:	6442                	ld	s0,16(sp)
    80001ab8:	64a2                	ld	s1,8(sp)
    80001aba:	6105                	addi	sp,sp,32
    80001abc:	8082                	ret
    int irq = plic_claim();
    80001abe:	5eb020ef          	jal	ra,800048a8 <plic_claim>
    80001ac2:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001ac4:	47a9                	li	a5,10
    80001ac6:	02f50363          	beq	a0,a5,80001aec <devintr+0x5c>
    } else if(irq == VIRTIO0_IRQ){
    80001aca:	4785                	li	a5,1
    80001acc:	02f50363          	beq	a0,a5,80001af2 <devintr+0x62>
    return 1;
    80001ad0:	4505                	li	a0,1
    } else if(irq){
    80001ad2:	d0ed                	beqz	s1,80001ab4 <devintr+0x24>
      printf("unexpected interrupt irq=%d\n", irq);
    80001ad4:	85a6                	mv	a1,s1
    80001ad6:	00006517          	auipc	a0,0x6
    80001ada:	82a50513          	addi	a0,a0,-2006 # 80007300 <states.0+0x38>
    80001ade:	784030ef          	jal	ra,80005262 <printf>
      plic_complete(irq);
    80001ae2:	8526                	mv	a0,s1
    80001ae4:	5e5020ef          	jal	ra,800048c8 <plic_complete>
    return 1;
    80001ae8:	4505                	li	a0,1
    80001aea:	b7e9                	j	80001ab4 <devintr+0x24>
      uartintr();
    80001aec:	483030ef          	jal	ra,8000576e <uartintr>
    80001af0:	bfcd                	j	80001ae2 <devintr+0x52>
      virtio_disk_intr();
    80001af2:	246030ef          	jal	ra,80004d38 <virtio_disk_intr>
    80001af6:	b7f5                	j	80001ae2 <devintr+0x52>
    clockintr();
    80001af8:	f45ff0ef          	jal	ra,80001a3c <clockintr>
    return 2;
    80001afc:	4509                	li	a0,2
    80001afe:	bf5d                	j	80001ab4 <devintr+0x24>

0000000080001b00 <usertrap>:
{
    80001b00:	1101                	addi	sp,sp,-32
    80001b02:	ec06                	sd	ra,24(sp)
    80001b04:	e822                	sd	s0,16(sp)
    80001b06:	e426                	sd	s1,8(sp)
    80001b08:	e04a                	sd	s2,0(sp)
    80001b0a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b0c:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001b10:	1007f793          	andi	a5,a5,256
    80001b14:	ef85                	bnez	a5,80001b4c <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001b16:	00003797          	auipc	a5,0x3
    80001b1a:	cea78793          	addi	a5,a5,-790 # 80004800 <kernelvec>
    80001b1e:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001b22:	af8ff0ef          	jal	ra,80000e1a <myproc>
    80001b26:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001b28:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b2a:	14102773          	csrr	a4,sepc
    80001b2e:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b30:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001b34:	47a1                	li	a5,8
    80001b36:	02f70163          	beq	a4,a5,80001b58 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001b3a:	f57ff0ef          	jal	ra,80001a90 <devintr>
    80001b3e:	892a                	mv	s2,a0
    80001b40:	c135                	beqz	a0,80001ba4 <usertrap+0xa4>
  if(killed(p))
    80001b42:	8526                	mv	a0,s1
    80001b44:	b65ff0ef          	jal	ra,800016a8 <killed>
    80001b48:	cd1d                	beqz	a0,80001b86 <usertrap+0x86>
    80001b4a:	a81d                	j	80001b80 <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001b4c:	00005517          	auipc	a0,0x5
    80001b50:	7d450513          	addi	a0,a0,2004 # 80007320 <states.0+0x58>
    80001b54:	1c3030ef          	jal	ra,80005516 <panic>
    if(killed(p))
    80001b58:	b51ff0ef          	jal	ra,800016a8 <killed>
    80001b5c:	e121                	bnez	a0,80001b9c <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001b5e:	6cb8                	ld	a4,88(s1)
    80001b60:	6f1c                	ld	a5,24(a4)
    80001b62:	0791                	addi	a5,a5,4
    80001b64:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b66:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001b6a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001b6e:	10079073          	csrw	sstatus,a5
    syscall();
    80001b72:	248000ef          	jal	ra,80001dba <syscall>
  if(killed(p))
    80001b76:	8526                	mv	a0,s1
    80001b78:	b31ff0ef          	jal	ra,800016a8 <killed>
    80001b7c:	c901                	beqz	a0,80001b8c <usertrap+0x8c>
    80001b7e:	4901                	li	s2,0
    exit(-1);
    80001b80:	557d                	li	a0,-1
    80001b82:	9fbff0ef          	jal	ra,8000157c <exit>
  if(which_dev == 2)
    80001b86:	4789                	li	a5,2
    80001b88:	04f90563          	beq	s2,a5,80001bd2 <usertrap+0xd2>
  usertrapret();
    80001b8c:	e1fff0ef          	jal	ra,800019aa <usertrapret>
}
    80001b90:	60e2                	ld	ra,24(sp)
    80001b92:	6442                	ld	s0,16(sp)
    80001b94:	64a2                	ld	s1,8(sp)
    80001b96:	6902                	ld	s2,0(sp)
    80001b98:	6105                	addi	sp,sp,32
    80001b9a:	8082                	ret
      exit(-1);
    80001b9c:	557d                	li	a0,-1
    80001b9e:	9dfff0ef          	jal	ra,8000157c <exit>
    80001ba2:	bf75                	j	80001b5e <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001ba4:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001ba8:	5890                	lw	a2,48(s1)
    80001baa:	00005517          	auipc	a0,0x5
    80001bae:	79650513          	addi	a0,a0,1942 # 80007340 <states.0+0x78>
    80001bb2:	6b0030ef          	jal	ra,80005262 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001bb6:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001bba:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001bbe:	00005517          	auipc	a0,0x5
    80001bc2:	7b250513          	addi	a0,a0,1970 # 80007370 <states.0+0xa8>
    80001bc6:	69c030ef          	jal	ra,80005262 <printf>
    setkilled(p);
    80001bca:	8526                	mv	a0,s1
    80001bcc:	ab9ff0ef          	jal	ra,80001684 <setkilled>
    80001bd0:	b75d                	j	80001b76 <usertrap+0x76>
    yield();
    80001bd2:	873ff0ef          	jal	ra,80001444 <yield>
    80001bd6:	bf5d                	j	80001b8c <usertrap+0x8c>

0000000080001bd8 <kerneltrap>:
{
    80001bd8:	7179                	addi	sp,sp,-48
    80001bda:	f406                	sd	ra,40(sp)
    80001bdc:	f022                	sd	s0,32(sp)
    80001bde:	ec26                	sd	s1,24(sp)
    80001be0:	e84a                	sd	s2,16(sp)
    80001be2:	e44e                	sd	s3,8(sp)
    80001be4:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001be6:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001bea:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001bee:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80001bf2:	1004f793          	andi	a5,s1,256
    80001bf6:	c795                	beqz	a5,80001c22 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001bf8:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001bfc:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001bfe:	eb85                	bnez	a5,80001c2e <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    80001c00:	e91ff0ef          	jal	ra,80001a90 <devintr>
    80001c04:	c91d                	beqz	a0,80001c3a <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    80001c06:	4789                	li	a5,2
    80001c08:	04f50a63          	beq	a0,a5,80001c5c <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001c0c:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001c10:	10049073          	csrw	sstatus,s1
}
    80001c14:	70a2                	ld	ra,40(sp)
    80001c16:	7402                	ld	s0,32(sp)
    80001c18:	64e2                	ld	s1,24(sp)
    80001c1a:	6942                	ld	s2,16(sp)
    80001c1c:	69a2                	ld	s3,8(sp)
    80001c1e:	6145                	addi	sp,sp,48
    80001c20:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001c22:	00005517          	auipc	a0,0x5
    80001c26:	77650513          	addi	a0,a0,1910 # 80007398 <states.0+0xd0>
    80001c2a:	0ed030ef          	jal	ra,80005516 <panic>
    panic("kerneltrap: interrupts enabled");
    80001c2e:	00005517          	auipc	a0,0x5
    80001c32:	79250513          	addi	a0,a0,1938 # 800073c0 <states.0+0xf8>
    80001c36:	0e1030ef          	jal	ra,80005516 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001c3a:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001c3e:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001c42:	85ce                	mv	a1,s3
    80001c44:	00005517          	auipc	a0,0x5
    80001c48:	79c50513          	addi	a0,a0,1948 # 800073e0 <states.0+0x118>
    80001c4c:	616030ef          	jal	ra,80005262 <printf>
    panic("kerneltrap");
    80001c50:	00005517          	auipc	a0,0x5
    80001c54:	7b850513          	addi	a0,a0,1976 # 80007408 <states.0+0x140>
    80001c58:	0bf030ef          	jal	ra,80005516 <panic>
  if(which_dev == 2 && myproc() != 0)
    80001c5c:	9beff0ef          	jal	ra,80000e1a <myproc>
    80001c60:	d555                	beqz	a0,80001c0c <kerneltrap+0x34>
    yield();
    80001c62:	fe2ff0ef          	jal	ra,80001444 <yield>
    80001c66:	b75d                	j	80001c0c <kerneltrap+0x34>

0000000080001c68 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001c68:	1101                	addi	sp,sp,-32
    80001c6a:	ec06                	sd	ra,24(sp)
    80001c6c:	e822                	sd	s0,16(sp)
    80001c6e:	e426                	sd	s1,8(sp)
    80001c70:	1000                	addi	s0,sp,32
    80001c72:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c74:	9a6ff0ef          	jal	ra,80000e1a <myproc>
  switch (n) {
    80001c78:	4795                	li	a5,5
    80001c7a:	0497e163          	bltu	a5,s1,80001cbc <argraw+0x54>
    80001c7e:	048a                	slli	s1,s1,0x2
    80001c80:	00005717          	auipc	a4,0x5
    80001c84:	7c070713          	addi	a4,a4,1984 # 80007440 <states.0+0x178>
    80001c88:	94ba                	add	s1,s1,a4
    80001c8a:	409c                	lw	a5,0(s1)
    80001c8c:	97ba                	add	a5,a5,a4
    80001c8e:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001c90:	6d3c                	ld	a5,88(a0)
    80001c92:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001c94:	60e2                	ld	ra,24(sp)
    80001c96:	6442                	ld	s0,16(sp)
    80001c98:	64a2                	ld	s1,8(sp)
    80001c9a:	6105                	addi	sp,sp,32
    80001c9c:	8082                	ret
    return p->trapframe->a1;
    80001c9e:	6d3c                	ld	a5,88(a0)
    80001ca0:	7fa8                	ld	a0,120(a5)
    80001ca2:	bfcd                	j	80001c94 <argraw+0x2c>
    return p->trapframe->a2;
    80001ca4:	6d3c                	ld	a5,88(a0)
    80001ca6:	63c8                	ld	a0,128(a5)
    80001ca8:	b7f5                	j	80001c94 <argraw+0x2c>
    return p->trapframe->a3;
    80001caa:	6d3c                	ld	a5,88(a0)
    80001cac:	67c8                	ld	a0,136(a5)
    80001cae:	b7dd                	j	80001c94 <argraw+0x2c>
    return p->trapframe->a4;
    80001cb0:	6d3c                	ld	a5,88(a0)
    80001cb2:	6bc8                	ld	a0,144(a5)
    80001cb4:	b7c5                	j	80001c94 <argraw+0x2c>
    return p->trapframe->a5;
    80001cb6:	6d3c                	ld	a5,88(a0)
    80001cb8:	6fc8                	ld	a0,152(a5)
    80001cba:	bfe9                	j	80001c94 <argraw+0x2c>
  panic("argraw");
    80001cbc:	00005517          	auipc	a0,0x5
    80001cc0:	75c50513          	addi	a0,a0,1884 # 80007418 <states.0+0x150>
    80001cc4:	053030ef          	jal	ra,80005516 <panic>

0000000080001cc8 <fetchaddr>:
{
    80001cc8:	1101                	addi	sp,sp,-32
    80001cca:	ec06                	sd	ra,24(sp)
    80001ccc:	e822                	sd	s0,16(sp)
    80001cce:	e426                	sd	s1,8(sp)
    80001cd0:	e04a                	sd	s2,0(sp)
    80001cd2:	1000                	addi	s0,sp,32
    80001cd4:	84aa                	mv	s1,a0
    80001cd6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001cd8:	942ff0ef          	jal	ra,80000e1a <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001cdc:	653c                	ld	a5,72(a0)
    80001cde:	02f4f663          	bgeu	s1,a5,80001d0a <fetchaddr+0x42>
    80001ce2:	00848713          	addi	a4,s1,8
    80001ce6:	02e7e463          	bltu	a5,a4,80001d0e <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001cea:	46a1                	li	a3,8
    80001cec:	8626                	mv	a2,s1
    80001cee:	85ca                	mv	a1,s2
    80001cf0:	6928                	ld	a0,80(a0)
    80001cf2:	d9dfe0ef          	jal	ra,80000a8e <copyin>
    80001cf6:	00a03533          	snez	a0,a0
    80001cfa:	40a00533          	neg	a0,a0
}
    80001cfe:	60e2                	ld	ra,24(sp)
    80001d00:	6442                	ld	s0,16(sp)
    80001d02:	64a2                	ld	s1,8(sp)
    80001d04:	6902                	ld	s2,0(sp)
    80001d06:	6105                	addi	sp,sp,32
    80001d08:	8082                	ret
    return -1;
    80001d0a:	557d                	li	a0,-1
    80001d0c:	bfcd                	j	80001cfe <fetchaddr+0x36>
    80001d0e:	557d                	li	a0,-1
    80001d10:	b7fd                	j	80001cfe <fetchaddr+0x36>

0000000080001d12 <fetchstr>:
{
    80001d12:	7179                	addi	sp,sp,-48
    80001d14:	f406                	sd	ra,40(sp)
    80001d16:	f022                	sd	s0,32(sp)
    80001d18:	ec26                	sd	s1,24(sp)
    80001d1a:	e84a                	sd	s2,16(sp)
    80001d1c:	e44e                	sd	s3,8(sp)
    80001d1e:	1800                	addi	s0,sp,48
    80001d20:	892a                	mv	s2,a0
    80001d22:	84ae                	mv	s1,a1
    80001d24:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80001d26:	8f4ff0ef          	jal	ra,80000e1a <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001d2a:	86ce                	mv	a3,s3
    80001d2c:	864a                	mv	a2,s2
    80001d2e:	85a6                	mv	a1,s1
    80001d30:	6928                	ld	a0,80(a0)
    80001d32:	de3fe0ef          	jal	ra,80000b14 <copyinstr>
    80001d36:	00054c63          	bltz	a0,80001d4e <fetchstr+0x3c>
  return strlen(buf);
    80001d3a:	8526                	mv	a0,s1
    80001d3c:	d88fe0ef          	jal	ra,800002c4 <strlen>
}
    80001d40:	70a2                	ld	ra,40(sp)
    80001d42:	7402                	ld	s0,32(sp)
    80001d44:	64e2                	ld	s1,24(sp)
    80001d46:	6942                	ld	s2,16(sp)
    80001d48:	69a2                	ld	s3,8(sp)
    80001d4a:	6145                	addi	sp,sp,48
    80001d4c:	8082                	ret
    return -1;
    80001d4e:	557d                	li	a0,-1
    80001d50:	bfc5                	j	80001d40 <fetchstr+0x2e>

0000000080001d52 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001d52:	1101                	addi	sp,sp,-32
    80001d54:	ec06                	sd	ra,24(sp)
    80001d56:	e822                	sd	s0,16(sp)
    80001d58:	e426                	sd	s1,8(sp)
    80001d5a:	1000                	addi	s0,sp,32
    80001d5c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d5e:	f0bff0ef          	jal	ra,80001c68 <argraw>
    80001d62:	c088                	sw	a0,0(s1)
}
    80001d64:	60e2                	ld	ra,24(sp)
    80001d66:	6442                	ld	s0,16(sp)
    80001d68:	64a2                	ld	s1,8(sp)
    80001d6a:	6105                	addi	sp,sp,32
    80001d6c:	8082                	ret

0000000080001d6e <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001d6e:	1101                	addi	sp,sp,-32
    80001d70:	ec06                	sd	ra,24(sp)
    80001d72:	e822                	sd	s0,16(sp)
    80001d74:	e426                	sd	s1,8(sp)
    80001d76:	1000                	addi	s0,sp,32
    80001d78:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d7a:	eefff0ef          	jal	ra,80001c68 <argraw>
    80001d7e:	e088                	sd	a0,0(s1)
}
    80001d80:	60e2                	ld	ra,24(sp)
    80001d82:	6442                	ld	s0,16(sp)
    80001d84:	64a2                	ld	s1,8(sp)
    80001d86:	6105                	addi	sp,sp,32
    80001d88:	8082                	ret

0000000080001d8a <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001d8a:	7179                	addi	sp,sp,-48
    80001d8c:	f406                	sd	ra,40(sp)
    80001d8e:	f022                	sd	s0,32(sp)
    80001d90:	ec26                	sd	s1,24(sp)
    80001d92:	e84a                	sd	s2,16(sp)
    80001d94:	1800                	addi	s0,sp,48
    80001d96:	84ae                	mv	s1,a1
    80001d98:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80001d9a:	fd840593          	addi	a1,s0,-40
    80001d9e:	fd1ff0ef          	jal	ra,80001d6e <argaddr>
  return fetchstr(addr, buf, max);
    80001da2:	864a                	mv	a2,s2
    80001da4:	85a6                	mv	a1,s1
    80001da6:	fd843503          	ld	a0,-40(s0)
    80001daa:	f69ff0ef          	jal	ra,80001d12 <fetchstr>
}
    80001dae:	70a2                	ld	ra,40(sp)
    80001db0:	7402                	ld	s0,32(sp)
    80001db2:	64e2                	ld	s1,24(sp)
    80001db4:	6942                	ld	s2,16(sp)
    80001db6:	6145                	addi	sp,sp,48
    80001db8:	8082                	ret

0000000080001dba <syscall>:



void
syscall(void)
{
    80001dba:	1101                	addi	sp,sp,-32
    80001dbc:	ec06                	sd	ra,24(sp)
    80001dbe:	e822                	sd	s0,16(sp)
    80001dc0:	e426                	sd	s1,8(sp)
    80001dc2:	e04a                	sd	s2,0(sp)
    80001dc4:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001dc6:	854ff0ef          	jal	ra,80000e1a <myproc>
    80001dca:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001dcc:	05853903          	ld	s2,88(a0)
    80001dd0:	0a893783          	ld	a5,168(s2)
    80001dd4:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001dd8:	37fd                	addiw	a5,a5,-1
    80001dda:	02200713          	li	a4,34
    80001dde:	00f76f63          	bltu	a4,a5,80001dfc <syscall+0x42>
    80001de2:	00369713          	slli	a4,a3,0x3
    80001de6:	00005797          	auipc	a5,0x5
    80001dea:	67278793          	addi	a5,a5,1650 # 80007458 <syscalls>
    80001dee:	97ba                	add	a5,a5,a4
    80001df0:	639c                	ld	a5,0(a5)
    80001df2:	c789                	beqz	a5,80001dfc <syscall+0x42>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001df4:	9782                	jalr	a5
    80001df6:	06a93823          	sd	a0,112(s2)
    80001dfa:	a829                	j	80001e14 <syscall+0x5a>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001dfc:	16048613          	addi	a2,s1,352
    80001e00:	588c                	lw	a1,48(s1)
    80001e02:	00005517          	auipc	a0,0x5
    80001e06:	61e50513          	addi	a0,a0,1566 # 80007420 <states.0+0x158>
    80001e0a:	458030ef          	jal	ra,80005262 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001e0e:	6cbc                	ld	a5,88(s1)
    80001e10:	577d                	li	a4,-1
    80001e12:	fbb8                	sd	a4,112(a5)
  }
}
    80001e14:	60e2                	ld	ra,24(sp)
    80001e16:	6442                	ld	s0,16(sp)
    80001e18:	64a2                	ld	s1,8(sp)
    80001e1a:	6902                	ld	s2,0(sp)
    80001e1c:	6105                	addi	sp,sp,32
    80001e1e:	8082                	ret

0000000080001e20 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001e20:	1101                	addi	sp,sp,-32
    80001e22:	ec06                	sd	ra,24(sp)
    80001e24:	e822                	sd	s0,16(sp)
    80001e26:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001e28:	fec40593          	addi	a1,s0,-20
    80001e2c:	4501                	li	a0,0
    80001e2e:	f25ff0ef          	jal	ra,80001d52 <argint>
  exit(n);
    80001e32:	fec42503          	lw	a0,-20(s0)
    80001e36:	f46ff0ef          	jal	ra,8000157c <exit>
  return 0;  // not reached
}
    80001e3a:	4501                	li	a0,0
    80001e3c:	60e2                	ld	ra,24(sp)
    80001e3e:	6442                	ld	s0,16(sp)
    80001e40:	6105                	addi	sp,sp,32
    80001e42:	8082                	ret

0000000080001e44 <sys_getpid>:

uint64
sys_getpid(void)
{
    80001e44:	1141                	addi	sp,sp,-16
    80001e46:	e406                	sd	ra,8(sp)
    80001e48:	e022                	sd	s0,0(sp)
    80001e4a:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001e4c:	fcffe0ef          	jal	ra,80000e1a <myproc>
}
    80001e50:	5908                	lw	a0,48(a0)
    80001e52:	60a2                	ld	ra,8(sp)
    80001e54:	6402                	ld	s0,0(sp)
    80001e56:	0141                	addi	sp,sp,16
    80001e58:	8082                	ret

0000000080001e5a <sys_fork>:

uint64
sys_fork(void)
{
    80001e5a:	1141                	addi	sp,sp,-16
    80001e5c:	e406                	sd	ra,8(sp)
    80001e5e:	e022                	sd	s0,0(sp)
    80001e60:	0800                	addi	s0,sp,16
  return fork();
    80001e62:	b68ff0ef          	jal	ra,800011ca <fork>
}
    80001e66:	60a2                	ld	ra,8(sp)
    80001e68:	6402                	ld	s0,0(sp)
    80001e6a:	0141                	addi	sp,sp,16
    80001e6c:	8082                	ret

0000000080001e6e <sys_wait>:

uint64
sys_wait(void)
{
    80001e6e:	1101                	addi	sp,sp,-32
    80001e70:	ec06                	sd	ra,24(sp)
    80001e72:	e822                	sd	s0,16(sp)
    80001e74:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001e76:	fe840593          	addi	a1,s0,-24
    80001e7a:	4501                	li	a0,0
    80001e7c:	ef3ff0ef          	jal	ra,80001d6e <argaddr>
  return wait(p);
    80001e80:	fe843503          	ld	a0,-24(s0)
    80001e84:	84fff0ef          	jal	ra,800016d2 <wait>
}
    80001e88:	60e2                	ld	ra,24(sp)
    80001e8a:	6442                	ld	s0,16(sp)
    80001e8c:	6105                	addi	sp,sp,32
    80001e8e:	8082                	ret

0000000080001e90 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001e90:	7179                	addi	sp,sp,-48
    80001e92:	f406                	sd	ra,40(sp)
    80001e94:	f022                	sd	s0,32(sp)
    80001e96:	ec26                	sd	s1,24(sp)
    80001e98:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001e9a:	fdc40593          	addi	a1,s0,-36
    80001e9e:	4501                	li	a0,0
    80001ea0:	eb3ff0ef          	jal	ra,80001d52 <argint>
  addr = myproc()->sz;
    80001ea4:	f77fe0ef          	jal	ra,80000e1a <myproc>
    80001ea8:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80001eaa:	fdc42503          	lw	a0,-36(s0)
    80001eae:	accff0ef          	jal	ra,8000117a <growproc>
    80001eb2:	00054863          	bltz	a0,80001ec2 <sys_sbrk+0x32>
    return -1;
  return addr;
}
    80001eb6:	8526                	mv	a0,s1
    80001eb8:	70a2                	ld	ra,40(sp)
    80001eba:	7402                	ld	s0,32(sp)
    80001ebc:	64e2                	ld	s1,24(sp)
    80001ebe:	6145                	addi	sp,sp,48
    80001ec0:	8082                	ret
    return -1;
    80001ec2:	54fd                	li	s1,-1
    80001ec4:	bfcd                	j	80001eb6 <sys_sbrk+0x26>

0000000080001ec6 <sys_sleep>:

uint64
sys_sleep(void)
{
    80001ec6:	7139                	addi	sp,sp,-64
    80001ec8:	fc06                	sd	ra,56(sp)
    80001eca:	f822                	sd	s0,48(sp)
    80001ecc:	f426                	sd	s1,40(sp)
    80001ece:	f04a                	sd	s2,32(sp)
    80001ed0:	ec4e                	sd	s3,24(sp)
    80001ed2:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;


  argint(0, &n);
    80001ed4:	fcc40593          	addi	a1,s0,-52
    80001ed8:	4501                	li	a0,0
    80001eda:	e79ff0ef          	jal	ra,80001d52 <argint>
  if(n < 0)
    80001ede:	fcc42783          	lw	a5,-52(s0)
    80001ee2:	0607c563          	bltz	a5,80001f4c <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80001ee6:	0000c517          	auipc	a0,0xc
    80001eea:	b1a50513          	addi	a0,a0,-1254 # 8000da00 <tickslock>
    80001eee:	13d030ef          	jal	ra,8000582a <acquire>
  ticks0 = ticks;
    80001ef2:	00006917          	auipc	s2,0x6
    80001ef6:	aa692903          	lw	s2,-1370(s2) # 80007998 <ticks>
  while(ticks - ticks0 < n){
    80001efa:	fcc42783          	lw	a5,-52(s0)
    80001efe:	cb8d                	beqz	a5,80001f30 <sys_sleep+0x6a>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001f00:	0000c997          	auipc	s3,0xc
    80001f04:	b0098993          	addi	s3,s3,-1280 # 8000da00 <tickslock>
    80001f08:	00006497          	auipc	s1,0x6
    80001f0c:	a9048493          	addi	s1,s1,-1392 # 80007998 <ticks>
    if(killed(myproc())){
    80001f10:	f0bfe0ef          	jal	ra,80000e1a <myproc>
    80001f14:	f94ff0ef          	jal	ra,800016a8 <killed>
    80001f18:	ed0d                	bnez	a0,80001f52 <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80001f1a:	85ce                	mv	a1,s3
    80001f1c:	8526                	mv	a0,s1
    80001f1e:	d52ff0ef          	jal	ra,80001470 <sleep>
  while(ticks - ticks0 < n){
    80001f22:	409c                	lw	a5,0(s1)
    80001f24:	412787bb          	subw	a5,a5,s2
    80001f28:	fcc42703          	lw	a4,-52(s0)
    80001f2c:	fee7e2e3          	bltu	a5,a4,80001f10 <sys_sleep+0x4a>
  }
  release(&tickslock);
    80001f30:	0000c517          	auipc	a0,0xc
    80001f34:	ad050513          	addi	a0,a0,-1328 # 8000da00 <tickslock>
    80001f38:	18b030ef          	jal	ra,800058c2 <release>
  return 0;
    80001f3c:	4501                	li	a0,0
}
    80001f3e:	70e2                	ld	ra,56(sp)
    80001f40:	7442                	ld	s0,48(sp)
    80001f42:	74a2                	ld	s1,40(sp)
    80001f44:	7902                	ld	s2,32(sp)
    80001f46:	69e2                	ld	s3,24(sp)
    80001f48:	6121                	addi	sp,sp,64
    80001f4a:	8082                	ret
    n = 0;
    80001f4c:	fc042623          	sw	zero,-52(s0)
    80001f50:	bf59                	j	80001ee6 <sys_sleep+0x20>
      release(&tickslock);
    80001f52:	0000c517          	auipc	a0,0xc
    80001f56:	aae50513          	addi	a0,a0,-1362 # 8000da00 <tickslock>
    80001f5a:	169030ef          	jal	ra,800058c2 <release>
      return -1;
    80001f5e:	557d                	li	a0,-1
    80001f60:	bff9                	j	80001f3e <sys_sleep+0x78>

0000000080001f62 <sys_pgpte>:


#ifdef LAB_PGTBL
int
sys_pgpte(void)
{
    80001f62:	7179                	addi	sp,sp,-48
    80001f64:	f406                	sd	ra,40(sp)
    80001f66:	f022                	sd	s0,32(sp)
    80001f68:	ec26                	sd	s1,24(sp)
    80001f6a:	1800                	addi	s0,sp,48
  uint64 va;
  struct proc *p;  

  p = myproc();
    80001f6c:	eaffe0ef          	jal	ra,80000e1a <myproc>
    80001f70:	84aa                	mv	s1,a0
  argaddr(0, &va);
    80001f72:	fd840593          	addi	a1,s0,-40
    80001f76:	4501                	li	a0,0
    80001f78:	df7ff0ef          	jal	ra,80001d6e <argaddr>
  pte_t *pte = pgpte(p->pagetable, va);
    80001f7c:	fd843583          	ld	a1,-40(s0)
    80001f80:	68a8                	ld	a0,80(s1)
    80001f82:	d29fe0ef          	jal	ra,80000caa <pgpte>
    80001f86:	87aa                	mv	a5,a0
  if(pte != 0) {
      return (uint64) *pte;
  }
  return 0;
    80001f88:	4501                	li	a0,0
  if(pte != 0) {
    80001f8a:	c391                	beqz	a5,80001f8e <sys_pgpte+0x2c>
      return (uint64) *pte;
    80001f8c:	4388                	lw	a0,0(a5)
}
    80001f8e:	70a2                	ld	ra,40(sp)
    80001f90:	7402                	ld	s0,32(sp)
    80001f92:	64e2                	ld	s1,24(sp)
    80001f94:	6145                	addi	sp,sp,48
    80001f96:	8082                	ret

0000000080001f98 <sys_kpgtbl>:
#endif

#ifdef LAB_PGTBL
int
sys_kpgtbl(void)
{
    80001f98:	1141                	addi	sp,sp,-16
    80001f9a:	e406                	sd	ra,8(sp)
    80001f9c:	e022                	sd	s0,0(sp)
    80001f9e:	0800                	addi	s0,sp,16
  struct proc *p;  

  p = myproc();
    80001fa0:	e7bfe0ef          	jal	ra,80000e1a <myproc>
  vmprint(p->pagetable);
    80001fa4:	6928                	ld	a0,80(a0)
    80001fa6:	cd9fe0ef          	jal	ra,80000c7e <vmprint>
  return 0;
}
    80001faa:	4501                	li	a0,0
    80001fac:	60a2                	ld	ra,8(sp)
    80001fae:	6402                	ld	s0,0(sp)
    80001fb0:	0141                	addi	sp,sp,16
    80001fb2:	8082                	ret

0000000080001fb4 <sys_kill>:
#endif


uint64
sys_kill(void)
{
    80001fb4:	1101                	addi	sp,sp,-32
    80001fb6:	ec06                	sd	ra,24(sp)
    80001fb8:	e822                	sd	s0,16(sp)
    80001fba:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80001fbc:	fec40593          	addi	a1,s0,-20
    80001fc0:	4501                	li	a0,0
    80001fc2:	d91ff0ef          	jal	ra,80001d52 <argint>
  return kill(pid);
    80001fc6:	fec42503          	lw	a0,-20(s0)
    80001fca:	e54ff0ef          	jal	ra,8000161e <kill>
}
    80001fce:	60e2                	ld	ra,24(sp)
    80001fd0:	6442                	ld	s0,16(sp)
    80001fd2:	6105                	addi	sp,sp,32
    80001fd4:	8082                	ret

0000000080001fd6 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80001fd6:	1101                	addi	sp,sp,-32
    80001fd8:	ec06                	sd	ra,24(sp)
    80001fda:	e822                	sd	s0,16(sp)
    80001fdc:	e426                	sd	s1,8(sp)
    80001fde:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80001fe0:	0000c517          	auipc	a0,0xc
    80001fe4:	a2050513          	addi	a0,a0,-1504 # 8000da00 <tickslock>
    80001fe8:	043030ef          	jal	ra,8000582a <acquire>
  xticks = ticks;
    80001fec:	00006497          	auipc	s1,0x6
    80001ff0:	9ac4a483          	lw	s1,-1620(s1) # 80007998 <ticks>
  release(&tickslock);
    80001ff4:	0000c517          	auipc	a0,0xc
    80001ff8:	a0c50513          	addi	a0,a0,-1524 # 8000da00 <tickslock>
    80001ffc:	0c7030ef          	jal	ra,800058c2 <release>
  return xticks;
}
    80002000:	02049513          	slli	a0,s1,0x20
    80002004:	9101                	srli	a0,a0,0x20
    80002006:	60e2                	ld	ra,24(sp)
    80002008:	6442                	ld	s0,16(sp)
    8000200a:	64a2                	ld	s1,8(sp)
    8000200c:	6105                	addi	sp,sp,32
    8000200e:	8082                	ret

0000000080002010 <sys_pgaccess>:


//This code was added by Ashish CS23B099
uint64
sys_pgaccess(void){
    80002010:	711d                	addi	sp,sp,-96
    80002012:	ec86                	sd	ra,88(sp)
    80002014:	e8a2                	sd	s0,80(sp)
    80002016:	e4a6                	sd	s1,72(sp)
    80002018:	e0ca                	sd	s2,64(sp)
    8000201a:	fc4e                	sd	s3,56(sp)
    8000201c:	f852                	sd	s4,48(sp)
    8000201e:	f456                	sd	s5,40(sp)
    80002020:	1080                	addi	s0,sp,96
  uint64 base;
  int len;
  uint64 mask;
  argaddr(0,&base);
    80002022:	fb840593          	addi	a1,s0,-72
    80002026:	4501                	li	a0,0
    80002028:	d47ff0ef          	jal	ra,80001d6e <argaddr>
  argint(1,&len);
    8000202c:	fb440593          	addi	a1,s0,-76
    80002030:	4505                	li	a0,1
    80002032:	d21ff0ef          	jal	ra,80001d52 <argint>
  argaddr(2,&mask);
    80002036:	fa840593          	addi	a1,s0,-88
    8000203a:	4509                	li	a0,2
    8000203c:	d33ff0ef          	jal	ra,80001d6e <argaddr>

  if(len > 32) // since pgaccess return an int, keep len atmost 32
    80002040:	fb442703          	lw	a4,-76(s0)
    80002044:	02000793          	li	a5,32
    80002048:	00e7d463          	bge	a5,a4,80002050 <sys_pgaccess+0x40>
    len = 32;
    8000204c:	faf42a23          	sw	a5,-76(s0)

  struct proc *p = myproc();
    80002050:	dcbfe0ef          	jal	ra,80000e1a <myproc>
    80002054:	89aa                	mv	s3,a0
  unsigned int abits = 0; //no bits are assigned initially
    80002056:	fa042223          	sw	zero,-92(s0)
  for(int i = 0; i < len; i++){
    8000205a:	fb442783          	lw	a5,-76(s0)
    8000205e:	04f05d63          	blez	a5,800020b8 <sys_pgaccess+0xa8>
    80002062:	4481                	li	s1,0
    pagetable_t pagetable = p->pagetable; //getting the process pagetable
    uint64 va = base + i * PGSIZE; //finding the corresponding virtual address
    pte_t *pte = walk(pagetable, va, 0); //getting the pte for the virtual address
    if(pte && (*pte & PTE_V) && (*pte & PTE_A)){ //ensure pte is not null and then check for valid and accessed bit
    80002064:	04100a13          	li	s4,65
      abits |= (1 << i);
    80002068:	4a85                	li	s5,1
    8000206a:	a801                	j	8000207a <sys_pgaccess+0x6a>
  for(int i = 0; i < len; i++){
    8000206c:	0485                	addi	s1,s1,1
    8000206e:	fb442703          	lw	a4,-76(s0)
    80002072:	0004879b          	sext.w	a5,s1
    80002076:	04e7d163          	bge	a5,a4,800020b8 <sys_pgaccess+0xa8>
    8000207a:	0004891b          	sext.w	s2,s1
    uint64 va = base + i * PGSIZE; //finding the corresponding virtual address
    8000207e:	00c49793          	slli	a5,s1,0xc
    pte_t *pte = walk(pagetable, va, 0); //getting the pte for the virtual address
    80002082:	4601                	li	a2,0
    80002084:	fb843583          	ld	a1,-72(s0)
    80002088:	95be                	add	a1,a1,a5
    8000208a:	0509b503          	ld	a0,80(s3)
    8000208e:	b3afe0ef          	jal	ra,800003c8 <walk>
    if(pte && (*pte & PTE_V) && (*pte & PTE_A)){ //ensure pte is not null and then check for valid and accessed bit
    80002092:	dd69                	beqz	a0,8000206c <sys_pgaccess+0x5c>
    80002094:	611c                	ld	a5,0(a0)
    80002096:	0417f793          	andi	a5,a5,65
    8000209a:	fd4799e3          	bne	a5,s4,8000206c <sys_pgaccess+0x5c>
      abits |= (1 << i);
    8000209e:	012a993b          	sllw	s2,s5,s2
    800020a2:	fa442783          	lw	a5,-92(s0)
    800020a6:	00f96933          	or	s2,s2,a5
    800020aa:	fb242223          	sw	s2,-92(s0)
      *pte &= ~PTE_A; // set accessed bit to 0;
    800020ae:	611c                	ld	a5,0(a0)
    800020b0:	fbf7f793          	andi	a5,a5,-65
    800020b4:	e11c                	sd	a5,0(a0)
    800020b6:	bf5d                	j	8000206c <sys_pgaccess+0x5c>
    }
  }
  if(copyout(p->pagetable,mask,(char*)&abits,sizeof(abits)) < 0)
    800020b8:	4691                	li	a3,4
    800020ba:	fa440613          	addi	a2,s0,-92
    800020be:	fa843583          	ld	a1,-88(s0)
    800020c2:	0509b503          	ld	a0,80(s3)
    800020c6:	911fe0ef          	jal	ra,800009d6 <copyout>
    return -1;
  return 0;
}
    800020ca:	957d                	srai	a0,a0,0x3f
    800020cc:	60e6                	ld	ra,88(sp)
    800020ce:	6446                	ld	s0,80(sp)
    800020d0:	64a6                	ld	s1,72(sp)
    800020d2:	6906                	ld	s2,64(sp)
    800020d4:	79e2                	ld	s3,56(sp)
    800020d6:	7a42                	ld	s4,48(sp)
    800020d8:	7aa2                	ld	s5,40(sp)
    800020da:	6125                	addi	sp,sp,96
    800020dc:	8082                	ret

00000000800020de <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    800020de:	7179                	addi	sp,sp,-48
    800020e0:	f406                	sd	ra,40(sp)
    800020e2:	f022                	sd	s0,32(sp)
    800020e4:	ec26                	sd	s1,24(sp)
    800020e6:	e84a                	sd	s2,16(sp)
    800020e8:	e44e                	sd	s3,8(sp)
    800020ea:	e052                	sd	s4,0(sp)
    800020ec:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    800020ee:	00005597          	auipc	a1,0x5
    800020f2:	48a58593          	addi	a1,a1,1162 # 80007578 <syscalls+0x120>
    800020f6:	0000c517          	auipc	a0,0xc
    800020fa:	92250513          	addi	a0,a0,-1758 # 8000da18 <bcache>
    800020fe:	6ac030ef          	jal	ra,800057aa <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002102:	00014797          	auipc	a5,0x14
    80002106:	91678793          	addi	a5,a5,-1770 # 80015a18 <bcache+0x8000>
    8000210a:	00014717          	auipc	a4,0x14
    8000210e:	b7670713          	addi	a4,a4,-1162 # 80015c80 <bcache+0x8268>
    80002112:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002116:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000211a:	0000c497          	auipc	s1,0xc
    8000211e:	91648493          	addi	s1,s1,-1770 # 8000da30 <bcache+0x18>
    b->next = bcache.head.next;
    80002122:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002124:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002126:	00005a17          	auipc	s4,0x5
    8000212a:	45aa0a13          	addi	s4,s4,1114 # 80007580 <syscalls+0x128>
    b->next = bcache.head.next;
    8000212e:	2b893783          	ld	a5,696(s2)
    80002132:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002134:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002138:	85d2                	mv	a1,s4
    8000213a:	01048513          	addi	a0,s1,16
    8000213e:	22a010ef          	jal	ra,80003368 <initsleeplock>
    bcache.head.next->prev = b;
    80002142:	2b893783          	ld	a5,696(s2)
    80002146:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002148:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000214c:	45848493          	addi	s1,s1,1112
    80002150:	fd349fe3          	bne	s1,s3,8000212e <binit+0x50>
  }
}
    80002154:	70a2                	ld	ra,40(sp)
    80002156:	7402                	ld	s0,32(sp)
    80002158:	64e2                	ld	s1,24(sp)
    8000215a:	6942                	ld	s2,16(sp)
    8000215c:	69a2                	ld	s3,8(sp)
    8000215e:	6a02                	ld	s4,0(sp)
    80002160:	6145                	addi	sp,sp,48
    80002162:	8082                	ret

0000000080002164 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002164:	7179                	addi	sp,sp,-48
    80002166:	f406                	sd	ra,40(sp)
    80002168:	f022                	sd	s0,32(sp)
    8000216a:	ec26                	sd	s1,24(sp)
    8000216c:	e84a                	sd	s2,16(sp)
    8000216e:	e44e                	sd	s3,8(sp)
    80002170:	1800                	addi	s0,sp,48
    80002172:	892a                	mv	s2,a0
    80002174:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002176:	0000c517          	auipc	a0,0xc
    8000217a:	8a250513          	addi	a0,a0,-1886 # 8000da18 <bcache>
    8000217e:	6ac030ef          	jal	ra,8000582a <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002182:	00014497          	auipc	s1,0x14
    80002186:	b4e4b483          	ld	s1,-1202(s1) # 80015cd0 <bcache+0x82b8>
    8000218a:	00014797          	auipc	a5,0x14
    8000218e:	af678793          	addi	a5,a5,-1290 # 80015c80 <bcache+0x8268>
    80002192:	02f48b63          	beq	s1,a5,800021c8 <bread+0x64>
    80002196:	873e                	mv	a4,a5
    80002198:	a021                	j	800021a0 <bread+0x3c>
    8000219a:	68a4                	ld	s1,80(s1)
    8000219c:	02e48663          	beq	s1,a4,800021c8 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    800021a0:	449c                	lw	a5,8(s1)
    800021a2:	ff279ce3          	bne	a5,s2,8000219a <bread+0x36>
    800021a6:	44dc                	lw	a5,12(s1)
    800021a8:	ff3799e3          	bne	a5,s3,8000219a <bread+0x36>
      b->refcnt++;
    800021ac:	40bc                	lw	a5,64(s1)
    800021ae:	2785                	addiw	a5,a5,1
    800021b0:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800021b2:	0000c517          	auipc	a0,0xc
    800021b6:	86650513          	addi	a0,a0,-1946 # 8000da18 <bcache>
    800021ba:	708030ef          	jal	ra,800058c2 <release>
      acquiresleep(&b->lock);
    800021be:	01048513          	addi	a0,s1,16
    800021c2:	1dc010ef          	jal	ra,8000339e <acquiresleep>
      return b;
    800021c6:	a889                	j	80002218 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800021c8:	00014497          	auipc	s1,0x14
    800021cc:	b004b483          	ld	s1,-1280(s1) # 80015cc8 <bcache+0x82b0>
    800021d0:	00014797          	auipc	a5,0x14
    800021d4:	ab078793          	addi	a5,a5,-1360 # 80015c80 <bcache+0x8268>
    800021d8:	00f48863          	beq	s1,a5,800021e8 <bread+0x84>
    800021dc:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    800021de:	40bc                	lw	a5,64(s1)
    800021e0:	cb91                	beqz	a5,800021f4 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800021e2:	64a4                	ld	s1,72(s1)
    800021e4:	fee49de3          	bne	s1,a4,800021de <bread+0x7a>
  panic("bget: no buffers");
    800021e8:	00005517          	auipc	a0,0x5
    800021ec:	3a050513          	addi	a0,a0,928 # 80007588 <syscalls+0x130>
    800021f0:	326030ef          	jal	ra,80005516 <panic>
      b->dev = dev;
    800021f4:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    800021f8:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    800021fc:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002200:	4785                	li	a5,1
    80002202:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002204:	0000c517          	auipc	a0,0xc
    80002208:	81450513          	addi	a0,a0,-2028 # 8000da18 <bcache>
    8000220c:	6b6030ef          	jal	ra,800058c2 <release>
      acquiresleep(&b->lock);
    80002210:	01048513          	addi	a0,s1,16
    80002214:	18a010ef          	jal	ra,8000339e <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002218:	409c                	lw	a5,0(s1)
    8000221a:	cb89                	beqz	a5,8000222c <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000221c:	8526                	mv	a0,s1
    8000221e:	70a2                	ld	ra,40(sp)
    80002220:	7402                	ld	s0,32(sp)
    80002222:	64e2                	ld	s1,24(sp)
    80002224:	6942                	ld	s2,16(sp)
    80002226:	69a2                	ld	s3,8(sp)
    80002228:	6145                	addi	sp,sp,48
    8000222a:	8082                	ret
    virtio_disk_rw(b, 0);
    8000222c:	4581                	li	a1,0
    8000222e:	8526                	mv	a0,s1
    80002230:	0ed020ef          	jal	ra,80004b1c <virtio_disk_rw>
    b->valid = 1;
    80002234:	4785                	li	a5,1
    80002236:	c09c                	sw	a5,0(s1)
  return b;
    80002238:	b7d5                	j	8000221c <bread+0xb8>

000000008000223a <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000223a:	1101                	addi	sp,sp,-32
    8000223c:	ec06                	sd	ra,24(sp)
    8000223e:	e822                	sd	s0,16(sp)
    80002240:	e426                	sd	s1,8(sp)
    80002242:	1000                	addi	s0,sp,32
    80002244:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002246:	0541                	addi	a0,a0,16
    80002248:	1d4010ef          	jal	ra,8000341c <holdingsleep>
    8000224c:	c911                	beqz	a0,80002260 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    8000224e:	4585                	li	a1,1
    80002250:	8526                	mv	a0,s1
    80002252:	0cb020ef          	jal	ra,80004b1c <virtio_disk_rw>
}
    80002256:	60e2                	ld	ra,24(sp)
    80002258:	6442                	ld	s0,16(sp)
    8000225a:	64a2                	ld	s1,8(sp)
    8000225c:	6105                	addi	sp,sp,32
    8000225e:	8082                	ret
    panic("bwrite");
    80002260:	00005517          	auipc	a0,0x5
    80002264:	34050513          	addi	a0,a0,832 # 800075a0 <syscalls+0x148>
    80002268:	2ae030ef          	jal	ra,80005516 <panic>

000000008000226c <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000226c:	1101                	addi	sp,sp,-32
    8000226e:	ec06                	sd	ra,24(sp)
    80002270:	e822                	sd	s0,16(sp)
    80002272:	e426                	sd	s1,8(sp)
    80002274:	e04a                	sd	s2,0(sp)
    80002276:	1000                	addi	s0,sp,32
    80002278:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000227a:	01050913          	addi	s2,a0,16
    8000227e:	854a                	mv	a0,s2
    80002280:	19c010ef          	jal	ra,8000341c <holdingsleep>
    80002284:	c13d                	beqz	a0,800022ea <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
    80002286:	854a                	mv	a0,s2
    80002288:	15c010ef          	jal	ra,800033e4 <releasesleep>

  acquire(&bcache.lock);
    8000228c:	0000b517          	auipc	a0,0xb
    80002290:	78c50513          	addi	a0,a0,1932 # 8000da18 <bcache>
    80002294:	596030ef          	jal	ra,8000582a <acquire>
  b->refcnt--;
    80002298:	40bc                	lw	a5,64(s1)
    8000229a:	37fd                	addiw	a5,a5,-1
    8000229c:	0007871b          	sext.w	a4,a5
    800022a0:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800022a2:	eb05                	bnez	a4,800022d2 <brelse+0x66>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800022a4:	68bc                	ld	a5,80(s1)
    800022a6:	64b8                	ld	a4,72(s1)
    800022a8:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    800022aa:	64bc                	ld	a5,72(s1)
    800022ac:	68b8                	ld	a4,80(s1)
    800022ae:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800022b0:	00013797          	auipc	a5,0x13
    800022b4:	76878793          	addi	a5,a5,1896 # 80015a18 <bcache+0x8000>
    800022b8:	2b87b703          	ld	a4,696(a5)
    800022bc:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800022be:	00014717          	auipc	a4,0x14
    800022c2:	9c270713          	addi	a4,a4,-1598 # 80015c80 <bcache+0x8268>
    800022c6:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800022c8:	2b87b703          	ld	a4,696(a5)
    800022cc:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800022ce:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800022d2:	0000b517          	auipc	a0,0xb
    800022d6:	74650513          	addi	a0,a0,1862 # 8000da18 <bcache>
    800022da:	5e8030ef          	jal	ra,800058c2 <release>
}
    800022de:	60e2                	ld	ra,24(sp)
    800022e0:	6442                	ld	s0,16(sp)
    800022e2:	64a2                	ld	s1,8(sp)
    800022e4:	6902                	ld	s2,0(sp)
    800022e6:	6105                	addi	sp,sp,32
    800022e8:	8082                	ret
    panic("brelse");
    800022ea:	00005517          	auipc	a0,0x5
    800022ee:	2be50513          	addi	a0,a0,702 # 800075a8 <syscalls+0x150>
    800022f2:	224030ef          	jal	ra,80005516 <panic>

00000000800022f6 <bpin>:

void
bpin(struct buf *b) {
    800022f6:	1101                	addi	sp,sp,-32
    800022f8:	ec06                	sd	ra,24(sp)
    800022fa:	e822                	sd	s0,16(sp)
    800022fc:	e426                	sd	s1,8(sp)
    800022fe:	1000                	addi	s0,sp,32
    80002300:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002302:	0000b517          	auipc	a0,0xb
    80002306:	71650513          	addi	a0,a0,1814 # 8000da18 <bcache>
    8000230a:	520030ef          	jal	ra,8000582a <acquire>
  b->refcnt++;
    8000230e:	40bc                	lw	a5,64(s1)
    80002310:	2785                	addiw	a5,a5,1
    80002312:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002314:	0000b517          	auipc	a0,0xb
    80002318:	70450513          	addi	a0,a0,1796 # 8000da18 <bcache>
    8000231c:	5a6030ef          	jal	ra,800058c2 <release>
}
    80002320:	60e2                	ld	ra,24(sp)
    80002322:	6442                	ld	s0,16(sp)
    80002324:	64a2                	ld	s1,8(sp)
    80002326:	6105                	addi	sp,sp,32
    80002328:	8082                	ret

000000008000232a <bunpin>:

void
bunpin(struct buf *b) {
    8000232a:	1101                	addi	sp,sp,-32
    8000232c:	ec06                	sd	ra,24(sp)
    8000232e:	e822                	sd	s0,16(sp)
    80002330:	e426                	sd	s1,8(sp)
    80002332:	1000                	addi	s0,sp,32
    80002334:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002336:	0000b517          	auipc	a0,0xb
    8000233a:	6e250513          	addi	a0,a0,1762 # 8000da18 <bcache>
    8000233e:	4ec030ef          	jal	ra,8000582a <acquire>
  b->refcnt--;
    80002342:	40bc                	lw	a5,64(s1)
    80002344:	37fd                	addiw	a5,a5,-1
    80002346:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002348:	0000b517          	auipc	a0,0xb
    8000234c:	6d050513          	addi	a0,a0,1744 # 8000da18 <bcache>
    80002350:	572030ef          	jal	ra,800058c2 <release>
}
    80002354:	60e2                	ld	ra,24(sp)
    80002356:	6442                	ld	s0,16(sp)
    80002358:	64a2                	ld	s1,8(sp)
    8000235a:	6105                	addi	sp,sp,32
    8000235c:	8082                	ret

000000008000235e <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    8000235e:	1101                	addi	sp,sp,-32
    80002360:	ec06                	sd	ra,24(sp)
    80002362:	e822                	sd	s0,16(sp)
    80002364:	e426                	sd	s1,8(sp)
    80002366:	e04a                	sd	s2,0(sp)
    80002368:	1000                	addi	s0,sp,32
    8000236a:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000236c:	00d5d59b          	srliw	a1,a1,0xd
    80002370:	00014797          	auipc	a5,0x14
    80002374:	d847a783          	lw	a5,-636(a5) # 800160f4 <sb+0x1c>
    80002378:	9dbd                	addw	a1,a1,a5
    8000237a:	debff0ef          	jal	ra,80002164 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    8000237e:	0074f713          	andi	a4,s1,7
    80002382:	4785                	li	a5,1
    80002384:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    80002388:	14ce                	slli	s1,s1,0x33
    8000238a:	90d9                	srli	s1,s1,0x36
    8000238c:	00950733          	add	a4,a0,s1
    80002390:	05874703          	lbu	a4,88(a4)
    80002394:	00e7f6b3          	and	a3,a5,a4
    80002398:	c29d                	beqz	a3,800023be <bfree+0x60>
    8000239a:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    8000239c:	94aa                	add	s1,s1,a0
    8000239e:	fff7c793          	not	a5,a5
    800023a2:	8ff9                	and	a5,a5,a4
    800023a4:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    800023a8:	6ef000ef          	jal	ra,80003296 <log_write>
  brelse(bp);
    800023ac:	854a                	mv	a0,s2
    800023ae:	ebfff0ef          	jal	ra,8000226c <brelse>
}
    800023b2:	60e2                	ld	ra,24(sp)
    800023b4:	6442                	ld	s0,16(sp)
    800023b6:	64a2                	ld	s1,8(sp)
    800023b8:	6902                	ld	s2,0(sp)
    800023ba:	6105                	addi	sp,sp,32
    800023bc:	8082                	ret
    panic("freeing free block");
    800023be:	00005517          	auipc	a0,0x5
    800023c2:	1f250513          	addi	a0,a0,498 # 800075b0 <syscalls+0x158>
    800023c6:	150030ef          	jal	ra,80005516 <panic>

00000000800023ca <balloc>:
{
    800023ca:	711d                	addi	sp,sp,-96
    800023cc:	ec86                	sd	ra,88(sp)
    800023ce:	e8a2                	sd	s0,80(sp)
    800023d0:	e4a6                	sd	s1,72(sp)
    800023d2:	e0ca                	sd	s2,64(sp)
    800023d4:	fc4e                	sd	s3,56(sp)
    800023d6:	f852                	sd	s4,48(sp)
    800023d8:	f456                	sd	s5,40(sp)
    800023da:	f05a                	sd	s6,32(sp)
    800023dc:	ec5e                	sd	s7,24(sp)
    800023de:	e862                	sd	s8,16(sp)
    800023e0:	e466                	sd	s9,8(sp)
    800023e2:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    800023e4:	00014797          	auipc	a5,0x14
    800023e8:	cf87a783          	lw	a5,-776(a5) # 800160dc <sb+0x4>
    800023ec:	0e078163          	beqz	a5,800024ce <balloc+0x104>
    800023f0:	8baa                	mv	s7,a0
    800023f2:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800023f4:	00014b17          	auipc	s6,0x14
    800023f8:	ce4b0b13          	addi	s6,s6,-796 # 800160d8 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800023fc:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    800023fe:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002400:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002402:	6c89                	lui	s9,0x2
    80002404:	a0b5                	j	80002470 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002406:	974a                	add	a4,a4,s2
    80002408:	8fd5                	or	a5,a5,a3
    8000240a:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    8000240e:	854a                	mv	a0,s2
    80002410:	687000ef          	jal	ra,80003296 <log_write>
        brelse(bp);
    80002414:	854a                	mv	a0,s2
    80002416:	e57ff0ef          	jal	ra,8000226c <brelse>
  bp = bread(dev, bno);
    8000241a:	85a6                	mv	a1,s1
    8000241c:	855e                	mv	a0,s7
    8000241e:	d47ff0ef          	jal	ra,80002164 <bread>
    80002422:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002424:	40000613          	li	a2,1024
    80002428:	4581                	li	a1,0
    8000242a:	05850513          	addi	a0,a0,88
    8000242e:	d1ffd0ef          	jal	ra,8000014c <memset>
  log_write(bp);
    80002432:	854a                	mv	a0,s2
    80002434:	663000ef          	jal	ra,80003296 <log_write>
  brelse(bp);
    80002438:	854a                	mv	a0,s2
    8000243a:	e33ff0ef          	jal	ra,8000226c <brelse>
}
    8000243e:	8526                	mv	a0,s1
    80002440:	60e6                	ld	ra,88(sp)
    80002442:	6446                	ld	s0,80(sp)
    80002444:	64a6                	ld	s1,72(sp)
    80002446:	6906                	ld	s2,64(sp)
    80002448:	79e2                	ld	s3,56(sp)
    8000244a:	7a42                	ld	s4,48(sp)
    8000244c:	7aa2                	ld	s5,40(sp)
    8000244e:	7b02                	ld	s6,32(sp)
    80002450:	6be2                	ld	s7,24(sp)
    80002452:	6c42                	ld	s8,16(sp)
    80002454:	6ca2                	ld	s9,8(sp)
    80002456:	6125                	addi	sp,sp,96
    80002458:	8082                	ret
    brelse(bp);
    8000245a:	854a                	mv	a0,s2
    8000245c:	e11ff0ef          	jal	ra,8000226c <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002460:	015c87bb          	addw	a5,s9,s5
    80002464:	00078a9b          	sext.w	s5,a5
    80002468:	004b2703          	lw	a4,4(s6)
    8000246c:	06eaf163          	bgeu	s5,a4,800024ce <balloc+0x104>
    bp = bread(dev, BBLOCK(b, sb));
    80002470:	41fad79b          	sraiw	a5,s5,0x1f
    80002474:	0137d79b          	srliw	a5,a5,0x13
    80002478:	015787bb          	addw	a5,a5,s5
    8000247c:	40d7d79b          	sraiw	a5,a5,0xd
    80002480:	01cb2583          	lw	a1,28(s6)
    80002484:	9dbd                	addw	a1,a1,a5
    80002486:	855e                	mv	a0,s7
    80002488:	cddff0ef          	jal	ra,80002164 <bread>
    8000248c:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000248e:	004b2503          	lw	a0,4(s6)
    80002492:	000a849b          	sext.w	s1,s5
    80002496:	8662                	mv	a2,s8
    80002498:	fca4f1e3          	bgeu	s1,a0,8000245a <balloc+0x90>
      m = 1 << (bi % 8);
    8000249c:	41f6579b          	sraiw	a5,a2,0x1f
    800024a0:	01d7d69b          	srliw	a3,a5,0x1d
    800024a4:	00c6873b          	addw	a4,a3,a2
    800024a8:	00777793          	andi	a5,a4,7
    800024ac:	9f95                	subw	a5,a5,a3
    800024ae:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800024b2:	4037571b          	sraiw	a4,a4,0x3
    800024b6:	00e906b3          	add	a3,s2,a4
    800024ba:	0586c683          	lbu	a3,88(a3)
    800024be:	00d7f5b3          	and	a1,a5,a3
    800024c2:	d1b1                	beqz	a1,80002406 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800024c4:	2605                	addiw	a2,a2,1
    800024c6:	2485                	addiw	s1,s1,1
    800024c8:	fd4618e3          	bne	a2,s4,80002498 <balloc+0xce>
    800024cc:	b779                	j	8000245a <balloc+0x90>
  printf("balloc: out of blocks\n");
    800024ce:	00005517          	auipc	a0,0x5
    800024d2:	0fa50513          	addi	a0,a0,250 # 800075c8 <syscalls+0x170>
    800024d6:	58d020ef          	jal	ra,80005262 <printf>
  return 0;
    800024da:	4481                	li	s1,0
    800024dc:	b78d                	j	8000243e <balloc+0x74>

00000000800024de <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800024de:	7179                	addi	sp,sp,-48
    800024e0:	f406                	sd	ra,40(sp)
    800024e2:	f022                	sd	s0,32(sp)
    800024e4:	ec26                	sd	s1,24(sp)
    800024e6:	e84a                	sd	s2,16(sp)
    800024e8:	e44e                	sd	s3,8(sp)
    800024ea:	e052                	sd	s4,0(sp)
    800024ec:	1800                	addi	s0,sp,48
    800024ee:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800024f0:	47ad                	li	a5,11
    800024f2:	02b7e663          	bltu	a5,a1,8000251e <bmap+0x40>
    if((addr = ip->addrs[bn]) == 0){
    800024f6:	02059793          	slli	a5,a1,0x20
    800024fa:	01e7d593          	srli	a1,a5,0x1e
    800024fe:	00b504b3          	add	s1,a0,a1
    80002502:	0504a903          	lw	s2,80(s1)
    80002506:	06091663          	bnez	s2,80002572 <bmap+0x94>
      addr = balloc(ip->dev);
    8000250a:	4108                	lw	a0,0(a0)
    8000250c:	ebfff0ef          	jal	ra,800023ca <balloc>
    80002510:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002514:	04090f63          	beqz	s2,80002572 <bmap+0x94>
        return 0;
      ip->addrs[bn] = addr;
    80002518:	0524a823          	sw	s2,80(s1)
    8000251c:	a899                	j	80002572 <bmap+0x94>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000251e:	ff45849b          	addiw	s1,a1,-12
    80002522:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80002526:	0ff00793          	li	a5,255
    8000252a:	06e7eb63          	bltu	a5,a4,800025a0 <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000252e:	08052903          	lw	s2,128(a0)
    80002532:	00091b63          	bnez	s2,80002548 <bmap+0x6a>
      addr = balloc(ip->dev);
    80002536:	4108                	lw	a0,0(a0)
    80002538:	e93ff0ef          	jal	ra,800023ca <balloc>
    8000253c:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002540:	02090963          	beqz	s2,80002572 <bmap+0x94>
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002544:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80002548:	85ca                	mv	a1,s2
    8000254a:	0009a503          	lw	a0,0(s3)
    8000254e:	c17ff0ef          	jal	ra,80002164 <bread>
    80002552:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002554:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002558:	02049713          	slli	a4,s1,0x20
    8000255c:	01e75593          	srli	a1,a4,0x1e
    80002560:	00b784b3          	add	s1,a5,a1
    80002564:	0004a903          	lw	s2,0(s1)
    80002568:	00090e63          	beqz	s2,80002584 <bmap+0xa6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000256c:	8552                	mv	a0,s4
    8000256e:	cffff0ef          	jal	ra,8000226c <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    80002572:	854a                	mv	a0,s2
    80002574:	70a2                	ld	ra,40(sp)
    80002576:	7402                	ld	s0,32(sp)
    80002578:	64e2                	ld	s1,24(sp)
    8000257a:	6942                	ld	s2,16(sp)
    8000257c:	69a2                	ld	s3,8(sp)
    8000257e:	6a02                	ld	s4,0(sp)
    80002580:	6145                	addi	sp,sp,48
    80002582:	8082                	ret
      addr = balloc(ip->dev);
    80002584:	0009a503          	lw	a0,0(s3)
    80002588:	e43ff0ef          	jal	ra,800023ca <balloc>
    8000258c:	0005091b          	sext.w	s2,a0
      if(addr){
    80002590:	fc090ee3          	beqz	s2,8000256c <bmap+0x8e>
        a[bn] = addr;
    80002594:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80002598:	8552                	mv	a0,s4
    8000259a:	4fd000ef          	jal	ra,80003296 <log_write>
    8000259e:	b7f9                	j	8000256c <bmap+0x8e>
  panic("bmap: out of range");
    800025a0:	00005517          	auipc	a0,0x5
    800025a4:	04050513          	addi	a0,a0,64 # 800075e0 <syscalls+0x188>
    800025a8:	76f020ef          	jal	ra,80005516 <panic>

00000000800025ac <iget>:
{
    800025ac:	7179                	addi	sp,sp,-48
    800025ae:	f406                	sd	ra,40(sp)
    800025b0:	f022                	sd	s0,32(sp)
    800025b2:	ec26                	sd	s1,24(sp)
    800025b4:	e84a                	sd	s2,16(sp)
    800025b6:	e44e                	sd	s3,8(sp)
    800025b8:	e052                	sd	s4,0(sp)
    800025ba:	1800                	addi	s0,sp,48
    800025bc:	89aa                	mv	s3,a0
    800025be:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800025c0:	00014517          	auipc	a0,0x14
    800025c4:	b3850513          	addi	a0,a0,-1224 # 800160f8 <itable>
    800025c8:	262030ef          	jal	ra,8000582a <acquire>
  empty = 0;
    800025cc:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800025ce:	00014497          	auipc	s1,0x14
    800025d2:	b4248493          	addi	s1,s1,-1214 # 80016110 <itable+0x18>
    800025d6:	00015697          	auipc	a3,0x15
    800025da:	5ca68693          	addi	a3,a3,1482 # 80017ba0 <log>
    800025de:	a039                	j	800025ec <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800025e0:	02090963          	beqz	s2,80002612 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800025e4:	08848493          	addi	s1,s1,136
    800025e8:	02d48863          	beq	s1,a3,80002618 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800025ec:	449c                	lw	a5,8(s1)
    800025ee:	fef059e3          	blez	a5,800025e0 <iget+0x34>
    800025f2:	4098                	lw	a4,0(s1)
    800025f4:	ff3716e3          	bne	a4,s3,800025e0 <iget+0x34>
    800025f8:	40d8                	lw	a4,4(s1)
    800025fa:	ff4713e3          	bne	a4,s4,800025e0 <iget+0x34>
      ip->ref++;
    800025fe:	2785                	addiw	a5,a5,1
    80002600:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002602:	00014517          	auipc	a0,0x14
    80002606:	af650513          	addi	a0,a0,-1290 # 800160f8 <itable>
    8000260a:	2b8030ef          	jal	ra,800058c2 <release>
      return ip;
    8000260e:	8926                	mv	s2,s1
    80002610:	a02d                	j	8000263a <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002612:	fbe9                	bnez	a5,800025e4 <iget+0x38>
    80002614:	8926                	mv	s2,s1
    80002616:	b7f9                	j	800025e4 <iget+0x38>
  if(empty == 0)
    80002618:	02090a63          	beqz	s2,8000264c <iget+0xa0>
  ip->dev = dev;
    8000261c:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002620:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002624:	4785                	li	a5,1
    80002626:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000262a:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000262e:	00014517          	auipc	a0,0x14
    80002632:	aca50513          	addi	a0,a0,-1334 # 800160f8 <itable>
    80002636:	28c030ef          	jal	ra,800058c2 <release>
}
    8000263a:	854a                	mv	a0,s2
    8000263c:	70a2                	ld	ra,40(sp)
    8000263e:	7402                	ld	s0,32(sp)
    80002640:	64e2                	ld	s1,24(sp)
    80002642:	6942                	ld	s2,16(sp)
    80002644:	69a2                	ld	s3,8(sp)
    80002646:	6a02                	ld	s4,0(sp)
    80002648:	6145                	addi	sp,sp,48
    8000264a:	8082                	ret
    panic("iget: no inodes");
    8000264c:	00005517          	auipc	a0,0x5
    80002650:	fac50513          	addi	a0,a0,-84 # 800075f8 <syscalls+0x1a0>
    80002654:	6c3020ef          	jal	ra,80005516 <panic>

0000000080002658 <fsinit>:
fsinit(int dev) {
    80002658:	7179                	addi	sp,sp,-48
    8000265a:	f406                	sd	ra,40(sp)
    8000265c:	f022                	sd	s0,32(sp)
    8000265e:	ec26                	sd	s1,24(sp)
    80002660:	e84a                	sd	s2,16(sp)
    80002662:	e44e                	sd	s3,8(sp)
    80002664:	1800                	addi	s0,sp,48
    80002666:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002668:	4585                	li	a1,1
    8000266a:	afbff0ef          	jal	ra,80002164 <bread>
    8000266e:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002670:	00014997          	auipc	s3,0x14
    80002674:	a6898993          	addi	s3,s3,-1432 # 800160d8 <sb>
    80002678:	02000613          	li	a2,32
    8000267c:	05850593          	addi	a1,a0,88
    80002680:	854e                	mv	a0,s3
    80002682:	b27fd0ef          	jal	ra,800001a8 <memmove>
  brelse(bp);
    80002686:	8526                	mv	a0,s1
    80002688:	be5ff0ef          	jal	ra,8000226c <brelse>
  if(sb.magic != FSMAGIC)
    8000268c:	0009a703          	lw	a4,0(s3)
    80002690:	102037b7          	lui	a5,0x10203
    80002694:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002698:	02f71063          	bne	a4,a5,800026b8 <fsinit+0x60>
  initlog(dev, &sb);
    8000269c:	00014597          	auipc	a1,0x14
    800026a0:	a3c58593          	addi	a1,a1,-1476 # 800160d8 <sb>
    800026a4:	854a                	mv	a0,s2
    800026a6:	1db000ef          	jal	ra,80003080 <initlog>
}
    800026aa:	70a2                	ld	ra,40(sp)
    800026ac:	7402                	ld	s0,32(sp)
    800026ae:	64e2                	ld	s1,24(sp)
    800026b0:	6942                	ld	s2,16(sp)
    800026b2:	69a2                	ld	s3,8(sp)
    800026b4:	6145                	addi	sp,sp,48
    800026b6:	8082                	ret
    panic("invalid file system");
    800026b8:	00005517          	auipc	a0,0x5
    800026bc:	f5050513          	addi	a0,a0,-176 # 80007608 <syscalls+0x1b0>
    800026c0:	657020ef          	jal	ra,80005516 <panic>

00000000800026c4 <iinit>:
{
    800026c4:	7179                	addi	sp,sp,-48
    800026c6:	f406                	sd	ra,40(sp)
    800026c8:	f022                	sd	s0,32(sp)
    800026ca:	ec26                	sd	s1,24(sp)
    800026cc:	e84a                	sd	s2,16(sp)
    800026ce:	e44e                	sd	s3,8(sp)
    800026d0:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800026d2:	00005597          	auipc	a1,0x5
    800026d6:	f4e58593          	addi	a1,a1,-178 # 80007620 <syscalls+0x1c8>
    800026da:	00014517          	auipc	a0,0x14
    800026de:	a1e50513          	addi	a0,a0,-1506 # 800160f8 <itable>
    800026e2:	0c8030ef          	jal	ra,800057aa <initlock>
  for(i = 0; i < NINODE; i++) {
    800026e6:	00014497          	auipc	s1,0x14
    800026ea:	a3a48493          	addi	s1,s1,-1478 # 80016120 <itable+0x28>
    800026ee:	00015997          	auipc	s3,0x15
    800026f2:	4c298993          	addi	s3,s3,1218 # 80017bb0 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800026f6:	00005917          	auipc	s2,0x5
    800026fa:	f3290913          	addi	s2,s2,-206 # 80007628 <syscalls+0x1d0>
    800026fe:	85ca                	mv	a1,s2
    80002700:	8526                	mv	a0,s1
    80002702:	467000ef          	jal	ra,80003368 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80002706:	08848493          	addi	s1,s1,136
    8000270a:	ff349ae3          	bne	s1,s3,800026fe <iinit+0x3a>
}
    8000270e:	70a2                	ld	ra,40(sp)
    80002710:	7402                	ld	s0,32(sp)
    80002712:	64e2                	ld	s1,24(sp)
    80002714:	6942                	ld	s2,16(sp)
    80002716:	69a2                	ld	s3,8(sp)
    80002718:	6145                	addi	sp,sp,48
    8000271a:	8082                	ret

000000008000271c <ialloc>:
{
    8000271c:	715d                	addi	sp,sp,-80
    8000271e:	e486                	sd	ra,72(sp)
    80002720:	e0a2                	sd	s0,64(sp)
    80002722:	fc26                	sd	s1,56(sp)
    80002724:	f84a                	sd	s2,48(sp)
    80002726:	f44e                	sd	s3,40(sp)
    80002728:	f052                	sd	s4,32(sp)
    8000272a:	ec56                	sd	s5,24(sp)
    8000272c:	e85a                	sd	s6,16(sp)
    8000272e:	e45e                	sd	s7,8(sp)
    80002730:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    80002732:	00014717          	auipc	a4,0x14
    80002736:	9b272703          	lw	a4,-1614(a4) # 800160e4 <sb+0xc>
    8000273a:	4785                	li	a5,1
    8000273c:	04e7f663          	bgeu	a5,a4,80002788 <ialloc+0x6c>
    80002740:	8aaa                	mv	s5,a0
    80002742:	8bae                	mv	s7,a1
    80002744:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    80002746:	00014a17          	auipc	s4,0x14
    8000274a:	992a0a13          	addi	s4,s4,-1646 # 800160d8 <sb>
    8000274e:	00048b1b          	sext.w	s6,s1
    80002752:	0044d793          	srli	a5,s1,0x4
    80002756:	018a2583          	lw	a1,24(s4)
    8000275a:	9dbd                	addw	a1,a1,a5
    8000275c:	8556                	mv	a0,s5
    8000275e:	a07ff0ef          	jal	ra,80002164 <bread>
    80002762:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002764:	05850993          	addi	s3,a0,88
    80002768:	00f4f793          	andi	a5,s1,15
    8000276c:	079a                	slli	a5,a5,0x6
    8000276e:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002770:	00099783          	lh	a5,0(s3)
    80002774:	cf85                	beqz	a5,800027ac <ialloc+0x90>
    brelse(bp);
    80002776:	af7ff0ef          	jal	ra,8000226c <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000277a:	0485                	addi	s1,s1,1
    8000277c:	00ca2703          	lw	a4,12(s4)
    80002780:	0004879b          	sext.w	a5,s1
    80002784:	fce7e5e3          	bltu	a5,a4,8000274e <ialloc+0x32>
  printf("ialloc: no inodes\n");
    80002788:	00005517          	auipc	a0,0x5
    8000278c:	ea850513          	addi	a0,a0,-344 # 80007630 <syscalls+0x1d8>
    80002790:	2d3020ef          	jal	ra,80005262 <printf>
  return 0;
    80002794:	4501                	li	a0,0
}
    80002796:	60a6                	ld	ra,72(sp)
    80002798:	6406                	ld	s0,64(sp)
    8000279a:	74e2                	ld	s1,56(sp)
    8000279c:	7942                	ld	s2,48(sp)
    8000279e:	79a2                	ld	s3,40(sp)
    800027a0:	7a02                	ld	s4,32(sp)
    800027a2:	6ae2                	ld	s5,24(sp)
    800027a4:	6b42                	ld	s6,16(sp)
    800027a6:	6ba2                	ld	s7,8(sp)
    800027a8:	6161                	addi	sp,sp,80
    800027aa:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800027ac:	04000613          	li	a2,64
    800027b0:	4581                	li	a1,0
    800027b2:	854e                	mv	a0,s3
    800027b4:	999fd0ef          	jal	ra,8000014c <memset>
      dip->type = type;
    800027b8:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800027bc:	854a                	mv	a0,s2
    800027be:	2d9000ef          	jal	ra,80003296 <log_write>
      brelse(bp);
    800027c2:	854a                	mv	a0,s2
    800027c4:	aa9ff0ef          	jal	ra,8000226c <brelse>
      return iget(dev, inum);
    800027c8:	85da                	mv	a1,s6
    800027ca:	8556                	mv	a0,s5
    800027cc:	de1ff0ef          	jal	ra,800025ac <iget>
    800027d0:	b7d9                	j	80002796 <ialloc+0x7a>

00000000800027d2 <iupdate>:
{
    800027d2:	1101                	addi	sp,sp,-32
    800027d4:	ec06                	sd	ra,24(sp)
    800027d6:	e822                	sd	s0,16(sp)
    800027d8:	e426                	sd	s1,8(sp)
    800027da:	e04a                	sd	s2,0(sp)
    800027dc:	1000                	addi	s0,sp,32
    800027de:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800027e0:	415c                	lw	a5,4(a0)
    800027e2:	0047d79b          	srliw	a5,a5,0x4
    800027e6:	00014597          	auipc	a1,0x14
    800027ea:	90a5a583          	lw	a1,-1782(a1) # 800160f0 <sb+0x18>
    800027ee:	9dbd                	addw	a1,a1,a5
    800027f0:	4108                	lw	a0,0(a0)
    800027f2:	973ff0ef          	jal	ra,80002164 <bread>
    800027f6:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800027f8:	05850793          	addi	a5,a0,88
    800027fc:	40c8                	lw	a0,4(s1)
    800027fe:	893d                	andi	a0,a0,15
    80002800:	051a                	slli	a0,a0,0x6
    80002802:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    80002804:	04449703          	lh	a4,68(s1)
    80002808:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    8000280c:	04649703          	lh	a4,70(s1)
    80002810:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    80002814:	04849703          	lh	a4,72(s1)
    80002818:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    8000281c:	04a49703          	lh	a4,74(s1)
    80002820:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    80002824:	44f8                	lw	a4,76(s1)
    80002826:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80002828:	03400613          	li	a2,52
    8000282c:	05048593          	addi	a1,s1,80
    80002830:	0531                	addi	a0,a0,12
    80002832:	977fd0ef          	jal	ra,800001a8 <memmove>
  log_write(bp);
    80002836:	854a                	mv	a0,s2
    80002838:	25f000ef          	jal	ra,80003296 <log_write>
  brelse(bp);
    8000283c:	854a                	mv	a0,s2
    8000283e:	a2fff0ef          	jal	ra,8000226c <brelse>
}
    80002842:	60e2                	ld	ra,24(sp)
    80002844:	6442                	ld	s0,16(sp)
    80002846:	64a2                	ld	s1,8(sp)
    80002848:	6902                	ld	s2,0(sp)
    8000284a:	6105                	addi	sp,sp,32
    8000284c:	8082                	ret

000000008000284e <idup>:
{
    8000284e:	1101                	addi	sp,sp,-32
    80002850:	ec06                	sd	ra,24(sp)
    80002852:	e822                	sd	s0,16(sp)
    80002854:	e426                	sd	s1,8(sp)
    80002856:	1000                	addi	s0,sp,32
    80002858:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000285a:	00014517          	auipc	a0,0x14
    8000285e:	89e50513          	addi	a0,a0,-1890 # 800160f8 <itable>
    80002862:	7c9020ef          	jal	ra,8000582a <acquire>
  ip->ref++;
    80002866:	449c                	lw	a5,8(s1)
    80002868:	2785                	addiw	a5,a5,1
    8000286a:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000286c:	00014517          	auipc	a0,0x14
    80002870:	88c50513          	addi	a0,a0,-1908 # 800160f8 <itable>
    80002874:	04e030ef          	jal	ra,800058c2 <release>
}
    80002878:	8526                	mv	a0,s1
    8000287a:	60e2                	ld	ra,24(sp)
    8000287c:	6442                	ld	s0,16(sp)
    8000287e:	64a2                	ld	s1,8(sp)
    80002880:	6105                	addi	sp,sp,32
    80002882:	8082                	ret

0000000080002884 <ilock>:
{
    80002884:	1101                	addi	sp,sp,-32
    80002886:	ec06                	sd	ra,24(sp)
    80002888:	e822                	sd	s0,16(sp)
    8000288a:	e426                	sd	s1,8(sp)
    8000288c:	e04a                	sd	s2,0(sp)
    8000288e:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80002890:	c105                	beqz	a0,800028b0 <ilock+0x2c>
    80002892:	84aa                	mv	s1,a0
    80002894:	451c                	lw	a5,8(a0)
    80002896:	00f05d63          	blez	a5,800028b0 <ilock+0x2c>
  acquiresleep(&ip->lock);
    8000289a:	0541                	addi	a0,a0,16
    8000289c:	303000ef          	jal	ra,8000339e <acquiresleep>
  if(ip->valid == 0){
    800028a0:	40bc                	lw	a5,64(s1)
    800028a2:	cf89                	beqz	a5,800028bc <ilock+0x38>
}
    800028a4:	60e2                	ld	ra,24(sp)
    800028a6:	6442                	ld	s0,16(sp)
    800028a8:	64a2                	ld	s1,8(sp)
    800028aa:	6902                	ld	s2,0(sp)
    800028ac:	6105                	addi	sp,sp,32
    800028ae:	8082                	ret
    panic("ilock");
    800028b0:	00005517          	auipc	a0,0x5
    800028b4:	d9850513          	addi	a0,a0,-616 # 80007648 <syscalls+0x1f0>
    800028b8:	45f020ef          	jal	ra,80005516 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800028bc:	40dc                	lw	a5,4(s1)
    800028be:	0047d79b          	srliw	a5,a5,0x4
    800028c2:	00014597          	auipc	a1,0x14
    800028c6:	82e5a583          	lw	a1,-2002(a1) # 800160f0 <sb+0x18>
    800028ca:	9dbd                	addw	a1,a1,a5
    800028cc:	4088                	lw	a0,0(s1)
    800028ce:	897ff0ef          	jal	ra,80002164 <bread>
    800028d2:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800028d4:	05850593          	addi	a1,a0,88
    800028d8:	40dc                	lw	a5,4(s1)
    800028da:	8bbd                	andi	a5,a5,15
    800028dc:	079a                	slli	a5,a5,0x6
    800028de:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800028e0:	00059783          	lh	a5,0(a1)
    800028e4:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800028e8:	00259783          	lh	a5,2(a1)
    800028ec:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800028f0:	00459783          	lh	a5,4(a1)
    800028f4:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800028f8:	00659783          	lh	a5,6(a1)
    800028fc:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80002900:	459c                	lw	a5,8(a1)
    80002902:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80002904:	03400613          	li	a2,52
    80002908:	05b1                	addi	a1,a1,12
    8000290a:	05048513          	addi	a0,s1,80
    8000290e:	89bfd0ef          	jal	ra,800001a8 <memmove>
    brelse(bp);
    80002912:	854a                	mv	a0,s2
    80002914:	959ff0ef          	jal	ra,8000226c <brelse>
    ip->valid = 1;
    80002918:	4785                	li	a5,1
    8000291a:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000291c:	04449783          	lh	a5,68(s1)
    80002920:	f3d1                	bnez	a5,800028a4 <ilock+0x20>
      panic("ilock: no type");
    80002922:	00005517          	auipc	a0,0x5
    80002926:	d2e50513          	addi	a0,a0,-722 # 80007650 <syscalls+0x1f8>
    8000292a:	3ed020ef          	jal	ra,80005516 <panic>

000000008000292e <iunlock>:
{
    8000292e:	1101                	addi	sp,sp,-32
    80002930:	ec06                	sd	ra,24(sp)
    80002932:	e822                	sd	s0,16(sp)
    80002934:	e426                	sd	s1,8(sp)
    80002936:	e04a                	sd	s2,0(sp)
    80002938:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000293a:	c505                	beqz	a0,80002962 <iunlock+0x34>
    8000293c:	84aa                	mv	s1,a0
    8000293e:	01050913          	addi	s2,a0,16
    80002942:	854a                	mv	a0,s2
    80002944:	2d9000ef          	jal	ra,8000341c <holdingsleep>
    80002948:	cd09                	beqz	a0,80002962 <iunlock+0x34>
    8000294a:	449c                	lw	a5,8(s1)
    8000294c:	00f05b63          	blez	a5,80002962 <iunlock+0x34>
  releasesleep(&ip->lock);
    80002950:	854a                	mv	a0,s2
    80002952:	293000ef          	jal	ra,800033e4 <releasesleep>
}
    80002956:	60e2                	ld	ra,24(sp)
    80002958:	6442                	ld	s0,16(sp)
    8000295a:	64a2                	ld	s1,8(sp)
    8000295c:	6902                	ld	s2,0(sp)
    8000295e:	6105                	addi	sp,sp,32
    80002960:	8082                	ret
    panic("iunlock");
    80002962:	00005517          	auipc	a0,0x5
    80002966:	cfe50513          	addi	a0,a0,-770 # 80007660 <syscalls+0x208>
    8000296a:	3ad020ef          	jal	ra,80005516 <panic>

000000008000296e <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000296e:	7179                	addi	sp,sp,-48
    80002970:	f406                	sd	ra,40(sp)
    80002972:	f022                	sd	s0,32(sp)
    80002974:	ec26                	sd	s1,24(sp)
    80002976:	e84a                	sd	s2,16(sp)
    80002978:	e44e                	sd	s3,8(sp)
    8000297a:	e052                	sd	s4,0(sp)
    8000297c:	1800                	addi	s0,sp,48
    8000297e:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80002980:	05050493          	addi	s1,a0,80
    80002984:	08050913          	addi	s2,a0,128
    80002988:	a021                	j	80002990 <itrunc+0x22>
    8000298a:	0491                	addi	s1,s1,4
    8000298c:	01248b63          	beq	s1,s2,800029a2 <itrunc+0x34>
    if(ip->addrs[i]){
    80002990:	408c                	lw	a1,0(s1)
    80002992:	dde5                	beqz	a1,8000298a <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    80002994:	0009a503          	lw	a0,0(s3)
    80002998:	9c7ff0ef          	jal	ra,8000235e <bfree>
      ip->addrs[i] = 0;
    8000299c:	0004a023          	sw	zero,0(s1)
    800029a0:	b7ed                	j	8000298a <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    800029a2:	0809a583          	lw	a1,128(s3)
    800029a6:	ed91                	bnez	a1,800029c2 <itrunc+0x54>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800029a8:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800029ac:	854e                	mv	a0,s3
    800029ae:	e25ff0ef          	jal	ra,800027d2 <iupdate>
}
    800029b2:	70a2                	ld	ra,40(sp)
    800029b4:	7402                	ld	s0,32(sp)
    800029b6:	64e2                	ld	s1,24(sp)
    800029b8:	6942                	ld	s2,16(sp)
    800029ba:	69a2                	ld	s3,8(sp)
    800029bc:	6a02                	ld	s4,0(sp)
    800029be:	6145                	addi	sp,sp,48
    800029c0:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800029c2:	0009a503          	lw	a0,0(s3)
    800029c6:	f9eff0ef          	jal	ra,80002164 <bread>
    800029ca:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800029cc:	05850493          	addi	s1,a0,88
    800029d0:	45850913          	addi	s2,a0,1112
    800029d4:	a021                	j	800029dc <itrunc+0x6e>
    800029d6:	0491                	addi	s1,s1,4
    800029d8:	01248963          	beq	s1,s2,800029ea <itrunc+0x7c>
      if(a[j])
    800029dc:	408c                	lw	a1,0(s1)
    800029de:	dde5                	beqz	a1,800029d6 <itrunc+0x68>
        bfree(ip->dev, a[j]);
    800029e0:	0009a503          	lw	a0,0(s3)
    800029e4:	97bff0ef          	jal	ra,8000235e <bfree>
    800029e8:	b7fd                	j	800029d6 <itrunc+0x68>
    brelse(bp);
    800029ea:	8552                	mv	a0,s4
    800029ec:	881ff0ef          	jal	ra,8000226c <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800029f0:	0809a583          	lw	a1,128(s3)
    800029f4:	0009a503          	lw	a0,0(s3)
    800029f8:	967ff0ef          	jal	ra,8000235e <bfree>
    ip->addrs[NDIRECT] = 0;
    800029fc:	0809a023          	sw	zero,128(s3)
    80002a00:	b765                	j	800029a8 <itrunc+0x3a>

0000000080002a02 <iput>:
{
    80002a02:	1101                	addi	sp,sp,-32
    80002a04:	ec06                	sd	ra,24(sp)
    80002a06:	e822                	sd	s0,16(sp)
    80002a08:	e426                	sd	s1,8(sp)
    80002a0a:	e04a                	sd	s2,0(sp)
    80002a0c:	1000                	addi	s0,sp,32
    80002a0e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002a10:	00013517          	auipc	a0,0x13
    80002a14:	6e850513          	addi	a0,a0,1768 # 800160f8 <itable>
    80002a18:	613020ef          	jal	ra,8000582a <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a1c:	4498                	lw	a4,8(s1)
    80002a1e:	4785                	li	a5,1
    80002a20:	02f70163          	beq	a4,a5,80002a42 <iput+0x40>
  ip->ref--;
    80002a24:	449c                	lw	a5,8(s1)
    80002a26:	37fd                	addiw	a5,a5,-1
    80002a28:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002a2a:	00013517          	auipc	a0,0x13
    80002a2e:	6ce50513          	addi	a0,a0,1742 # 800160f8 <itable>
    80002a32:	691020ef          	jal	ra,800058c2 <release>
}
    80002a36:	60e2                	ld	ra,24(sp)
    80002a38:	6442                	ld	s0,16(sp)
    80002a3a:	64a2                	ld	s1,8(sp)
    80002a3c:	6902                	ld	s2,0(sp)
    80002a3e:	6105                	addi	sp,sp,32
    80002a40:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a42:	40bc                	lw	a5,64(s1)
    80002a44:	d3e5                	beqz	a5,80002a24 <iput+0x22>
    80002a46:	04a49783          	lh	a5,74(s1)
    80002a4a:	ffe9                	bnez	a5,80002a24 <iput+0x22>
    acquiresleep(&ip->lock);
    80002a4c:	01048913          	addi	s2,s1,16
    80002a50:	854a                	mv	a0,s2
    80002a52:	14d000ef          	jal	ra,8000339e <acquiresleep>
    release(&itable.lock);
    80002a56:	00013517          	auipc	a0,0x13
    80002a5a:	6a250513          	addi	a0,a0,1698 # 800160f8 <itable>
    80002a5e:	665020ef          	jal	ra,800058c2 <release>
    itrunc(ip);
    80002a62:	8526                	mv	a0,s1
    80002a64:	f0bff0ef          	jal	ra,8000296e <itrunc>
    ip->type = 0;
    80002a68:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002a6c:	8526                	mv	a0,s1
    80002a6e:	d65ff0ef          	jal	ra,800027d2 <iupdate>
    ip->valid = 0;
    80002a72:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002a76:	854a                	mv	a0,s2
    80002a78:	16d000ef          	jal	ra,800033e4 <releasesleep>
    acquire(&itable.lock);
    80002a7c:	00013517          	auipc	a0,0x13
    80002a80:	67c50513          	addi	a0,a0,1660 # 800160f8 <itable>
    80002a84:	5a7020ef          	jal	ra,8000582a <acquire>
    80002a88:	bf71                	j	80002a24 <iput+0x22>

0000000080002a8a <iunlockput>:
{
    80002a8a:	1101                	addi	sp,sp,-32
    80002a8c:	ec06                	sd	ra,24(sp)
    80002a8e:	e822                	sd	s0,16(sp)
    80002a90:	e426                	sd	s1,8(sp)
    80002a92:	1000                	addi	s0,sp,32
    80002a94:	84aa                	mv	s1,a0
  iunlock(ip);
    80002a96:	e99ff0ef          	jal	ra,8000292e <iunlock>
  iput(ip);
    80002a9a:	8526                	mv	a0,s1
    80002a9c:	f67ff0ef          	jal	ra,80002a02 <iput>
}
    80002aa0:	60e2                	ld	ra,24(sp)
    80002aa2:	6442                	ld	s0,16(sp)
    80002aa4:	64a2                	ld	s1,8(sp)
    80002aa6:	6105                	addi	sp,sp,32
    80002aa8:	8082                	ret

0000000080002aaa <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002aaa:	1141                	addi	sp,sp,-16
    80002aac:	e422                	sd	s0,8(sp)
    80002aae:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002ab0:	411c                	lw	a5,0(a0)
    80002ab2:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002ab4:	415c                	lw	a5,4(a0)
    80002ab6:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002ab8:	04451783          	lh	a5,68(a0)
    80002abc:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002ac0:	04a51783          	lh	a5,74(a0)
    80002ac4:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002ac8:	04c56783          	lwu	a5,76(a0)
    80002acc:	e99c                	sd	a5,16(a1)
}
    80002ace:	6422                	ld	s0,8(sp)
    80002ad0:	0141                	addi	sp,sp,16
    80002ad2:	8082                	ret

0000000080002ad4 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002ad4:	457c                	lw	a5,76(a0)
    80002ad6:	0cd7ef63          	bltu	a5,a3,80002bb4 <readi+0xe0>
{
    80002ada:	7159                	addi	sp,sp,-112
    80002adc:	f486                	sd	ra,104(sp)
    80002ade:	f0a2                	sd	s0,96(sp)
    80002ae0:	eca6                	sd	s1,88(sp)
    80002ae2:	e8ca                	sd	s2,80(sp)
    80002ae4:	e4ce                	sd	s3,72(sp)
    80002ae6:	e0d2                	sd	s4,64(sp)
    80002ae8:	fc56                	sd	s5,56(sp)
    80002aea:	f85a                	sd	s6,48(sp)
    80002aec:	f45e                	sd	s7,40(sp)
    80002aee:	f062                	sd	s8,32(sp)
    80002af0:	ec66                	sd	s9,24(sp)
    80002af2:	e86a                	sd	s10,16(sp)
    80002af4:	e46e                	sd	s11,8(sp)
    80002af6:	1880                	addi	s0,sp,112
    80002af8:	8b2a                	mv	s6,a0
    80002afa:	8bae                	mv	s7,a1
    80002afc:	8a32                	mv	s4,a2
    80002afe:	84b6                	mv	s1,a3
    80002b00:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002b02:	9f35                	addw	a4,a4,a3
    return 0;
    80002b04:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002b06:	08d76663          	bltu	a4,a3,80002b92 <readi+0xbe>
  if(off + n > ip->size)
    80002b0a:	00e7f463          	bgeu	a5,a4,80002b12 <readi+0x3e>
    n = ip->size - off;
    80002b0e:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b12:	080a8f63          	beqz	s5,80002bb0 <readi+0xdc>
    80002b16:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b18:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002b1c:	5c7d                	li	s8,-1
    80002b1e:	a80d                	j	80002b50 <readi+0x7c>
    80002b20:	020d1d93          	slli	s11,s10,0x20
    80002b24:	020ddd93          	srli	s11,s11,0x20
    80002b28:	05890793          	addi	a5,s2,88
    80002b2c:	86ee                	mv	a3,s11
    80002b2e:	963e                	add	a2,a2,a5
    80002b30:	85d2                	mv	a1,s4
    80002b32:	855e                	mv	a0,s7
    80002b34:	c99fe0ef          	jal	ra,800017cc <either_copyout>
    80002b38:	05850763          	beq	a0,s8,80002b86 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002b3c:	854a                	mv	a0,s2
    80002b3e:	f2eff0ef          	jal	ra,8000226c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b42:	013d09bb          	addw	s3,s10,s3
    80002b46:	009d04bb          	addw	s1,s10,s1
    80002b4a:	9a6e                	add	s4,s4,s11
    80002b4c:	0559f163          	bgeu	s3,s5,80002b8e <readi+0xba>
    uint addr = bmap(ip, off/BSIZE);
    80002b50:	00a4d59b          	srliw	a1,s1,0xa
    80002b54:	855a                	mv	a0,s6
    80002b56:	989ff0ef          	jal	ra,800024de <bmap>
    80002b5a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80002b5e:	c985                	beqz	a1,80002b8e <readi+0xba>
    bp = bread(ip->dev, addr);
    80002b60:	000b2503          	lw	a0,0(s6)
    80002b64:	e00ff0ef          	jal	ra,80002164 <bread>
    80002b68:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b6a:	3ff4f613          	andi	a2,s1,1023
    80002b6e:	40cc87bb          	subw	a5,s9,a2
    80002b72:	413a873b          	subw	a4,s5,s3
    80002b76:	8d3e                	mv	s10,a5
    80002b78:	2781                	sext.w	a5,a5
    80002b7a:	0007069b          	sext.w	a3,a4
    80002b7e:	faf6f1e3          	bgeu	a3,a5,80002b20 <readi+0x4c>
    80002b82:	8d3a                	mv	s10,a4
    80002b84:	bf71                	j	80002b20 <readi+0x4c>
      brelse(bp);
    80002b86:	854a                	mv	a0,s2
    80002b88:	ee4ff0ef          	jal	ra,8000226c <brelse>
      tot = -1;
    80002b8c:	59fd                	li	s3,-1
  }
  return tot;
    80002b8e:	0009851b          	sext.w	a0,s3
}
    80002b92:	70a6                	ld	ra,104(sp)
    80002b94:	7406                	ld	s0,96(sp)
    80002b96:	64e6                	ld	s1,88(sp)
    80002b98:	6946                	ld	s2,80(sp)
    80002b9a:	69a6                	ld	s3,72(sp)
    80002b9c:	6a06                	ld	s4,64(sp)
    80002b9e:	7ae2                	ld	s5,56(sp)
    80002ba0:	7b42                	ld	s6,48(sp)
    80002ba2:	7ba2                	ld	s7,40(sp)
    80002ba4:	7c02                	ld	s8,32(sp)
    80002ba6:	6ce2                	ld	s9,24(sp)
    80002ba8:	6d42                	ld	s10,16(sp)
    80002baa:	6da2                	ld	s11,8(sp)
    80002bac:	6165                	addi	sp,sp,112
    80002bae:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002bb0:	89d6                	mv	s3,s5
    80002bb2:	bff1                	j	80002b8e <readi+0xba>
    return 0;
    80002bb4:	4501                	li	a0,0
}
    80002bb6:	8082                	ret

0000000080002bb8 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002bb8:	457c                	lw	a5,76(a0)
    80002bba:	0ed7ea63          	bltu	a5,a3,80002cae <writei+0xf6>
{
    80002bbe:	7159                	addi	sp,sp,-112
    80002bc0:	f486                	sd	ra,104(sp)
    80002bc2:	f0a2                	sd	s0,96(sp)
    80002bc4:	eca6                	sd	s1,88(sp)
    80002bc6:	e8ca                	sd	s2,80(sp)
    80002bc8:	e4ce                	sd	s3,72(sp)
    80002bca:	e0d2                	sd	s4,64(sp)
    80002bcc:	fc56                	sd	s5,56(sp)
    80002bce:	f85a                	sd	s6,48(sp)
    80002bd0:	f45e                	sd	s7,40(sp)
    80002bd2:	f062                	sd	s8,32(sp)
    80002bd4:	ec66                	sd	s9,24(sp)
    80002bd6:	e86a                	sd	s10,16(sp)
    80002bd8:	e46e                	sd	s11,8(sp)
    80002bda:	1880                	addi	s0,sp,112
    80002bdc:	8aaa                	mv	s5,a0
    80002bde:	8bae                	mv	s7,a1
    80002be0:	8a32                	mv	s4,a2
    80002be2:	8936                	mv	s2,a3
    80002be4:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80002be6:	00e687bb          	addw	a5,a3,a4
    80002bea:	0cd7e463          	bltu	a5,a3,80002cb2 <writei+0xfa>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80002bee:	00043737          	lui	a4,0x43
    80002bf2:	0cf76263          	bltu	a4,a5,80002cb6 <writei+0xfe>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002bf6:	0a0b0a63          	beqz	s6,80002caa <writei+0xf2>
    80002bfa:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002bfc:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002c00:	5c7d                	li	s8,-1
    80002c02:	a825                	j	80002c3a <writei+0x82>
    80002c04:	020d1d93          	slli	s11,s10,0x20
    80002c08:	020ddd93          	srli	s11,s11,0x20
    80002c0c:	05848793          	addi	a5,s1,88
    80002c10:	86ee                	mv	a3,s11
    80002c12:	8652                	mv	a2,s4
    80002c14:	85de                	mv	a1,s7
    80002c16:	953e                	add	a0,a0,a5
    80002c18:	bfffe0ef          	jal	ra,80001816 <either_copyin>
    80002c1c:	05850a63          	beq	a0,s8,80002c70 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002c20:	8526                	mv	a0,s1
    80002c22:	674000ef          	jal	ra,80003296 <log_write>
    brelse(bp);
    80002c26:	8526                	mv	a0,s1
    80002c28:	e44ff0ef          	jal	ra,8000226c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c2c:	013d09bb          	addw	s3,s10,s3
    80002c30:	012d093b          	addw	s2,s10,s2
    80002c34:	9a6e                	add	s4,s4,s11
    80002c36:	0569f063          	bgeu	s3,s6,80002c76 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002c3a:	00a9559b          	srliw	a1,s2,0xa
    80002c3e:	8556                	mv	a0,s5
    80002c40:	89fff0ef          	jal	ra,800024de <bmap>
    80002c44:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80002c48:	c59d                	beqz	a1,80002c76 <writei+0xbe>
    bp = bread(ip->dev, addr);
    80002c4a:	000aa503          	lw	a0,0(s5)
    80002c4e:	d16ff0ef          	jal	ra,80002164 <bread>
    80002c52:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c54:	3ff97513          	andi	a0,s2,1023
    80002c58:	40ac87bb          	subw	a5,s9,a0
    80002c5c:	413b073b          	subw	a4,s6,s3
    80002c60:	8d3e                	mv	s10,a5
    80002c62:	2781                	sext.w	a5,a5
    80002c64:	0007069b          	sext.w	a3,a4
    80002c68:	f8f6fee3          	bgeu	a3,a5,80002c04 <writei+0x4c>
    80002c6c:	8d3a                	mv	s10,a4
    80002c6e:	bf59                	j	80002c04 <writei+0x4c>
      brelse(bp);
    80002c70:	8526                	mv	a0,s1
    80002c72:	dfaff0ef          	jal	ra,8000226c <brelse>
  }

  if(off > ip->size)
    80002c76:	04caa783          	lw	a5,76(s5)
    80002c7a:	0127f463          	bgeu	a5,s2,80002c82 <writei+0xca>
    ip->size = off;
    80002c7e:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002c82:	8556                	mv	a0,s5
    80002c84:	b4fff0ef          	jal	ra,800027d2 <iupdate>

  return tot;
    80002c88:	0009851b          	sext.w	a0,s3
}
    80002c8c:	70a6                	ld	ra,104(sp)
    80002c8e:	7406                	ld	s0,96(sp)
    80002c90:	64e6                	ld	s1,88(sp)
    80002c92:	6946                	ld	s2,80(sp)
    80002c94:	69a6                	ld	s3,72(sp)
    80002c96:	6a06                	ld	s4,64(sp)
    80002c98:	7ae2                	ld	s5,56(sp)
    80002c9a:	7b42                	ld	s6,48(sp)
    80002c9c:	7ba2                	ld	s7,40(sp)
    80002c9e:	7c02                	ld	s8,32(sp)
    80002ca0:	6ce2                	ld	s9,24(sp)
    80002ca2:	6d42                	ld	s10,16(sp)
    80002ca4:	6da2                	ld	s11,8(sp)
    80002ca6:	6165                	addi	sp,sp,112
    80002ca8:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002caa:	89da                	mv	s3,s6
    80002cac:	bfd9                	j	80002c82 <writei+0xca>
    return -1;
    80002cae:	557d                	li	a0,-1
}
    80002cb0:	8082                	ret
    return -1;
    80002cb2:	557d                	li	a0,-1
    80002cb4:	bfe1                	j	80002c8c <writei+0xd4>
    return -1;
    80002cb6:	557d                	li	a0,-1
    80002cb8:	bfd1                	j	80002c8c <writei+0xd4>

0000000080002cba <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002cba:	1141                	addi	sp,sp,-16
    80002cbc:	e406                	sd	ra,8(sp)
    80002cbe:	e022                	sd	s0,0(sp)
    80002cc0:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002cc2:	4639                	li	a2,14
    80002cc4:	d54fd0ef          	jal	ra,80000218 <strncmp>
}
    80002cc8:	60a2                	ld	ra,8(sp)
    80002cca:	6402                	ld	s0,0(sp)
    80002ccc:	0141                	addi	sp,sp,16
    80002cce:	8082                	ret

0000000080002cd0 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002cd0:	7139                	addi	sp,sp,-64
    80002cd2:	fc06                	sd	ra,56(sp)
    80002cd4:	f822                	sd	s0,48(sp)
    80002cd6:	f426                	sd	s1,40(sp)
    80002cd8:	f04a                	sd	s2,32(sp)
    80002cda:	ec4e                	sd	s3,24(sp)
    80002cdc:	e852                	sd	s4,16(sp)
    80002cde:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002ce0:	04451703          	lh	a4,68(a0)
    80002ce4:	4785                	li	a5,1
    80002ce6:	00f71a63          	bne	a4,a5,80002cfa <dirlookup+0x2a>
    80002cea:	892a                	mv	s2,a0
    80002cec:	89ae                	mv	s3,a1
    80002cee:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cf0:	457c                	lw	a5,76(a0)
    80002cf2:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002cf4:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002cf6:	e39d                	bnez	a5,80002d1c <dirlookup+0x4c>
    80002cf8:	a095                	j	80002d5c <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80002cfa:	00005517          	auipc	a0,0x5
    80002cfe:	96e50513          	addi	a0,a0,-1682 # 80007668 <syscalls+0x210>
    80002d02:	015020ef          	jal	ra,80005516 <panic>
      panic("dirlookup read");
    80002d06:	00005517          	auipc	a0,0x5
    80002d0a:	97a50513          	addi	a0,a0,-1670 # 80007680 <syscalls+0x228>
    80002d0e:	009020ef          	jal	ra,80005516 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d12:	24c1                	addiw	s1,s1,16
    80002d14:	04c92783          	lw	a5,76(s2)
    80002d18:	04f4f163          	bgeu	s1,a5,80002d5a <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d1c:	4741                	li	a4,16
    80002d1e:	86a6                	mv	a3,s1
    80002d20:	fc040613          	addi	a2,s0,-64
    80002d24:	4581                	li	a1,0
    80002d26:	854a                	mv	a0,s2
    80002d28:	dadff0ef          	jal	ra,80002ad4 <readi>
    80002d2c:	47c1                	li	a5,16
    80002d2e:	fcf51ce3          	bne	a0,a5,80002d06 <dirlookup+0x36>
    if(de.inum == 0)
    80002d32:	fc045783          	lhu	a5,-64(s0)
    80002d36:	dff1                	beqz	a5,80002d12 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80002d38:	fc240593          	addi	a1,s0,-62
    80002d3c:	854e                	mv	a0,s3
    80002d3e:	f7dff0ef          	jal	ra,80002cba <namecmp>
    80002d42:	f961                	bnez	a0,80002d12 <dirlookup+0x42>
      if(poff)
    80002d44:	000a0463          	beqz	s4,80002d4c <dirlookup+0x7c>
        *poff = off;
    80002d48:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80002d4c:	fc045583          	lhu	a1,-64(s0)
    80002d50:	00092503          	lw	a0,0(s2)
    80002d54:	859ff0ef          	jal	ra,800025ac <iget>
    80002d58:	a011                	j	80002d5c <dirlookup+0x8c>
  return 0;
    80002d5a:	4501                	li	a0,0
}
    80002d5c:	70e2                	ld	ra,56(sp)
    80002d5e:	7442                	ld	s0,48(sp)
    80002d60:	74a2                	ld	s1,40(sp)
    80002d62:	7902                	ld	s2,32(sp)
    80002d64:	69e2                	ld	s3,24(sp)
    80002d66:	6a42                	ld	s4,16(sp)
    80002d68:	6121                	addi	sp,sp,64
    80002d6a:	8082                	ret

0000000080002d6c <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002d6c:	711d                	addi	sp,sp,-96
    80002d6e:	ec86                	sd	ra,88(sp)
    80002d70:	e8a2                	sd	s0,80(sp)
    80002d72:	e4a6                	sd	s1,72(sp)
    80002d74:	e0ca                	sd	s2,64(sp)
    80002d76:	fc4e                	sd	s3,56(sp)
    80002d78:	f852                	sd	s4,48(sp)
    80002d7a:	f456                	sd	s5,40(sp)
    80002d7c:	f05a                	sd	s6,32(sp)
    80002d7e:	ec5e                	sd	s7,24(sp)
    80002d80:	e862                	sd	s8,16(sp)
    80002d82:	e466                	sd	s9,8(sp)
    80002d84:	1080                	addi	s0,sp,96
    80002d86:	84aa                	mv	s1,a0
    80002d88:	8aae                	mv	s5,a1
    80002d8a:	8a32                	mv	s4,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002d8c:	00054703          	lbu	a4,0(a0)
    80002d90:	02f00793          	li	a5,47
    80002d94:	00f70f63          	beq	a4,a5,80002db2 <namex+0x46>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002d98:	882fe0ef          	jal	ra,80000e1a <myproc>
    80002d9c:	15853503          	ld	a0,344(a0)
    80002da0:	aafff0ef          	jal	ra,8000284e <idup>
    80002da4:	89aa                	mv	s3,a0
  while(*path == '/')
    80002da6:	02f00913          	li	s2,47
  len = path - s;
    80002daa:	4b01                	li	s6,0
  if(len >= DIRSIZ)
    80002dac:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002dae:	4b85                	li	s7,1
    80002db0:	a861                	j	80002e48 <namex+0xdc>
    ip = iget(ROOTDEV, ROOTINO);
    80002db2:	4585                	li	a1,1
    80002db4:	4505                	li	a0,1
    80002db6:	ff6ff0ef          	jal	ra,800025ac <iget>
    80002dba:	89aa                	mv	s3,a0
    80002dbc:	b7ed                	j	80002da6 <namex+0x3a>
      iunlockput(ip);
    80002dbe:	854e                	mv	a0,s3
    80002dc0:	ccbff0ef          	jal	ra,80002a8a <iunlockput>
      return 0;
    80002dc4:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002dc6:	854e                	mv	a0,s3
    80002dc8:	60e6                	ld	ra,88(sp)
    80002dca:	6446                	ld	s0,80(sp)
    80002dcc:	64a6                	ld	s1,72(sp)
    80002dce:	6906                	ld	s2,64(sp)
    80002dd0:	79e2                	ld	s3,56(sp)
    80002dd2:	7a42                	ld	s4,48(sp)
    80002dd4:	7aa2                	ld	s5,40(sp)
    80002dd6:	7b02                	ld	s6,32(sp)
    80002dd8:	6be2                	ld	s7,24(sp)
    80002dda:	6c42                	ld	s8,16(sp)
    80002ddc:	6ca2                	ld	s9,8(sp)
    80002dde:	6125                	addi	sp,sp,96
    80002de0:	8082                	ret
      iunlock(ip);
    80002de2:	854e                	mv	a0,s3
    80002de4:	b4bff0ef          	jal	ra,8000292e <iunlock>
      return ip;
    80002de8:	bff9                	j	80002dc6 <namex+0x5a>
      iunlockput(ip);
    80002dea:	854e                	mv	a0,s3
    80002dec:	c9fff0ef          	jal	ra,80002a8a <iunlockput>
      return 0;
    80002df0:	89e6                	mv	s3,s9
    80002df2:	bfd1                	j	80002dc6 <namex+0x5a>
  len = path - s;
    80002df4:	40b48633          	sub	a2,s1,a1
    80002df8:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80002dfc:	079c5c63          	bge	s8,s9,80002e74 <namex+0x108>
    memmove(name, s, DIRSIZ);
    80002e00:	4639                	li	a2,14
    80002e02:	8552                	mv	a0,s4
    80002e04:	ba4fd0ef          	jal	ra,800001a8 <memmove>
  while(*path == '/')
    80002e08:	0004c783          	lbu	a5,0(s1)
    80002e0c:	01279763          	bne	a5,s2,80002e1a <namex+0xae>
    path++;
    80002e10:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e12:	0004c783          	lbu	a5,0(s1)
    80002e16:	ff278de3          	beq	a5,s2,80002e10 <namex+0xa4>
    ilock(ip);
    80002e1a:	854e                	mv	a0,s3
    80002e1c:	a69ff0ef          	jal	ra,80002884 <ilock>
    if(ip->type != T_DIR){
    80002e20:	04499783          	lh	a5,68(s3)
    80002e24:	f9779de3          	bne	a5,s7,80002dbe <namex+0x52>
    if(nameiparent && *path == '\0'){
    80002e28:	000a8563          	beqz	s5,80002e32 <namex+0xc6>
    80002e2c:	0004c783          	lbu	a5,0(s1)
    80002e30:	dbcd                	beqz	a5,80002de2 <namex+0x76>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002e32:	865a                	mv	a2,s6
    80002e34:	85d2                	mv	a1,s4
    80002e36:	854e                	mv	a0,s3
    80002e38:	e99ff0ef          	jal	ra,80002cd0 <dirlookup>
    80002e3c:	8caa                	mv	s9,a0
    80002e3e:	d555                	beqz	a0,80002dea <namex+0x7e>
    iunlockput(ip);
    80002e40:	854e                	mv	a0,s3
    80002e42:	c49ff0ef          	jal	ra,80002a8a <iunlockput>
    ip = next;
    80002e46:	89e6                	mv	s3,s9
  while(*path == '/')
    80002e48:	0004c783          	lbu	a5,0(s1)
    80002e4c:	05279363          	bne	a5,s2,80002e92 <namex+0x126>
    path++;
    80002e50:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e52:	0004c783          	lbu	a5,0(s1)
    80002e56:	ff278de3          	beq	a5,s2,80002e50 <namex+0xe4>
  if(*path == 0)
    80002e5a:	c78d                	beqz	a5,80002e84 <namex+0x118>
    path++;
    80002e5c:	85a6                	mv	a1,s1
  len = path - s;
    80002e5e:	8cda                	mv	s9,s6
    80002e60:	865a                	mv	a2,s6
  while(*path != '/' && *path != 0)
    80002e62:	01278963          	beq	a5,s2,80002e74 <namex+0x108>
    80002e66:	d7d9                	beqz	a5,80002df4 <namex+0x88>
    path++;
    80002e68:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80002e6a:	0004c783          	lbu	a5,0(s1)
    80002e6e:	ff279ce3          	bne	a5,s2,80002e66 <namex+0xfa>
    80002e72:	b749                	j	80002df4 <namex+0x88>
    memmove(name, s, len);
    80002e74:	2601                	sext.w	a2,a2
    80002e76:	8552                	mv	a0,s4
    80002e78:	b30fd0ef          	jal	ra,800001a8 <memmove>
    name[len] = 0;
    80002e7c:	9cd2                	add	s9,s9,s4
    80002e7e:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80002e82:	b759                	j	80002e08 <namex+0x9c>
  if(nameiparent){
    80002e84:	f40a81e3          	beqz	s5,80002dc6 <namex+0x5a>
    iput(ip);
    80002e88:	854e                	mv	a0,s3
    80002e8a:	b79ff0ef          	jal	ra,80002a02 <iput>
    return 0;
    80002e8e:	4981                	li	s3,0
    80002e90:	bf1d                	j	80002dc6 <namex+0x5a>
  if(*path == 0)
    80002e92:	dbed                	beqz	a5,80002e84 <namex+0x118>
  while(*path != '/' && *path != 0)
    80002e94:	0004c783          	lbu	a5,0(s1)
    80002e98:	85a6                	mv	a1,s1
    80002e9a:	b7f1                	j	80002e66 <namex+0xfa>

0000000080002e9c <dirlink>:
{
    80002e9c:	7139                	addi	sp,sp,-64
    80002e9e:	fc06                	sd	ra,56(sp)
    80002ea0:	f822                	sd	s0,48(sp)
    80002ea2:	f426                	sd	s1,40(sp)
    80002ea4:	f04a                	sd	s2,32(sp)
    80002ea6:	ec4e                	sd	s3,24(sp)
    80002ea8:	e852                	sd	s4,16(sp)
    80002eaa:	0080                	addi	s0,sp,64
    80002eac:	892a                	mv	s2,a0
    80002eae:	8a2e                	mv	s4,a1
    80002eb0:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002eb2:	4601                	li	a2,0
    80002eb4:	e1dff0ef          	jal	ra,80002cd0 <dirlookup>
    80002eb8:	e52d                	bnez	a0,80002f22 <dirlink+0x86>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002eba:	04c92483          	lw	s1,76(s2)
    80002ebe:	c48d                	beqz	s1,80002ee8 <dirlink+0x4c>
    80002ec0:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002ec2:	4741                	li	a4,16
    80002ec4:	86a6                	mv	a3,s1
    80002ec6:	fc040613          	addi	a2,s0,-64
    80002eca:	4581                	li	a1,0
    80002ecc:	854a                	mv	a0,s2
    80002ece:	c07ff0ef          	jal	ra,80002ad4 <readi>
    80002ed2:	47c1                	li	a5,16
    80002ed4:	04f51b63          	bne	a0,a5,80002f2a <dirlink+0x8e>
    if(de.inum == 0)
    80002ed8:	fc045783          	lhu	a5,-64(s0)
    80002edc:	c791                	beqz	a5,80002ee8 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002ede:	24c1                	addiw	s1,s1,16
    80002ee0:	04c92783          	lw	a5,76(s2)
    80002ee4:	fcf4efe3          	bltu	s1,a5,80002ec2 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80002ee8:	4639                	li	a2,14
    80002eea:	85d2                	mv	a1,s4
    80002eec:	fc240513          	addi	a0,s0,-62
    80002ef0:	b64fd0ef          	jal	ra,80000254 <strncpy>
  de.inum = inum;
    80002ef4:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002ef8:	4741                	li	a4,16
    80002efa:	86a6                	mv	a3,s1
    80002efc:	fc040613          	addi	a2,s0,-64
    80002f00:	4581                	li	a1,0
    80002f02:	854a                	mv	a0,s2
    80002f04:	cb5ff0ef          	jal	ra,80002bb8 <writei>
    80002f08:	1541                	addi	a0,a0,-16
    80002f0a:	00a03533          	snez	a0,a0
    80002f0e:	40a00533          	neg	a0,a0
}
    80002f12:	70e2                	ld	ra,56(sp)
    80002f14:	7442                	ld	s0,48(sp)
    80002f16:	74a2                	ld	s1,40(sp)
    80002f18:	7902                	ld	s2,32(sp)
    80002f1a:	69e2                	ld	s3,24(sp)
    80002f1c:	6a42                	ld	s4,16(sp)
    80002f1e:	6121                	addi	sp,sp,64
    80002f20:	8082                	ret
    iput(ip);
    80002f22:	ae1ff0ef          	jal	ra,80002a02 <iput>
    return -1;
    80002f26:	557d                	li	a0,-1
    80002f28:	b7ed                	j	80002f12 <dirlink+0x76>
      panic("dirlink read");
    80002f2a:	00004517          	auipc	a0,0x4
    80002f2e:	76650513          	addi	a0,a0,1894 # 80007690 <syscalls+0x238>
    80002f32:	5e4020ef          	jal	ra,80005516 <panic>

0000000080002f36 <namei>:

struct inode*
namei(char *path)
{
    80002f36:	1101                	addi	sp,sp,-32
    80002f38:	ec06                	sd	ra,24(sp)
    80002f3a:	e822                	sd	s0,16(sp)
    80002f3c:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002f3e:	fe040613          	addi	a2,s0,-32
    80002f42:	4581                	li	a1,0
    80002f44:	e29ff0ef          	jal	ra,80002d6c <namex>
}
    80002f48:	60e2                	ld	ra,24(sp)
    80002f4a:	6442                	ld	s0,16(sp)
    80002f4c:	6105                	addi	sp,sp,32
    80002f4e:	8082                	ret

0000000080002f50 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002f50:	1141                	addi	sp,sp,-16
    80002f52:	e406                	sd	ra,8(sp)
    80002f54:	e022                	sd	s0,0(sp)
    80002f56:	0800                	addi	s0,sp,16
    80002f58:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002f5a:	4585                	li	a1,1
    80002f5c:	e11ff0ef          	jal	ra,80002d6c <namex>
}
    80002f60:	60a2                	ld	ra,8(sp)
    80002f62:	6402                	ld	s0,0(sp)
    80002f64:	0141                	addi	sp,sp,16
    80002f66:	8082                	ret

0000000080002f68 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002f68:	1101                	addi	sp,sp,-32
    80002f6a:	ec06                	sd	ra,24(sp)
    80002f6c:	e822                	sd	s0,16(sp)
    80002f6e:	e426                	sd	s1,8(sp)
    80002f70:	e04a                	sd	s2,0(sp)
    80002f72:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002f74:	00015917          	auipc	s2,0x15
    80002f78:	c2c90913          	addi	s2,s2,-980 # 80017ba0 <log>
    80002f7c:	01892583          	lw	a1,24(s2)
    80002f80:	02892503          	lw	a0,40(s2)
    80002f84:	9e0ff0ef          	jal	ra,80002164 <bread>
    80002f88:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002f8a:	02c92683          	lw	a3,44(s2)
    80002f8e:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002f90:	02d05863          	blez	a3,80002fc0 <write_head+0x58>
    80002f94:	00015797          	auipc	a5,0x15
    80002f98:	c3c78793          	addi	a5,a5,-964 # 80017bd0 <log+0x30>
    80002f9c:	05c50713          	addi	a4,a0,92
    80002fa0:	36fd                	addiw	a3,a3,-1
    80002fa2:	02069613          	slli	a2,a3,0x20
    80002fa6:	01e65693          	srli	a3,a2,0x1e
    80002faa:	00015617          	auipc	a2,0x15
    80002fae:	c2a60613          	addi	a2,a2,-982 # 80017bd4 <log+0x34>
    80002fb2:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80002fb4:	4390                	lw	a2,0(a5)
    80002fb6:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80002fb8:	0791                	addi	a5,a5,4
    80002fba:	0711                	addi	a4,a4,4
    80002fbc:	fed79ce3          	bne	a5,a3,80002fb4 <write_head+0x4c>
  }
  bwrite(buf);
    80002fc0:	8526                	mv	a0,s1
    80002fc2:	a78ff0ef          	jal	ra,8000223a <bwrite>
  brelse(buf);
    80002fc6:	8526                	mv	a0,s1
    80002fc8:	aa4ff0ef          	jal	ra,8000226c <brelse>
}
    80002fcc:	60e2                	ld	ra,24(sp)
    80002fce:	6442                	ld	s0,16(sp)
    80002fd0:	64a2                	ld	s1,8(sp)
    80002fd2:	6902                	ld	s2,0(sp)
    80002fd4:	6105                	addi	sp,sp,32
    80002fd6:	8082                	ret

0000000080002fd8 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002fd8:	00015797          	auipc	a5,0x15
    80002fdc:	bf47a783          	lw	a5,-1036(a5) # 80017bcc <log+0x2c>
    80002fe0:	08f05f63          	blez	a5,8000307e <install_trans+0xa6>
{
    80002fe4:	7139                	addi	sp,sp,-64
    80002fe6:	fc06                	sd	ra,56(sp)
    80002fe8:	f822                	sd	s0,48(sp)
    80002fea:	f426                	sd	s1,40(sp)
    80002fec:	f04a                	sd	s2,32(sp)
    80002fee:	ec4e                	sd	s3,24(sp)
    80002ff0:	e852                	sd	s4,16(sp)
    80002ff2:	e456                	sd	s5,8(sp)
    80002ff4:	e05a                	sd	s6,0(sp)
    80002ff6:	0080                	addi	s0,sp,64
    80002ff8:	8b2a                	mv	s6,a0
    80002ffa:	00015a97          	auipc	s5,0x15
    80002ffe:	bd6a8a93          	addi	s5,s5,-1066 # 80017bd0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003002:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003004:	00015997          	auipc	s3,0x15
    80003008:	b9c98993          	addi	s3,s3,-1124 # 80017ba0 <log>
    8000300c:	a829                	j	80003026 <install_trans+0x4e>
    brelse(lbuf);
    8000300e:	854a                	mv	a0,s2
    80003010:	a5cff0ef          	jal	ra,8000226c <brelse>
    brelse(dbuf);
    80003014:	8526                	mv	a0,s1
    80003016:	a56ff0ef          	jal	ra,8000226c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000301a:	2a05                	addiw	s4,s4,1
    8000301c:	0a91                	addi	s5,s5,4
    8000301e:	02c9a783          	lw	a5,44(s3)
    80003022:	04fa5463          	bge	s4,a5,8000306a <install_trans+0x92>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003026:	0189a583          	lw	a1,24(s3)
    8000302a:	014585bb          	addw	a1,a1,s4
    8000302e:	2585                	addiw	a1,a1,1
    80003030:	0289a503          	lw	a0,40(s3)
    80003034:	930ff0ef          	jal	ra,80002164 <bread>
    80003038:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    8000303a:	000aa583          	lw	a1,0(s5)
    8000303e:	0289a503          	lw	a0,40(s3)
    80003042:	922ff0ef          	jal	ra,80002164 <bread>
    80003046:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003048:	40000613          	li	a2,1024
    8000304c:	05890593          	addi	a1,s2,88
    80003050:	05850513          	addi	a0,a0,88
    80003054:	954fd0ef          	jal	ra,800001a8 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003058:	8526                	mv	a0,s1
    8000305a:	9e0ff0ef          	jal	ra,8000223a <bwrite>
    if(recovering == 0)
    8000305e:	fa0b18e3          	bnez	s6,8000300e <install_trans+0x36>
      bunpin(dbuf);
    80003062:	8526                	mv	a0,s1
    80003064:	ac6ff0ef          	jal	ra,8000232a <bunpin>
    80003068:	b75d                	j	8000300e <install_trans+0x36>
}
    8000306a:	70e2                	ld	ra,56(sp)
    8000306c:	7442                	ld	s0,48(sp)
    8000306e:	74a2                	ld	s1,40(sp)
    80003070:	7902                	ld	s2,32(sp)
    80003072:	69e2                	ld	s3,24(sp)
    80003074:	6a42                	ld	s4,16(sp)
    80003076:	6aa2                	ld	s5,8(sp)
    80003078:	6b02                	ld	s6,0(sp)
    8000307a:	6121                	addi	sp,sp,64
    8000307c:	8082                	ret
    8000307e:	8082                	ret

0000000080003080 <initlog>:
{
    80003080:	7179                	addi	sp,sp,-48
    80003082:	f406                	sd	ra,40(sp)
    80003084:	f022                	sd	s0,32(sp)
    80003086:	ec26                	sd	s1,24(sp)
    80003088:	e84a                	sd	s2,16(sp)
    8000308a:	e44e                	sd	s3,8(sp)
    8000308c:	1800                	addi	s0,sp,48
    8000308e:	892a                	mv	s2,a0
    80003090:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003092:	00015497          	auipc	s1,0x15
    80003096:	b0e48493          	addi	s1,s1,-1266 # 80017ba0 <log>
    8000309a:	00004597          	auipc	a1,0x4
    8000309e:	60658593          	addi	a1,a1,1542 # 800076a0 <syscalls+0x248>
    800030a2:	8526                	mv	a0,s1
    800030a4:	706020ef          	jal	ra,800057aa <initlock>
  log.start = sb->logstart;
    800030a8:	0149a583          	lw	a1,20(s3)
    800030ac:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    800030ae:	0109a783          	lw	a5,16(s3)
    800030b2:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    800030b4:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    800030b8:	854a                	mv	a0,s2
    800030ba:	8aaff0ef          	jal	ra,80002164 <bread>
  log.lh.n = lh->n;
    800030be:	4d34                	lw	a3,88(a0)
    800030c0:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    800030c2:	02d05663          	blez	a3,800030ee <initlog+0x6e>
    800030c6:	05c50793          	addi	a5,a0,92
    800030ca:	00015717          	auipc	a4,0x15
    800030ce:	b0670713          	addi	a4,a4,-1274 # 80017bd0 <log+0x30>
    800030d2:	36fd                	addiw	a3,a3,-1
    800030d4:	02069613          	slli	a2,a3,0x20
    800030d8:	01e65693          	srli	a3,a2,0x1e
    800030dc:	06050613          	addi	a2,a0,96
    800030e0:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    800030e2:	4390                	lw	a2,0(a5)
    800030e4:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800030e6:	0791                	addi	a5,a5,4
    800030e8:	0711                	addi	a4,a4,4
    800030ea:	fed79ce3          	bne	a5,a3,800030e2 <initlog+0x62>
  brelse(buf);
    800030ee:	97eff0ef          	jal	ra,8000226c <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800030f2:	4505                	li	a0,1
    800030f4:	ee5ff0ef          	jal	ra,80002fd8 <install_trans>
  log.lh.n = 0;
    800030f8:	00015797          	auipc	a5,0x15
    800030fc:	ac07aa23          	sw	zero,-1324(a5) # 80017bcc <log+0x2c>
  write_head(); // clear the log
    80003100:	e69ff0ef          	jal	ra,80002f68 <write_head>
}
    80003104:	70a2                	ld	ra,40(sp)
    80003106:	7402                	ld	s0,32(sp)
    80003108:	64e2                	ld	s1,24(sp)
    8000310a:	6942                	ld	s2,16(sp)
    8000310c:	69a2                	ld	s3,8(sp)
    8000310e:	6145                	addi	sp,sp,48
    80003110:	8082                	ret

0000000080003112 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003112:	1101                	addi	sp,sp,-32
    80003114:	ec06                	sd	ra,24(sp)
    80003116:	e822                	sd	s0,16(sp)
    80003118:	e426                	sd	s1,8(sp)
    8000311a:	e04a                	sd	s2,0(sp)
    8000311c:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000311e:	00015517          	auipc	a0,0x15
    80003122:	a8250513          	addi	a0,a0,-1406 # 80017ba0 <log>
    80003126:	704020ef          	jal	ra,8000582a <acquire>
  while(1){
    if(log.committing){
    8000312a:	00015497          	auipc	s1,0x15
    8000312e:	a7648493          	addi	s1,s1,-1418 # 80017ba0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003132:	4979                	li	s2,30
    80003134:	a029                	j	8000313e <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003136:	85a6                	mv	a1,s1
    80003138:	8526                	mv	a0,s1
    8000313a:	b36fe0ef          	jal	ra,80001470 <sleep>
    if(log.committing){
    8000313e:	50dc                	lw	a5,36(s1)
    80003140:	fbfd                	bnez	a5,80003136 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003142:	509c                	lw	a5,32(s1)
    80003144:	0017871b          	addiw	a4,a5,1
    80003148:	0007069b          	sext.w	a3,a4
    8000314c:	0027179b          	slliw	a5,a4,0x2
    80003150:	9fb9                	addw	a5,a5,a4
    80003152:	0017979b          	slliw	a5,a5,0x1
    80003156:	54d8                	lw	a4,44(s1)
    80003158:	9fb9                	addw	a5,a5,a4
    8000315a:	00f95763          	bge	s2,a5,80003168 <begin_op+0x56>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    8000315e:	85a6                	mv	a1,s1
    80003160:	8526                	mv	a0,s1
    80003162:	b0efe0ef          	jal	ra,80001470 <sleep>
    80003166:	bfe1                	j	8000313e <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003168:	00015517          	auipc	a0,0x15
    8000316c:	a3850513          	addi	a0,a0,-1480 # 80017ba0 <log>
    80003170:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80003172:	750020ef          	jal	ra,800058c2 <release>
      break;
    }
  }
}
    80003176:	60e2                	ld	ra,24(sp)
    80003178:	6442                	ld	s0,16(sp)
    8000317a:	64a2                	ld	s1,8(sp)
    8000317c:	6902                	ld	s2,0(sp)
    8000317e:	6105                	addi	sp,sp,32
    80003180:	8082                	ret

0000000080003182 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003182:	7139                	addi	sp,sp,-64
    80003184:	fc06                	sd	ra,56(sp)
    80003186:	f822                	sd	s0,48(sp)
    80003188:	f426                	sd	s1,40(sp)
    8000318a:	f04a                	sd	s2,32(sp)
    8000318c:	ec4e                	sd	s3,24(sp)
    8000318e:	e852                	sd	s4,16(sp)
    80003190:	e456                	sd	s5,8(sp)
    80003192:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003194:	00015497          	auipc	s1,0x15
    80003198:	a0c48493          	addi	s1,s1,-1524 # 80017ba0 <log>
    8000319c:	8526                	mv	a0,s1
    8000319e:	68c020ef          	jal	ra,8000582a <acquire>
  log.outstanding -= 1;
    800031a2:	509c                	lw	a5,32(s1)
    800031a4:	37fd                	addiw	a5,a5,-1
    800031a6:	0007891b          	sext.w	s2,a5
    800031aa:	d09c                	sw	a5,32(s1)
  if(log.committing)
    800031ac:	50dc                	lw	a5,36(s1)
    800031ae:	ef9d                	bnez	a5,800031ec <end_op+0x6a>
    panic("log.committing");
  if(log.outstanding == 0){
    800031b0:	04091463          	bnez	s2,800031f8 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    800031b4:	00015497          	auipc	s1,0x15
    800031b8:	9ec48493          	addi	s1,s1,-1556 # 80017ba0 <log>
    800031bc:	4785                	li	a5,1
    800031be:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800031c0:	8526                	mv	a0,s1
    800031c2:	700020ef          	jal	ra,800058c2 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800031c6:	54dc                	lw	a5,44(s1)
    800031c8:	04f04b63          	bgtz	a5,8000321e <end_op+0x9c>
    acquire(&log.lock);
    800031cc:	00015497          	auipc	s1,0x15
    800031d0:	9d448493          	addi	s1,s1,-1580 # 80017ba0 <log>
    800031d4:	8526                	mv	a0,s1
    800031d6:	654020ef          	jal	ra,8000582a <acquire>
    log.committing = 0;
    800031da:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    800031de:	8526                	mv	a0,s1
    800031e0:	adcfe0ef          	jal	ra,800014bc <wakeup>
    release(&log.lock);
    800031e4:	8526                	mv	a0,s1
    800031e6:	6dc020ef          	jal	ra,800058c2 <release>
}
    800031ea:	a00d                	j	8000320c <end_op+0x8a>
    panic("log.committing");
    800031ec:	00004517          	auipc	a0,0x4
    800031f0:	4bc50513          	addi	a0,a0,1212 # 800076a8 <syscalls+0x250>
    800031f4:	322020ef          	jal	ra,80005516 <panic>
    wakeup(&log);
    800031f8:	00015497          	auipc	s1,0x15
    800031fc:	9a848493          	addi	s1,s1,-1624 # 80017ba0 <log>
    80003200:	8526                	mv	a0,s1
    80003202:	abafe0ef          	jal	ra,800014bc <wakeup>
  release(&log.lock);
    80003206:	8526                	mv	a0,s1
    80003208:	6ba020ef          	jal	ra,800058c2 <release>
}
    8000320c:	70e2                	ld	ra,56(sp)
    8000320e:	7442                	ld	s0,48(sp)
    80003210:	74a2                	ld	s1,40(sp)
    80003212:	7902                	ld	s2,32(sp)
    80003214:	69e2                	ld	s3,24(sp)
    80003216:	6a42                	ld	s4,16(sp)
    80003218:	6aa2                	ld	s5,8(sp)
    8000321a:	6121                	addi	sp,sp,64
    8000321c:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    8000321e:	00015a97          	auipc	s5,0x15
    80003222:	9b2a8a93          	addi	s5,s5,-1614 # 80017bd0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003226:	00015a17          	auipc	s4,0x15
    8000322a:	97aa0a13          	addi	s4,s4,-1670 # 80017ba0 <log>
    8000322e:	018a2583          	lw	a1,24(s4)
    80003232:	012585bb          	addw	a1,a1,s2
    80003236:	2585                	addiw	a1,a1,1
    80003238:	028a2503          	lw	a0,40(s4)
    8000323c:	f29fe0ef          	jal	ra,80002164 <bread>
    80003240:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003242:	000aa583          	lw	a1,0(s5)
    80003246:	028a2503          	lw	a0,40(s4)
    8000324a:	f1bfe0ef          	jal	ra,80002164 <bread>
    8000324e:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003250:	40000613          	li	a2,1024
    80003254:	05850593          	addi	a1,a0,88
    80003258:	05848513          	addi	a0,s1,88
    8000325c:	f4dfc0ef          	jal	ra,800001a8 <memmove>
    bwrite(to);  // write the log
    80003260:	8526                	mv	a0,s1
    80003262:	fd9fe0ef          	jal	ra,8000223a <bwrite>
    brelse(from);
    80003266:	854e                	mv	a0,s3
    80003268:	804ff0ef          	jal	ra,8000226c <brelse>
    brelse(to);
    8000326c:	8526                	mv	a0,s1
    8000326e:	ffffe0ef          	jal	ra,8000226c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003272:	2905                	addiw	s2,s2,1
    80003274:	0a91                	addi	s5,s5,4
    80003276:	02ca2783          	lw	a5,44(s4)
    8000327a:	faf94ae3          	blt	s2,a5,8000322e <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    8000327e:	cebff0ef          	jal	ra,80002f68 <write_head>
    install_trans(0); // Now install writes to home locations
    80003282:	4501                	li	a0,0
    80003284:	d55ff0ef          	jal	ra,80002fd8 <install_trans>
    log.lh.n = 0;
    80003288:	00015797          	auipc	a5,0x15
    8000328c:	9407a223          	sw	zero,-1724(a5) # 80017bcc <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003290:	cd9ff0ef          	jal	ra,80002f68 <write_head>
    80003294:	bf25                	j	800031cc <end_op+0x4a>

0000000080003296 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003296:	1101                	addi	sp,sp,-32
    80003298:	ec06                	sd	ra,24(sp)
    8000329a:	e822                	sd	s0,16(sp)
    8000329c:	e426                	sd	s1,8(sp)
    8000329e:	e04a                	sd	s2,0(sp)
    800032a0:	1000                	addi	s0,sp,32
    800032a2:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800032a4:	00015917          	auipc	s2,0x15
    800032a8:	8fc90913          	addi	s2,s2,-1796 # 80017ba0 <log>
    800032ac:	854a                	mv	a0,s2
    800032ae:	57c020ef          	jal	ra,8000582a <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800032b2:	02c92603          	lw	a2,44(s2)
    800032b6:	47f5                	li	a5,29
    800032b8:	06c7c363          	blt	a5,a2,8000331e <log_write+0x88>
    800032bc:	00015797          	auipc	a5,0x15
    800032c0:	9007a783          	lw	a5,-1792(a5) # 80017bbc <log+0x1c>
    800032c4:	37fd                	addiw	a5,a5,-1
    800032c6:	04f65c63          	bge	a2,a5,8000331e <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800032ca:	00015797          	auipc	a5,0x15
    800032ce:	8f67a783          	lw	a5,-1802(a5) # 80017bc0 <log+0x20>
    800032d2:	04f05c63          	blez	a5,8000332a <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800032d6:	4781                	li	a5,0
    800032d8:	04c05f63          	blez	a2,80003336 <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800032dc:	44cc                	lw	a1,12(s1)
    800032de:	00015717          	auipc	a4,0x15
    800032e2:	8f270713          	addi	a4,a4,-1806 # 80017bd0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800032e6:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800032e8:	4314                	lw	a3,0(a4)
    800032ea:	04b68663          	beq	a3,a1,80003336 <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    800032ee:	2785                	addiw	a5,a5,1
    800032f0:	0711                	addi	a4,a4,4
    800032f2:	fef61be3          	bne	a2,a5,800032e8 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    800032f6:	0621                	addi	a2,a2,8
    800032f8:	060a                	slli	a2,a2,0x2
    800032fa:	00015797          	auipc	a5,0x15
    800032fe:	8a678793          	addi	a5,a5,-1882 # 80017ba0 <log>
    80003302:	963e                	add	a2,a2,a5
    80003304:	44dc                	lw	a5,12(s1)
    80003306:	ca1c                	sw	a5,16(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003308:	8526                	mv	a0,s1
    8000330a:	fedfe0ef          	jal	ra,800022f6 <bpin>
    log.lh.n++;
    8000330e:	00015717          	auipc	a4,0x15
    80003312:	89270713          	addi	a4,a4,-1902 # 80017ba0 <log>
    80003316:	575c                	lw	a5,44(a4)
    80003318:	2785                	addiw	a5,a5,1
    8000331a:	d75c                	sw	a5,44(a4)
    8000331c:	a815                	j	80003350 <log_write+0xba>
    panic("too big a transaction");
    8000331e:	00004517          	auipc	a0,0x4
    80003322:	39a50513          	addi	a0,a0,922 # 800076b8 <syscalls+0x260>
    80003326:	1f0020ef          	jal	ra,80005516 <panic>
    panic("log_write outside of trans");
    8000332a:	00004517          	auipc	a0,0x4
    8000332e:	3a650513          	addi	a0,a0,934 # 800076d0 <syscalls+0x278>
    80003332:	1e4020ef          	jal	ra,80005516 <panic>
  log.lh.block[i] = b->blockno;
    80003336:	00878713          	addi	a4,a5,8
    8000333a:	00271693          	slli	a3,a4,0x2
    8000333e:	00015717          	auipc	a4,0x15
    80003342:	86270713          	addi	a4,a4,-1950 # 80017ba0 <log>
    80003346:	9736                	add	a4,a4,a3
    80003348:	44d4                	lw	a3,12(s1)
    8000334a:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000334c:	faf60ee3          	beq	a2,a5,80003308 <log_write+0x72>
  }
  release(&log.lock);
    80003350:	00015517          	auipc	a0,0x15
    80003354:	85050513          	addi	a0,a0,-1968 # 80017ba0 <log>
    80003358:	56a020ef          	jal	ra,800058c2 <release>
}
    8000335c:	60e2                	ld	ra,24(sp)
    8000335e:	6442                	ld	s0,16(sp)
    80003360:	64a2                	ld	s1,8(sp)
    80003362:	6902                	ld	s2,0(sp)
    80003364:	6105                	addi	sp,sp,32
    80003366:	8082                	ret

0000000080003368 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003368:	1101                	addi	sp,sp,-32
    8000336a:	ec06                	sd	ra,24(sp)
    8000336c:	e822                	sd	s0,16(sp)
    8000336e:	e426                	sd	s1,8(sp)
    80003370:	e04a                	sd	s2,0(sp)
    80003372:	1000                	addi	s0,sp,32
    80003374:	84aa                	mv	s1,a0
    80003376:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003378:	00004597          	auipc	a1,0x4
    8000337c:	37858593          	addi	a1,a1,888 # 800076f0 <syscalls+0x298>
    80003380:	0521                	addi	a0,a0,8
    80003382:	428020ef          	jal	ra,800057aa <initlock>
  lk->name = name;
    80003386:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    8000338a:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000338e:	0204a423          	sw	zero,40(s1)
}
    80003392:	60e2                	ld	ra,24(sp)
    80003394:	6442                	ld	s0,16(sp)
    80003396:	64a2                	ld	s1,8(sp)
    80003398:	6902                	ld	s2,0(sp)
    8000339a:	6105                	addi	sp,sp,32
    8000339c:	8082                	ret

000000008000339e <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000339e:	1101                	addi	sp,sp,-32
    800033a0:	ec06                	sd	ra,24(sp)
    800033a2:	e822                	sd	s0,16(sp)
    800033a4:	e426                	sd	s1,8(sp)
    800033a6:	e04a                	sd	s2,0(sp)
    800033a8:	1000                	addi	s0,sp,32
    800033aa:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800033ac:	00850913          	addi	s2,a0,8
    800033b0:	854a                	mv	a0,s2
    800033b2:	478020ef          	jal	ra,8000582a <acquire>
  while (lk->locked) {
    800033b6:	409c                	lw	a5,0(s1)
    800033b8:	c799                	beqz	a5,800033c6 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800033ba:	85ca                	mv	a1,s2
    800033bc:	8526                	mv	a0,s1
    800033be:	8b2fe0ef          	jal	ra,80001470 <sleep>
  while (lk->locked) {
    800033c2:	409c                	lw	a5,0(s1)
    800033c4:	fbfd                	bnez	a5,800033ba <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800033c6:	4785                	li	a5,1
    800033c8:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800033ca:	a51fd0ef          	jal	ra,80000e1a <myproc>
    800033ce:	591c                	lw	a5,48(a0)
    800033d0:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800033d2:	854a                	mv	a0,s2
    800033d4:	4ee020ef          	jal	ra,800058c2 <release>
}
    800033d8:	60e2                	ld	ra,24(sp)
    800033da:	6442                	ld	s0,16(sp)
    800033dc:	64a2                	ld	s1,8(sp)
    800033de:	6902                	ld	s2,0(sp)
    800033e0:	6105                	addi	sp,sp,32
    800033e2:	8082                	ret

00000000800033e4 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800033e4:	1101                	addi	sp,sp,-32
    800033e6:	ec06                	sd	ra,24(sp)
    800033e8:	e822                	sd	s0,16(sp)
    800033ea:	e426                	sd	s1,8(sp)
    800033ec:	e04a                	sd	s2,0(sp)
    800033ee:	1000                	addi	s0,sp,32
    800033f0:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800033f2:	00850913          	addi	s2,a0,8
    800033f6:	854a                	mv	a0,s2
    800033f8:	432020ef          	jal	ra,8000582a <acquire>
  lk->locked = 0;
    800033fc:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003400:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003404:	8526                	mv	a0,s1
    80003406:	8b6fe0ef          	jal	ra,800014bc <wakeup>
  release(&lk->lk);
    8000340a:	854a                	mv	a0,s2
    8000340c:	4b6020ef          	jal	ra,800058c2 <release>
}
    80003410:	60e2                	ld	ra,24(sp)
    80003412:	6442                	ld	s0,16(sp)
    80003414:	64a2                	ld	s1,8(sp)
    80003416:	6902                	ld	s2,0(sp)
    80003418:	6105                	addi	sp,sp,32
    8000341a:	8082                	ret

000000008000341c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000341c:	7179                	addi	sp,sp,-48
    8000341e:	f406                	sd	ra,40(sp)
    80003420:	f022                	sd	s0,32(sp)
    80003422:	ec26                	sd	s1,24(sp)
    80003424:	e84a                	sd	s2,16(sp)
    80003426:	e44e                	sd	s3,8(sp)
    80003428:	1800                	addi	s0,sp,48
    8000342a:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000342c:	00850913          	addi	s2,a0,8
    80003430:	854a                	mv	a0,s2
    80003432:	3f8020ef          	jal	ra,8000582a <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003436:	409c                	lw	a5,0(s1)
    80003438:	ef89                	bnez	a5,80003452 <holdingsleep+0x36>
    8000343a:	4481                	li	s1,0
  release(&lk->lk);
    8000343c:	854a                	mv	a0,s2
    8000343e:	484020ef          	jal	ra,800058c2 <release>
  return r;
}
    80003442:	8526                	mv	a0,s1
    80003444:	70a2                	ld	ra,40(sp)
    80003446:	7402                	ld	s0,32(sp)
    80003448:	64e2                	ld	s1,24(sp)
    8000344a:	6942                	ld	s2,16(sp)
    8000344c:	69a2                	ld	s3,8(sp)
    8000344e:	6145                	addi	sp,sp,48
    80003450:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80003452:	0284a983          	lw	s3,40(s1)
    80003456:	9c5fd0ef          	jal	ra,80000e1a <myproc>
    8000345a:	5904                	lw	s1,48(a0)
    8000345c:	413484b3          	sub	s1,s1,s3
    80003460:	0014b493          	seqz	s1,s1
    80003464:	bfe1                	j	8000343c <holdingsleep+0x20>

0000000080003466 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003466:	1141                	addi	sp,sp,-16
    80003468:	e406                	sd	ra,8(sp)
    8000346a:	e022                	sd	s0,0(sp)
    8000346c:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000346e:	00004597          	auipc	a1,0x4
    80003472:	29258593          	addi	a1,a1,658 # 80007700 <syscalls+0x2a8>
    80003476:	00015517          	auipc	a0,0x15
    8000347a:	87250513          	addi	a0,a0,-1934 # 80017ce8 <ftable>
    8000347e:	32c020ef          	jal	ra,800057aa <initlock>
}
    80003482:	60a2                	ld	ra,8(sp)
    80003484:	6402                	ld	s0,0(sp)
    80003486:	0141                	addi	sp,sp,16
    80003488:	8082                	ret

000000008000348a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000348a:	1101                	addi	sp,sp,-32
    8000348c:	ec06                	sd	ra,24(sp)
    8000348e:	e822                	sd	s0,16(sp)
    80003490:	e426                	sd	s1,8(sp)
    80003492:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003494:	00015517          	auipc	a0,0x15
    80003498:	85450513          	addi	a0,a0,-1964 # 80017ce8 <ftable>
    8000349c:	38e020ef          	jal	ra,8000582a <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800034a0:	00015497          	auipc	s1,0x15
    800034a4:	86048493          	addi	s1,s1,-1952 # 80017d00 <ftable+0x18>
    800034a8:	00015717          	auipc	a4,0x15
    800034ac:	7f870713          	addi	a4,a4,2040 # 80018ca0 <disk>
    if(f->ref == 0){
    800034b0:	40dc                	lw	a5,4(s1)
    800034b2:	cf89                	beqz	a5,800034cc <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800034b4:	02848493          	addi	s1,s1,40
    800034b8:	fee49ce3          	bne	s1,a4,800034b0 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800034bc:	00015517          	auipc	a0,0x15
    800034c0:	82c50513          	addi	a0,a0,-2004 # 80017ce8 <ftable>
    800034c4:	3fe020ef          	jal	ra,800058c2 <release>
  return 0;
    800034c8:	4481                	li	s1,0
    800034ca:	a809                	j	800034dc <filealloc+0x52>
      f->ref = 1;
    800034cc:	4785                	li	a5,1
    800034ce:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800034d0:	00015517          	auipc	a0,0x15
    800034d4:	81850513          	addi	a0,a0,-2024 # 80017ce8 <ftable>
    800034d8:	3ea020ef          	jal	ra,800058c2 <release>
}
    800034dc:	8526                	mv	a0,s1
    800034de:	60e2                	ld	ra,24(sp)
    800034e0:	6442                	ld	s0,16(sp)
    800034e2:	64a2                	ld	s1,8(sp)
    800034e4:	6105                	addi	sp,sp,32
    800034e6:	8082                	ret

00000000800034e8 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800034e8:	1101                	addi	sp,sp,-32
    800034ea:	ec06                	sd	ra,24(sp)
    800034ec:	e822                	sd	s0,16(sp)
    800034ee:	e426                	sd	s1,8(sp)
    800034f0:	1000                	addi	s0,sp,32
    800034f2:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800034f4:	00014517          	auipc	a0,0x14
    800034f8:	7f450513          	addi	a0,a0,2036 # 80017ce8 <ftable>
    800034fc:	32e020ef          	jal	ra,8000582a <acquire>
  if(f->ref < 1)
    80003500:	40dc                	lw	a5,4(s1)
    80003502:	02f05063          	blez	a5,80003522 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003506:	2785                	addiw	a5,a5,1
    80003508:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000350a:	00014517          	auipc	a0,0x14
    8000350e:	7de50513          	addi	a0,a0,2014 # 80017ce8 <ftable>
    80003512:	3b0020ef          	jal	ra,800058c2 <release>
  return f;
}
    80003516:	8526                	mv	a0,s1
    80003518:	60e2                	ld	ra,24(sp)
    8000351a:	6442                	ld	s0,16(sp)
    8000351c:	64a2                	ld	s1,8(sp)
    8000351e:	6105                	addi	sp,sp,32
    80003520:	8082                	ret
    panic("filedup");
    80003522:	00004517          	auipc	a0,0x4
    80003526:	1e650513          	addi	a0,a0,486 # 80007708 <syscalls+0x2b0>
    8000352a:	7ed010ef          	jal	ra,80005516 <panic>

000000008000352e <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000352e:	7139                	addi	sp,sp,-64
    80003530:	fc06                	sd	ra,56(sp)
    80003532:	f822                	sd	s0,48(sp)
    80003534:	f426                	sd	s1,40(sp)
    80003536:	f04a                	sd	s2,32(sp)
    80003538:	ec4e                	sd	s3,24(sp)
    8000353a:	e852                	sd	s4,16(sp)
    8000353c:	e456                	sd	s5,8(sp)
    8000353e:	0080                	addi	s0,sp,64
    80003540:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003542:	00014517          	auipc	a0,0x14
    80003546:	7a650513          	addi	a0,a0,1958 # 80017ce8 <ftable>
    8000354a:	2e0020ef          	jal	ra,8000582a <acquire>
  if(f->ref < 1)
    8000354e:	40dc                	lw	a5,4(s1)
    80003550:	04f05963          	blez	a5,800035a2 <fileclose+0x74>
    panic("fileclose");
  if(--f->ref > 0){
    80003554:	37fd                	addiw	a5,a5,-1
    80003556:	0007871b          	sext.w	a4,a5
    8000355a:	c0dc                	sw	a5,4(s1)
    8000355c:	04e04963          	bgtz	a4,800035ae <fileclose+0x80>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003560:	0004a903          	lw	s2,0(s1)
    80003564:	0094ca83          	lbu	s5,9(s1)
    80003568:	0104ba03          	ld	s4,16(s1)
    8000356c:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80003570:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003574:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003578:	00014517          	auipc	a0,0x14
    8000357c:	77050513          	addi	a0,a0,1904 # 80017ce8 <ftable>
    80003580:	342020ef          	jal	ra,800058c2 <release>

  if(ff.type == FD_PIPE){
    80003584:	4785                	li	a5,1
    80003586:	04f90363          	beq	s2,a5,800035cc <fileclose+0x9e>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000358a:	3979                	addiw	s2,s2,-2
    8000358c:	4785                	li	a5,1
    8000358e:	0327e663          	bltu	a5,s2,800035ba <fileclose+0x8c>
    begin_op();
    80003592:	b81ff0ef          	jal	ra,80003112 <begin_op>
    iput(ff.ip);
    80003596:	854e                	mv	a0,s3
    80003598:	c6aff0ef          	jal	ra,80002a02 <iput>
    end_op();
    8000359c:	be7ff0ef          	jal	ra,80003182 <end_op>
    800035a0:	a829                	j	800035ba <fileclose+0x8c>
    panic("fileclose");
    800035a2:	00004517          	auipc	a0,0x4
    800035a6:	16e50513          	addi	a0,a0,366 # 80007710 <syscalls+0x2b8>
    800035aa:	76d010ef          	jal	ra,80005516 <panic>
    release(&ftable.lock);
    800035ae:	00014517          	auipc	a0,0x14
    800035b2:	73a50513          	addi	a0,a0,1850 # 80017ce8 <ftable>
    800035b6:	30c020ef          	jal	ra,800058c2 <release>
  }
}
    800035ba:	70e2                	ld	ra,56(sp)
    800035bc:	7442                	ld	s0,48(sp)
    800035be:	74a2                	ld	s1,40(sp)
    800035c0:	7902                	ld	s2,32(sp)
    800035c2:	69e2                	ld	s3,24(sp)
    800035c4:	6a42                	ld	s4,16(sp)
    800035c6:	6aa2                	ld	s5,8(sp)
    800035c8:	6121                	addi	sp,sp,64
    800035ca:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800035cc:	85d6                	mv	a1,s5
    800035ce:	8552                	mv	a0,s4
    800035d0:	2ec000ef          	jal	ra,800038bc <pipeclose>
    800035d4:	b7dd                	j	800035ba <fileclose+0x8c>

00000000800035d6 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800035d6:	715d                	addi	sp,sp,-80
    800035d8:	e486                	sd	ra,72(sp)
    800035da:	e0a2                	sd	s0,64(sp)
    800035dc:	fc26                	sd	s1,56(sp)
    800035de:	f84a                	sd	s2,48(sp)
    800035e0:	f44e                	sd	s3,40(sp)
    800035e2:	0880                	addi	s0,sp,80
    800035e4:	84aa                	mv	s1,a0
    800035e6:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800035e8:	833fd0ef          	jal	ra,80000e1a <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800035ec:	409c                	lw	a5,0(s1)
    800035ee:	37f9                	addiw	a5,a5,-2
    800035f0:	4705                	li	a4,1
    800035f2:	02f76f63          	bltu	a4,a5,80003630 <filestat+0x5a>
    800035f6:	892a                	mv	s2,a0
    ilock(f->ip);
    800035f8:	6c88                	ld	a0,24(s1)
    800035fa:	a8aff0ef          	jal	ra,80002884 <ilock>
    stati(f->ip, &st);
    800035fe:	fb840593          	addi	a1,s0,-72
    80003602:	6c88                	ld	a0,24(s1)
    80003604:	ca6ff0ef          	jal	ra,80002aaa <stati>
    iunlock(f->ip);
    80003608:	6c88                	ld	a0,24(s1)
    8000360a:	b24ff0ef          	jal	ra,8000292e <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000360e:	46e1                	li	a3,24
    80003610:	fb840613          	addi	a2,s0,-72
    80003614:	85ce                	mv	a1,s3
    80003616:	05093503          	ld	a0,80(s2)
    8000361a:	bbcfd0ef          	jal	ra,800009d6 <copyout>
    8000361e:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    80003622:	60a6                	ld	ra,72(sp)
    80003624:	6406                	ld	s0,64(sp)
    80003626:	74e2                	ld	s1,56(sp)
    80003628:	7942                	ld	s2,48(sp)
    8000362a:	79a2                	ld	s3,40(sp)
    8000362c:	6161                	addi	sp,sp,80
    8000362e:	8082                	ret
  return -1;
    80003630:	557d                	li	a0,-1
    80003632:	bfc5                	j	80003622 <filestat+0x4c>

0000000080003634 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003634:	7179                	addi	sp,sp,-48
    80003636:	f406                	sd	ra,40(sp)
    80003638:	f022                	sd	s0,32(sp)
    8000363a:	ec26                	sd	s1,24(sp)
    8000363c:	e84a                	sd	s2,16(sp)
    8000363e:	e44e                	sd	s3,8(sp)
    80003640:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003642:	00854783          	lbu	a5,8(a0)
    80003646:	cbc1                	beqz	a5,800036d6 <fileread+0xa2>
    80003648:	84aa                	mv	s1,a0
    8000364a:	89ae                	mv	s3,a1
    8000364c:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    8000364e:	411c                	lw	a5,0(a0)
    80003650:	4705                	li	a4,1
    80003652:	04e78363          	beq	a5,a4,80003698 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003656:	470d                	li	a4,3
    80003658:	04e78563          	beq	a5,a4,800036a2 <fileread+0x6e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    8000365c:	4709                	li	a4,2
    8000365e:	06e79663          	bne	a5,a4,800036ca <fileread+0x96>
    ilock(f->ip);
    80003662:	6d08                	ld	a0,24(a0)
    80003664:	a20ff0ef          	jal	ra,80002884 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80003668:	874a                	mv	a4,s2
    8000366a:	5094                	lw	a3,32(s1)
    8000366c:	864e                	mv	a2,s3
    8000366e:	4585                	li	a1,1
    80003670:	6c88                	ld	a0,24(s1)
    80003672:	c62ff0ef          	jal	ra,80002ad4 <readi>
    80003676:	892a                	mv	s2,a0
    80003678:	00a05563          	blez	a0,80003682 <fileread+0x4e>
      f->off += r;
    8000367c:	509c                	lw	a5,32(s1)
    8000367e:	9fa9                	addw	a5,a5,a0
    80003680:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80003682:	6c88                	ld	a0,24(s1)
    80003684:	aaaff0ef          	jal	ra,8000292e <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    80003688:	854a                	mv	a0,s2
    8000368a:	70a2                	ld	ra,40(sp)
    8000368c:	7402                	ld	s0,32(sp)
    8000368e:	64e2                	ld	s1,24(sp)
    80003690:	6942                	ld	s2,16(sp)
    80003692:	69a2                	ld	s3,8(sp)
    80003694:	6145                	addi	sp,sp,48
    80003696:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80003698:	6908                	ld	a0,16(a0)
    8000369a:	34e000ef          	jal	ra,800039e8 <piperead>
    8000369e:	892a                	mv	s2,a0
    800036a0:	b7e5                	j	80003688 <fileread+0x54>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800036a2:	02451783          	lh	a5,36(a0)
    800036a6:	03079693          	slli	a3,a5,0x30
    800036aa:	92c1                	srli	a3,a3,0x30
    800036ac:	4725                	li	a4,9
    800036ae:	02d76663          	bltu	a4,a3,800036da <fileread+0xa6>
    800036b2:	0792                	slli	a5,a5,0x4
    800036b4:	00014717          	auipc	a4,0x14
    800036b8:	59470713          	addi	a4,a4,1428 # 80017c48 <devsw>
    800036bc:	97ba                	add	a5,a5,a4
    800036be:	639c                	ld	a5,0(a5)
    800036c0:	cf99                	beqz	a5,800036de <fileread+0xaa>
    r = devsw[f->major].read(1, addr, n);
    800036c2:	4505                	li	a0,1
    800036c4:	9782                	jalr	a5
    800036c6:	892a                	mv	s2,a0
    800036c8:	b7c1                	j	80003688 <fileread+0x54>
    panic("fileread");
    800036ca:	00004517          	auipc	a0,0x4
    800036ce:	05650513          	addi	a0,a0,86 # 80007720 <syscalls+0x2c8>
    800036d2:	645010ef          	jal	ra,80005516 <panic>
    return -1;
    800036d6:	597d                	li	s2,-1
    800036d8:	bf45                	j	80003688 <fileread+0x54>
      return -1;
    800036da:	597d                	li	s2,-1
    800036dc:	b775                	j	80003688 <fileread+0x54>
    800036de:	597d                	li	s2,-1
    800036e0:	b765                	j	80003688 <fileread+0x54>

00000000800036e2 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800036e2:	715d                	addi	sp,sp,-80
    800036e4:	e486                	sd	ra,72(sp)
    800036e6:	e0a2                	sd	s0,64(sp)
    800036e8:	fc26                	sd	s1,56(sp)
    800036ea:	f84a                	sd	s2,48(sp)
    800036ec:	f44e                	sd	s3,40(sp)
    800036ee:	f052                	sd	s4,32(sp)
    800036f0:	ec56                	sd	s5,24(sp)
    800036f2:	e85a                	sd	s6,16(sp)
    800036f4:	e45e                	sd	s7,8(sp)
    800036f6:	e062                	sd	s8,0(sp)
    800036f8:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800036fa:	00954783          	lbu	a5,9(a0)
    800036fe:	0e078863          	beqz	a5,800037ee <filewrite+0x10c>
    80003702:	892a                	mv	s2,a0
    80003704:	8aae                	mv	s5,a1
    80003706:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    80003708:	411c                	lw	a5,0(a0)
    8000370a:	4705                	li	a4,1
    8000370c:	02e78263          	beq	a5,a4,80003730 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003710:	470d                	li	a4,3
    80003712:	02e78463          	beq	a5,a4,8000373a <filewrite+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80003716:	4709                	li	a4,2
    80003718:	0ce79563          	bne	a5,a4,800037e2 <filewrite+0x100>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    8000371c:	0ac05163          	blez	a2,800037be <filewrite+0xdc>
    int i = 0;
    80003720:	4981                	li	s3,0
    80003722:	6b05                	lui	s6,0x1
    80003724:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    80003728:	6b85                	lui	s7,0x1
    8000372a:	c00b8b9b          	addiw	s7,s7,-1024
    8000372e:	a041                	j	800037ae <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80003730:	6908                	ld	a0,16(a0)
    80003732:	1e2000ef          	jal	ra,80003914 <pipewrite>
    80003736:	8a2a                	mv	s4,a0
    80003738:	a071                	j	800037c4 <filewrite+0xe2>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000373a:	02451783          	lh	a5,36(a0)
    8000373e:	03079693          	slli	a3,a5,0x30
    80003742:	92c1                	srli	a3,a3,0x30
    80003744:	4725                	li	a4,9
    80003746:	0ad76663          	bltu	a4,a3,800037f2 <filewrite+0x110>
    8000374a:	0792                	slli	a5,a5,0x4
    8000374c:	00014717          	auipc	a4,0x14
    80003750:	4fc70713          	addi	a4,a4,1276 # 80017c48 <devsw>
    80003754:	97ba                	add	a5,a5,a4
    80003756:	679c                	ld	a5,8(a5)
    80003758:	cfd9                	beqz	a5,800037f6 <filewrite+0x114>
    ret = devsw[f->major].write(1, addr, n);
    8000375a:	4505                	li	a0,1
    8000375c:	9782                	jalr	a5
    8000375e:	8a2a                	mv	s4,a0
    80003760:	a095                	j	800037c4 <filewrite+0xe2>
    80003762:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    80003766:	9adff0ef          	jal	ra,80003112 <begin_op>
      ilock(f->ip);
    8000376a:	01893503          	ld	a0,24(s2)
    8000376e:	916ff0ef          	jal	ra,80002884 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80003772:	8762                	mv	a4,s8
    80003774:	02092683          	lw	a3,32(s2)
    80003778:	01598633          	add	a2,s3,s5
    8000377c:	4585                	li	a1,1
    8000377e:	01893503          	ld	a0,24(s2)
    80003782:	c36ff0ef          	jal	ra,80002bb8 <writei>
    80003786:	84aa                	mv	s1,a0
    80003788:	00a05763          	blez	a0,80003796 <filewrite+0xb4>
        f->off += r;
    8000378c:	02092783          	lw	a5,32(s2)
    80003790:	9fa9                	addw	a5,a5,a0
    80003792:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80003796:	01893503          	ld	a0,24(s2)
    8000379a:	994ff0ef          	jal	ra,8000292e <iunlock>
      end_op();
    8000379e:	9e5ff0ef          	jal	ra,80003182 <end_op>

      if(r != n1){
    800037a2:	009c1f63          	bne	s8,s1,800037c0 <filewrite+0xde>
        // error from writei
        break;
      }
      i += r;
    800037a6:	013489bb          	addw	s3,s1,s3
    while(i < n){
    800037aa:	0149db63          	bge	s3,s4,800037c0 <filewrite+0xde>
      int n1 = n - i;
    800037ae:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    800037b2:	84be                	mv	s1,a5
    800037b4:	2781                	sext.w	a5,a5
    800037b6:	fafb56e3          	bge	s6,a5,80003762 <filewrite+0x80>
    800037ba:	84de                	mv	s1,s7
    800037bc:	b75d                	j	80003762 <filewrite+0x80>
    int i = 0;
    800037be:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    800037c0:	013a1f63          	bne	s4,s3,800037de <filewrite+0xfc>
  } else {
    panic("filewrite");
  }

  return ret;
}
    800037c4:	8552                	mv	a0,s4
    800037c6:	60a6                	ld	ra,72(sp)
    800037c8:	6406                	ld	s0,64(sp)
    800037ca:	74e2                	ld	s1,56(sp)
    800037cc:	7942                	ld	s2,48(sp)
    800037ce:	79a2                	ld	s3,40(sp)
    800037d0:	7a02                	ld	s4,32(sp)
    800037d2:	6ae2                	ld	s5,24(sp)
    800037d4:	6b42                	ld	s6,16(sp)
    800037d6:	6ba2                	ld	s7,8(sp)
    800037d8:	6c02                	ld	s8,0(sp)
    800037da:	6161                	addi	sp,sp,80
    800037dc:	8082                	ret
    ret = (i == n ? n : -1);
    800037de:	5a7d                	li	s4,-1
    800037e0:	b7d5                	j	800037c4 <filewrite+0xe2>
    panic("filewrite");
    800037e2:	00004517          	auipc	a0,0x4
    800037e6:	f4e50513          	addi	a0,a0,-178 # 80007730 <syscalls+0x2d8>
    800037ea:	52d010ef          	jal	ra,80005516 <panic>
    return -1;
    800037ee:	5a7d                	li	s4,-1
    800037f0:	bfd1                	j	800037c4 <filewrite+0xe2>
      return -1;
    800037f2:	5a7d                	li	s4,-1
    800037f4:	bfc1                	j	800037c4 <filewrite+0xe2>
    800037f6:	5a7d                	li	s4,-1
    800037f8:	b7f1                	j	800037c4 <filewrite+0xe2>

00000000800037fa <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800037fa:	7179                	addi	sp,sp,-48
    800037fc:	f406                	sd	ra,40(sp)
    800037fe:	f022                	sd	s0,32(sp)
    80003800:	ec26                	sd	s1,24(sp)
    80003802:	e84a                	sd	s2,16(sp)
    80003804:	e44e                	sd	s3,8(sp)
    80003806:	e052                	sd	s4,0(sp)
    80003808:	1800                	addi	s0,sp,48
    8000380a:	84aa                	mv	s1,a0
    8000380c:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000380e:	0005b023          	sd	zero,0(a1)
    80003812:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80003816:	c75ff0ef          	jal	ra,8000348a <filealloc>
    8000381a:	e088                	sd	a0,0(s1)
    8000381c:	cd35                	beqz	a0,80003898 <pipealloc+0x9e>
    8000381e:	c6dff0ef          	jal	ra,8000348a <filealloc>
    80003822:	00aa3023          	sd	a0,0(s4)
    80003826:	c52d                	beqz	a0,80003890 <pipealloc+0x96>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80003828:	8d5fc0ef          	jal	ra,800000fc <kalloc>
    8000382c:	892a                	mv	s2,a0
    8000382e:	cd31                	beqz	a0,8000388a <pipealloc+0x90>
    goto bad;
  pi->readopen = 1;
    80003830:	4985                	li	s3,1
    80003832:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80003836:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000383a:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000383e:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003842:	00004597          	auipc	a1,0x4
    80003846:	efe58593          	addi	a1,a1,-258 # 80007740 <syscalls+0x2e8>
    8000384a:	761010ef          	jal	ra,800057aa <initlock>
  (*f0)->type = FD_PIPE;
    8000384e:	609c                	ld	a5,0(s1)
    80003850:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003854:	609c                	ld	a5,0(s1)
    80003856:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000385a:	609c                	ld	a5,0(s1)
    8000385c:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80003860:	609c                	ld	a5,0(s1)
    80003862:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80003866:	000a3783          	ld	a5,0(s4)
    8000386a:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000386e:	000a3783          	ld	a5,0(s4)
    80003872:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80003876:	000a3783          	ld	a5,0(s4)
    8000387a:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000387e:	000a3783          	ld	a5,0(s4)
    80003882:	0127b823          	sd	s2,16(a5)
  return 0;
    80003886:	4501                	li	a0,0
    80003888:	a005                	j	800038a8 <pipealloc+0xae>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000388a:	6088                	ld	a0,0(s1)
    8000388c:	e501                	bnez	a0,80003894 <pipealloc+0x9a>
    8000388e:	a029                	j	80003898 <pipealloc+0x9e>
    80003890:	6088                	ld	a0,0(s1)
    80003892:	c11d                	beqz	a0,800038b8 <pipealloc+0xbe>
    fileclose(*f0);
    80003894:	c9bff0ef          	jal	ra,8000352e <fileclose>
  if(*f1)
    80003898:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    8000389c:	557d                	li	a0,-1
  if(*f1)
    8000389e:	c789                	beqz	a5,800038a8 <pipealloc+0xae>
    fileclose(*f1);
    800038a0:	853e                	mv	a0,a5
    800038a2:	c8dff0ef          	jal	ra,8000352e <fileclose>
  return -1;
    800038a6:	557d                	li	a0,-1
}
    800038a8:	70a2                	ld	ra,40(sp)
    800038aa:	7402                	ld	s0,32(sp)
    800038ac:	64e2                	ld	s1,24(sp)
    800038ae:	6942                	ld	s2,16(sp)
    800038b0:	69a2                	ld	s3,8(sp)
    800038b2:	6a02                	ld	s4,0(sp)
    800038b4:	6145                	addi	sp,sp,48
    800038b6:	8082                	ret
  return -1;
    800038b8:	557d                	li	a0,-1
    800038ba:	b7fd                	j	800038a8 <pipealloc+0xae>

00000000800038bc <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800038bc:	1101                	addi	sp,sp,-32
    800038be:	ec06                	sd	ra,24(sp)
    800038c0:	e822                	sd	s0,16(sp)
    800038c2:	e426                	sd	s1,8(sp)
    800038c4:	e04a                	sd	s2,0(sp)
    800038c6:	1000                	addi	s0,sp,32
    800038c8:	84aa                	mv	s1,a0
    800038ca:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800038cc:	75f010ef          	jal	ra,8000582a <acquire>
  if(writable){
    800038d0:	02090763          	beqz	s2,800038fe <pipeclose+0x42>
    pi->writeopen = 0;
    800038d4:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800038d8:	21848513          	addi	a0,s1,536
    800038dc:	be1fd0ef          	jal	ra,800014bc <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800038e0:	2204b783          	ld	a5,544(s1)
    800038e4:	e785                	bnez	a5,8000390c <pipeclose+0x50>
    release(&pi->lock);
    800038e6:	8526                	mv	a0,s1
    800038e8:	7db010ef          	jal	ra,800058c2 <release>
    kfree((char*)pi);
    800038ec:	8526                	mv	a0,s1
    800038ee:	f2efc0ef          	jal	ra,8000001c <kfree>
  } else
    release(&pi->lock);
}
    800038f2:	60e2                	ld	ra,24(sp)
    800038f4:	6442                	ld	s0,16(sp)
    800038f6:	64a2                	ld	s1,8(sp)
    800038f8:	6902                	ld	s2,0(sp)
    800038fa:	6105                	addi	sp,sp,32
    800038fc:	8082                	ret
    pi->readopen = 0;
    800038fe:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80003902:	21c48513          	addi	a0,s1,540
    80003906:	bb7fd0ef          	jal	ra,800014bc <wakeup>
    8000390a:	bfd9                	j	800038e0 <pipeclose+0x24>
    release(&pi->lock);
    8000390c:	8526                	mv	a0,s1
    8000390e:	7b5010ef          	jal	ra,800058c2 <release>
}
    80003912:	b7c5                	j	800038f2 <pipeclose+0x36>

0000000080003914 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80003914:	711d                	addi	sp,sp,-96
    80003916:	ec86                	sd	ra,88(sp)
    80003918:	e8a2                	sd	s0,80(sp)
    8000391a:	e4a6                	sd	s1,72(sp)
    8000391c:	e0ca                	sd	s2,64(sp)
    8000391e:	fc4e                	sd	s3,56(sp)
    80003920:	f852                	sd	s4,48(sp)
    80003922:	f456                	sd	s5,40(sp)
    80003924:	f05a                	sd	s6,32(sp)
    80003926:	ec5e                	sd	s7,24(sp)
    80003928:	e862                	sd	s8,16(sp)
    8000392a:	1080                	addi	s0,sp,96
    8000392c:	84aa                	mv	s1,a0
    8000392e:	8aae                	mv	s5,a1
    80003930:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80003932:	ce8fd0ef          	jal	ra,80000e1a <myproc>
    80003936:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80003938:	8526                	mv	a0,s1
    8000393a:	6f1010ef          	jal	ra,8000582a <acquire>
  while(i < n){
    8000393e:	09405c63          	blez	s4,800039d6 <pipewrite+0xc2>
  int i = 0;
    80003942:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003944:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80003946:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000394a:	21c48b93          	addi	s7,s1,540
    8000394e:	a81d                	j	80003984 <pipewrite+0x70>
      release(&pi->lock);
    80003950:	8526                	mv	a0,s1
    80003952:	771010ef          	jal	ra,800058c2 <release>
      return -1;
    80003956:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003958:	854a                	mv	a0,s2
    8000395a:	60e6                	ld	ra,88(sp)
    8000395c:	6446                	ld	s0,80(sp)
    8000395e:	64a6                	ld	s1,72(sp)
    80003960:	6906                	ld	s2,64(sp)
    80003962:	79e2                	ld	s3,56(sp)
    80003964:	7a42                	ld	s4,48(sp)
    80003966:	7aa2                	ld	s5,40(sp)
    80003968:	7b02                	ld	s6,32(sp)
    8000396a:	6be2                	ld	s7,24(sp)
    8000396c:	6c42                	ld	s8,16(sp)
    8000396e:	6125                	addi	sp,sp,96
    80003970:	8082                	ret
      wakeup(&pi->nread);
    80003972:	8562                	mv	a0,s8
    80003974:	b49fd0ef          	jal	ra,800014bc <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80003978:	85a6                	mv	a1,s1
    8000397a:	855e                	mv	a0,s7
    8000397c:	af5fd0ef          	jal	ra,80001470 <sleep>
  while(i < n){
    80003980:	05495c63          	bge	s2,s4,800039d8 <pipewrite+0xc4>
    if(pi->readopen == 0 || killed(pr)){
    80003984:	2204a783          	lw	a5,544(s1)
    80003988:	d7e1                	beqz	a5,80003950 <pipewrite+0x3c>
    8000398a:	854e                	mv	a0,s3
    8000398c:	d1dfd0ef          	jal	ra,800016a8 <killed>
    80003990:	f161                	bnez	a0,80003950 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80003992:	2184a783          	lw	a5,536(s1)
    80003996:	21c4a703          	lw	a4,540(s1)
    8000399a:	2007879b          	addiw	a5,a5,512
    8000399e:	fcf70ae3          	beq	a4,a5,80003972 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800039a2:	4685                	li	a3,1
    800039a4:	01590633          	add	a2,s2,s5
    800039a8:	faf40593          	addi	a1,s0,-81
    800039ac:	0509b503          	ld	a0,80(s3)
    800039b0:	8defd0ef          	jal	ra,80000a8e <copyin>
    800039b4:	03650263          	beq	a0,s6,800039d8 <pipewrite+0xc4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800039b8:	21c4a783          	lw	a5,540(s1)
    800039bc:	0017871b          	addiw	a4,a5,1
    800039c0:	20e4ae23          	sw	a4,540(s1)
    800039c4:	1ff7f793          	andi	a5,a5,511
    800039c8:	97a6                	add	a5,a5,s1
    800039ca:	faf44703          	lbu	a4,-81(s0)
    800039ce:	00e78c23          	sb	a4,24(a5)
      i++;
    800039d2:	2905                	addiw	s2,s2,1
    800039d4:	b775                	j	80003980 <pipewrite+0x6c>
  int i = 0;
    800039d6:	4901                	li	s2,0
  wakeup(&pi->nread);
    800039d8:	21848513          	addi	a0,s1,536
    800039dc:	ae1fd0ef          	jal	ra,800014bc <wakeup>
  release(&pi->lock);
    800039e0:	8526                	mv	a0,s1
    800039e2:	6e1010ef          	jal	ra,800058c2 <release>
  return i;
    800039e6:	bf8d                	j	80003958 <pipewrite+0x44>

00000000800039e8 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800039e8:	715d                	addi	sp,sp,-80
    800039ea:	e486                	sd	ra,72(sp)
    800039ec:	e0a2                	sd	s0,64(sp)
    800039ee:	fc26                	sd	s1,56(sp)
    800039f0:	f84a                	sd	s2,48(sp)
    800039f2:	f44e                	sd	s3,40(sp)
    800039f4:	f052                	sd	s4,32(sp)
    800039f6:	ec56                	sd	s5,24(sp)
    800039f8:	e85a                	sd	s6,16(sp)
    800039fa:	0880                	addi	s0,sp,80
    800039fc:	84aa                	mv	s1,a0
    800039fe:	892e                	mv	s2,a1
    80003a00:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003a02:	c18fd0ef          	jal	ra,80000e1a <myproc>
    80003a06:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80003a08:	8526                	mv	a0,s1
    80003a0a:	621010ef          	jal	ra,8000582a <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a0e:	2184a703          	lw	a4,536(s1)
    80003a12:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003a16:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a1a:	02f71363          	bne	a4,a5,80003a40 <piperead+0x58>
    80003a1e:	2244a783          	lw	a5,548(s1)
    80003a22:	cf99                	beqz	a5,80003a40 <piperead+0x58>
    if(killed(pr)){
    80003a24:	8552                	mv	a0,s4
    80003a26:	c83fd0ef          	jal	ra,800016a8 <killed>
    80003a2a:	e141                	bnez	a0,80003aaa <piperead+0xc2>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003a2c:	85a6                	mv	a1,s1
    80003a2e:	854e                	mv	a0,s3
    80003a30:	a41fd0ef          	jal	ra,80001470 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a34:	2184a703          	lw	a4,536(s1)
    80003a38:	21c4a783          	lw	a5,540(s1)
    80003a3c:	fef701e3          	beq	a4,a5,80003a1e <piperead+0x36>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a40:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003a42:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a44:	05505163          	blez	s5,80003a86 <piperead+0x9e>
    if(pi->nread == pi->nwrite)
    80003a48:	2184a783          	lw	a5,536(s1)
    80003a4c:	21c4a703          	lw	a4,540(s1)
    80003a50:	02f70b63          	beq	a4,a5,80003a86 <piperead+0x9e>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003a54:	0017871b          	addiw	a4,a5,1
    80003a58:	20e4ac23          	sw	a4,536(s1)
    80003a5c:	1ff7f793          	andi	a5,a5,511
    80003a60:	97a6                	add	a5,a5,s1
    80003a62:	0187c783          	lbu	a5,24(a5)
    80003a66:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003a6a:	4685                	li	a3,1
    80003a6c:	fbf40613          	addi	a2,s0,-65
    80003a70:	85ca                	mv	a1,s2
    80003a72:	050a3503          	ld	a0,80(s4)
    80003a76:	f61fc0ef          	jal	ra,800009d6 <copyout>
    80003a7a:	01650663          	beq	a0,s6,80003a86 <piperead+0x9e>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a7e:	2985                	addiw	s3,s3,1
    80003a80:	0905                	addi	s2,s2,1
    80003a82:	fd3a93e3          	bne	s5,s3,80003a48 <piperead+0x60>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003a86:	21c48513          	addi	a0,s1,540
    80003a8a:	a33fd0ef          	jal	ra,800014bc <wakeup>
  release(&pi->lock);
    80003a8e:	8526                	mv	a0,s1
    80003a90:	633010ef          	jal	ra,800058c2 <release>
  return i;
}
    80003a94:	854e                	mv	a0,s3
    80003a96:	60a6                	ld	ra,72(sp)
    80003a98:	6406                	ld	s0,64(sp)
    80003a9a:	74e2                	ld	s1,56(sp)
    80003a9c:	7942                	ld	s2,48(sp)
    80003a9e:	79a2                	ld	s3,40(sp)
    80003aa0:	7a02                	ld	s4,32(sp)
    80003aa2:	6ae2                	ld	s5,24(sp)
    80003aa4:	6b42                	ld	s6,16(sp)
    80003aa6:	6161                	addi	sp,sp,80
    80003aa8:	8082                	ret
      release(&pi->lock);
    80003aaa:	8526                	mv	a0,s1
    80003aac:	617010ef          	jal	ra,800058c2 <release>
      return -1;
    80003ab0:	59fd                	li	s3,-1
    80003ab2:	b7cd                	j	80003a94 <piperead+0xac>

0000000080003ab4 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003ab4:	1141                	addi	sp,sp,-16
    80003ab6:	e422                	sd	s0,8(sp)
    80003ab8:	0800                	addi	s0,sp,16
    80003aba:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003abc:	8905                	andi	a0,a0,1
    80003abe:	c111                	beqz	a0,80003ac2 <flags2perm+0xe>
      perm = PTE_X;
    80003ac0:	4521                	li	a0,8
    if(flags & 0x2)
    80003ac2:	8b89                	andi	a5,a5,2
    80003ac4:	c399                	beqz	a5,80003aca <flags2perm+0x16>
      perm |= PTE_W;
    80003ac6:	00456513          	ori	a0,a0,4
    return perm;
}
    80003aca:	6422                	ld	s0,8(sp)
    80003acc:	0141                	addi	sp,sp,16
    80003ace:	8082                	ret

0000000080003ad0 <exec>:

int
exec(char *path, char **argv)
{
    80003ad0:	de010113          	addi	sp,sp,-544
    80003ad4:	20113c23          	sd	ra,536(sp)
    80003ad8:	20813823          	sd	s0,528(sp)
    80003adc:	20913423          	sd	s1,520(sp)
    80003ae0:	21213023          	sd	s2,512(sp)
    80003ae4:	ffce                	sd	s3,504(sp)
    80003ae6:	fbd2                	sd	s4,496(sp)
    80003ae8:	f7d6                	sd	s5,488(sp)
    80003aea:	f3da                	sd	s6,480(sp)
    80003aec:	efde                	sd	s7,472(sp)
    80003aee:	ebe2                	sd	s8,464(sp)
    80003af0:	e7e6                	sd	s9,456(sp)
    80003af2:	e3ea                	sd	s10,448(sp)
    80003af4:	ff6e                	sd	s11,440(sp)
    80003af6:	1400                	addi	s0,sp,544
    80003af8:	892a                	mv	s2,a0
    80003afa:	dea43423          	sd	a0,-536(s0)
    80003afe:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003b02:	b18fd0ef          	jal	ra,80000e1a <myproc>
    80003b06:	84aa                	mv	s1,a0

  begin_op();
    80003b08:	e0aff0ef          	jal	ra,80003112 <begin_op>

  if((ip = namei(path)) == 0){
    80003b0c:	854a                	mv	a0,s2
    80003b0e:	c28ff0ef          	jal	ra,80002f36 <namei>
    80003b12:	c13d                	beqz	a0,80003b78 <exec+0xa8>
    80003b14:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80003b16:	d6ffe0ef          	jal	ra,80002884 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80003b1a:	04000713          	li	a4,64
    80003b1e:	4681                	li	a3,0
    80003b20:	e5040613          	addi	a2,s0,-432
    80003b24:	4581                	li	a1,0
    80003b26:	8556                	mv	a0,s5
    80003b28:	fadfe0ef          	jal	ra,80002ad4 <readi>
    80003b2c:	04000793          	li	a5,64
    80003b30:	00f51a63          	bne	a0,a5,80003b44 <exec+0x74>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003b34:	e5042703          	lw	a4,-432(s0)
    80003b38:	464c47b7          	lui	a5,0x464c4
    80003b3c:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003b40:	04f70063          	beq	a4,a5,80003b80 <exec+0xb0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003b44:	8556                	mv	a0,s5
    80003b46:	f45fe0ef          	jal	ra,80002a8a <iunlockput>
    end_op();
    80003b4a:	e38ff0ef          	jal	ra,80003182 <end_op>
  }
  return -1;
    80003b4e:	557d                	li	a0,-1
}
    80003b50:	21813083          	ld	ra,536(sp)
    80003b54:	21013403          	ld	s0,528(sp)
    80003b58:	20813483          	ld	s1,520(sp)
    80003b5c:	20013903          	ld	s2,512(sp)
    80003b60:	79fe                	ld	s3,504(sp)
    80003b62:	7a5e                	ld	s4,496(sp)
    80003b64:	7abe                	ld	s5,488(sp)
    80003b66:	7b1e                	ld	s6,480(sp)
    80003b68:	6bfe                	ld	s7,472(sp)
    80003b6a:	6c5e                	ld	s8,464(sp)
    80003b6c:	6cbe                	ld	s9,456(sp)
    80003b6e:	6d1e                	ld	s10,448(sp)
    80003b70:	7dfa                	ld	s11,440(sp)
    80003b72:	22010113          	addi	sp,sp,544
    80003b76:	8082                	ret
    end_op();
    80003b78:	e0aff0ef          	jal	ra,80003182 <end_op>
    return -1;
    80003b7c:	557d                	li	a0,-1
    80003b7e:	bfc9                	j	80003b50 <exec+0x80>
  if((pagetable = proc_pagetable(p)) == 0)
    80003b80:	8526                	mv	a0,s1
    80003b82:	b40fd0ef          	jal	ra,80000ec2 <proc_pagetable>
    80003b86:	8b2a                	mv	s6,a0
    80003b88:	dd55                	beqz	a0,80003b44 <exec+0x74>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003b8a:	e7042783          	lw	a5,-400(s0)
    80003b8e:	e8845703          	lhu	a4,-376(s0)
    80003b92:	c325                	beqz	a4,80003bf2 <exec+0x122>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003b94:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003b96:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80003b9a:	6a05                	lui	s4,0x1
    80003b9c:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80003ba0:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    80003ba4:	6d85                	lui	s11,0x1
    80003ba6:	7d7d                	lui	s10,0xfffff
    80003ba8:	ac21                	j	80003dc0 <exec+0x2f0>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80003baa:	00004517          	auipc	a0,0x4
    80003bae:	b9e50513          	addi	a0,a0,-1122 # 80007748 <syscalls+0x2f0>
    80003bb2:	165010ef          	jal	ra,80005516 <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003bb6:	874a                	mv	a4,s2
    80003bb8:	009c86bb          	addw	a3,s9,s1
    80003bbc:	4581                	li	a1,0
    80003bbe:	8556                	mv	a0,s5
    80003bc0:	f15fe0ef          	jal	ra,80002ad4 <readi>
    80003bc4:	2501                	sext.w	a0,a0
    80003bc6:	18a91c63          	bne	s2,a0,80003d5e <exec+0x28e>
  for(i = 0; i < sz; i += PGSIZE){
    80003bca:	009d84bb          	addw	s1,s11,s1
    80003bce:	013d09bb          	addw	s3,s10,s3
    80003bd2:	1d74f763          	bgeu	s1,s7,80003da0 <exec+0x2d0>
    pa = walkaddr(pagetable, va + i);
    80003bd6:	02049593          	slli	a1,s1,0x20
    80003bda:	9181                	srli	a1,a1,0x20
    80003bdc:	95e2                	add	a1,a1,s8
    80003bde:	855a                	mv	a0,s6
    80003be0:	88bfc0ef          	jal	ra,8000046a <walkaddr>
    80003be4:	862a                	mv	a2,a0
    if(pa == 0)
    80003be6:	d171                	beqz	a0,80003baa <exec+0xda>
      n = PGSIZE;
    80003be8:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80003bea:	fd49f6e3          	bgeu	s3,s4,80003bb6 <exec+0xe6>
      n = sz - i;
    80003bee:	894e                	mv	s2,s3
    80003bf0:	b7d9                	j	80003bb6 <exec+0xe6>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003bf2:	4901                	li	s2,0
  iunlockput(ip);
    80003bf4:	8556                	mv	a0,s5
    80003bf6:	e95fe0ef          	jal	ra,80002a8a <iunlockput>
  end_op();
    80003bfa:	d88ff0ef          	jal	ra,80003182 <end_op>
  p = myproc();
    80003bfe:	a1cfd0ef          	jal	ra,80000e1a <myproc>
    80003c02:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    80003c04:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003c08:	6785                	lui	a5,0x1
    80003c0a:	17fd                	addi	a5,a5,-1
    80003c0c:	993e                	add	s2,s2,a5
    80003c0e:	77fd                	lui	a5,0xfffff
    80003c10:	00f977b3          	and	a5,s2,a5
    80003c14:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003c18:	4691                	li	a3,4
    80003c1a:	6609                	lui	a2,0x2
    80003c1c:	963e                	add	a2,a2,a5
    80003c1e:	85be                	mv	a1,a5
    80003c20:	855a                	mv	a0,s6
    80003c22:	bb1fc0ef          	jal	ra,800007d2 <uvmalloc>
    80003c26:	8c2a                	mv	s8,a0
  ip = 0;
    80003c28:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003c2a:	12050a63          	beqz	a0,80003d5e <exec+0x28e>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003c2e:	75f9                	lui	a1,0xffffe
    80003c30:	95aa                	add	a1,a1,a0
    80003c32:	855a                	mv	a0,s6
    80003c34:	d79fc0ef          	jal	ra,800009ac <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003c38:	7afd                	lui	s5,0xfffff
    80003c3a:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80003c3c:	df043783          	ld	a5,-528(s0)
    80003c40:	6388                	ld	a0,0(a5)
    80003c42:	c135                	beqz	a0,80003ca6 <exec+0x1d6>
    80003c44:	e9040993          	addi	s3,s0,-368
    80003c48:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80003c4c:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80003c4e:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80003c50:	e74fc0ef          	jal	ra,800002c4 <strlen>
    80003c54:	0015079b          	addiw	a5,a0,1
    80003c58:	40f90933          	sub	s2,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003c5c:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    80003c60:	13596463          	bltu	s2,s5,80003d88 <exec+0x2b8>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003c64:	df043d83          	ld	s11,-528(s0)
    80003c68:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80003c6c:	8552                	mv	a0,s4
    80003c6e:	e56fc0ef          	jal	ra,800002c4 <strlen>
    80003c72:	0015069b          	addiw	a3,a0,1
    80003c76:	8652                	mv	a2,s4
    80003c78:	85ca                	mv	a1,s2
    80003c7a:	855a                	mv	a0,s6
    80003c7c:	d5bfc0ef          	jal	ra,800009d6 <copyout>
    80003c80:	10054863          	bltz	a0,80003d90 <exec+0x2c0>
    ustack[argc] = sp;
    80003c84:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80003c88:	0485                	addi	s1,s1,1
    80003c8a:	008d8793          	addi	a5,s11,8
    80003c8e:	def43823          	sd	a5,-528(s0)
    80003c92:	008db503          	ld	a0,8(s11)
    80003c96:	c911                	beqz	a0,80003caa <exec+0x1da>
    if(argc >= MAXARG)
    80003c98:	09a1                	addi	s3,s3,8
    80003c9a:	fb3c9be3          	bne	s9,s3,80003c50 <exec+0x180>
  sz = sz1;
    80003c9e:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003ca2:	4a81                	li	s5,0
    80003ca4:	a86d                	j	80003d5e <exec+0x28e>
  sp = sz;
    80003ca6:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80003ca8:	4481                	li	s1,0
  ustack[argc] = 0;
    80003caa:	00349793          	slli	a5,s1,0x3
    80003cae:	f9040713          	addi	a4,s0,-112
    80003cb2:	97ba                	add	a5,a5,a4
    80003cb4:	f007b023          	sd	zero,-256(a5) # ffffffffffffef00 <end+0xffffffff7ffde020>
  sp -= (argc+1) * sizeof(uint64);
    80003cb8:	00148693          	addi	a3,s1,1
    80003cbc:	068e                	slli	a3,a3,0x3
    80003cbe:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003cc2:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80003cc6:	01597663          	bgeu	s2,s5,80003cd2 <exec+0x202>
  sz = sz1;
    80003cca:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003cce:	4a81                	li	s5,0
    80003cd0:	a079                	j	80003d5e <exec+0x28e>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003cd2:	e9040613          	addi	a2,s0,-368
    80003cd6:	85ca                	mv	a1,s2
    80003cd8:	855a                	mv	a0,s6
    80003cda:	cfdfc0ef          	jal	ra,800009d6 <copyout>
    80003cde:	0a054d63          	bltz	a0,80003d98 <exec+0x2c8>
  p->trapframe->a1 = sp;
    80003ce2:	058bb783          	ld	a5,88(s7) # 1058 <_entry-0x7fffefa8>
    80003ce6:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003cea:	de843783          	ld	a5,-536(s0)
    80003cee:	0007c703          	lbu	a4,0(a5)
    80003cf2:	cf11                	beqz	a4,80003d0e <exec+0x23e>
    80003cf4:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003cf6:	02f00693          	li	a3,47
    80003cfa:	a039                	j	80003d08 <exec+0x238>
      last = s+1;
    80003cfc:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    80003d00:	0785                	addi	a5,a5,1
    80003d02:	fff7c703          	lbu	a4,-1(a5)
    80003d06:	c701                	beqz	a4,80003d0e <exec+0x23e>
    if(*s == '/')
    80003d08:	fed71ce3          	bne	a4,a3,80003d00 <exec+0x230>
    80003d0c:	bfc5                	j	80003cfc <exec+0x22c>
  safestrcpy(p->name, last, sizeof(p->name));
    80003d0e:	4641                	li	a2,16
    80003d10:	de843583          	ld	a1,-536(s0)
    80003d14:	160b8513          	addi	a0,s7,352
    80003d18:	d7afc0ef          	jal	ra,80000292 <safestrcpy>
  oldpagetable = p->pagetable;
    80003d1c:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    80003d20:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    80003d24:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003d28:	058bb783          	ld	a5,88(s7)
    80003d2c:	e6843703          	ld	a4,-408(s0)
    80003d30:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003d32:	058bb783          	ld	a5,88(s7)
    80003d36:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003d3a:	85ea                	mv	a1,s10
    80003d3c:	a54fd0ef          	jal	ra,80000f90 <proc_freepagetable>
  if(p->pid == 1){
    80003d40:	030ba703          	lw	a4,48(s7)
    80003d44:	4785                	li	a5,1
    80003d46:	00f70563          	beq	a4,a5,80003d50 <exec+0x280>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003d4a:	0004851b          	sext.w	a0,s1
    80003d4e:	b509                	j	80003b50 <exec+0x80>
    vmprint(p->pagetable);
    80003d50:	050bb503          	ld	a0,80(s7)
    80003d54:	f2bfc0ef          	jal	ra,80000c7e <vmprint>
    80003d58:	bfcd                	j	80003d4a <exec+0x27a>
    80003d5a:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003d5e:	df843583          	ld	a1,-520(s0)
    80003d62:	855a                	mv	a0,s6
    80003d64:	a2cfd0ef          	jal	ra,80000f90 <proc_freepagetable>
  if(ip){
    80003d68:	dc0a9ee3          	bnez	s5,80003b44 <exec+0x74>
  return -1;
    80003d6c:	557d                	li	a0,-1
    80003d6e:	b3cd                	j	80003b50 <exec+0x80>
    80003d70:	df243c23          	sd	s2,-520(s0)
    80003d74:	b7ed                	j	80003d5e <exec+0x28e>
    80003d76:	df243c23          	sd	s2,-520(s0)
    80003d7a:	b7d5                	j	80003d5e <exec+0x28e>
    80003d7c:	df243c23          	sd	s2,-520(s0)
    80003d80:	bff9                	j	80003d5e <exec+0x28e>
    80003d82:	df243c23          	sd	s2,-520(s0)
    80003d86:	bfe1                	j	80003d5e <exec+0x28e>
  sz = sz1;
    80003d88:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003d8c:	4a81                	li	s5,0
    80003d8e:	bfc1                	j	80003d5e <exec+0x28e>
  sz = sz1;
    80003d90:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003d94:	4a81                	li	s5,0
    80003d96:	b7e1                	j	80003d5e <exec+0x28e>
  sz = sz1;
    80003d98:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003d9c:	4a81                	li	s5,0
    80003d9e:	b7c1                	j	80003d5e <exec+0x28e>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003da0:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003da4:	e0843783          	ld	a5,-504(s0)
    80003da8:	0017869b          	addiw	a3,a5,1
    80003dac:	e0d43423          	sd	a3,-504(s0)
    80003db0:	e0043783          	ld	a5,-512(s0)
    80003db4:	0387879b          	addiw	a5,a5,56
    80003db8:	e8845703          	lhu	a4,-376(s0)
    80003dbc:	e2e6dce3          	bge	a3,a4,80003bf4 <exec+0x124>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003dc0:	2781                	sext.w	a5,a5
    80003dc2:	e0f43023          	sd	a5,-512(s0)
    80003dc6:	03800713          	li	a4,56
    80003dca:	86be                	mv	a3,a5
    80003dcc:	e1840613          	addi	a2,s0,-488
    80003dd0:	4581                	li	a1,0
    80003dd2:	8556                	mv	a0,s5
    80003dd4:	d01fe0ef          	jal	ra,80002ad4 <readi>
    80003dd8:	03800793          	li	a5,56
    80003ddc:	f6f51fe3          	bne	a0,a5,80003d5a <exec+0x28a>
    if(ph.type != ELF_PROG_LOAD)
    80003de0:	e1842783          	lw	a5,-488(s0)
    80003de4:	4705                	li	a4,1
    80003de6:	fae79fe3          	bne	a5,a4,80003da4 <exec+0x2d4>
    if(ph.memsz < ph.filesz)
    80003dea:	e4043483          	ld	s1,-448(s0)
    80003dee:	e3843783          	ld	a5,-456(s0)
    80003df2:	f6f4efe3          	bltu	s1,a5,80003d70 <exec+0x2a0>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003df6:	e2843783          	ld	a5,-472(s0)
    80003dfa:	94be                	add	s1,s1,a5
    80003dfc:	f6f4ede3          	bltu	s1,a5,80003d76 <exec+0x2a6>
    if(ph.vaddr % PGSIZE != 0)
    80003e00:	de043703          	ld	a4,-544(s0)
    80003e04:	8ff9                	and	a5,a5,a4
    80003e06:	fbbd                	bnez	a5,80003d7c <exec+0x2ac>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003e08:	e1c42503          	lw	a0,-484(s0)
    80003e0c:	ca9ff0ef          	jal	ra,80003ab4 <flags2perm>
    80003e10:	86aa                	mv	a3,a0
    80003e12:	8626                	mv	a2,s1
    80003e14:	85ca                	mv	a1,s2
    80003e16:	855a                	mv	a0,s6
    80003e18:	9bbfc0ef          	jal	ra,800007d2 <uvmalloc>
    80003e1c:	dea43c23          	sd	a0,-520(s0)
    80003e20:	d12d                	beqz	a0,80003d82 <exec+0x2b2>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003e22:	e2843c03          	ld	s8,-472(s0)
    80003e26:	e2042c83          	lw	s9,-480(s0)
    80003e2a:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003e2e:	f60b89e3          	beqz	s7,80003da0 <exec+0x2d0>
    80003e32:	89de                	mv	s3,s7
    80003e34:	4481                	li	s1,0
    80003e36:	b345                	j	80003bd6 <exec+0x106>

0000000080003e38 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003e38:	7179                	addi	sp,sp,-48
    80003e3a:	f406                	sd	ra,40(sp)
    80003e3c:	f022                	sd	s0,32(sp)
    80003e3e:	ec26                	sd	s1,24(sp)
    80003e40:	e84a                	sd	s2,16(sp)
    80003e42:	1800                	addi	s0,sp,48
    80003e44:	892e                	mv	s2,a1
    80003e46:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003e48:	fdc40593          	addi	a1,s0,-36
    80003e4c:	f07fd0ef          	jal	ra,80001d52 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003e50:	fdc42703          	lw	a4,-36(s0)
    80003e54:	47bd                	li	a5,15
    80003e56:	02e7e963          	bltu	a5,a4,80003e88 <argfd+0x50>
    80003e5a:	fc1fc0ef          	jal	ra,80000e1a <myproc>
    80003e5e:	fdc42703          	lw	a4,-36(s0)
    80003e62:	01a70793          	addi	a5,a4,26
    80003e66:	078e                	slli	a5,a5,0x3
    80003e68:	953e                	add	a0,a0,a5
    80003e6a:	651c                	ld	a5,8(a0)
    80003e6c:	c385                	beqz	a5,80003e8c <argfd+0x54>
    return -1;
  if(pfd)
    80003e6e:	00090463          	beqz	s2,80003e76 <argfd+0x3e>
    *pfd = fd;
    80003e72:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003e76:	4501                	li	a0,0
  if(pf)
    80003e78:	c091                	beqz	s1,80003e7c <argfd+0x44>
    *pf = f;
    80003e7a:	e09c                	sd	a5,0(s1)
}
    80003e7c:	70a2                	ld	ra,40(sp)
    80003e7e:	7402                	ld	s0,32(sp)
    80003e80:	64e2                	ld	s1,24(sp)
    80003e82:	6942                	ld	s2,16(sp)
    80003e84:	6145                	addi	sp,sp,48
    80003e86:	8082                	ret
    return -1;
    80003e88:	557d                	li	a0,-1
    80003e8a:	bfcd                	j	80003e7c <argfd+0x44>
    80003e8c:	557d                	li	a0,-1
    80003e8e:	b7fd                	j	80003e7c <argfd+0x44>

0000000080003e90 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003e90:	1101                	addi	sp,sp,-32
    80003e92:	ec06                	sd	ra,24(sp)
    80003e94:	e822                	sd	s0,16(sp)
    80003e96:	e426                	sd	s1,8(sp)
    80003e98:	1000                	addi	s0,sp,32
    80003e9a:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003e9c:	f7ffc0ef          	jal	ra,80000e1a <myproc>
    80003ea0:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003ea2:	0d850793          	addi	a5,a0,216
    80003ea6:	4501                	li	a0,0
    80003ea8:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003eaa:	6398                	ld	a4,0(a5)
    80003eac:	cb19                	beqz	a4,80003ec2 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003eae:	2505                	addiw	a0,a0,1
    80003eb0:	07a1                	addi	a5,a5,8
    80003eb2:	fed51ce3          	bne	a0,a3,80003eaa <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003eb6:	557d                	li	a0,-1
}
    80003eb8:	60e2                	ld	ra,24(sp)
    80003eba:	6442                	ld	s0,16(sp)
    80003ebc:	64a2                	ld	s1,8(sp)
    80003ebe:	6105                	addi	sp,sp,32
    80003ec0:	8082                	ret
      p->ofile[fd] = f;
    80003ec2:	01a50793          	addi	a5,a0,26
    80003ec6:	078e                	slli	a5,a5,0x3
    80003ec8:	963e                	add	a2,a2,a5
    80003eca:	e604                	sd	s1,8(a2)
      return fd;
    80003ecc:	b7f5                	j	80003eb8 <fdalloc+0x28>

0000000080003ece <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003ece:	715d                	addi	sp,sp,-80
    80003ed0:	e486                	sd	ra,72(sp)
    80003ed2:	e0a2                	sd	s0,64(sp)
    80003ed4:	fc26                	sd	s1,56(sp)
    80003ed6:	f84a                	sd	s2,48(sp)
    80003ed8:	f44e                	sd	s3,40(sp)
    80003eda:	f052                	sd	s4,32(sp)
    80003edc:	ec56                	sd	s5,24(sp)
    80003ede:	e85a                	sd	s6,16(sp)
    80003ee0:	0880                	addi	s0,sp,80
    80003ee2:	8b2e                	mv	s6,a1
    80003ee4:	89b2                	mv	s3,a2
    80003ee6:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003ee8:	fb040593          	addi	a1,s0,-80
    80003eec:	864ff0ef          	jal	ra,80002f50 <nameiparent>
    80003ef0:	84aa                	mv	s1,a0
    80003ef2:	10050b63          	beqz	a0,80004008 <create+0x13a>
    return 0;

  ilock(dp);
    80003ef6:	98ffe0ef          	jal	ra,80002884 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003efa:	4601                	li	a2,0
    80003efc:	fb040593          	addi	a1,s0,-80
    80003f00:	8526                	mv	a0,s1
    80003f02:	dcffe0ef          	jal	ra,80002cd0 <dirlookup>
    80003f06:	8aaa                	mv	s5,a0
    80003f08:	c521                	beqz	a0,80003f50 <create+0x82>
    iunlockput(dp);
    80003f0a:	8526                	mv	a0,s1
    80003f0c:	b7ffe0ef          	jal	ra,80002a8a <iunlockput>
    ilock(ip);
    80003f10:	8556                	mv	a0,s5
    80003f12:	973fe0ef          	jal	ra,80002884 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003f16:	000b059b          	sext.w	a1,s6
    80003f1a:	4789                	li	a5,2
    80003f1c:	02f59563          	bne	a1,a5,80003f46 <create+0x78>
    80003f20:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffde164>
    80003f24:	37f9                	addiw	a5,a5,-2
    80003f26:	17c2                	slli	a5,a5,0x30
    80003f28:	93c1                	srli	a5,a5,0x30
    80003f2a:	4705                	li	a4,1
    80003f2c:	00f76d63          	bltu	a4,a5,80003f46 <create+0x78>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003f30:	8556                	mv	a0,s5
    80003f32:	60a6                	ld	ra,72(sp)
    80003f34:	6406                	ld	s0,64(sp)
    80003f36:	74e2                	ld	s1,56(sp)
    80003f38:	7942                	ld	s2,48(sp)
    80003f3a:	79a2                	ld	s3,40(sp)
    80003f3c:	7a02                	ld	s4,32(sp)
    80003f3e:	6ae2                	ld	s5,24(sp)
    80003f40:	6b42                	ld	s6,16(sp)
    80003f42:	6161                	addi	sp,sp,80
    80003f44:	8082                	ret
    iunlockput(ip);
    80003f46:	8556                	mv	a0,s5
    80003f48:	b43fe0ef          	jal	ra,80002a8a <iunlockput>
    return 0;
    80003f4c:	4a81                	li	s5,0
    80003f4e:	b7cd                	j	80003f30 <create+0x62>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003f50:	85da                	mv	a1,s6
    80003f52:	4088                	lw	a0,0(s1)
    80003f54:	fc8fe0ef          	jal	ra,8000271c <ialloc>
    80003f58:	8a2a                	mv	s4,a0
    80003f5a:	cd1d                	beqz	a0,80003f98 <create+0xca>
  ilock(ip);
    80003f5c:	929fe0ef          	jal	ra,80002884 <ilock>
  ip->major = major;
    80003f60:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80003f64:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80003f68:	4905                	li	s2,1
    80003f6a:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80003f6e:	8552                	mv	a0,s4
    80003f70:	863fe0ef          	jal	ra,800027d2 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80003f74:	000b059b          	sext.w	a1,s6
    80003f78:	03258563          	beq	a1,s2,80003fa2 <create+0xd4>
  if(dirlink(dp, name, ip->inum) < 0)
    80003f7c:	004a2603          	lw	a2,4(s4)
    80003f80:	fb040593          	addi	a1,s0,-80
    80003f84:	8526                	mv	a0,s1
    80003f86:	f17fe0ef          	jal	ra,80002e9c <dirlink>
    80003f8a:	06054363          	bltz	a0,80003ff0 <create+0x122>
  iunlockput(dp);
    80003f8e:	8526                	mv	a0,s1
    80003f90:	afbfe0ef          	jal	ra,80002a8a <iunlockput>
  return ip;
    80003f94:	8ad2                	mv	s5,s4
    80003f96:	bf69                	j	80003f30 <create+0x62>
    iunlockput(dp);
    80003f98:	8526                	mv	a0,s1
    80003f9a:	af1fe0ef          	jal	ra,80002a8a <iunlockput>
    return 0;
    80003f9e:	8ad2                	mv	s5,s4
    80003fa0:	bf41                	j	80003f30 <create+0x62>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80003fa2:	004a2603          	lw	a2,4(s4)
    80003fa6:	00003597          	auipc	a1,0x3
    80003faa:	7c258593          	addi	a1,a1,1986 # 80007768 <syscalls+0x310>
    80003fae:	8552                	mv	a0,s4
    80003fb0:	eedfe0ef          	jal	ra,80002e9c <dirlink>
    80003fb4:	02054e63          	bltz	a0,80003ff0 <create+0x122>
    80003fb8:	40d0                	lw	a2,4(s1)
    80003fba:	00003597          	auipc	a1,0x3
    80003fbe:	7b658593          	addi	a1,a1,1974 # 80007770 <syscalls+0x318>
    80003fc2:	8552                	mv	a0,s4
    80003fc4:	ed9fe0ef          	jal	ra,80002e9c <dirlink>
    80003fc8:	02054463          	bltz	a0,80003ff0 <create+0x122>
  if(dirlink(dp, name, ip->inum) < 0)
    80003fcc:	004a2603          	lw	a2,4(s4)
    80003fd0:	fb040593          	addi	a1,s0,-80
    80003fd4:	8526                	mv	a0,s1
    80003fd6:	ec7fe0ef          	jal	ra,80002e9c <dirlink>
    80003fda:	00054b63          	bltz	a0,80003ff0 <create+0x122>
    dp->nlink++;  // for ".."
    80003fde:	04a4d783          	lhu	a5,74(s1)
    80003fe2:	2785                	addiw	a5,a5,1
    80003fe4:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80003fe8:	8526                	mv	a0,s1
    80003fea:	fe8fe0ef          	jal	ra,800027d2 <iupdate>
    80003fee:	b745                	j	80003f8e <create+0xc0>
  ip->nlink = 0;
    80003ff0:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80003ff4:	8552                	mv	a0,s4
    80003ff6:	fdcfe0ef          	jal	ra,800027d2 <iupdate>
  iunlockput(ip);
    80003ffa:	8552                	mv	a0,s4
    80003ffc:	a8ffe0ef          	jal	ra,80002a8a <iunlockput>
  iunlockput(dp);
    80004000:	8526                	mv	a0,s1
    80004002:	a89fe0ef          	jal	ra,80002a8a <iunlockput>
  return 0;
    80004006:	b72d                	j	80003f30 <create+0x62>
    return 0;
    80004008:	8aaa                	mv	s5,a0
    8000400a:	b71d                	j	80003f30 <create+0x62>

000000008000400c <sys_dup>:
{
    8000400c:	7179                	addi	sp,sp,-48
    8000400e:	f406                	sd	ra,40(sp)
    80004010:	f022                	sd	s0,32(sp)
    80004012:	ec26                	sd	s1,24(sp)
    80004014:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004016:	fd840613          	addi	a2,s0,-40
    8000401a:	4581                	li	a1,0
    8000401c:	4501                	li	a0,0
    8000401e:	e1bff0ef          	jal	ra,80003e38 <argfd>
    return -1;
    80004022:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004024:	00054f63          	bltz	a0,80004042 <sys_dup+0x36>
  if((fd=fdalloc(f)) < 0)
    80004028:	fd843503          	ld	a0,-40(s0)
    8000402c:	e65ff0ef          	jal	ra,80003e90 <fdalloc>
    80004030:	84aa                	mv	s1,a0
    return -1;
    80004032:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004034:	00054763          	bltz	a0,80004042 <sys_dup+0x36>
  filedup(f);
    80004038:	fd843503          	ld	a0,-40(s0)
    8000403c:	cacff0ef          	jal	ra,800034e8 <filedup>
  return fd;
    80004040:	87a6                	mv	a5,s1
}
    80004042:	853e                	mv	a0,a5
    80004044:	70a2                	ld	ra,40(sp)
    80004046:	7402                	ld	s0,32(sp)
    80004048:	64e2                	ld	s1,24(sp)
    8000404a:	6145                	addi	sp,sp,48
    8000404c:	8082                	ret

000000008000404e <sys_read>:
{
    8000404e:	7179                	addi	sp,sp,-48
    80004050:	f406                	sd	ra,40(sp)
    80004052:	f022                	sd	s0,32(sp)
    80004054:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004056:	fd840593          	addi	a1,s0,-40
    8000405a:	4505                	li	a0,1
    8000405c:	d13fd0ef          	jal	ra,80001d6e <argaddr>
  argint(2, &n);
    80004060:	fe440593          	addi	a1,s0,-28
    80004064:	4509                	li	a0,2
    80004066:	cedfd0ef          	jal	ra,80001d52 <argint>
  if(argfd(0, 0, &f) < 0)
    8000406a:	fe840613          	addi	a2,s0,-24
    8000406e:	4581                	li	a1,0
    80004070:	4501                	li	a0,0
    80004072:	dc7ff0ef          	jal	ra,80003e38 <argfd>
    80004076:	87aa                	mv	a5,a0
    return -1;
    80004078:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000407a:	0007ca63          	bltz	a5,8000408e <sys_read+0x40>
  return fileread(f, p, n);
    8000407e:	fe442603          	lw	a2,-28(s0)
    80004082:	fd843583          	ld	a1,-40(s0)
    80004086:	fe843503          	ld	a0,-24(s0)
    8000408a:	daaff0ef          	jal	ra,80003634 <fileread>
}
    8000408e:	70a2                	ld	ra,40(sp)
    80004090:	7402                	ld	s0,32(sp)
    80004092:	6145                	addi	sp,sp,48
    80004094:	8082                	ret

0000000080004096 <sys_write>:
{
    80004096:	7179                	addi	sp,sp,-48
    80004098:	f406                	sd	ra,40(sp)
    8000409a:	f022                	sd	s0,32(sp)
    8000409c:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000409e:	fd840593          	addi	a1,s0,-40
    800040a2:	4505                	li	a0,1
    800040a4:	ccbfd0ef          	jal	ra,80001d6e <argaddr>
  argint(2, &n);
    800040a8:	fe440593          	addi	a1,s0,-28
    800040ac:	4509                	li	a0,2
    800040ae:	ca5fd0ef          	jal	ra,80001d52 <argint>
  if(argfd(0, 0, &f) < 0)
    800040b2:	fe840613          	addi	a2,s0,-24
    800040b6:	4581                	li	a1,0
    800040b8:	4501                	li	a0,0
    800040ba:	d7fff0ef          	jal	ra,80003e38 <argfd>
    800040be:	87aa                	mv	a5,a0
    return -1;
    800040c0:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800040c2:	0007ca63          	bltz	a5,800040d6 <sys_write+0x40>
  return filewrite(f, p, n);
    800040c6:	fe442603          	lw	a2,-28(s0)
    800040ca:	fd843583          	ld	a1,-40(s0)
    800040ce:	fe843503          	ld	a0,-24(s0)
    800040d2:	e10ff0ef          	jal	ra,800036e2 <filewrite>
}
    800040d6:	70a2                	ld	ra,40(sp)
    800040d8:	7402                	ld	s0,32(sp)
    800040da:	6145                	addi	sp,sp,48
    800040dc:	8082                	ret

00000000800040de <sys_close>:
{
    800040de:	1101                	addi	sp,sp,-32
    800040e0:	ec06                	sd	ra,24(sp)
    800040e2:	e822                	sd	s0,16(sp)
    800040e4:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800040e6:	fe040613          	addi	a2,s0,-32
    800040ea:	fec40593          	addi	a1,s0,-20
    800040ee:	4501                	li	a0,0
    800040f0:	d49ff0ef          	jal	ra,80003e38 <argfd>
    return -1;
    800040f4:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800040f6:	02054063          	bltz	a0,80004116 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    800040fa:	d21fc0ef          	jal	ra,80000e1a <myproc>
    800040fe:	fec42783          	lw	a5,-20(s0)
    80004102:	07e9                	addi	a5,a5,26
    80004104:	078e                	slli	a5,a5,0x3
    80004106:	97aa                	add	a5,a5,a0
    80004108:	0007b423          	sd	zero,8(a5)
  fileclose(f);
    8000410c:	fe043503          	ld	a0,-32(s0)
    80004110:	c1eff0ef          	jal	ra,8000352e <fileclose>
  return 0;
    80004114:	4781                	li	a5,0
}
    80004116:	853e                	mv	a0,a5
    80004118:	60e2                	ld	ra,24(sp)
    8000411a:	6442                	ld	s0,16(sp)
    8000411c:	6105                	addi	sp,sp,32
    8000411e:	8082                	ret

0000000080004120 <sys_fstat>:
{
    80004120:	1101                	addi	sp,sp,-32
    80004122:	ec06                	sd	ra,24(sp)
    80004124:	e822                	sd	s0,16(sp)
    80004126:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004128:	fe040593          	addi	a1,s0,-32
    8000412c:	4505                	li	a0,1
    8000412e:	c41fd0ef          	jal	ra,80001d6e <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004132:	fe840613          	addi	a2,s0,-24
    80004136:	4581                	li	a1,0
    80004138:	4501                	li	a0,0
    8000413a:	cffff0ef          	jal	ra,80003e38 <argfd>
    8000413e:	87aa                	mv	a5,a0
    return -1;
    80004140:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004142:	0007c863          	bltz	a5,80004152 <sys_fstat+0x32>
  return filestat(f, st);
    80004146:	fe043583          	ld	a1,-32(s0)
    8000414a:	fe843503          	ld	a0,-24(s0)
    8000414e:	c88ff0ef          	jal	ra,800035d6 <filestat>
}
    80004152:	60e2                	ld	ra,24(sp)
    80004154:	6442                	ld	s0,16(sp)
    80004156:	6105                	addi	sp,sp,32
    80004158:	8082                	ret

000000008000415a <sys_link>:
{
    8000415a:	7169                	addi	sp,sp,-304
    8000415c:	f606                	sd	ra,296(sp)
    8000415e:	f222                	sd	s0,288(sp)
    80004160:	ee26                	sd	s1,280(sp)
    80004162:	ea4a                	sd	s2,272(sp)
    80004164:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004166:	08000613          	li	a2,128
    8000416a:	ed040593          	addi	a1,s0,-304
    8000416e:	4501                	li	a0,0
    80004170:	c1bfd0ef          	jal	ra,80001d8a <argstr>
    return -1;
    80004174:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004176:	0c054663          	bltz	a0,80004242 <sys_link+0xe8>
    8000417a:	08000613          	li	a2,128
    8000417e:	f5040593          	addi	a1,s0,-176
    80004182:	4505                	li	a0,1
    80004184:	c07fd0ef          	jal	ra,80001d8a <argstr>
    return -1;
    80004188:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000418a:	0a054c63          	bltz	a0,80004242 <sys_link+0xe8>
  begin_op();
    8000418e:	f85fe0ef          	jal	ra,80003112 <begin_op>
  if((ip = namei(old)) == 0){
    80004192:	ed040513          	addi	a0,s0,-304
    80004196:	da1fe0ef          	jal	ra,80002f36 <namei>
    8000419a:	84aa                	mv	s1,a0
    8000419c:	c525                	beqz	a0,80004204 <sys_link+0xaa>
  ilock(ip);
    8000419e:	ee6fe0ef          	jal	ra,80002884 <ilock>
  if(ip->type == T_DIR){
    800041a2:	04449703          	lh	a4,68(s1)
    800041a6:	4785                	li	a5,1
    800041a8:	06f70263          	beq	a4,a5,8000420c <sys_link+0xb2>
  ip->nlink++;
    800041ac:	04a4d783          	lhu	a5,74(s1)
    800041b0:	2785                	addiw	a5,a5,1
    800041b2:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800041b6:	8526                	mv	a0,s1
    800041b8:	e1afe0ef          	jal	ra,800027d2 <iupdate>
  iunlock(ip);
    800041bc:	8526                	mv	a0,s1
    800041be:	f70fe0ef          	jal	ra,8000292e <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800041c2:	fd040593          	addi	a1,s0,-48
    800041c6:	f5040513          	addi	a0,s0,-176
    800041ca:	d87fe0ef          	jal	ra,80002f50 <nameiparent>
    800041ce:	892a                	mv	s2,a0
    800041d0:	c921                	beqz	a0,80004220 <sys_link+0xc6>
  ilock(dp);
    800041d2:	eb2fe0ef          	jal	ra,80002884 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800041d6:	00092703          	lw	a4,0(s2)
    800041da:	409c                	lw	a5,0(s1)
    800041dc:	02f71f63          	bne	a4,a5,8000421a <sys_link+0xc0>
    800041e0:	40d0                	lw	a2,4(s1)
    800041e2:	fd040593          	addi	a1,s0,-48
    800041e6:	854a                	mv	a0,s2
    800041e8:	cb5fe0ef          	jal	ra,80002e9c <dirlink>
    800041ec:	02054763          	bltz	a0,8000421a <sys_link+0xc0>
  iunlockput(dp);
    800041f0:	854a                	mv	a0,s2
    800041f2:	899fe0ef          	jal	ra,80002a8a <iunlockput>
  iput(ip);
    800041f6:	8526                	mv	a0,s1
    800041f8:	80bfe0ef          	jal	ra,80002a02 <iput>
  end_op();
    800041fc:	f87fe0ef          	jal	ra,80003182 <end_op>
  return 0;
    80004200:	4781                	li	a5,0
    80004202:	a081                	j	80004242 <sys_link+0xe8>
    end_op();
    80004204:	f7ffe0ef          	jal	ra,80003182 <end_op>
    return -1;
    80004208:	57fd                	li	a5,-1
    8000420a:	a825                	j	80004242 <sys_link+0xe8>
    iunlockput(ip);
    8000420c:	8526                	mv	a0,s1
    8000420e:	87dfe0ef          	jal	ra,80002a8a <iunlockput>
    end_op();
    80004212:	f71fe0ef          	jal	ra,80003182 <end_op>
    return -1;
    80004216:	57fd                	li	a5,-1
    80004218:	a02d                	j	80004242 <sys_link+0xe8>
    iunlockput(dp);
    8000421a:	854a                	mv	a0,s2
    8000421c:	86ffe0ef          	jal	ra,80002a8a <iunlockput>
  ilock(ip);
    80004220:	8526                	mv	a0,s1
    80004222:	e62fe0ef          	jal	ra,80002884 <ilock>
  ip->nlink--;
    80004226:	04a4d783          	lhu	a5,74(s1)
    8000422a:	37fd                	addiw	a5,a5,-1
    8000422c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004230:	8526                	mv	a0,s1
    80004232:	da0fe0ef          	jal	ra,800027d2 <iupdate>
  iunlockput(ip);
    80004236:	8526                	mv	a0,s1
    80004238:	853fe0ef          	jal	ra,80002a8a <iunlockput>
  end_op();
    8000423c:	f47fe0ef          	jal	ra,80003182 <end_op>
  return -1;
    80004240:	57fd                	li	a5,-1
}
    80004242:	853e                	mv	a0,a5
    80004244:	70b2                	ld	ra,296(sp)
    80004246:	7412                	ld	s0,288(sp)
    80004248:	64f2                	ld	s1,280(sp)
    8000424a:	6952                	ld	s2,272(sp)
    8000424c:	6155                	addi	sp,sp,304
    8000424e:	8082                	ret

0000000080004250 <sys_unlink>:
{
    80004250:	7151                	addi	sp,sp,-240
    80004252:	f586                	sd	ra,232(sp)
    80004254:	f1a2                	sd	s0,224(sp)
    80004256:	eda6                	sd	s1,216(sp)
    80004258:	e9ca                	sd	s2,208(sp)
    8000425a:	e5ce                	sd	s3,200(sp)
    8000425c:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000425e:	08000613          	li	a2,128
    80004262:	f3040593          	addi	a1,s0,-208
    80004266:	4501                	li	a0,0
    80004268:	b23fd0ef          	jal	ra,80001d8a <argstr>
    8000426c:	12054b63          	bltz	a0,800043a2 <sys_unlink+0x152>
  begin_op();
    80004270:	ea3fe0ef          	jal	ra,80003112 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004274:	fb040593          	addi	a1,s0,-80
    80004278:	f3040513          	addi	a0,s0,-208
    8000427c:	cd5fe0ef          	jal	ra,80002f50 <nameiparent>
    80004280:	84aa                	mv	s1,a0
    80004282:	c54d                	beqz	a0,8000432c <sys_unlink+0xdc>
  ilock(dp);
    80004284:	e00fe0ef          	jal	ra,80002884 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004288:	00003597          	auipc	a1,0x3
    8000428c:	4e058593          	addi	a1,a1,1248 # 80007768 <syscalls+0x310>
    80004290:	fb040513          	addi	a0,s0,-80
    80004294:	a27fe0ef          	jal	ra,80002cba <namecmp>
    80004298:	10050a63          	beqz	a0,800043ac <sys_unlink+0x15c>
    8000429c:	00003597          	auipc	a1,0x3
    800042a0:	4d458593          	addi	a1,a1,1236 # 80007770 <syscalls+0x318>
    800042a4:	fb040513          	addi	a0,s0,-80
    800042a8:	a13fe0ef          	jal	ra,80002cba <namecmp>
    800042ac:	10050063          	beqz	a0,800043ac <sys_unlink+0x15c>
  if((ip = dirlookup(dp, name, &off)) == 0)
    800042b0:	f2c40613          	addi	a2,s0,-212
    800042b4:	fb040593          	addi	a1,s0,-80
    800042b8:	8526                	mv	a0,s1
    800042ba:	a17fe0ef          	jal	ra,80002cd0 <dirlookup>
    800042be:	892a                	mv	s2,a0
    800042c0:	0e050663          	beqz	a0,800043ac <sys_unlink+0x15c>
  ilock(ip);
    800042c4:	dc0fe0ef          	jal	ra,80002884 <ilock>
  if(ip->nlink < 1)
    800042c8:	04a91783          	lh	a5,74(s2)
    800042cc:	06f05463          	blez	a5,80004334 <sys_unlink+0xe4>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800042d0:	04491703          	lh	a4,68(s2)
    800042d4:	4785                	li	a5,1
    800042d6:	06f70563          	beq	a4,a5,80004340 <sys_unlink+0xf0>
  memset(&de, 0, sizeof(de));
    800042da:	4641                	li	a2,16
    800042dc:	4581                	li	a1,0
    800042de:	fc040513          	addi	a0,s0,-64
    800042e2:	e6bfb0ef          	jal	ra,8000014c <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800042e6:	4741                	li	a4,16
    800042e8:	f2c42683          	lw	a3,-212(s0)
    800042ec:	fc040613          	addi	a2,s0,-64
    800042f0:	4581                	li	a1,0
    800042f2:	8526                	mv	a0,s1
    800042f4:	8c5fe0ef          	jal	ra,80002bb8 <writei>
    800042f8:	47c1                	li	a5,16
    800042fa:	08f51563          	bne	a0,a5,80004384 <sys_unlink+0x134>
  if(ip->type == T_DIR){
    800042fe:	04491703          	lh	a4,68(s2)
    80004302:	4785                	li	a5,1
    80004304:	08f70663          	beq	a4,a5,80004390 <sys_unlink+0x140>
  iunlockput(dp);
    80004308:	8526                	mv	a0,s1
    8000430a:	f80fe0ef          	jal	ra,80002a8a <iunlockput>
  ip->nlink--;
    8000430e:	04a95783          	lhu	a5,74(s2)
    80004312:	37fd                	addiw	a5,a5,-1
    80004314:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004318:	854a                	mv	a0,s2
    8000431a:	cb8fe0ef          	jal	ra,800027d2 <iupdate>
  iunlockput(ip);
    8000431e:	854a                	mv	a0,s2
    80004320:	f6afe0ef          	jal	ra,80002a8a <iunlockput>
  end_op();
    80004324:	e5ffe0ef          	jal	ra,80003182 <end_op>
  return 0;
    80004328:	4501                	li	a0,0
    8000432a:	a079                	j	800043b8 <sys_unlink+0x168>
    end_op();
    8000432c:	e57fe0ef          	jal	ra,80003182 <end_op>
    return -1;
    80004330:	557d                	li	a0,-1
    80004332:	a059                	j	800043b8 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004334:	00003517          	auipc	a0,0x3
    80004338:	44450513          	addi	a0,a0,1092 # 80007778 <syscalls+0x320>
    8000433c:	1da010ef          	jal	ra,80005516 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004340:	04c92703          	lw	a4,76(s2)
    80004344:	02000793          	li	a5,32
    80004348:	f8e7f9e3          	bgeu	a5,a4,800042da <sys_unlink+0x8a>
    8000434c:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004350:	4741                	li	a4,16
    80004352:	86ce                	mv	a3,s3
    80004354:	f1840613          	addi	a2,s0,-232
    80004358:	4581                	li	a1,0
    8000435a:	854a                	mv	a0,s2
    8000435c:	f78fe0ef          	jal	ra,80002ad4 <readi>
    80004360:	47c1                	li	a5,16
    80004362:	00f51b63          	bne	a0,a5,80004378 <sys_unlink+0x128>
    if(de.inum != 0)
    80004366:	f1845783          	lhu	a5,-232(s0)
    8000436a:	ef95                	bnez	a5,800043a6 <sys_unlink+0x156>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000436c:	29c1                	addiw	s3,s3,16
    8000436e:	04c92783          	lw	a5,76(s2)
    80004372:	fcf9efe3          	bltu	s3,a5,80004350 <sys_unlink+0x100>
    80004376:	b795                	j	800042da <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004378:	00003517          	auipc	a0,0x3
    8000437c:	41850513          	addi	a0,a0,1048 # 80007790 <syscalls+0x338>
    80004380:	196010ef          	jal	ra,80005516 <panic>
    panic("unlink: writei");
    80004384:	00003517          	auipc	a0,0x3
    80004388:	42450513          	addi	a0,a0,1060 # 800077a8 <syscalls+0x350>
    8000438c:	18a010ef          	jal	ra,80005516 <panic>
    dp->nlink--;
    80004390:	04a4d783          	lhu	a5,74(s1)
    80004394:	37fd                	addiw	a5,a5,-1
    80004396:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000439a:	8526                	mv	a0,s1
    8000439c:	c36fe0ef          	jal	ra,800027d2 <iupdate>
    800043a0:	b7a5                	j	80004308 <sys_unlink+0xb8>
    return -1;
    800043a2:	557d                	li	a0,-1
    800043a4:	a811                	j	800043b8 <sys_unlink+0x168>
    iunlockput(ip);
    800043a6:	854a                	mv	a0,s2
    800043a8:	ee2fe0ef          	jal	ra,80002a8a <iunlockput>
  iunlockput(dp);
    800043ac:	8526                	mv	a0,s1
    800043ae:	edcfe0ef          	jal	ra,80002a8a <iunlockput>
  end_op();
    800043b2:	dd1fe0ef          	jal	ra,80003182 <end_op>
  return -1;
    800043b6:	557d                	li	a0,-1
}
    800043b8:	70ae                	ld	ra,232(sp)
    800043ba:	740e                	ld	s0,224(sp)
    800043bc:	64ee                	ld	s1,216(sp)
    800043be:	694e                	ld	s2,208(sp)
    800043c0:	69ae                	ld	s3,200(sp)
    800043c2:	616d                	addi	sp,sp,240
    800043c4:	8082                	ret

00000000800043c6 <sys_open>:

uint64
sys_open(void)
{
    800043c6:	7131                	addi	sp,sp,-192
    800043c8:	fd06                	sd	ra,184(sp)
    800043ca:	f922                	sd	s0,176(sp)
    800043cc:	f526                	sd	s1,168(sp)
    800043ce:	f14a                	sd	s2,160(sp)
    800043d0:	ed4e                	sd	s3,152(sp)
    800043d2:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800043d4:	f4c40593          	addi	a1,s0,-180
    800043d8:	4505                	li	a0,1
    800043da:	979fd0ef          	jal	ra,80001d52 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800043de:	08000613          	li	a2,128
    800043e2:	f5040593          	addi	a1,s0,-176
    800043e6:	4501                	li	a0,0
    800043e8:	9a3fd0ef          	jal	ra,80001d8a <argstr>
    800043ec:	87aa                	mv	a5,a0
    return -1;
    800043ee:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800043f0:	0807cd63          	bltz	a5,8000448a <sys_open+0xc4>

  begin_op();
    800043f4:	d1ffe0ef          	jal	ra,80003112 <begin_op>

  if(omode & O_CREATE){
    800043f8:	f4c42783          	lw	a5,-180(s0)
    800043fc:	2007f793          	andi	a5,a5,512
    80004400:	c3c5                	beqz	a5,800044a0 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80004402:	4681                	li	a3,0
    80004404:	4601                	li	a2,0
    80004406:	4589                	li	a1,2
    80004408:	f5040513          	addi	a0,s0,-176
    8000440c:	ac3ff0ef          	jal	ra,80003ece <create>
    80004410:	84aa                	mv	s1,a0
    if(ip == 0){
    80004412:	c159                	beqz	a0,80004498 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004414:	04449703          	lh	a4,68(s1)
    80004418:	478d                	li	a5,3
    8000441a:	00f71763          	bne	a4,a5,80004428 <sys_open+0x62>
    8000441e:	0464d703          	lhu	a4,70(s1)
    80004422:	47a5                	li	a5,9
    80004424:	0ae7e963          	bltu	a5,a4,800044d6 <sys_open+0x110>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004428:	862ff0ef          	jal	ra,8000348a <filealloc>
    8000442c:	89aa                	mv	s3,a0
    8000442e:	0c050963          	beqz	a0,80004500 <sys_open+0x13a>
    80004432:	a5fff0ef          	jal	ra,80003e90 <fdalloc>
    80004436:	892a                	mv	s2,a0
    80004438:	0c054163          	bltz	a0,800044fa <sys_open+0x134>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000443c:	04449703          	lh	a4,68(s1)
    80004440:	478d                	li	a5,3
    80004442:	0af70163          	beq	a4,a5,800044e4 <sys_open+0x11e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004446:	4789                	li	a5,2
    80004448:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    8000444c:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80004450:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80004454:	f4c42783          	lw	a5,-180(s0)
    80004458:	0017c713          	xori	a4,a5,1
    8000445c:	8b05                	andi	a4,a4,1
    8000445e:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004462:	0037f713          	andi	a4,a5,3
    80004466:	00e03733          	snez	a4,a4
    8000446a:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000446e:	4007f793          	andi	a5,a5,1024
    80004472:	c791                	beqz	a5,8000447e <sys_open+0xb8>
    80004474:	04449703          	lh	a4,68(s1)
    80004478:	4789                	li	a5,2
    8000447a:	06f70c63          	beq	a4,a5,800044f2 <sys_open+0x12c>
    itrunc(ip);
  }

  iunlock(ip);
    8000447e:	8526                	mv	a0,s1
    80004480:	caefe0ef          	jal	ra,8000292e <iunlock>
  end_op();
    80004484:	cfffe0ef          	jal	ra,80003182 <end_op>

  return fd;
    80004488:	854a                	mv	a0,s2
}
    8000448a:	70ea                	ld	ra,184(sp)
    8000448c:	744a                	ld	s0,176(sp)
    8000448e:	74aa                	ld	s1,168(sp)
    80004490:	790a                	ld	s2,160(sp)
    80004492:	69ea                	ld	s3,152(sp)
    80004494:	6129                	addi	sp,sp,192
    80004496:	8082                	ret
      end_op();
    80004498:	cebfe0ef          	jal	ra,80003182 <end_op>
      return -1;
    8000449c:	557d                	li	a0,-1
    8000449e:	b7f5                	j	8000448a <sys_open+0xc4>
    if((ip = namei(path)) == 0){
    800044a0:	f5040513          	addi	a0,s0,-176
    800044a4:	a93fe0ef          	jal	ra,80002f36 <namei>
    800044a8:	84aa                	mv	s1,a0
    800044aa:	c115                	beqz	a0,800044ce <sys_open+0x108>
    ilock(ip);
    800044ac:	bd8fe0ef          	jal	ra,80002884 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800044b0:	04449703          	lh	a4,68(s1)
    800044b4:	4785                	li	a5,1
    800044b6:	f4f71fe3          	bne	a4,a5,80004414 <sys_open+0x4e>
    800044ba:	f4c42783          	lw	a5,-180(s0)
    800044be:	d7ad                	beqz	a5,80004428 <sys_open+0x62>
      iunlockput(ip);
    800044c0:	8526                	mv	a0,s1
    800044c2:	dc8fe0ef          	jal	ra,80002a8a <iunlockput>
      end_op();
    800044c6:	cbdfe0ef          	jal	ra,80003182 <end_op>
      return -1;
    800044ca:	557d                	li	a0,-1
    800044cc:	bf7d                	j	8000448a <sys_open+0xc4>
      end_op();
    800044ce:	cb5fe0ef          	jal	ra,80003182 <end_op>
      return -1;
    800044d2:	557d                	li	a0,-1
    800044d4:	bf5d                	j	8000448a <sys_open+0xc4>
    iunlockput(ip);
    800044d6:	8526                	mv	a0,s1
    800044d8:	db2fe0ef          	jal	ra,80002a8a <iunlockput>
    end_op();
    800044dc:	ca7fe0ef          	jal	ra,80003182 <end_op>
    return -1;
    800044e0:	557d                	li	a0,-1
    800044e2:	b765                	j	8000448a <sys_open+0xc4>
    f->type = FD_DEVICE;
    800044e4:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    800044e8:	04649783          	lh	a5,70(s1)
    800044ec:	02f99223          	sh	a5,36(s3)
    800044f0:	b785                	j	80004450 <sys_open+0x8a>
    itrunc(ip);
    800044f2:	8526                	mv	a0,s1
    800044f4:	c7afe0ef          	jal	ra,8000296e <itrunc>
    800044f8:	b759                	j	8000447e <sys_open+0xb8>
      fileclose(f);
    800044fa:	854e                	mv	a0,s3
    800044fc:	832ff0ef          	jal	ra,8000352e <fileclose>
    iunlockput(ip);
    80004500:	8526                	mv	a0,s1
    80004502:	d88fe0ef          	jal	ra,80002a8a <iunlockput>
    end_op();
    80004506:	c7dfe0ef          	jal	ra,80003182 <end_op>
    return -1;
    8000450a:	557d                	li	a0,-1
    8000450c:	bfbd                	j	8000448a <sys_open+0xc4>

000000008000450e <sys_mkdir>:

uint64
sys_mkdir(void)
{
    8000450e:	7175                	addi	sp,sp,-144
    80004510:	e506                	sd	ra,136(sp)
    80004512:	e122                	sd	s0,128(sp)
    80004514:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004516:	bfdfe0ef          	jal	ra,80003112 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000451a:	08000613          	li	a2,128
    8000451e:	f7040593          	addi	a1,s0,-144
    80004522:	4501                	li	a0,0
    80004524:	867fd0ef          	jal	ra,80001d8a <argstr>
    80004528:	02054363          	bltz	a0,8000454e <sys_mkdir+0x40>
    8000452c:	4681                	li	a3,0
    8000452e:	4601                	li	a2,0
    80004530:	4585                	li	a1,1
    80004532:	f7040513          	addi	a0,s0,-144
    80004536:	999ff0ef          	jal	ra,80003ece <create>
    8000453a:	c911                	beqz	a0,8000454e <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000453c:	d4efe0ef          	jal	ra,80002a8a <iunlockput>
  end_op();
    80004540:	c43fe0ef          	jal	ra,80003182 <end_op>
  return 0;
    80004544:	4501                	li	a0,0
}
    80004546:	60aa                	ld	ra,136(sp)
    80004548:	640a                	ld	s0,128(sp)
    8000454a:	6149                	addi	sp,sp,144
    8000454c:	8082                	ret
    end_op();
    8000454e:	c35fe0ef          	jal	ra,80003182 <end_op>
    return -1;
    80004552:	557d                	li	a0,-1
    80004554:	bfcd                	j	80004546 <sys_mkdir+0x38>

0000000080004556 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004556:	7135                	addi	sp,sp,-160
    80004558:	ed06                	sd	ra,152(sp)
    8000455a:	e922                	sd	s0,144(sp)
    8000455c:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000455e:	bb5fe0ef          	jal	ra,80003112 <begin_op>
  argint(1, &major);
    80004562:	f6c40593          	addi	a1,s0,-148
    80004566:	4505                	li	a0,1
    80004568:	feafd0ef          	jal	ra,80001d52 <argint>
  argint(2, &minor);
    8000456c:	f6840593          	addi	a1,s0,-152
    80004570:	4509                	li	a0,2
    80004572:	fe0fd0ef          	jal	ra,80001d52 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004576:	08000613          	li	a2,128
    8000457a:	f7040593          	addi	a1,s0,-144
    8000457e:	4501                	li	a0,0
    80004580:	80bfd0ef          	jal	ra,80001d8a <argstr>
    80004584:	02054563          	bltz	a0,800045ae <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004588:	f6841683          	lh	a3,-152(s0)
    8000458c:	f6c41603          	lh	a2,-148(s0)
    80004590:	458d                	li	a1,3
    80004592:	f7040513          	addi	a0,s0,-144
    80004596:	939ff0ef          	jal	ra,80003ece <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000459a:	c911                	beqz	a0,800045ae <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000459c:	ceefe0ef          	jal	ra,80002a8a <iunlockput>
  end_op();
    800045a0:	be3fe0ef          	jal	ra,80003182 <end_op>
  return 0;
    800045a4:	4501                	li	a0,0
}
    800045a6:	60ea                	ld	ra,152(sp)
    800045a8:	644a                	ld	s0,144(sp)
    800045aa:	610d                	addi	sp,sp,160
    800045ac:	8082                	ret
    end_op();
    800045ae:	bd5fe0ef          	jal	ra,80003182 <end_op>
    return -1;
    800045b2:	557d                	li	a0,-1
    800045b4:	bfcd                	j	800045a6 <sys_mknod+0x50>

00000000800045b6 <sys_chdir>:

uint64
sys_chdir(void)
{
    800045b6:	7135                	addi	sp,sp,-160
    800045b8:	ed06                	sd	ra,152(sp)
    800045ba:	e922                	sd	s0,144(sp)
    800045bc:	e526                	sd	s1,136(sp)
    800045be:	e14a                	sd	s2,128(sp)
    800045c0:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800045c2:	859fc0ef          	jal	ra,80000e1a <myproc>
    800045c6:	892a                	mv	s2,a0
  
  begin_op();
    800045c8:	b4bfe0ef          	jal	ra,80003112 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800045cc:	08000613          	li	a2,128
    800045d0:	f6040593          	addi	a1,s0,-160
    800045d4:	4501                	li	a0,0
    800045d6:	fb4fd0ef          	jal	ra,80001d8a <argstr>
    800045da:	04054163          	bltz	a0,8000461c <sys_chdir+0x66>
    800045de:	f6040513          	addi	a0,s0,-160
    800045e2:	955fe0ef          	jal	ra,80002f36 <namei>
    800045e6:	84aa                	mv	s1,a0
    800045e8:	c915                	beqz	a0,8000461c <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800045ea:	a9afe0ef          	jal	ra,80002884 <ilock>
  if(ip->type != T_DIR){
    800045ee:	04449703          	lh	a4,68(s1)
    800045f2:	4785                	li	a5,1
    800045f4:	02f71863          	bne	a4,a5,80004624 <sys_chdir+0x6e>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800045f8:	8526                	mv	a0,s1
    800045fa:	b34fe0ef          	jal	ra,8000292e <iunlock>
  iput(p->cwd);
    800045fe:	15893503          	ld	a0,344(s2)
    80004602:	c00fe0ef          	jal	ra,80002a02 <iput>
  end_op();
    80004606:	b7dfe0ef          	jal	ra,80003182 <end_op>
  p->cwd = ip;
    8000460a:	14993c23          	sd	s1,344(s2)
  return 0;
    8000460e:	4501                	li	a0,0
}
    80004610:	60ea                	ld	ra,152(sp)
    80004612:	644a                	ld	s0,144(sp)
    80004614:	64aa                	ld	s1,136(sp)
    80004616:	690a                	ld	s2,128(sp)
    80004618:	610d                	addi	sp,sp,160
    8000461a:	8082                	ret
    end_op();
    8000461c:	b67fe0ef          	jal	ra,80003182 <end_op>
    return -1;
    80004620:	557d                	li	a0,-1
    80004622:	b7fd                	j	80004610 <sys_chdir+0x5a>
    iunlockput(ip);
    80004624:	8526                	mv	a0,s1
    80004626:	c64fe0ef          	jal	ra,80002a8a <iunlockput>
    end_op();
    8000462a:	b59fe0ef          	jal	ra,80003182 <end_op>
    return -1;
    8000462e:	557d                	li	a0,-1
    80004630:	b7c5                	j	80004610 <sys_chdir+0x5a>

0000000080004632 <sys_exec>:

uint64
sys_exec(void)
{
    80004632:	7145                	addi	sp,sp,-464
    80004634:	e786                	sd	ra,456(sp)
    80004636:	e3a2                	sd	s0,448(sp)
    80004638:	ff26                	sd	s1,440(sp)
    8000463a:	fb4a                	sd	s2,432(sp)
    8000463c:	f74e                	sd	s3,424(sp)
    8000463e:	f352                	sd	s4,416(sp)
    80004640:	ef56                	sd	s5,408(sp)
    80004642:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004644:	e3840593          	addi	a1,s0,-456
    80004648:	4505                	li	a0,1
    8000464a:	f24fd0ef          	jal	ra,80001d6e <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000464e:	08000613          	li	a2,128
    80004652:	f4040593          	addi	a1,s0,-192
    80004656:	4501                	li	a0,0
    80004658:	f32fd0ef          	jal	ra,80001d8a <argstr>
    8000465c:	87aa                	mv	a5,a0
    return -1;
    8000465e:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004660:	0a07c463          	bltz	a5,80004708 <sys_exec+0xd6>
  }
  memset(argv, 0, sizeof(argv));
    80004664:	10000613          	li	a2,256
    80004668:	4581                	li	a1,0
    8000466a:	e4040513          	addi	a0,s0,-448
    8000466e:	adffb0ef          	jal	ra,8000014c <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80004672:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80004676:	89a6                	mv	s3,s1
    80004678:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    8000467a:	02000a13          	li	s4,32
    8000467e:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004682:	00391793          	slli	a5,s2,0x3
    80004686:	e3040593          	addi	a1,s0,-464
    8000468a:	e3843503          	ld	a0,-456(s0)
    8000468e:	953e                	add	a0,a0,a5
    80004690:	e38fd0ef          	jal	ra,80001cc8 <fetchaddr>
    80004694:	02054663          	bltz	a0,800046c0 <sys_exec+0x8e>
      goto bad;
    }
    if(uarg == 0){
    80004698:	e3043783          	ld	a5,-464(s0)
    8000469c:	cf8d                	beqz	a5,800046d6 <sys_exec+0xa4>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    8000469e:	a5ffb0ef          	jal	ra,800000fc <kalloc>
    800046a2:	85aa                	mv	a1,a0
    800046a4:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800046a8:	cd01                	beqz	a0,800046c0 <sys_exec+0x8e>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800046aa:	6605                	lui	a2,0x1
    800046ac:	e3043503          	ld	a0,-464(s0)
    800046b0:	e62fd0ef          	jal	ra,80001d12 <fetchstr>
    800046b4:	00054663          	bltz	a0,800046c0 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    800046b8:	0905                	addi	s2,s2,1
    800046ba:	09a1                	addi	s3,s3,8
    800046bc:	fd4911e3          	bne	s2,s4,8000467e <sys_exec+0x4c>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046c0:	10048913          	addi	s2,s1,256
    800046c4:	6088                	ld	a0,0(s1)
    800046c6:	c121                	beqz	a0,80004706 <sys_exec+0xd4>
    kfree(argv[i]);
    800046c8:	955fb0ef          	jal	ra,8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046cc:	04a1                	addi	s1,s1,8
    800046ce:	ff249be3          	bne	s1,s2,800046c4 <sys_exec+0x92>
  return -1;
    800046d2:	557d                	li	a0,-1
    800046d4:	a815                	j	80004708 <sys_exec+0xd6>
      argv[i] = 0;
    800046d6:	0a8e                	slli	s5,s5,0x3
    800046d8:	fc040793          	addi	a5,s0,-64
    800046dc:	9abe                	add	s5,s5,a5
    800046de:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    800046e2:	e4040593          	addi	a1,s0,-448
    800046e6:	f4040513          	addi	a0,s0,-192
    800046ea:	be6ff0ef          	jal	ra,80003ad0 <exec>
    800046ee:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046f0:	10048993          	addi	s3,s1,256
    800046f4:	6088                	ld	a0,0(s1)
    800046f6:	c511                	beqz	a0,80004702 <sys_exec+0xd0>
    kfree(argv[i]);
    800046f8:	925fb0ef          	jal	ra,8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046fc:	04a1                	addi	s1,s1,8
    800046fe:	ff349be3          	bne	s1,s3,800046f4 <sys_exec+0xc2>
  return ret;
    80004702:	854a                	mv	a0,s2
    80004704:	a011                	j	80004708 <sys_exec+0xd6>
  return -1;
    80004706:	557d                	li	a0,-1
}
    80004708:	60be                	ld	ra,456(sp)
    8000470a:	641e                	ld	s0,448(sp)
    8000470c:	74fa                	ld	s1,440(sp)
    8000470e:	795a                	ld	s2,432(sp)
    80004710:	79ba                	ld	s3,424(sp)
    80004712:	7a1a                	ld	s4,416(sp)
    80004714:	6afa                	ld	s5,408(sp)
    80004716:	6179                	addi	sp,sp,464
    80004718:	8082                	ret

000000008000471a <sys_pipe>:

uint64
sys_pipe(void)
{
    8000471a:	7139                	addi	sp,sp,-64
    8000471c:	fc06                	sd	ra,56(sp)
    8000471e:	f822                	sd	s0,48(sp)
    80004720:	f426                	sd	s1,40(sp)
    80004722:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80004724:	ef6fc0ef          	jal	ra,80000e1a <myproc>
    80004728:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000472a:	fd840593          	addi	a1,s0,-40
    8000472e:	4501                	li	a0,0
    80004730:	e3efd0ef          	jal	ra,80001d6e <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80004734:	fc840593          	addi	a1,s0,-56
    80004738:	fd040513          	addi	a0,s0,-48
    8000473c:	8beff0ef          	jal	ra,800037fa <pipealloc>
    return -1;
    80004740:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004742:	0a054463          	bltz	a0,800047ea <sys_pipe+0xd0>
  fd0 = -1;
    80004746:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000474a:	fd043503          	ld	a0,-48(s0)
    8000474e:	f42ff0ef          	jal	ra,80003e90 <fdalloc>
    80004752:	fca42223          	sw	a0,-60(s0)
    80004756:	08054163          	bltz	a0,800047d8 <sys_pipe+0xbe>
    8000475a:	fc843503          	ld	a0,-56(s0)
    8000475e:	f32ff0ef          	jal	ra,80003e90 <fdalloc>
    80004762:	fca42023          	sw	a0,-64(s0)
    80004766:	06054063          	bltz	a0,800047c6 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000476a:	4691                	li	a3,4
    8000476c:	fc440613          	addi	a2,s0,-60
    80004770:	fd843583          	ld	a1,-40(s0)
    80004774:	68a8                	ld	a0,80(s1)
    80004776:	a60fc0ef          	jal	ra,800009d6 <copyout>
    8000477a:	00054e63          	bltz	a0,80004796 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    8000477e:	4691                	li	a3,4
    80004780:	fc040613          	addi	a2,s0,-64
    80004784:	fd843583          	ld	a1,-40(s0)
    80004788:	0591                	addi	a1,a1,4
    8000478a:	68a8                	ld	a0,80(s1)
    8000478c:	a4afc0ef          	jal	ra,800009d6 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80004790:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80004792:	04055c63          	bgez	a0,800047ea <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    80004796:	fc442783          	lw	a5,-60(s0)
    8000479a:	07e9                	addi	a5,a5,26
    8000479c:	078e                	slli	a5,a5,0x3
    8000479e:	97a6                	add	a5,a5,s1
    800047a0:	0007b423          	sd	zero,8(a5)
    p->ofile[fd1] = 0;
    800047a4:	fc042503          	lw	a0,-64(s0)
    800047a8:	0569                	addi	a0,a0,26
    800047aa:	050e                	slli	a0,a0,0x3
    800047ac:	94aa                	add	s1,s1,a0
    800047ae:	0004b423          	sd	zero,8(s1)
    fileclose(rf);
    800047b2:	fd043503          	ld	a0,-48(s0)
    800047b6:	d79fe0ef          	jal	ra,8000352e <fileclose>
    fileclose(wf);
    800047ba:	fc843503          	ld	a0,-56(s0)
    800047be:	d71fe0ef          	jal	ra,8000352e <fileclose>
    return -1;
    800047c2:	57fd                	li	a5,-1
    800047c4:	a01d                	j	800047ea <sys_pipe+0xd0>
    if(fd0 >= 0)
    800047c6:	fc442783          	lw	a5,-60(s0)
    800047ca:	0007c763          	bltz	a5,800047d8 <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800047ce:	07e9                	addi	a5,a5,26
    800047d0:	078e                	slli	a5,a5,0x3
    800047d2:	94be                	add	s1,s1,a5
    800047d4:	0004b423          	sd	zero,8(s1)
    fileclose(rf);
    800047d8:	fd043503          	ld	a0,-48(s0)
    800047dc:	d53fe0ef          	jal	ra,8000352e <fileclose>
    fileclose(wf);
    800047e0:	fc843503          	ld	a0,-56(s0)
    800047e4:	d4bfe0ef          	jal	ra,8000352e <fileclose>
    return -1;
    800047e8:	57fd                	li	a5,-1
}
    800047ea:	853e                	mv	a0,a5
    800047ec:	70e2                	ld	ra,56(sp)
    800047ee:	7442                	ld	s0,48(sp)
    800047f0:	74a2                	ld	s1,40(sp)
    800047f2:	6121                	addi	sp,sp,64
    800047f4:	8082                	ret
	...

0000000080004800 <kernelvec>:
    80004800:	7111                	addi	sp,sp,-256
    80004802:	e006                	sd	ra,0(sp)
    80004804:	e40a                	sd	sp,8(sp)
    80004806:	e80e                	sd	gp,16(sp)
    80004808:	ec12                	sd	tp,24(sp)
    8000480a:	f016                	sd	t0,32(sp)
    8000480c:	f41a                	sd	t1,40(sp)
    8000480e:	f81e                	sd	t2,48(sp)
    80004810:	e4aa                	sd	a0,72(sp)
    80004812:	e8ae                	sd	a1,80(sp)
    80004814:	ecb2                	sd	a2,88(sp)
    80004816:	f0b6                	sd	a3,96(sp)
    80004818:	f4ba                	sd	a4,104(sp)
    8000481a:	f8be                	sd	a5,112(sp)
    8000481c:	fcc2                	sd	a6,120(sp)
    8000481e:	e146                	sd	a7,128(sp)
    80004820:	edf2                	sd	t3,216(sp)
    80004822:	f1f6                	sd	t4,224(sp)
    80004824:	f5fa                	sd	t5,232(sp)
    80004826:	f9fe                	sd	t6,240(sp)
    80004828:	bb0fd0ef          	jal	ra,80001bd8 <kerneltrap>
    8000482c:	6082                	ld	ra,0(sp)
    8000482e:	6122                	ld	sp,8(sp)
    80004830:	61c2                	ld	gp,16(sp)
    80004832:	7282                	ld	t0,32(sp)
    80004834:	7322                	ld	t1,40(sp)
    80004836:	73c2                	ld	t2,48(sp)
    80004838:	6526                	ld	a0,72(sp)
    8000483a:	65c6                	ld	a1,80(sp)
    8000483c:	6666                	ld	a2,88(sp)
    8000483e:	7686                	ld	a3,96(sp)
    80004840:	7726                	ld	a4,104(sp)
    80004842:	77c6                	ld	a5,112(sp)
    80004844:	7866                	ld	a6,120(sp)
    80004846:	688a                	ld	a7,128(sp)
    80004848:	6e6e                	ld	t3,216(sp)
    8000484a:	7e8e                	ld	t4,224(sp)
    8000484c:	7f2e                	ld	t5,232(sp)
    8000484e:	7fce                	ld	t6,240(sp)
    80004850:	6111                	addi	sp,sp,256
    80004852:	10200073          	sret
	...

000000008000485e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000485e:	1141                	addi	sp,sp,-16
    80004860:	e422                	sd	s0,8(sp)
    80004862:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004864:	0c0007b7          	lui	a5,0xc000
    80004868:	4705                	li	a4,1
    8000486a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000486c:	c3d8                	sw	a4,4(a5)
}
    8000486e:	6422                	ld	s0,8(sp)
    80004870:	0141                	addi	sp,sp,16
    80004872:	8082                	ret

0000000080004874 <plicinithart>:

void
plicinithart(void)
{
    80004874:	1141                	addi	sp,sp,-16
    80004876:	e406                	sd	ra,8(sp)
    80004878:	e022                	sd	s0,0(sp)
    8000487a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    8000487c:	d72fc0ef          	jal	ra,80000dee <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004880:	0085171b          	slliw	a4,a0,0x8
    80004884:	0c0027b7          	lui	a5,0xc002
    80004888:	97ba                	add	a5,a5,a4
    8000488a:	40200713          	li	a4,1026
    8000488e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80004892:	00d5151b          	slliw	a0,a0,0xd
    80004896:	0c2017b7          	lui	a5,0xc201
    8000489a:	953e                	add	a0,a0,a5
    8000489c:	00052023          	sw	zero,0(a0)
}
    800048a0:	60a2                	ld	ra,8(sp)
    800048a2:	6402                	ld	s0,0(sp)
    800048a4:	0141                	addi	sp,sp,16
    800048a6:	8082                	ret

00000000800048a8 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800048a8:	1141                	addi	sp,sp,-16
    800048aa:	e406                	sd	ra,8(sp)
    800048ac:	e022                	sd	s0,0(sp)
    800048ae:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800048b0:	d3efc0ef          	jal	ra,80000dee <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800048b4:	00d5179b          	slliw	a5,a0,0xd
    800048b8:	0c201537          	lui	a0,0xc201
    800048bc:	953e                	add	a0,a0,a5
  return irq;
}
    800048be:	4148                	lw	a0,4(a0)
    800048c0:	60a2                	ld	ra,8(sp)
    800048c2:	6402                	ld	s0,0(sp)
    800048c4:	0141                	addi	sp,sp,16
    800048c6:	8082                	ret

00000000800048c8 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800048c8:	1101                	addi	sp,sp,-32
    800048ca:	ec06                	sd	ra,24(sp)
    800048cc:	e822                	sd	s0,16(sp)
    800048ce:	e426                	sd	s1,8(sp)
    800048d0:	1000                	addi	s0,sp,32
    800048d2:	84aa                	mv	s1,a0
  int hart = cpuid();
    800048d4:	d1afc0ef          	jal	ra,80000dee <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800048d8:	00d5151b          	slliw	a0,a0,0xd
    800048dc:	0c2017b7          	lui	a5,0xc201
    800048e0:	97aa                	add	a5,a5,a0
    800048e2:	c3c4                	sw	s1,4(a5)
}
    800048e4:	60e2                	ld	ra,24(sp)
    800048e6:	6442                	ld	s0,16(sp)
    800048e8:	64a2                	ld	s1,8(sp)
    800048ea:	6105                	addi	sp,sp,32
    800048ec:	8082                	ret

00000000800048ee <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800048ee:	1141                	addi	sp,sp,-16
    800048f0:	e406                	sd	ra,8(sp)
    800048f2:	e022                	sd	s0,0(sp)
    800048f4:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800048f6:	479d                	li	a5,7
    800048f8:	04a7ca63          	blt	a5,a0,8000494c <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800048fc:	00014797          	auipc	a5,0x14
    80004900:	3a478793          	addi	a5,a5,932 # 80018ca0 <disk>
    80004904:	97aa                	add	a5,a5,a0
    80004906:	0187c783          	lbu	a5,24(a5)
    8000490a:	e7b9                	bnez	a5,80004958 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    8000490c:	00451613          	slli	a2,a0,0x4
    80004910:	00014797          	auipc	a5,0x14
    80004914:	39078793          	addi	a5,a5,912 # 80018ca0 <disk>
    80004918:	6394                	ld	a3,0(a5)
    8000491a:	96b2                	add	a3,a3,a2
    8000491c:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    80004920:	6398                	ld	a4,0(a5)
    80004922:	9732                	add	a4,a4,a2
    80004924:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004928:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    8000492c:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004930:	953e                	add	a0,a0,a5
    80004932:	4785                	li	a5,1
    80004934:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    80004938:	00014517          	auipc	a0,0x14
    8000493c:	38050513          	addi	a0,a0,896 # 80018cb8 <disk+0x18>
    80004940:	b7dfc0ef          	jal	ra,800014bc <wakeup>
}
    80004944:	60a2                	ld	ra,8(sp)
    80004946:	6402                	ld	s0,0(sp)
    80004948:	0141                	addi	sp,sp,16
    8000494a:	8082                	ret
    panic("free_desc 1");
    8000494c:	00003517          	auipc	a0,0x3
    80004950:	e6c50513          	addi	a0,a0,-404 # 800077b8 <syscalls+0x360>
    80004954:	3c3000ef          	jal	ra,80005516 <panic>
    panic("free_desc 2");
    80004958:	00003517          	auipc	a0,0x3
    8000495c:	e7050513          	addi	a0,a0,-400 # 800077c8 <syscalls+0x370>
    80004960:	3b7000ef          	jal	ra,80005516 <panic>

0000000080004964 <virtio_disk_init>:
{
    80004964:	1101                	addi	sp,sp,-32
    80004966:	ec06                	sd	ra,24(sp)
    80004968:	e822                	sd	s0,16(sp)
    8000496a:	e426                	sd	s1,8(sp)
    8000496c:	e04a                	sd	s2,0(sp)
    8000496e:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004970:	00003597          	auipc	a1,0x3
    80004974:	e6858593          	addi	a1,a1,-408 # 800077d8 <syscalls+0x380>
    80004978:	00014517          	auipc	a0,0x14
    8000497c:	45050513          	addi	a0,a0,1104 # 80018dc8 <disk+0x128>
    80004980:	62b000ef          	jal	ra,800057aa <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004984:	100017b7          	lui	a5,0x10001
    80004988:	4398                	lw	a4,0(a5)
    8000498a:	2701                	sext.w	a4,a4
    8000498c:	747277b7          	lui	a5,0x74727
    80004990:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80004994:	14f71063          	bne	a4,a5,80004ad4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80004998:	100017b7          	lui	a5,0x10001
    8000499c:	43dc                	lw	a5,4(a5)
    8000499e:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800049a0:	4709                	li	a4,2
    800049a2:	12e79963          	bne	a5,a4,80004ad4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800049a6:	100017b7          	lui	a5,0x10001
    800049aa:	479c                	lw	a5,8(a5)
    800049ac:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800049ae:	12e79363          	bne	a5,a4,80004ad4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800049b2:	100017b7          	lui	a5,0x10001
    800049b6:	47d8                	lw	a4,12(a5)
    800049b8:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800049ba:	554d47b7          	lui	a5,0x554d4
    800049be:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800049c2:	10f71963          	bne	a4,a5,80004ad4 <virtio_disk_init+0x170>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049c6:	100017b7          	lui	a5,0x10001
    800049ca:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049ce:	4705                	li	a4,1
    800049d0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049d2:	470d                	li	a4,3
    800049d4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800049d6:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800049d8:	c7ffe737          	lui	a4,0xc7ffe
    800049dc:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd87f>
    800049e0:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800049e2:	2701                	sext.w	a4,a4
    800049e4:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049e6:	472d                	li	a4,11
    800049e8:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800049ea:	5bbc                	lw	a5,112(a5)
    800049ec:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800049f0:	8ba1                	andi	a5,a5,8
    800049f2:	0e078763          	beqz	a5,80004ae0 <virtio_disk_init+0x17c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800049f6:	100017b7          	lui	a5,0x10001
    800049fa:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800049fe:	43fc                	lw	a5,68(a5)
    80004a00:	2781                	sext.w	a5,a5
    80004a02:	0e079563          	bnez	a5,80004aec <virtio_disk_init+0x188>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004a06:	100017b7          	lui	a5,0x10001
    80004a0a:	5bdc                	lw	a5,52(a5)
    80004a0c:	2781                	sext.w	a5,a5
  if(max == 0)
    80004a0e:	0e078563          	beqz	a5,80004af8 <virtio_disk_init+0x194>
  if(max < NUM)
    80004a12:	471d                	li	a4,7
    80004a14:	0ef77863          	bgeu	a4,a5,80004b04 <virtio_disk_init+0x1a0>
  disk.desc = kalloc();
    80004a18:	ee4fb0ef          	jal	ra,800000fc <kalloc>
    80004a1c:	00014497          	auipc	s1,0x14
    80004a20:	28448493          	addi	s1,s1,644 # 80018ca0 <disk>
    80004a24:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004a26:	ed6fb0ef          	jal	ra,800000fc <kalloc>
    80004a2a:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004a2c:	ed0fb0ef          	jal	ra,800000fc <kalloc>
    80004a30:	87aa                	mv	a5,a0
    80004a32:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004a34:	6088                	ld	a0,0(s1)
    80004a36:	cd69                	beqz	a0,80004b10 <virtio_disk_init+0x1ac>
    80004a38:	00014717          	auipc	a4,0x14
    80004a3c:	27073703          	ld	a4,624(a4) # 80018ca8 <disk+0x8>
    80004a40:	cb61                	beqz	a4,80004b10 <virtio_disk_init+0x1ac>
    80004a42:	c7f9                	beqz	a5,80004b10 <virtio_disk_init+0x1ac>
  memset(disk.desc, 0, PGSIZE);
    80004a44:	6605                	lui	a2,0x1
    80004a46:	4581                	li	a1,0
    80004a48:	f04fb0ef          	jal	ra,8000014c <memset>
  memset(disk.avail, 0, PGSIZE);
    80004a4c:	00014497          	auipc	s1,0x14
    80004a50:	25448493          	addi	s1,s1,596 # 80018ca0 <disk>
    80004a54:	6605                	lui	a2,0x1
    80004a56:	4581                	li	a1,0
    80004a58:	6488                	ld	a0,8(s1)
    80004a5a:	ef2fb0ef          	jal	ra,8000014c <memset>
  memset(disk.used, 0, PGSIZE);
    80004a5e:	6605                	lui	a2,0x1
    80004a60:	4581                	li	a1,0
    80004a62:	6888                	ld	a0,16(s1)
    80004a64:	ee8fb0ef          	jal	ra,8000014c <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004a68:	100017b7          	lui	a5,0x10001
    80004a6c:	4721                	li	a4,8
    80004a6e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004a70:	4098                	lw	a4,0(s1)
    80004a72:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004a76:	40d8                	lw	a4,4(s1)
    80004a78:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004a7c:	6498                	ld	a4,8(s1)
    80004a7e:	0007069b          	sext.w	a3,a4
    80004a82:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80004a86:	9701                	srai	a4,a4,0x20
    80004a88:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004a8c:	6898                	ld	a4,16(s1)
    80004a8e:	0007069b          	sext.w	a3,a4
    80004a92:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80004a96:	9701                	srai	a4,a4,0x20
    80004a98:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004a9c:	4705                	li	a4,1
    80004a9e:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80004aa0:	00e48c23          	sb	a4,24(s1)
    80004aa4:	00e48ca3          	sb	a4,25(s1)
    80004aa8:	00e48d23          	sb	a4,26(s1)
    80004aac:	00e48da3          	sb	a4,27(s1)
    80004ab0:	00e48e23          	sb	a4,28(s1)
    80004ab4:	00e48ea3          	sb	a4,29(s1)
    80004ab8:	00e48f23          	sb	a4,30(s1)
    80004abc:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004ac0:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ac4:	0727a823          	sw	s2,112(a5)
}
    80004ac8:	60e2                	ld	ra,24(sp)
    80004aca:	6442                	ld	s0,16(sp)
    80004acc:	64a2                	ld	s1,8(sp)
    80004ace:	6902                	ld	s2,0(sp)
    80004ad0:	6105                	addi	sp,sp,32
    80004ad2:	8082                	ret
    panic("could not find virtio disk");
    80004ad4:	00003517          	auipc	a0,0x3
    80004ad8:	d1450513          	addi	a0,a0,-748 # 800077e8 <syscalls+0x390>
    80004adc:	23b000ef          	jal	ra,80005516 <panic>
    panic("virtio disk FEATURES_OK unset");
    80004ae0:	00003517          	auipc	a0,0x3
    80004ae4:	d2850513          	addi	a0,a0,-728 # 80007808 <syscalls+0x3b0>
    80004ae8:	22f000ef          	jal	ra,80005516 <panic>
    panic("virtio disk should not be ready");
    80004aec:	00003517          	auipc	a0,0x3
    80004af0:	d3c50513          	addi	a0,a0,-708 # 80007828 <syscalls+0x3d0>
    80004af4:	223000ef          	jal	ra,80005516 <panic>
    panic("virtio disk has no queue 0");
    80004af8:	00003517          	auipc	a0,0x3
    80004afc:	d5050513          	addi	a0,a0,-688 # 80007848 <syscalls+0x3f0>
    80004b00:	217000ef          	jal	ra,80005516 <panic>
    panic("virtio disk max queue too short");
    80004b04:	00003517          	auipc	a0,0x3
    80004b08:	d6450513          	addi	a0,a0,-668 # 80007868 <syscalls+0x410>
    80004b0c:	20b000ef          	jal	ra,80005516 <panic>
    panic("virtio disk kalloc");
    80004b10:	00003517          	auipc	a0,0x3
    80004b14:	d7850513          	addi	a0,a0,-648 # 80007888 <syscalls+0x430>
    80004b18:	1ff000ef          	jal	ra,80005516 <panic>

0000000080004b1c <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004b1c:	7119                	addi	sp,sp,-128
    80004b1e:	fc86                	sd	ra,120(sp)
    80004b20:	f8a2                	sd	s0,112(sp)
    80004b22:	f4a6                	sd	s1,104(sp)
    80004b24:	f0ca                	sd	s2,96(sp)
    80004b26:	ecce                	sd	s3,88(sp)
    80004b28:	e8d2                	sd	s4,80(sp)
    80004b2a:	e4d6                	sd	s5,72(sp)
    80004b2c:	e0da                	sd	s6,64(sp)
    80004b2e:	fc5e                	sd	s7,56(sp)
    80004b30:	f862                	sd	s8,48(sp)
    80004b32:	f466                	sd	s9,40(sp)
    80004b34:	f06a                	sd	s10,32(sp)
    80004b36:	ec6e                	sd	s11,24(sp)
    80004b38:	0100                	addi	s0,sp,128
    80004b3a:	8aaa                	mv	s5,a0
    80004b3c:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004b3e:	00c52d03          	lw	s10,12(a0)
    80004b42:	001d1d1b          	slliw	s10,s10,0x1
    80004b46:	1d02                	slli	s10,s10,0x20
    80004b48:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    80004b4c:	00014517          	auipc	a0,0x14
    80004b50:	27c50513          	addi	a0,a0,636 # 80018dc8 <disk+0x128>
    80004b54:	4d7000ef          	jal	ra,8000582a <acquire>
  for(int i = 0; i < 3; i++){
    80004b58:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80004b5a:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004b5c:	00014b97          	auipc	s7,0x14
    80004b60:	144b8b93          	addi	s7,s7,324 # 80018ca0 <disk>
  for(int i = 0; i < 3; i++){
    80004b64:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004b66:	00014c97          	auipc	s9,0x14
    80004b6a:	262c8c93          	addi	s9,s9,610 # 80018dc8 <disk+0x128>
    80004b6e:	a8a9                	j	80004bc8 <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80004b70:	00fb8733          	add	a4,s7,a5
    80004b74:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004b78:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004b7a:	0207c563          	bltz	a5,80004ba4 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    80004b7e:	2905                	addiw	s2,s2,1
    80004b80:	0611                	addi	a2,a2,4
    80004b82:	05690863          	beq	s2,s6,80004bd2 <virtio_disk_rw+0xb6>
    idx[i] = alloc_desc();
    80004b86:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004b88:	00014717          	auipc	a4,0x14
    80004b8c:	11870713          	addi	a4,a4,280 # 80018ca0 <disk>
    80004b90:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80004b92:	01874683          	lbu	a3,24(a4)
    80004b96:	fee9                	bnez	a3,80004b70 <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80004b98:	2785                	addiw	a5,a5,1
    80004b9a:	0705                	addi	a4,a4,1
    80004b9c:	fe979be3          	bne	a5,s1,80004b92 <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    80004ba0:	57fd                	li	a5,-1
    80004ba2:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80004ba4:	01205b63          	blez	s2,80004bba <virtio_disk_rw+0x9e>
    80004ba8:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    80004baa:	000a2503          	lw	a0,0(s4)
    80004bae:	d41ff0ef          	jal	ra,800048ee <free_desc>
      for(int j = 0; j < i; j++)
    80004bb2:	2d85                	addiw	s11,s11,1
    80004bb4:	0a11                	addi	s4,s4,4
    80004bb6:	ffb91ae3          	bne	s2,s11,80004baa <virtio_disk_rw+0x8e>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004bba:	85e6                	mv	a1,s9
    80004bbc:	00014517          	auipc	a0,0x14
    80004bc0:	0fc50513          	addi	a0,a0,252 # 80018cb8 <disk+0x18>
    80004bc4:	8adfc0ef          	jal	ra,80001470 <sleep>
  for(int i = 0; i < 3; i++){
    80004bc8:	f8040a13          	addi	s4,s0,-128
{
    80004bcc:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    80004bce:	894e                	mv	s2,s3
    80004bd0:	bf5d                	j	80004b86 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004bd2:	f8042583          	lw	a1,-128(s0)
    80004bd6:	00a58793          	addi	a5,a1,10
    80004bda:	0792                	slli	a5,a5,0x4

  if(write)
    80004bdc:	00014617          	auipc	a2,0x14
    80004be0:	0c460613          	addi	a2,a2,196 # 80018ca0 <disk>
    80004be4:	00f60733          	add	a4,a2,a5
    80004be8:	018036b3          	snez	a3,s8
    80004bec:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004bee:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004bf2:	01a73823          	sd	s10,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004bf6:	f6078693          	addi	a3,a5,-160
    80004bfa:	6218                	ld	a4,0(a2)
    80004bfc:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004bfe:	00878513          	addi	a0,a5,8
    80004c02:	9532                	add	a0,a0,a2
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004c04:	e308                	sd	a0,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004c06:	6208                	ld	a0,0(a2)
    80004c08:	96aa                	add	a3,a3,a0
    80004c0a:	4741                	li	a4,16
    80004c0c:	c698                	sw	a4,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004c0e:	4705                	li	a4,1
    80004c10:	00e69623          	sh	a4,12(a3)
  disk.desc[idx[0]].next = idx[1];
    80004c14:	f8442703          	lw	a4,-124(s0)
    80004c18:	00e69723          	sh	a4,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004c1c:	0712                	slli	a4,a4,0x4
    80004c1e:	953a                	add	a0,a0,a4
    80004c20:	058a8693          	addi	a3,s5,88
    80004c24:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    80004c26:	6208                	ld	a0,0(a2)
    80004c28:	972a                	add	a4,a4,a0
    80004c2a:	40000693          	li	a3,1024
    80004c2e:	c714                	sw	a3,8(a4)
  if(write)
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    80004c30:	001c3c13          	seqz	s8,s8
    80004c34:	0c06                	slli	s8,s8,0x1
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004c36:	001c6c13          	ori	s8,s8,1
    80004c3a:	01871623          	sh	s8,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004c3e:	f8842603          	lw	a2,-120(s0)
    80004c42:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004c46:	00014697          	auipc	a3,0x14
    80004c4a:	05a68693          	addi	a3,a3,90 # 80018ca0 <disk>
    80004c4e:	00258713          	addi	a4,a1,2
    80004c52:	0712                	slli	a4,a4,0x4
    80004c54:	9736                	add	a4,a4,a3
    80004c56:	587d                	li	a6,-1
    80004c58:	01070823          	sb	a6,16(a4)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004c5c:	0612                	slli	a2,a2,0x4
    80004c5e:	9532                	add	a0,a0,a2
    80004c60:	f9078793          	addi	a5,a5,-112
    80004c64:	97b6                	add	a5,a5,a3
    80004c66:	e11c                	sd	a5,0(a0)
  disk.desc[idx[2]].len = 1;
    80004c68:	629c                	ld	a5,0(a3)
    80004c6a:	97b2                	add	a5,a5,a2
    80004c6c:	4605                	li	a2,1
    80004c6e:	c790                	sw	a2,8(a5)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004c70:	4509                	li	a0,2
    80004c72:	00a79623          	sh	a0,12(a5)
  disk.desc[idx[2]].next = 0;
    80004c76:	00079723          	sh	zero,14(a5)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004c7a:	00caa223          	sw	a2,4(s5)
  disk.info[idx[0]].b = b;
    80004c7e:	01573423          	sd	s5,8(a4)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004c82:	6698                	ld	a4,8(a3)
    80004c84:	00275783          	lhu	a5,2(a4)
    80004c88:	8b9d                	andi	a5,a5,7
    80004c8a:	0786                	slli	a5,a5,0x1
    80004c8c:	97ba                	add	a5,a5,a4
    80004c8e:	00b79223          	sh	a1,4(a5)

  __sync_synchronize();
    80004c92:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004c96:	6698                	ld	a4,8(a3)
    80004c98:	00275783          	lhu	a5,2(a4)
    80004c9c:	2785                	addiw	a5,a5,1
    80004c9e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004ca2:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004ca6:	100017b7          	lui	a5,0x10001
    80004caa:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004cae:	004aa783          	lw	a5,4(s5)
    80004cb2:	00c79f63          	bne	a5,a2,80004cd0 <virtio_disk_rw+0x1b4>
    sleep(b, &disk.vdisk_lock);
    80004cb6:	00014917          	auipc	s2,0x14
    80004cba:	11290913          	addi	s2,s2,274 # 80018dc8 <disk+0x128>
  while(b->disk == 1) {
    80004cbe:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80004cc0:	85ca                	mv	a1,s2
    80004cc2:	8556                	mv	a0,s5
    80004cc4:	facfc0ef          	jal	ra,80001470 <sleep>
  while(b->disk == 1) {
    80004cc8:	004aa783          	lw	a5,4(s5)
    80004ccc:	fe978ae3          	beq	a5,s1,80004cc0 <virtio_disk_rw+0x1a4>
  }

  disk.info[idx[0]].b = 0;
    80004cd0:	f8042903          	lw	s2,-128(s0)
    80004cd4:	00290793          	addi	a5,s2,2
    80004cd8:	00479713          	slli	a4,a5,0x4
    80004cdc:	00014797          	auipc	a5,0x14
    80004ce0:	fc478793          	addi	a5,a5,-60 # 80018ca0 <disk>
    80004ce4:	97ba                	add	a5,a5,a4
    80004ce6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004cea:	00014997          	auipc	s3,0x14
    80004cee:	fb698993          	addi	s3,s3,-74 # 80018ca0 <disk>
    80004cf2:	00491713          	slli	a4,s2,0x4
    80004cf6:	0009b783          	ld	a5,0(s3)
    80004cfa:	97ba                	add	a5,a5,a4
    80004cfc:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004d00:	854a                	mv	a0,s2
    80004d02:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004d06:	be9ff0ef          	jal	ra,800048ee <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004d0a:	8885                	andi	s1,s1,1
    80004d0c:	f0fd                	bnez	s1,80004cf2 <virtio_disk_rw+0x1d6>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004d0e:	00014517          	auipc	a0,0x14
    80004d12:	0ba50513          	addi	a0,a0,186 # 80018dc8 <disk+0x128>
    80004d16:	3ad000ef          	jal	ra,800058c2 <release>
}
    80004d1a:	70e6                	ld	ra,120(sp)
    80004d1c:	7446                	ld	s0,112(sp)
    80004d1e:	74a6                	ld	s1,104(sp)
    80004d20:	7906                	ld	s2,96(sp)
    80004d22:	69e6                	ld	s3,88(sp)
    80004d24:	6a46                	ld	s4,80(sp)
    80004d26:	6aa6                	ld	s5,72(sp)
    80004d28:	6b06                	ld	s6,64(sp)
    80004d2a:	7be2                	ld	s7,56(sp)
    80004d2c:	7c42                	ld	s8,48(sp)
    80004d2e:	7ca2                	ld	s9,40(sp)
    80004d30:	7d02                	ld	s10,32(sp)
    80004d32:	6de2                	ld	s11,24(sp)
    80004d34:	6109                	addi	sp,sp,128
    80004d36:	8082                	ret

0000000080004d38 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004d38:	1101                	addi	sp,sp,-32
    80004d3a:	ec06                	sd	ra,24(sp)
    80004d3c:	e822                	sd	s0,16(sp)
    80004d3e:	e426                	sd	s1,8(sp)
    80004d40:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004d42:	00014497          	auipc	s1,0x14
    80004d46:	f5e48493          	addi	s1,s1,-162 # 80018ca0 <disk>
    80004d4a:	00014517          	auipc	a0,0x14
    80004d4e:	07e50513          	addi	a0,a0,126 # 80018dc8 <disk+0x128>
    80004d52:	2d9000ef          	jal	ra,8000582a <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004d56:	10001737          	lui	a4,0x10001
    80004d5a:	533c                	lw	a5,96(a4)
    80004d5c:	8b8d                	andi	a5,a5,3
    80004d5e:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004d60:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004d64:	689c                	ld	a5,16(s1)
    80004d66:	0204d703          	lhu	a4,32(s1)
    80004d6a:	0027d783          	lhu	a5,2(a5)
    80004d6e:	04f70663          	beq	a4,a5,80004dba <virtio_disk_intr+0x82>
    __sync_synchronize();
    80004d72:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004d76:	6898                	ld	a4,16(s1)
    80004d78:	0204d783          	lhu	a5,32(s1)
    80004d7c:	8b9d                	andi	a5,a5,7
    80004d7e:	078e                	slli	a5,a5,0x3
    80004d80:	97ba                	add	a5,a5,a4
    80004d82:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004d84:	00278713          	addi	a4,a5,2
    80004d88:	0712                	slli	a4,a4,0x4
    80004d8a:	9726                	add	a4,a4,s1
    80004d8c:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80004d90:	e321                	bnez	a4,80004dd0 <virtio_disk_intr+0x98>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004d92:	0789                	addi	a5,a5,2
    80004d94:	0792                	slli	a5,a5,0x4
    80004d96:	97a6                	add	a5,a5,s1
    80004d98:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004d9a:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004d9e:	f1efc0ef          	jal	ra,800014bc <wakeup>

    disk.used_idx += 1;
    80004da2:	0204d783          	lhu	a5,32(s1)
    80004da6:	2785                	addiw	a5,a5,1
    80004da8:	17c2                	slli	a5,a5,0x30
    80004daa:	93c1                	srli	a5,a5,0x30
    80004dac:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004db0:	6898                	ld	a4,16(s1)
    80004db2:	00275703          	lhu	a4,2(a4)
    80004db6:	faf71ee3          	bne	a4,a5,80004d72 <virtio_disk_intr+0x3a>
  }

  release(&disk.vdisk_lock);
    80004dba:	00014517          	auipc	a0,0x14
    80004dbe:	00e50513          	addi	a0,a0,14 # 80018dc8 <disk+0x128>
    80004dc2:	301000ef          	jal	ra,800058c2 <release>
}
    80004dc6:	60e2                	ld	ra,24(sp)
    80004dc8:	6442                	ld	s0,16(sp)
    80004dca:	64a2                	ld	s1,8(sp)
    80004dcc:	6105                	addi	sp,sp,32
    80004dce:	8082                	ret
      panic("virtio_disk_intr status");
    80004dd0:	00003517          	auipc	a0,0x3
    80004dd4:	ad050513          	addi	a0,a0,-1328 # 800078a0 <syscalls+0x448>
    80004dd8:	73e000ef          	jal	ra,80005516 <panic>

0000000080004ddc <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004ddc:	1141                	addi	sp,sp,-16
    80004dde:	e422                	sd	s0,8(sp)
    80004de0:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004de2:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004de6:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004dea:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004dee:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004df2:	577d                	li	a4,-1
    80004df4:	177e                	slli	a4,a4,0x3f
    80004df6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004df8:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004dfc:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004e00:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004e04:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004e08:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004e0c:	000f4737          	lui	a4,0xf4
    80004e10:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004e14:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004e16:	14d79073          	csrw	0x14d,a5
}
    80004e1a:	6422                	ld	s0,8(sp)
    80004e1c:	0141                	addi	sp,sp,16
    80004e1e:	8082                	ret

0000000080004e20 <start>:
{
    80004e20:	1141                	addi	sp,sp,-16
    80004e22:	e406                	sd	ra,8(sp)
    80004e24:	e022                	sd	s0,0(sp)
    80004e26:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004e28:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004e2c:	7779                	lui	a4,0xffffe
    80004e2e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd91f>
    80004e32:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004e34:	6705                	lui	a4,0x1
    80004e36:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004e3a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004e3c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004e40:	ffffb797          	auipc	a5,0xffffb
    80004e44:	4ae78793          	addi	a5,a5,1198 # 800002ee <main>
    80004e48:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004e4c:	4781                	li	a5,0
    80004e4e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004e52:	67c1                	lui	a5,0x10
    80004e54:	17fd                	addi	a5,a5,-1
    80004e56:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004e5a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004e5e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004e62:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004e66:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004e6a:	57fd                	li	a5,-1
    80004e6c:	83a9                	srli	a5,a5,0xa
    80004e6e:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004e72:	47bd                	li	a5,15
    80004e74:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004e78:	f65ff0ef          	jal	ra,80004ddc <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004e7c:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004e80:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004e82:	823e                	mv	tp,a5
  asm volatile("mret");
    80004e84:	30200073          	mret
}
    80004e88:	60a2                	ld	ra,8(sp)
    80004e8a:	6402                	ld	s0,0(sp)
    80004e8c:	0141                	addi	sp,sp,16
    80004e8e:	8082                	ret

0000000080004e90 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004e90:	715d                	addi	sp,sp,-80
    80004e92:	e486                	sd	ra,72(sp)
    80004e94:	e0a2                	sd	s0,64(sp)
    80004e96:	fc26                	sd	s1,56(sp)
    80004e98:	f84a                	sd	s2,48(sp)
    80004e9a:	f44e                	sd	s3,40(sp)
    80004e9c:	f052                	sd	s4,32(sp)
    80004e9e:	ec56                	sd	s5,24(sp)
    80004ea0:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80004ea2:	04c05263          	blez	a2,80004ee6 <consolewrite+0x56>
    80004ea6:	8a2a                	mv	s4,a0
    80004ea8:	84ae                	mv	s1,a1
    80004eaa:	89b2                	mv	s3,a2
    80004eac:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80004eae:	5afd                	li	s5,-1
    80004eb0:	4685                	li	a3,1
    80004eb2:	8626                	mv	a2,s1
    80004eb4:	85d2                	mv	a1,s4
    80004eb6:	fbf40513          	addi	a0,s0,-65
    80004eba:	95dfc0ef          	jal	ra,80001816 <either_copyin>
    80004ebe:	01550a63          	beq	a0,s5,80004ed2 <consolewrite+0x42>
      break;
    uartputc(c);
    80004ec2:	fbf44503          	lbu	a0,-65(s0)
    80004ec6:	7da000ef          	jal	ra,800056a0 <uartputc>
  for(i = 0; i < n; i++){
    80004eca:	2905                	addiw	s2,s2,1
    80004ecc:	0485                	addi	s1,s1,1
    80004ece:	ff2991e3          	bne	s3,s2,80004eb0 <consolewrite+0x20>
  }

  return i;
}
    80004ed2:	854a                	mv	a0,s2
    80004ed4:	60a6                	ld	ra,72(sp)
    80004ed6:	6406                	ld	s0,64(sp)
    80004ed8:	74e2                	ld	s1,56(sp)
    80004eda:	7942                	ld	s2,48(sp)
    80004edc:	79a2                	ld	s3,40(sp)
    80004ede:	7a02                	ld	s4,32(sp)
    80004ee0:	6ae2                	ld	s5,24(sp)
    80004ee2:	6161                	addi	sp,sp,80
    80004ee4:	8082                	ret
  for(i = 0; i < n; i++){
    80004ee6:	4901                	li	s2,0
    80004ee8:	b7ed                	j	80004ed2 <consolewrite+0x42>

0000000080004eea <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80004eea:	7159                	addi	sp,sp,-112
    80004eec:	f486                	sd	ra,104(sp)
    80004eee:	f0a2                	sd	s0,96(sp)
    80004ef0:	eca6                	sd	s1,88(sp)
    80004ef2:	e8ca                	sd	s2,80(sp)
    80004ef4:	e4ce                	sd	s3,72(sp)
    80004ef6:	e0d2                	sd	s4,64(sp)
    80004ef8:	fc56                	sd	s5,56(sp)
    80004efa:	f85a                	sd	s6,48(sp)
    80004efc:	f45e                	sd	s7,40(sp)
    80004efe:	f062                	sd	s8,32(sp)
    80004f00:	ec66                	sd	s9,24(sp)
    80004f02:	e86a                	sd	s10,16(sp)
    80004f04:	1880                	addi	s0,sp,112
    80004f06:	8aaa                	mv	s5,a0
    80004f08:	8a2e                	mv	s4,a1
    80004f0a:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80004f0c:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80004f10:	0001c517          	auipc	a0,0x1c
    80004f14:	ed050513          	addi	a0,a0,-304 # 80020de0 <cons>
    80004f18:	113000ef          	jal	ra,8000582a <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80004f1c:	0001c497          	auipc	s1,0x1c
    80004f20:	ec448493          	addi	s1,s1,-316 # 80020de0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80004f24:	0001c917          	auipc	s2,0x1c
    80004f28:	f5490913          	addi	s2,s2,-172 # 80020e78 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    80004f2c:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004f2e:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    80004f30:	4ca9                	li	s9,10
  while(n > 0){
    80004f32:	07305363          	blez	s3,80004f98 <consoleread+0xae>
    while(cons.r == cons.w){
    80004f36:	0984a783          	lw	a5,152(s1)
    80004f3a:	09c4a703          	lw	a4,156(s1)
    80004f3e:	02f71163          	bne	a4,a5,80004f60 <consoleread+0x76>
      if(killed(myproc())){
    80004f42:	ed9fb0ef          	jal	ra,80000e1a <myproc>
    80004f46:	f62fc0ef          	jal	ra,800016a8 <killed>
    80004f4a:	e125                	bnez	a0,80004faa <consoleread+0xc0>
      sleep(&cons.r, &cons.lock);
    80004f4c:	85a6                	mv	a1,s1
    80004f4e:	854a                	mv	a0,s2
    80004f50:	d20fc0ef          	jal	ra,80001470 <sleep>
    while(cons.r == cons.w){
    80004f54:	0984a783          	lw	a5,152(s1)
    80004f58:	09c4a703          	lw	a4,156(s1)
    80004f5c:	fef703e3          	beq	a4,a5,80004f42 <consoleread+0x58>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80004f60:	0017871b          	addiw	a4,a5,1
    80004f64:	08e4ac23          	sw	a4,152(s1)
    80004f68:	07f7f713          	andi	a4,a5,127
    80004f6c:	9726                	add	a4,a4,s1
    80004f6e:	01874703          	lbu	a4,24(a4)
    80004f72:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    80004f76:	057d0f63          	beq	s10,s7,80004fd4 <consoleread+0xea>
    cbuf = c;
    80004f7a:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004f7e:	4685                	li	a3,1
    80004f80:	f9f40613          	addi	a2,s0,-97
    80004f84:	85d2                	mv	a1,s4
    80004f86:	8556                	mv	a0,s5
    80004f88:	845fc0ef          	jal	ra,800017cc <either_copyout>
    80004f8c:	01850663          	beq	a0,s8,80004f98 <consoleread+0xae>
    dst++;
    80004f90:	0a05                	addi	s4,s4,1
    --n;
    80004f92:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    80004f94:	f99d1fe3          	bne	s10,s9,80004f32 <consoleread+0x48>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    80004f98:	0001c517          	auipc	a0,0x1c
    80004f9c:	e4850513          	addi	a0,a0,-440 # 80020de0 <cons>
    80004fa0:	123000ef          	jal	ra,800058c2 <release>

  return target - n;
    80004fa4:	413b053b          	subw	a0,s6,s3
    80004fa8:	a801                	j	80004fb8 <consoleread+0xce>
        release(&cons.lock);
    80004faa:	0001c517          	auipc	a0,0x1c
    80004fae:	e3650513          	addi	a0,a0,-458 # 80020de0 <cons>
    80004fb2:	111000ef          	jal	ra,800058c2 <release>
        return -1;
    80004fb6:	557d                	li	a0,-1
}
    80004fb8:	70a6                	ld	ra,104(sp)
    80004fba:	7406                	ld	s0,96(sp)
    80004fbc:	64e6                	ld	s1,88(sp)
    80004fbe:	6946                	ld	s2,80(sp)
    80004fc0:	69a6                	ld	s3,72(sp)
    80004fc2:	6a06                	ld	s4,64(sp)
    80004fc4:	7ae2                	ld	s5,56(sp)
    80004fc6:	7b42                	ld	s6,48(sp)
    80004fc8:	7ba2                	ld	s7,40(sp)
    80004fca:	7c02                	ld	s8,32(sp)
    80004fcc:	6ce2                	ld	s9,24(sp)
    80004fce:	6d42                	ld	s10,16(sp)
    80004fd0:	6165                	addi	sp,sp,112
    80004fd2:	8082                	ret
      if(n < target){
    80004fd4:	0009871b          	sext.w	a4,s3
    80004fd8:	fd6770e3          	bgeu	a4,s6,80004f98 <consoleread+0xae>
        cons.r--;
    80004fdc:	0001c717          	auipc	a4,0x1c
    80004fe0:	e8f72e23          	sw	a5,-356(a4) # 80020e78 <cons+0x98>
    80004fe4:	bf55                	j	80004f98 <consoleread+0xae>

0000000080004fe6 <consputc>:
{
    80004fe6:	1141                	addi	sp,sp,-16
    80004fe8:	e406                	sd	ra,8(sp)
    80004fea:	e022                	sd	s0,0(sp)
    80004fec:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80004fee:	10000793          	li	a5,256
    80004ff2:	00f50863          	beq	a0,a5,80005002 <consputc+0x1c>
    uartputc_sync(c);
    80004ff6:	5d4000ef          	jal	ra,800055ca <uartputc_sync>
}
    80004ffa:	60a2                	ld	ra,8(sp)
    80004ffc:	6402                	ld	s0,0(sp)
    80004ffe:	0141                	addi	sp,sp,16
    80005000:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80005002:	4521                	li	a0,8
    80005004:	5c6000ef          	jal	ra,800055ca <uartputc_sync>
    80005008:	02000513          	li	a0,32
    8000500c:	5be000ef          	jal	ra,800055ca <uartputc_sync>
    80005010:	4521                	li	a0,8
    80005012:	5b8000ef          	jal	ra,800055ca <uartputc_sync>
    80005016:	b7d5                	j	80004ffa <consputc+0x14>

0000000080005018 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005018:	1101                	addi	sp,sp,-32
    8000501a:	ec06                	sd	ra,24(sp)
    8000501c:	e822                	sd	s0,16(sp)
    8000501e:	e426                	sd	s1,8(sp)
    80005020:	e04a                	sd	s2,0(sp)
    80005022:	1000                	addi	s0,sp,32
    80005024:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80005026:	0001c517          	auipc	a0,0x1c
    8000502a:	dba50513          	addi	a0,a0,-582 # 80020de0 <cons>
    8000502e:	7fc000ef          	jal	ra,8000582a <acquire>

  switch(c){
    80005032:	47d5                	li	a5,21
    80005034:	0af48063          	beq	s1,a5,800050d4 <consoleintr+0xbc>
    80005038:	0297c663          	blt	a5,s1,80005064 <consoleintr+0x4c>
    8000503c:	47a1                	li	a5,8
    8000503e:	0cf48f63          	beq	s1,a5,8000511c <consoleintr+0x104>
    80005042:	47c1                	li	a5,16
    80005044:	10f49063          	bne	s1,a5,80005144 <consoleintr+0x12c>
  case C('P'):  // Print process list.
    procdump();
    80005048:	819fc0ef          	jal	ra,80001860 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    8000504c:	0001c517          	auipc	a0,0x1c
    80005050:	d9450513          	addi	a0,a0,-620 # 80020de0 <cons>
    80005054:	06f000ef          	jal	ra,800058c2 <release>
}
    80005058:	60e2                	ld	ra,24(sp)
    8000505a:	6442                	ld	s0,16(sp)
    8000505c:	64a2                	ld	s1,8(sp)
    8000505e:	6902                	ld	s2,0(sp)
    80005060:	6105                	addi	sp,sp,32
    80005062:	8082                	ret
  switch(c){
    80005064:	07f00793          	li	a5,127
    80005068:	0af48a63          	beq	s1,a5,8000511c <consoleintr+0x104>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    8000506c:	0001c717          	auipc	a4,0x1c
    80005070:	d7470713          	addi	a4,a4,-652 # 80020de0 <cons>
    80005074:	0a072783          	lw	a5,160(a4)
    80005078:	09872703          	lw	a4,152(a4)
    8000507c:	9f99                	subw	a5,a5,a4
    8000507e:	07f00713          	li	a4,127
    80005082:	fcf765e3          	bltu	a4,a5,8000504c <consoleintr+0x34>
      c = (c == '\r') ? '\n' : c;
    80005086:	47b5                	li	a5,13
    80005088:	0cf48163          	beq	s1,a5,8000514a <consoleintr+0x132>
      consputc(c);
    8000508c:	8526                	mv	a0,s1
    8000508e:	f59ff0ef          	jal	ra,80004fe6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005092:	0001c797          	auipc	a5,0x1c
    80005096:	d4e78793          	addi	a5,a5,-690 # 80020de0 <cons>
    8000509a:	0a07a683          	lw	a3,160(a5)
    8000509e:	0016871b          	addiw	a4,a3,1
    800050a2:	0007061b          	sext.w	a2,a4
    800050a6:	0ae7a023          	sw	a4,160(a5)
    800050aa:	07f6f693          	andi	a3,a3,127
    800050ae:	97b6                	add	a5,a5,a3
    800050b0:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    800050b4:	47a9                	li	a5,10
    800050b6:	0af48f63          	beq	s1,a5,80005174 <consoleintr+0x15c>
    800050ba:	4791                	li	a5,4
    800050bc:	0af48c63          	beq	s1,a5,80005174 <consoleintr+0x15c>
    800050c0:	0001c797          	auipc	a5,0x1c
    800050c4:	db87a783          	lw	a5,-584(a5) # 80020e78 <cons+0x98>
    800050c8:	9f1d                	subw	a4,a4,a5
    800050ca:	08000793          	li	a5,128
    800050ce:	f6f71fe3          	bne	a4,a5,8000504c <consoleintr+0x34>
    800050d2:	a04d                	j	80005174 <consoleintr+0x15c>
    while(cons.e != cons.w &&
    800050d4:	0001c717          	auipc	a4,0x1c
    800050d8:	d0c70713          	addi	a4,a4,-756 # 80020de0 <cons>
    800050dc:	0a072783          	lw	a5,160(a4)
    800050e0:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800050e4:	0001c497          	auipc	s1,0x1c
    800050e8:	cfc48493          	addi	s1,s1,-772 # 80020de0 <cons>
    while(cons.e != cons.w &&
    800050ec:	4929                	li	s2,10
    800050ee:	f4f70fe3          	beq	a4,a5,8000504c <consoleintr+0x34>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800050f2:	37fd                	addiw	a5,a5,-1
    800050f4:	07f7f713          	andi	a4,a5,127
    800050f8:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    800050fa:	01874703          	lbu	a4,24(a4)
    800050fe:	f52707e3          	beq	a4,s2,8000504c <consoleintr+0x34>
      cons.e--;
    80005102:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005106:	10000513          	li	a0,256
    8000510a:	eddff0ef          	jal	ra,80004fe6 <consputc>
    while(cons.e != cons.w &&
    8000510e:	0a04a783          	lw	a5,160(s1)
    80005112:	09c4a703          	lw	a4,156(s1)
    80005116:	fcf71ee3          	bne	a4,a5,800050f2 <consoleintr+0xda>
    8000511a:	bf0d                	j	8000504c <consoleintr+0x34>
    if(cons.e != cons.w){
    8000511c:	0001c717          	auipc	a4,0x1c
    80005120:	cc470713          	addi	a4,a4,-828 # 80020de0 <cons>
    80005124:	0a072783          	lw	a5,160(a4)
    80005128:	09c72703          	lw	a4,156(a4)
    8000512c:	f2f700e3          	beq	a4,a5,8000504c <consoleintr+0x34>
      cons.e--;
    80005130:	37fd                	addiw	a5,a5,-1
    80005132:	0001c717          	auipc	a4,0x1c
    80005136:	d4f72723          	sw	a5,-690(a4) # 80020e80 <cons+0xa0>
      consputc(BACKSPACE);
    8000513a:	10000513          	li	a0,256
    8000513e:	ea9ff0ef          	jal	ra,80004fe6 <consputc>
    80005142:	b729                	j	8000504c <consoleintr+0x34>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005144:	f00484e3          	beqz	s1,8000504c <consoleintr+0x34>
    80005148:	b715                	j	8000506c <consoleintr+0x54>
      consputc(c);
    8000514a:	4529                	li	a0,10
    8000514c:	e9bff0ef          	jal	ra,80004fe6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005150:	0001c797          	auipc	a5,0x1c
    80005154:	c9078793          	addi	a5,a5,-880 # 80020de0 <cons>
    80005158:	0a07a703          	lw	a4,160(a5)
    8000515c:	0017069b          	addiw	a3,a4,1
    80005160:	0006861b          	sext.w	a2,a3
    80005164:	0ad7a023          	sw	a3,160(a5)
    80005168:	07f77713          	andi	a4,a4,127
    8000516c:	97ba                	add	a5,a5,a4
    8000516e:	4729                	li	a4,10
    80005170:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80005174:	0001c797          	auipc	a5,0x1c
    80005178:	d0c7a423          	sw	a2,-760(a5) # 80020e7c <cons+0x9c>
        wakeup(&cons.r);
    8000517c:	0001c517          	auipc	a0,0x1c
    80005180:	cfc50513          	addi	a0,a0,-772 # 80020e78 <cons+0x98>
    80005184:	b38fc0ef          	jal	ra,800014bc <wakeup>
    80005188:	b5d1                	j	8000504c <consoleintr+0x34>

000000008000518a <consoleinit>:

void
consoleinit(void)
{
    8000518a:	1141                	addi	sp,sp,-16
    8000518c:	e406                	sd	ra,8(sp)
    8000518e:	e022                	sd	s0,0(sp)
    80005190:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80005192:	00002597          	auipc	a1,0x2
    80005196:	72658593          	addi	a1,a1,1830 # 800078b8 <syscalls+0x460>
    8000519a:	0001c517          	auipc	a0,0x1c
    8000519e:	c4650513          	addi	a0,a0,-954 # 80020de0 <cons>
    800051a2:	608000ef          	jal	ra,800057aa <initlock>

  uartinit();
    800051a6:	3d8000ef          	jal	ra,8000557e <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    800051aa:	00013797          	auipc	a5,0x13
    800051ae:	a9e78793          	addi	a5,a5,-1378 # 80017c48 <devsw>
    800051b2:	00000717          	auipc	a4,0x0
    800051b6:	d3870713          	addi	a4,a4,-712 # 80004eea <consoleread>
    800051ba:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800051bc:	00000717          	auipc	a4,0x0
    800051c0:	cd470713          	addi	a4,a4,-812 # 80004e90 <consolewrite>
    800051c4:	ef98                	sd	a4,24(a5)
}
    800051c6:	60a2                	ld	ra,8(sp)
    800051c8:	6402                	ld	s0,0(sp)
    800051ca:	0141                	addi	sp,sp,16
    800051cc:	8082                	ret

00000000800051ce <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    800051ce:	7179                	addi	sp,sp,-48
    800051d0:	f406                	sd	ra,40(sp)
    800051d2:	f022                	sd	s0,32(sp)
    800051d4:	ec26                	sd	s1,24(sp)
    800051d6:	e84a                	sd	s2,16(sp)
    800051d8:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    800051da:	c219                	beqz	a2,800051e0 <printint+0x12>
    800051dc:	06054f63          	bltz	a0,8000525a <printint+0x8c>
    x = -xx;
  else
    x = xx;
    800051e0:	4881                	li	a7,0
    800051e2:	fd040693          	addi	a3,s0,-48

  i = 0;
    800051e6:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    800051e8:	00002617          	auipc	a2,0x2
    800051ec:	6f860613          	addi	a2,a2,1784 # 800078e0 <digits>
    800051f0:	883e                	mv	a6,a5
    800051f2:	2785                	addiw	a5,a5,1
    800051f4:	02b57733          	remu	a4,a0,a1
    800051f8:	9732                	add	a4,a4,a2
    800051fa:	00074703          	lbu	a4,0(a4)
    800051fe:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80005202:	872a                	mv	a4,a0
    80005204:	02b55533          	divu	a0,a0,a1
    80005208:	0685                	addi	a3,a3,1
    8000520a:	feb773e3          	bgeu	a4,a1,800051f0 <printint+0x22>

  if(sign)
    8000520e:	00088b63          	beqz	a7,80005224 <printint+0x56>
    buf[i++] = '-';
    80005212:	fe040713          	addi	a4,s0,-32
    80005216:	97ba                	add	a5,a5,a4
    80005218:	02d00713          	li	a4,45
    8000521c:	fee78823          	sb	a4,-16(a5)
    80005220:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    80005224:	02f05563          	blez	a5,8000524e <printint+0x80>
    80005228:	fd040713          	addi	a4,s0,-48
    8000522c:	00f704b3          	add	s1,a4,a5
    80005230:	fff70913          	addi	s2,a4,-1
    80005234:	993e                	add	s2,s2,a5
    80005236:	37fd                	addiw	a5,a5,-1
    80005238:	1782                	slli	a5,a5,0x20
    8000523a:	9381                	srli	a5,a5,0x20
    8000523c:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    80005240:	fff4c503          	lbu	a0,-1(s1)
    80005244:	da3ff0ef          	jal	ra,80004fe6 <consputc>
  while(--i >= 0)
    80005248:	14fd                	addi	s1,s1,-1
    8000524a:	ff249be3          	bne	s1,s2,80005240 <printint+0x72>
}
    8000524e:	70a2                	ld	ra,40(sp)
    80005250:	7402                	ld	s0,32(sp)
    80005252:	64e2                	ld	s1,24(sp)
    80005254:	6942                	ld	s2,16(sp)
    80005256:	6145                	addi	sp,sp,48
    80005258:	8082                	ret
    x = -xx;
    8000525a:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000525e:	4885                	li	a7,1
    x = -xx;
    80005260:	b749                	j	800051e2 <printint+0x14>

0000000080005262 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    80005262:	7155                	addi	sp,sp,-208
    80005264:	e506                	sd	ra,136(sp)
    80005266:	e122                	sd	s0,128(sp)
    80005268:	fca6                	sd	s1,120(sp)
    8000526a:	f8ca                	sd	s2,112(sp)
    8000526c:	f4ce                	sd	s3,104(sp)
    8000526e:	f0d2                	sd	s4,96(sp)
    80005270:	ecd6                	sd	s5,88(sp)
    80005272:	e8da                	sd	s6,80(sp)
    80005274:	e4de                	sd	s7,72(sp)
    80005276:	e0e2                	sd	s8,64(sp)
    80005278:	fc66                	sd	s9,56(sp)
    8000527a:	f86a                	sd	s10,48(sp)
    8000527c:	f46e                	sd	s11,40(sp)
    8000527e:	0900                	addi	s0,sp,144
    80005280:	8a2a                	mv	s4,a0
    80005282:	e40c                	sd	a1,8(s0)
    80005284:	e810                	sd	a2,16(s0)
    80005286:	ec14                	sd	a3,24(s0)
    80005288:	f018                	sd	a4,32(s0)
    8000528a:	f41c                	sd	a5,40(s0)
    8000528c:	03043823          	sd	a6,48(s0)
    80005290:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    80005294:	0001c797          	auipc	a5,0x1c
    80005298:	c0c7a783          	lw	a5,-1012(a5) # 80020ea0 <pr+0x18>
    8000529c:	f6f43c23          	sd	a5,-136(s0)
  if(locking)
    800052a0:	eb9d                	bnez	a5,800052d6 <printf+0x74>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800052a2:	00840793          	addi	a5,s0,8
    800052a6:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800052aa:	00054503          	lbu	a0,0(a0)
    800052ae:	24050463          	beqz	a0,800054f6 <printf+0x294>
    800052b2:	4981                	li	s3,0
    if(cx != '%'){
    800052b4:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    800052b8:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    800052bc:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800052c0:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    800052c4:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    800052c8:	07000d93          	li	s11,112
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800052cc:	00002b97          	auipc	s7,0x2
    800052d0:	614b8b93          	addi	s7,s7,1556 # 800078e0 <digits>
    800052d4:	a081                	j	80005314 <printf+0xb2>
    acquire(&pr.lock);
    800052d6:	0001c517          	auipc	a0,0x1c
    800052da:	bb250513          	addi	a0,a0,-1102 # 80020e88 <pr>
    800052de:	54c000ef          	jal	ra,8000582a <acquire>
  va_start(ap, fmt);
    800052e2:	00840793          	addi	a5,s0,8
    800052e6:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800052ea:	000a4503          	lbu	a0,0(s4)
    800052ee:	f171                	bnez	a0,800052b2 <printf+0x50>
#endif
  }
  va_end(ap);

  if(locking)
    release(&pr.lock);
    800052f0:	0001c517          	auipc	a0,0x1c
    800052f4:	b9850513          	addi	a0,a0,-1128 # 80020e88 <pr>
    800052f8:	5ca000ef          	jal	ra,800058c2 <release>
    800052fc:	aaed                	j	800054f6 <printf+0x294>
      consputc(cx);
    800052fe:	ce9ff0ef          	jal	ra,80004fe6 <consputc>
      continue;
    80005302:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005304:	0014899b          	addiw	s3,s1,1
    80005308:	013a07b3          	add	a5,s4,s3
    8000530c:	0007c503          	lbu	a0,0(a5)
    80005310:	1c050f63          	beqz	a0,800054ee <printf+0x28c>
    if(cx != '%'){
    80005314:	ff5515e3          	bne	a0,s5,800052fe <printf+0x9c>
    i++;
    80005318:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000531c:	009a07b3          	add	a5,s4,s1
    80005320:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005324:	1c090563          	beqz	s2,800054ee <printf+0x28c>
    80005328:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000532c:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    8000532e:	c789                	beqz	a5,80005338 <printf+0xd6>
    80005330:	009a0733          	add	a4,s4,s1
    80005334:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    80005338:	03690463          	beq	s2,s6,80005360 <printf+0xfe>
    } else if(c0 == 'l' && c1 == 'd'){
    8000533c:	03890e63          	beq	s2,s8,80005378 <printf+0x116>
    } else if(c0 == 'u'){
    80005340:	0b990d63          	beq	s2,s9,800053fa <printf+0x198>
    } else if(c0 == 'x'){
    80005344:	11a90363          	beq	s2,s10,8000544a <printf+0x1e8>
    } else if(c0 == 'p'){
    80005348:	13b90b63          	beq	s2,s11,8000547e <printf+0x21c>
    } else if(c0 == 's'){
    8000534c:	07300793          	li	a5,115
    80005350:	16f90363          	beq	s2,a5,800054b6 <printf+0x254>
    } else if(c0 == '%'){
    80005354:	03591c63          	bne	s2,s5,8000538c <printf+0x12a>
      consputc('%');
    80005358:	8556                	mv	a0,s5
    8000535a:	c8dff0ef          	jal	ra,80004fe6 <consputc>
    8000535e:	b75d                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, int), 10, 1);
    80005360:	f8843783          	ld	a5,-120(s0)
    80005364:	00878713          	addi	a4,a5,8
    80005368:	f8e43423          	sd	a4,-120(s0)
    8000536c:	4605                	li	a2,1
    8000536e:	45a9                	li	a1,10
    80005370:	4388                	lw	a0,0(a5)
    80005372:	e5dff0ef          	jal	ra,800051ce <printint>
    80005376:	b779                	j	80005304 <printf+0xa2>
    } else if(c0 == 'l' && c1 == 'd'){
    80005378:	03678163          	beq	a5,s6,8000539a <printf+0x138>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000537c:	03878d63          	beq	a5,s8,800053b6 <printf+0x154>
    } else if(c0 == 'l' && c1 == 'u'){
    80005380:	09978963          	beq	a5,s9,80005412 <printf+0x1b0>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005384:	03878b63          	beq	a5,s8,800053ba <printf+0x158>
    } else if(c0 == 'l' && c1 == 'x'){
    80005388:	0da78d63          	beq	a5,s10,80005462 <printf+0x200>
      consputc('%');
    8000538c:	8556                	mv	a0,s5
    8000538e:	c59ff0ef          	jal	ra,80004fe6 <consputc>
      consputc(c0);
    80005392:	854a                	mv	a0,s2
    80005394:	c53ff0ef          	jal	ra,80004fe6 <consputc>
    80005398:	b7b5                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 1);
    8000539a:	f8843783          	ld	a5,-120(s0)
    8000539e:	00878713          	addi	a4,a5,8
    800053a2:	f8e43423          	sd	a4,-120(s0)
    800053a6:	4605                	li	a2,1
    800053a8:	45a9                	li	a1,10
    800053aa:	6388                	ld	a0,0(a5)
    800053ac:	e23ff0ef          	jal	ra,800051ce <printint>
      i += 1;
    800053b0:	0029849b          	addiw	s1,s3,2
    800053b4:	bf81                	j	80005304 <printf+0xa2>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800053b6:	03668463          	beq	a3,s6,800053de <printf+0x17c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800053ba:	07968a63          	beq	a3,s9,8000542e <printf+0x1cc>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800053be:	fda697e3          	bne	a3,s10,8000538c <printf+0x12a>
      printint(va_arg(ap, uint64), 16, 0);
    800053c2:	f8843783          	ld	a5,-120(s0)
    800053c6:	00878713          	addi	a4,a5,8
    800053ca:	f8e43423          	sd	a4,-120(s0)
    800053ce:	4601                	li	a2,0
    800053d0:	45c1                	li	a1,16
    800053d2:	6388                	ld	a0,0(a5)
    800053d4:	dfbff0ef          	jal	ra,800051ce <printint>
      i += 2;
    800053d8:	0039849b          	addiw	s1,s3,3
    800053dc:	b725                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 1);
    800053de:	f8843783          	ld	a5,-120(s0)
    800053e2:	00878713          	addi	a4,a5,8
    800053e6:	f8e43423          	sd	a4,-120(s0)
    800053ea:	4605                	li	a2,1
    800053ec:	45a9                	li	a1,10
    800053ee:	6388                	ld	a0,0(a5)
    800053f0:	ddfff0ef          	jal	ra,800051ce <printint>
      i += 2;
    800053f4:	0039849b          	addiw	s1,s3,3
    800053f8:	b731                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, int), 10, 0);
    800053fa:	f8843783          	ld	a5,-120(s0)
    800053fe:	00878713          	addi	a4,a5,8
    80005402:	f8e43423          	sd	a4,-120(s0)
    80005406:	4601                	li	a2,0
    80005408:	45a9                	li	a1,10
    8000540a:	4388                	lw	a0,0(a5)
    8000540c:	dc3ff0ef          	jal	ra,800051ce <printint>
    80005410:	bdd5                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 0);
    80005412:	f8843783          	ld	a5,-120(s0)
    80005416:	00878713          	addi	a4,a5,8
    8000541a:	f8e43423          	sd	a4,-120(s0)
    8000541e:	4601                	li	a2,0
    80005420:	45a9                	li	a1,10
    80005422:	6388                	ld	a0,0(a5)
    80005424:	dabff0ef          	jal	ra,800051ce <printint>
      i += 1;
    80005428:	0029849b          	addiw	s1,s3,2
    8000542c:	bde1                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 0);
    8000542e:	f8843783          	ld	a5,-120(s0)
    80005432:	00878713          	addi	a4,a5,8
    80005436:	f8e43423          	sd	a4,-120(s0)
    8000543a:	4601                	li	a2,0
    8000543c:	45a9                	li	a1,10
    8000543e:	6388                	ld	a0,0(a5)
    80005440:	d8fff0ef          	jal	ra,800051ce <printint>
      i += 2;
    80005444:	0039849b          	addiw	s1,s3,3
    80005448:	bd75                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, int), 16, 0);
    8000544a:	f8843783          	ld	a5,-120(s0)
    8000544e:	00878713          	addi	a4,a5,8
    80005452:	f8e43423          	sd	a4,-120(s0)
    80005456:	4601                	li	a2,0
    80005458:	45c1                	li	a1,16
    8000545a:	4388                	lw	a0,0(a5)
    8000545c:	d73ff0ef          	jal	ra,800051ce <printint>
    80005460:	b555                	j	80005304 <printf+0xa2>
      printint(va_arg(ap, uint64), 16, 0);
    80005462:	f8843783          	ld	a5,-120(s0)
    80005466:	00878713          	addi	a4,a5,8
    8000546a:	f8e43423          	sd	a4,-120(s0)
    8000546e:	4601                	li	a2,0
    80005470:	45c1                	li	a1,16
    80005472:	6388                	ld	a0,0(a5)
    80005474:	d5bff0ef          	jal	ra,800051ce <printint>
      i += 1;
    80005478:	0029849b          	addiw	s1,s3,2
    8000547c:	b561                	j	80005304 <printf+0xa2>
      printptr(va_arg(ap, uint64));
    8000547e:	f8843783          	ld	a5,-120(s0)
    80005482:	00878713          	addi	a4,a5,8
    80005486:	f8e43423          	sd	a4,-120(s0)
    8000548a:	0007b983          	ld	s3,0(a5)
  consputc('0');
    8000548e:	03000513          	li	a0,48
    80005492:	b55ff0ef          	jal	ra,80004fe6 <consputc>
  consputc('x');
    80005496:	856a                	mv	a0,s10
    80005498:	b4fff0ef          	jal	ra,80004fe6 <consputc>
    8000549c:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000549e:	03c9d793          	srli	a5,s3,0x3c
    800054a2:	97de                	add	a5,a5,s7
    800054a4:	0007c503          	lbu	a0,0(a5)
    800054a8:	b3fff0ef          	jal	ra,80004fe6 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800054ac:	0992                	slli	s3,s3,0x4
    800054ae:	397d                	addiw	s2,s2,-1
    800054b0:	fe0917e3          	bnez	s2,8000549e <printf+0x23c>
    800054b4:	bd81                	j	80005304 <printf+0xa2>
      if((s = va_arg(ap, char*)) == 0)
    800054b6:	f8843783          	ld	a5,-120(s0)
    800054ba:	00878713          	addi	a4,a5,8
    800054be:	f8e43423          	sd	a4,-120(s0)
    800054c2:	0007b903          	ld	s2,0(a5)
    800054c6:	00090d63          	beqz	s2,800054e0 <printf+0x27e>
      for(; *s; s++)
    800054ca:	00094503          	lbu	a0,0(s2)
    800054ce:	e2050be3          	beqz	a0,80005304 <printf+0xa2>
        consputc(*s);
    800054d2:	b15ff0ef          	jal	ra,80004fe6 <consputc>
      for(; *s; s++)
    800054d6:	0905                	addi	s2,s2,1
    800054d8:	00094503          	lbu	a0,0(s2)
    800054dc:	f97d                	bnez	a0,800054d2 <printf+0x270>
    800054de:	b51d                	j	80005304 <printf+0xa2>
        s = "(null)";
    800054e0:	00002917          	auipc	s2,0x2
    800054e4:	3e090913          	addi	s2,s2,992 # 800078c0 <syscalls+0x468>
      for(; *s; s++)
    800054e8:	02800513          	li	a0,40
    800054ec:	b7dd                	j	800054d2 <printf+0x270>
  if(locking)
    800054ee:	f7843783          	ld	a5,-136(s0)
    800054f2:	de079fe3          	bnez	a5,800052f0 <printf+0x8e>

  return 0;
}
    800054f6:	4501                	li	a0,0
    800054f8:	60aa                	ld	ra,136(sp)
    800054fa:	640a                	ld	s0,128(sp)
    800054fc:	74e6                	ld	s1,120(sp)
    800054fe:	7946                	ld	s2,112(sp)
    80005500:	79a6                	ld	s3,104(sp)
    80005502:	7a06                	ld	s4,96(sp)
    80005504:	6ae6                	ld	s5,88(sp)
    80005506:	6b46                	ld	s6,80(sp)
    80005508:	6ba6                	ld	s7,72(sp)
    8000550a:	6c06                	ld	s8,64(sp)
    8000550c:	7ce2                	ld	s9,56(sp)
    8000550e:	7d42                	ld	s10,48(sp)
    80005510:	7da2                	ld	s11,40(sp)
    80005512:	6169                	addi	sp,sp,208
    80005514:	8082                	ret

0000000080005516 <panic>:

void
panic(char *s)
{
    80005516:	1101                	addi	sp,sp,-32
    80005518:	ec06                	sd	ra,24(sp)
    8000551a:	e822                	sd	s0,16(sp)
    8000551c:	e426                	sd	s1,8(sp)
    8000551e:	1000                	addi	s0,sp,32
    80005520:	84aa                	mv	s1,a0
  pr.locking = 0;
    80005522:	0001c797          	auipc	a5,0x1c
    80005526:	9607af23          	sw	zero,-1666(a5) # 80020ea0 <pr+0x18>
  printf("panic: ");
    8000552a:	00002517          	auipc	a0,0x2
    8000552e:	39e50513          	addi	a0,a0,926 # 800078c8 <syscalls+0x470>
    80005532:	d31ff0ef          	jal	ra,80005262 <printf>
  printf("%s\n", s);
    80005536:	85a6                	mv	a1,s1
    80005538:	00002517          	auipc	a0,0x2
    8000553c:	39850513          	addi	a0,a0,920 # 800078d0 <syscalls+0x478>
    80005540:	d23ff0ef          	jal	ra,80005262 <printf>
  panicked = 1; // freeze uart output from other CPUs
    80005544:	4785                	li	a5,1
    80005546:	00002717          	auipc	a4,0x2
    8000554a:	44f72b23          	sw	a5,1110(a4) # 8000799c <panicked>
  for(;;)
    8000554e:	a001                	j	8000554e <panic+0x38>

0000000080005550 <printfinit>:
    ;
}

void
printfinit(void)
{
    80005550:	1101                	addi	sp,sp,-32
    80005552:	ec06                	sd	ra,24(sp)
    80005554:	e822                	sd	s0,16(sp)
    80005556:	e426                	sd	s1,8(sp)
    80005558:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    8000555a:	0001c497          	auipc	s1,0x1c
    8000555e:	92e48493          	addi	s1,s1,-1746 # 80020e88 <pr>
    80005562:	00002597          	auipc	a1,0x2
    80005566:	37658593          	addi	a1,a1,886 # 800078d8 <syscalls+0x480>
    8000556a:	8526                	mv	a0,s1
    8000556c:	23e000ef          	jal	ra,800057aa <initlock>
  pr.locking = 1;
    80005570:	4785                	li	a5,1
    80005572:	cc9c                	sw	a5,24(s1)
}
    80005574:	60e2                	ld	ra,24(sp)
    80005576:	6442                	ld	s0,16(sp)
    80005578:	64a2                	ld	s1,8(sp)
    8000557a:	6105                	addi	sp,sp,32
    8000557c:	8082                	ret

000000008000557e <uartinit>:

void uartstart();

void
uartinit(void)
{
    8000557e:	1141                	addi	sp,sp,-16
    80005580:	e406                	sd	ra,8(sp)
    80005582:	e022                	sd	s0,0(sp)
    80005584:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80005586:	100007b7          	lui	a5,0x10000
    8000558a:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    8000558e:	f8000713          	li	a4,-128
    80005592:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80005596:	470d                	li	a4,3
    80005598:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000559c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800055a0:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800055a4:	469d                	li	a3,7
    800055a6:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800055aa:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    800055ae:	00002597          	auipc	a1,0x2
    800055b2:	34a58593          	addi	a1,a1,842 # 800078f8 <digits+0x18>
    800055b6:	0001c517          	auipc	a0,0x1c
    800055ba:	8f250513          	addi	a0,a0,-1806 # 80020ea8 <uart_tx_lock>
    800055be:	1ec000ef          	jal	ra,800057aa <initlock>
}
    800055c2:	60a2                	ld	ra,8(sp)
    800055c4:	6402                	ld	s0,0(sp)
    800055c6:	0141                	addi	sp,sp,16
    800055c8:	8082                	ret

00000000800055ca <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800055ca:	1101                	addi	sp,sp,-32
    800055cc:	ec06                	sd	ra,24(sp)
    800055ce:	e822                	sd	s0,16(sp)
    800055d0:	e426                	sd	s1,8(sp)
    800055d2:	1000                	addi	s0,sp,32
    800055d4:	84aa                	mv	s1,a0
  push_off();
    800055d6:	214000ef          	jal	ra,800057ea <push_off>

  if(panicked){
    800055da:	00002797          	auipc	a5,0x2
    800055de:	3c27a783          	lw	a5,962(a5) # 8000799c <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800055e2:	10000737          	lui	a4,0x10000
  if(panicked){
    800055e6:	c391                	beqz	a5,800055ea <uartputc_sync+0x20>
    for(;;)
    800055e8:	a001                	j	800055e8 <uartputc_sync+0x1e>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800055ea:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    800055ee:	0207f793          	andi	a5,a5,32
    800055f2:	dfe5                	beqz	a5,800055ea <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    800055f4:	0ff4f513          	zext.b	a0,s1
    800055f8:	100007b7          	lui	a5,0x10000
    800055fc:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80005600:	26e000ef          	jal	ra,8000586e <pop_off>
}
    80005604:	60e2                	ld	ra,24(sp)
    80005606:	6442                	ld	s0,16(sp)
    80005608:	64a2                	ld	s1,8(sp)
    8000560a:	6105                	addi	sp,sp,32
    8000560c:	8082                	ret

000000008000560e <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    8000560e:	00002797          	auipc	a5,0x2
    80005612:	3927b783          	ld	a5,914(a5) # 800079a0 <uart_tx_r>
    80005616:	00002717          	auipc	a4,0x2
    8000561a:	39273703          	ld	a4,914(a4) # 800079a8 <uart_tx_w>
    8000561e:	06f70c63          	beq	a4,a5,80005696 <uartstart+0x88>
{
    80005622:	7139                	addi	sp,sp,-64
    80005624:	fc06                	sd	ra,56(sp)
    80005626:	f822                	sd	s0,48(sp)
    80005628:	f426                	sd	s1,40(sp)
    8000562a:	f04a                	sd	s2,32(sp)
    8000562c:	ec4e                	sd	s3,24(sp)
    8000562e:	e852                	sd	s4,16(sp)
    80005630:	e456                	sd	s5,8(sp)
    80005632:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005634:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005638:	0001ca17          	auipc	s4,0x1c
    8000563c:	870a0a13          	addi	s4,s4,-1936 # 80020ea8 <uart_tx_lock>
    uart_tx_r += 1;
    80005640:	00002497          	auipc	s1,0x2
    80005644:	36048493          	addi	s1,s1,864 # 800079a0 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80005648:	00002997          	auipc	s3,0x2
    8000564c:	36098993          	addi	s3,s3,864 # 800079a8 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005650:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    80005654:	02077713          	andi	a4,a4,32
    80005658:	c715                	beqz	a4,80005684 <uartstart+0x76>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000565a:	01f7f713          	andi	a4,a5,31
    8000565e:	9752                	add	a4,a4,s4
    80005660:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    80005664:	0785                	addi	a5,a5,1
    80005666:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80005668:	8526                	mv	a0,s1
    8000566a:	e53fb0ef          	jal	ra,800014bc <wakeup>
    
    WriteReg(THR, c);
    8000566e:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    80005672:	609c                	ld	a5,0(s1)
    80005674:	0009b703          	ld	a4,0(s3)
    80005678:	fcf71ce3          	bne	a4,a5,80005650 <uartstart+0x42>
      ReadReg(ISR);
    8000567c:	100007b7          	lui	a5,0x10000
    80005680:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005684:	70e2                	ld	ra,56(sp)
    80005686:	7442                	ld	s0,48(sp)
    80005688:	74a2                	ld	s1,40(sp)
    8000568a:	7902                	ld	s2,32(sp)
    8000568c:	69e2                	ld	s3,24(sp)
    8000568e:	6a42                	ld	s4,16(sp)
    80005690:	6aa2                	ld	s5,8(sp)
    80005692:	6121                	addi	sp,sp,64
    80005694:	8082                	ret
      ReadReg(ISR);
    80005696:	100007b7          	lui	a5,0x10000
    8000569a:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    8000569e:	8082                	ret

00000000800056a0 <uartputc>:
{
    800056a0:	7179                	addi	sp,sp,-48
    800056a2:	f406                	sd	ra,40(sp)
    800056a4:	f022                	sd	s0,32(sp)
    800056a6:	ec26                	sd	s1,24(sp)
    800056a8:	e84a                	sd	s2,16(sp)
    800056aa:	e44e                	sd	s3,8(sp)
    800056ac:	e052                	sd	s4,0(sp)
    800056ae:	1800                	addi	s0,sp,48
    800056b0:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800056b2:	0001b517          	auipc	a0,0x1b
    800056b6:	7f650513          	addi	a0,a0,2038 # 80020ea8 <uart_tx_lock>
    800056ba:	170000ef          	jal	ra,8000582a <acquire>
  if(panicked){
    800056be:	00002797          	auipc	a5,0x2
    800056c2:	2de7a783          	lw	a5,734(a5) # 8000799c <panicked>
    800056c6:	efbd                	bnez	a5,80005744 <uartputc+0xa4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056c8:	00002717          	auipc	a4,0x2
    800056cc:	2e073703          	ld	a4,736(a4) # 800079a8 <uart_tx_w>
    800056d0:	00002797          	auipc	a5,0x2
    800056d4:	2d07b783          	ld	a5,720(a5) # 800079a0 <uart_tx_r>
    800056d8:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800056dc:	0001b997          	auipc	s3,0x1b
    800056e0:	7cc98993          	addi	s3,s3,1996 # 80020ea8 <uart_tx_lock>
    800056e4:	00002497          	auipc	s1,0x2
    800056e8:	2bc48493          	addi	s1,s1,700 # 800079a0 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056ec:	00002917          	auipc	s2,0x2
    800056f0:	2bc90913          	addi	s2,s2,700 # 800079a8 <uart_tx_w>
    800056f4:	00e79d63          	bne	a5,a4,8000570e <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800056f8:	85ce                	mv	a1,s3
    800056fa:	8526                	mv	a0,s1
    800056fc:	d75fb0ef          	jal	ra,80001470 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005700:	00093703          	ld	a4,0(s2)
    80005704:	609c                	ld	a5,0(s1)
    80005706:	02078793          	addi	a5,a5,32
    8000570a:	fee787e3          	beq	a5,a4,800056f8 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    8000570e:	0001b497          	auipc	s1,0x1b
    80005712:	79a48493          	addi	s1,s1,1946 # 80020ea8 <uart_tx_lock>
    80005716:	01f77793          	andi	a5,a4,31
    8000571a:	97a6                	add	a5,a5,s1
    8000571c:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80005720:	0705                	addi	a4,a4,1
    80005722:	00002797          	auipc	a5,0x2
    80005726:	28e7b323          	sd	a4,646(a5) # 800079a8 <uart_tx_w>
  uartstart();
    8000572a:	ee5ff0ef          	jal	ra,8000560e <uartstart>
  release(&uart_tx_lock);
    8000572e:	8526                	mv	a0,s1
    80005730:	192000ef          	jal	ra,800058c2 <release>
}
    80005734:	70a2                	ld	ra,40(sp)
    80005736:	7402                	ld	s0,32(sp)
    80005738:	64e2                	ld	s1,24(sp)
    8000573a:	6942                	ld	s2,16(sp)
    8000573c:	69a2                	ld	s3,8(sp)
    8000573e:	6a02                	ld	s4,0(sp)
    80005740:	6145                	addi	sp,sp,48
    80005742:	8082                	ret
    for(;;)
    80005744:	a001                	j	80005744 <uartputc+0xa4>

0000000080005746 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80005746:	1141                	addi	sp,sp,-16
    80005748:	e422                	sd	s0,8(sp)
    8000574a:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    8000574c:	100007b7          	lui	a5,0x10000
    80005750:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80005754:	8b85                	andi	a5,a5,1
    80005756:	cb91                	beqz	a5,8000576a <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80005758:	100007b7          	lui	a5,0x10000
    8000575c:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    80005760:	0ff57513          	zext.b	a0,a0
  } else {
    return -1;
  }
}
    80005764:	6422                	ld	s0,8(sp)
    80005766:	0141                	addi	sp,sp,16
    80005768:	8082                	ret
    return -1;
    8000576a:	557d                	li	a0,-1
    8000576c:	bfe5                	j	80005764 <uartgetc+0x1e>

000000008000576e <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000576e:	1101                	addi	sp,sp,-32
    80005770:	ec06                	sd	ra,24(sp)
    80005772:	e822                	sd	s0,16(sp)
    80005774:	e426                	sd	s1,8(sp)
    80005776:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80005778:	54fd                	li	s1,-1
    8000577a:	a019                	j	80005780 <uartintr+0x12>
      break;
    consoleintr(c);
    8000577c:	89dff0ef          	jal	ra,80005018 <consoleintr>
    int c = uartgetc();
    80005780:	fc7ff0ef          	jal	ra,80005746 <uartgetc>
    if(c == -1)
    80005784:	fe951ce3          	bne	a0,s1,8000577c <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80005788:	0001b497          	auipc	s1,0x1b
    8000578c:	72048493          	addi	s1,s1,1824 # 80020ea8 <uart_tx_lock>
    80005790:	8526                	mv	a0,s1
    80005792:	098000ef          	jal	ra,8000582a <acquire>
  uartstart();
    80005796:	e79ff0ef          	jal	ra,8000560e <uartstart>
  release(&uart_tx_lock);
    8000579a:	8526                	mv	a0,s1
    8000579c:	126000ef          	jal	ra,800058c2 <release>
}
    800057a0:	60e2                	ld	ra,24(sp)
    800057a2:	6442                	ld	s0,16(sp)
    800057a4:	64a2                	ld	s1,8(sp)
    800057a6:	6105                	addi	sp,sp,32
    800057a8:	8082                	ret

00000000800057aa <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    800057aa:	1141                	addi	sp,sp,-16
    800057ac:	e422                	sd	s0,8(sp)
    800057ae:	0800                	addi	s0,sp,16
  lk->name = name;
    800057b0:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    800057b2:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    800057b6:	00053823          	sd	zero,16(a0)
}
    800057ba:	6422                	ld	s0,8(sp)
    800057bc:	0141                	addi	sp,sp,16
    800057be:	8082                	ret

00000000800057c0 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    800057c0:	411c                	lw	a5,0(a0)
    800057c2:	e399                	bnez	a5,800057c8 <holding+0x8>
    800057c4:	4501                	li	a0,0
  return r;
}
    800057c6:	8082                	ret
{
    800057c8:	1101                	addi	sp,sp,-32
    800057ca:	ec06                	sd	ra,24(sp)
    800057cc:	e822                	sd	s0,16(sp)
    800057ce:	e426                	sd	s1,8(sp)
    800057d0:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800057d2:	6904                	ld	s1,16(a0)
    800057d4:	e2afb0ef          	jal	ra,80000dfe <mycpu>
    800057d8:	40a48533          	sub	a0,s1,a0
    800057dc:	00153513          	seqz	a0,a0
}
    800057e0:	60e2                	ld	ra,24(sp)
    800057e2:	6442                	ld	s0,16(sp)
    800057e4:	64a2                	ld	s1,8(sp)
    800057e6:	6105                	addi	sp,sp,32
    800057e8:	8082                	ret

00000000800057ea <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800057ea:	1101                	addi	sp,sp,-32
    800057ec:	ec06                	sd	ra,24(sp)
    800057ee:	e822                	sd	s0,16(sp)
    800057f0:	e426                	sd	s1,8(sp)
    800057f2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800057f4:	100024f3          	csrr	s1,sstatus
    800057f8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800057fc:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800057fe:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80005802:	dfcfb0ef          	jal	ra,80000dfe <mycpu>
    80005806:	5d3c                	lw	a5,120(a0)
    80005808:	cb99                	beqz	a5,8000581e <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    8000580a:	df4fb0ef          	jal	ra,80000dfe <mycpu>
    8000580e:	5d3c                	lw	a5,120(a0)
    80005810:	2785                	addiw	a5,a5,1
    80005812:	dd3c                	sw	a5,120(a0)
}
    80005814:	60e2                	ld	ra,24(sp)
    80005816:	6442                	ld	s0,16(sp)
    80005818:	64a2                	ld	s1,8(sp)
    8000581a:	6105                	addi	sp,sp,32
    8000581c:	8082                	ret
    mycpu()->intena = old;
    8000581e:	de0fb0ef          	jal	ra,80000dfe <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80005822:	8085                	srli	s1,s1,0x1
    80005824:	8885                	andi	s1,s1,1
    80005826:	dd64                	sw	s1,124(a0)
    80005828:	b7cd                	j	8000580a <push_off+0x20>

000000008000582a <acquire>:
{
    8000582a:	1101                	addi	sp,sp,-32
    8000582c:	ec06                	sd	ra,24(sp)
    8000582e:	e822                	sd	s0,16(sp)
    80005830:	e426                	sd	s1,8(sp)
    80005832:	1000                	addi	s0,sp,32
    80005834:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80005836:	fb5ff0ef          	jal	ra,800057ea <push_off>
  if(holding(lk))
    8000583a:	8526                	mv	a0,s1
    8000583c:	f85ff0ef          	jal	ra,800057c0 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005840:	4705                	li	a4,1
  if(holding(lk))
    80005842:	e105                	bnez	a0,80005862 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005844:	87ba                	mv	a5,a4
    80005846:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    8000584a:	2781                	sext.w	a5,a5
    8000584c:	ffe5                	bnez	a5,80005844 <acquire+0x1a>
  __sync_synchronize();
    8000584e:	0ff0000f          	fence
  lk->cpu = mycpu();
    80005852:	dacfb0ef          	jal	ra,80000dfe <mycpu>
    80005856:	e888                	sd	a0,16(s1)
}
    80005858:	60e2                	ld	ra,24(sp)
    8000585a:	6442                	ld	s0,16(sp)
    8000585c:	64a2                	ld	s1,8(sp)
    8000585e:	6105                	addi	sp,sp,32
    80005860:	8082                	ret
    panic("acquire");
    80005862:	00002517          	auipc	a0,0x2
    80005866:	09e50513          	addi	a0,a0,158 # 80007900 <digits+0x20>
    8000586a:	cadff0ef          	jal	ra,80005516 <panic>

000000008000586e <pop_off>:

void
pop_off(void)
{
    8000586e:	1141                	addi	sp,sp,-16
    80005870:	e406                	sd	ra,8(sp)
    80005872:	e022                	sd	s0,0(sp)
    80005874:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005876:	d88fb0ef          	jal	ra,80000dfe <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000587a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000587e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005880:	e78d                	bnez	a5,800058aa <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005882:	5d3c                	lw	a5,120(a0)
    80005884:	02f05963          	blez	a5,800058b6 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80005888:	37fd                	addiw	a5,a5,-1
    8000588a:	0007871b          	sext.w	a4,a5
    8000588e:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80005890:	eb09                	bnez	a4,800058a2 <pop_off+0x34>
    80005892:	5d7c                	lw	a5,124(a0)
    80005894:	c799                	beqz	a5,800058a2 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005896:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000589a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000589e:	10079073          	csrw	sstatus,a5
    intr_on();
}
    800058a2:	60a2                	ld	ra,8(sp)
    800058a4:	6402                	ld	s0,0(sp)
    800058a6:	0141                	addi	sp,sp,16
    800058a8:	8082                	ret
    panic("pop_off - interruptible");
    800058aa:	00002517          	auipc	a0,0x2
    800058ae:	05e50513          	addi	a0,a0,94 # 80007908 <digits+0x28>
    800058b2:	c65ff0ef          	jal	ra,80005516 <panic>
    panic("pop_off");
    800058b6:	00002517          	auipc	a0,0x2
    800058ba:	06a50513          	addi	a0,a0,106 # 80007920 <digits+0x40>
    800058be:	c59ff0ef          	jal	ra,80005516 <panic>

00000000800058c2 <release>:
{
    800058c2:	1101                	addi	sp,sp,-32
    800058c4:	ec06                	sd	ra,24(sp)
    800058c6:	e822                	sd	s0,16(sp)
    800058c8:	e426                	sd	s1,8(sp)
    800058ca:	1000                	addi	s0,sp,32
    800058cc:	84aa                	mv	s1,a0
  if(!holding(lk))
    800058ce:	ef3ff0ef          	jal	ra,800057c0 <holding>
    800058d2:	c105                	beqz	a0,800058f2 <release+0x30>
  lk->cpu = 0;
    800058d4:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    800058d8:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    800058dc:	0f50000f          	fence	iorw,ow
    800058e0:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    800058e4:	f8bff0ef          	jal	ra,8000586e <pop_off>
}
    800058e8:	60e2                	ld	ra,24(sp)
    800058ea:	6442                	ld	s0,16(sp)
    800058ec:	64a2                	ld	s1,8(sp)
    800058ee:	6105                	addi	sp,sp,32
    800058f0:	8082                	ret
    panic("release");
    800058f2:	00002517          	auipc	a0,0x2
    800058f6:	03650513          	addi	a0,a0,54 # 80007928 <digits+0x48>
    800058fa:	c1dff0ef          	jal	ra,80005516 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
