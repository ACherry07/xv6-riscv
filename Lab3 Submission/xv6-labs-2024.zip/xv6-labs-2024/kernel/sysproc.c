#include "types.h"
#include "riscv.h"
#include "param.h"
#include "defs.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;


  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}


#ifdef LAB_PGTBL
int
sys_pgpte(void)
{
  uint64 va;
  struct proc *p;  

  p = myproc();
  argaddr(0, &va);
  pte_t *pte = pgpte(p->pagetable, va);
  if(pte != 0) {
      return (uint64) *pte;
  }
  return 0;
}
#endif

#ifdef LAB_PGTBL
int
sys_kpgtbl(void)
{
  struct proc *p;  

  p = myproc();
  vmprint(p->pagetable);
  return 0;
}
#endif


uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}


//This code was added by Ashish CS23B099
uint64
sys_pgaccess(void){
  uint64 base;
  int len;
  uint64 mask;
  argaddr(0,&base);
  argint(1,&len);
  argaddr(2,&mask);

  if(len > 32) // since pgaccess return an int, keep len atmost 32
    len = 32;

  struct proc *p = myproc();
  unsigned int abits = 0; //no bits are assigned initially
  for(int i = 0; i < len; i++){
    pagetable_t pagetable = p->pagetable; //getting the process pagetable
    uint64 va = base + i * PGSIZE; //finding the corresponding virtual address
    pte_t *pte = walk(pagetable, va, 0); //getting the pte for the virtual address
    if(pte && (*pte & PTE_V) && (*pte & PTE_A)){ //ensure pte is not null and then check for valid and accessed bit
      abits |= (1 << i);
      *pte &= ~PTE_A; // set accessed bit to 0;
    }
  }
  if(copyout(p->pagetable,mask,(char*)&abits,sizeof(abits)) < 0)
    return -1;
  return 0;
}
//Added code ends here