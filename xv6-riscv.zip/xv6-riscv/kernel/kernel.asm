
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	9c010113          	addi	sp,sp,-1600 # 800079c0 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04a000ef          	jal	ra,80000060 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	0x14d,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd917>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	e3c78793          	addi	a5,a5,-452 # 80000ebc <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a2:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	ra,8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	715d                	addi	sp,sp,-80
    800000d2:	e486                	sd	ra,72(sp)
    800000d4:	e0a2                	sd	s0,64(sp)
    800000d6:	fc26                	sd	s1,56(sp)
    800000d8:	f84a                	sd	s2,48(sp)
    800000da:	f44e                	sd	s3,40(sp)
    800000dc:	f052                	sd	s4,32(sp)
    800000de:	ec56                	sd	s5,24(sp)
    800000e0:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    800000e2:	04c05263          	blez	a2,80000126 <consolewrite+0x56>
    800000e6:	8a2a                	mv	s4,a0
    800000e8:	84ae                	mv	s1,a1
    800000ea:	89b2                	mv	s3,a2
    800000ec:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    800000ee:	5afd                	li	s5,-1
    800000f0:	4685                	li	a3,1
    800000f2:	8626                	mv	a2,s1
    800000f4:	85d2                	mv	a1,s4
    800000f6:	fbf40513          	addi	a0,s0,-65
    800000fa:	170020ef          	jal	ra,8000226a <either_copyin>
    800000fe:	01550a63          	beq	a0,s5,80000112 <consolewrite+0x42>
      break;
    uartputc(c);
    80000102:	fbf44503          	lbu	a0,-65(s0)
    80000106:	045000ef          	jal	ra,8000094a <uartputc>
  for(i = 0; i < n; i++){
    8000010a:	2905                	addiw	s2,s2,1
    8000010c:	0485                	addi	s1,s1,1
    8000010e:	ff2991e3          	bne	s3,s2,800000f0 <consolewrite+0x20>
  }

  return i;
}
    80000112:	854a                	mv	a0,s2
    80000114:	60a6                	ld	ra,72(sp)
    80000116:	6406                	ld	s0,64(sp)
    80000118:	74e2                	ld	s1,56(sp)
    8000011a:	7942                	ld	s2,48(sp)
    8000011c:	79a2                	ld	s3,40(sp)
    8000011e:	7a02                	ld	s4,32(sp)
    80000120:	6ae2                	ld	s5,24(sp)
    80000122:	6161                	addi	sp,sp,80
    80000124:	8082                	ret
  for(i = 0; i < n; i++){
    80000126:	4901                	li	s2,0
    80000128:	b7ed                	j	80000112 <consolewrite+0x42>

000000008000012a <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000012a:	7159                	addi	sp,sp,-112
    8000012c:	f486                	sd	ra,104(sp)
    8000012e:	f0a2                	sd	s0,96(sp)
    80000130:	eca6                	sd	s1,88(sp)
    80000132:	e8ca                	sd	s2,80(sp)
    80000134:	e4ce                	sd	s3,72(sp)
    80000136:	e0d2                	sd	s4,64(sp)
    80000138:	fc56                	sd	s5,56(sp)
    8000013a:	f85a                	sd	s6,48(sp)
    8000013c:	f45e                	sd	s7,40(sp)
    8000013e:	f062                	sd	s8,32(sp)
    80000140:	ec66                	sd	s9,24(sp)
    80000142:	e86a                	sd	s10,16(sp)
    80000144:	1880                	addi	s0,sp,112
    80000146:	8aaa                	mv	s5,a0
    80000148:	8a2e                	mv	s4,a1
    8000014a:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    8000014c:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80000150:	00010517          	auipc	a0,0x10
    80000154:	87050513          	addi	a0,a0,-1936 # 8000f9c0 <cons>
    80000158:	2ef000ef          	jal	ra,80000c46 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000015c:	00010497          	auipc	s1,0x10
    80000160:	86448493          	addi	s1,s1,-1948 # 8000f9c0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000164:	00010917          	auipc	s2,0x10
    80000168:	8f490913          	addi	s2,s2,-1804 # 8000fa58 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    8000016c:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    8000016e:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    80000170:	4ca9                	li	s9,10
  while(n > 0){
    80000172:	07305363          	blez	s3,800001d8 <consoleread+0xae>
    while(cons.r == cons.w){
    80000176:	0984a783          	lw	a5,152(s1)
    8000017a:	09c4a703          	lw	a4,156(s1)
    8000017e:	02f71163          	bne	a4,a5,800001a0 <consoleread+0x76>
      if(killed(myproc())){
    80000182:	75c010ef          	jal	ra,800018de <myproc>
    80000186:	777010ef          	jal	ra,800020fc <killed>
    8000018a:	e125                	bnez	a0,800001ea <consoleread+0xc0>
      sleep(&cons.r, &cons.lock);
    8000018c:	85a6                	mv	a1,s1
    8000018e:	854a                	mv	a0,s2
    80000190:	535010ef          	jal	ra,80001ec4 <sleep>
    while(cons.r == cons.w){
    80000194:	0984a783          	lw	a5,152(s1)
    80000198:	09c4a703          	lw	a4,156(s1)
    8000019c:	fef703e3          	beq	a4,a5,80000182 <consoleread+0x58>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001a0:	0017871b          	addiw	a4,a5,1
    800001a4:	08e4ac23          	sw	a4,152(s1)
    800001a8:	07f7f713          	andi	a4,a5,127
    800001ac:	9726                	add	a4,a4,s1
    800001ae:	01874703          	lbu	a4,24(a4)
    800001b2:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    800001b6:	057d0f63          	beq	s10,s7,80000214 <consoleread+0xea>
    cbuf = c;
    800001ba:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001be:	4685                	li	a3,1
    800001c0:	f9f40613          	addi	a2,s0,-97
    800001c4:	85d2                	mv	a1,s4
    800001c6:	8556                	mv	a0,s5
    800001c8:	058020ef          	jal	ra,80002220 <either_copyout>
    800001cc:	01850663          	beq	a0,s8,800001d8 <consoleread+0xae>
    dst++;
    800001d0:	0a05                	addi	s4,s4,1
    --n;
    800001d2:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    800001d4:	f99d1fe3          	bne	s10,s9,80000172 <consoleread+0x48>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    800001d8:	0000f517          	auipc	a0,0xf
    800001dc:	7e850513          	addi	a0,a0,2024 # 8000f9c0 <cons>
    800001e0:	2ff000ef          	jal	ra,80000cde <release>

  return target - n;
    800001e4:	413b053b          	subw	a0,s6,s3
    800001e8:	a801                	j	800001f8 <consoleread+0xce>
        release(&cons.lock);
    800001ea:	0000f517          	auipc	a0,0xf
    800001ee:	7d650513          	addi	a0,a0,2006 # 8000f9c0 <cons>
    800001f2:	2ed000ef          	jal	ra,80000cde <release>
        return -1;
    800001f6:	557d                	li	a0,-1
}
    800001f8:	70a6                	ld	ra,104(sp)
    800001fa:	7406                	ld	s0,96(sp)
    800001fc:	64e6                	ld	s1,88(sp)
    800001fe:	6946                	ld	s2,80(sp)
    80000200:	69a6                	ld	s3,72(sp)
    80000202:	6a06                	ld	s4,64(sp)
    80000204:	7ae2                	ld	s5,56(sp)
    80000206:	7b42                	ld	s6,48(sp)
    80000208:	7ba2                	ld	s7,40(sp)
    8000020a:	7c02                	ld	s8,32(sp)
    8000020c:	6ce2                	ld	s9,24(sp)
    8000020e:	6d42                	ld	s10,16(sp)
    80000210:	6165                	addi	sp,sp,112
    80000212:	8082                	ret
      if(n < target){
    80000214:	0009871b          	sext.w	a4,s3
    80000218:	fd6770e3          	bgeu	a4,s6,800001d8 <consoleread+0xae>
        cons.r--;
    8000021c:	00010717          	auipc	a4,0x10
    80000220:	82f72e23          	sw	a5,-1988(a4) # 8000fa58 <cons+0x98>
    80000224:	bf55                	j	800001d8 <consoleread+0xae>

0000000080000226 <consputc>:
{
    80000226:	1141                	addi	sp,sp,-16
    80000228:	e406                	sd	ra,8(sp)
    8000022a:	e022                	sd	s0,0(sp)
    8000022c:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    8000022e:	10000793          	li	a5,256
    80000232:	00f50863          	beq	a0,a5,80000242 <consputc+0x1c>
    uartputc_sync(c);
    80000236:	636000ef          	jal	ra,8000086c <uartputc_sync>
}
    8000023a:	60a2                	ld	ra,8(sp)
    8000023c:	6402                	ld	s0,0(sp)
    8000023e:	0141                	addi	sp,sp,16
    80000240:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000242:	4521                	li	a0,8
    80000244:	628000ef          	jal	ra,8000086c <uartputc_sync>
    80000248:	02000513          	li	a0,32
    8000024c:	620000ef          	jal	ra,8000086c <uartputc_sync>
    80000250:	4521                	li	a0,8
    80000252:	61a000ef          	jal	ra,8000086c <uartputc_sync>
    80000256:	b7d5                	j	8000023a <consputc+0x14>

0000000080000258 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80000258:	1101                	addi	sp,sp,-32
    8000025a:	ec06                	sd	ra,24(sp)
    8000025c:	e822                	sd	s0,16(sp)
    8000025e:	e426                	sd	s1,8(sp)
    80000260:	e04a                	sd	s2,0(sp)
    80000262:	1000                	addi	s0,sp,32
    80000264:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80000266:	0000f517          	auipc	a0,0xf
    8000026a:	75a50513          	addi	a0,a0,1882 # 8000f9c0 <cons>
    8000026e:	1d9000ef          	jal	ra,80000c46 <acquire>

  switch(c){
    80000272:	47d5                	li	a5,21
    80000274:	0af48063          	beq	s1,a5,80000314 <consoleintr+0xbc>
    80000278:	0297c663          	blt	a5,s1,800002a4 <consoleintr+0x4c>
    8000027c:	47a1                	li	a5,8
    8000027e:	0cf48f63          	beq	s1,a5,8000035c <consoleintr+0x104>
    80000282:	47c1                	li	a5,16
    80000284:	10f49063          	bne	s1,a5,80000384 <consoleintr+0x12c>
  case C('P'):  // Print process list.
    procdump();
    80000288:	02c020ef          	jal	ra,800022b4 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    8000028c:	0000f517          	auipc	a0,0xf
    80000290:	73450513          	addi	a0,a0,1844 # 8000f9c0 <cons>
    80000294:	24b000ef          	jal	ra,80000cde <release>
}
    80000298:	60e2                	ld	ra,24(sp)
    8000029a:	6442                	ld	s0,16(sp)
    8000029c:	64a2                	ld	s1,8(sp)
    8000029e:	6902                	ld	s2,0(sp)
    800002a0:	6105                	addi	sp,sp,32
    800002a2:	8082                	ret
  switch(c){
    800002a4:	07f00793          	li	a5,127
    800002a8:	0af48a63          	beq	s1,a5,8000035c <consoleintr+0x104>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002ac:	0000f717          	auipc	a4,0xf
    800002b0:	71470713          	addi	a4,a4,1812 # 8000f9c0 <cons>
    800002b4:	0a072783          	lw	a5,160(a4)
    800002b8:	09872703          	lw	a4,152(a4)
    800002bc:	9f99                	subw	a5,a5,a4
    800002be:	07f00713          	li	a4,127
    800002c2:	fcf765e3          	bltu	a4,a5,8000028c <consoleintr+0x34>
      c = (c == '\r') ? '\n' : c;
    800002c6:	47b5                	li	a5,13
    800002c8:	0cf48163          	beq	s1,a5,8000038a <consoleintr+0x132>
      consputc(c);
    800002cc:	8526                	mv	a0,s1
    800002ce:	f59ff0ef          	jal	ra,80000226 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002d2:	0000f797          	auipc	a5,0xf
    800002d6:	6ee78793          	addi	a5,a5,1774 # 8000f9c0 <cons>
    800002da:	0a07a683          	lw	a3,160(a5)
    800002de:	0016871b          	addiw	a4,a3,1
    800002e2:	0007061b          	sext.w	a2,a4
    800002e6:	0ae7a023          	sw	a4,160(a5)
    800002ea:	07f6f693          	andi	a3,a3,127
    800002ee:	97b6                	add	a5,a5,a3
    800002f0:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    800002f4:	47a9                	li	a5,10
    800002f6:	0af48f63          	beq	s1,a5,800003b4 <consoleintr+0x15c>
    800002fa:	4791                	li	a5,4
    800002fc:	0af48c63          	beq	s1,a5,800003b4 <consoleintr+0x15c>
    80000300:	0000f797          	auipc	a5,0xf
    80000304:	7587a783          	lw	a5,1880(a5) # 8000fa58 <cons+0x98>
    80000308:	9f1d                	subw	a4,a4,a5
    8000030a:	08000793          	li	a5,128
    8000030e:	f6f71fe3          	bne	a4,a5,8000028c <consoleintr+0x34>
    80000312:	a04d                	j	800003b4 <consoleintr+0x15c>
    while(cons.e != cons.w &&
    80000314:	0000f717          	auipc	a4,0xf
    80000318:	6ac70713          	addi	a4,a4,1708 # 8000f9c0 <cons>
    8000031c:	0a072783          	lw	a5,160(a4)
    80000320:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000324:	0000f497          	auipc	s1,0xf
    80000328:	69c48493          	addi	s1,s1,1692 # 8000f9c0 <cons>
    while(cons.e != cons.w &&
    8000032c:	4929                	li	s2,10
    8000032e:	f4f70fe3          	beq	a4,a5,8000028c <consoleintr+0x34>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000332:	37fd                	addiw	a5,a5,-1
    80000334:	07f7f713          	andi	a4,a5,127
    80000338:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000033a:	01874703          	lbu	a4,24(a4)
    8000033e:	f52707e3          	beq	a4,s2,8000028c <consoleintr+0x34>
      cons.e--;
    80000342:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000346:	10000513          	li	a0,256
    8000034a:	eddff0ef          	jal	ra,80000226 <consputc>
    while(cons.e != cons.w &&
    8000034e:	0a04a783          	lw	a5,160(s1)
    80000352:	09c4a703          	lw	a4,156(s1)
    80000356:	fcf71ee3          	bne	a4,a5,80000332 <consoleintr+0xda>
    8000035a:	bf0d                	j	8000028c <consoleintr+0x34>
    if(cons.e != cons.w){
    8000035c:	0000f717          	auipc	a4,0xf
    80000360:	66470713          	addi	a4,a4,1636 # 8000f9c0 <cons>
    80000364:	0a072783          	lw	a5,160(a4)
    80000368:	09c72703          	lw	a4,156(a4)
    8000036c:	f2f700e3          	beq	a4,a5,8000028c <consoleintr+0x34>
      cons.e--;
    80000370:	37fd                	addiw	a5,a5,-1
    80000372:	0000f717          	auipc	a4,0xf
    80000376:	6ef72723          	sw	a5,1774(a4) # 8000fa60 <cons+0xa0>
      consputc(BACKSPACE);
    8000037a:	10000513          	li	a0,256
    8000037e:	ea9ff0ef          	jal	ra,80000226 <consputc>
    80000382:	b729                	j	8000028c <consoleintr+0x34>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000384:	f00484e3          	beqz	s1,8000028c <consoleintr+0x34>
    80000388:	b715                	j	800002ac <consoleintr+0x54>
      consputc(c);
    8000038a:	4529                	li	a0,10
    8000038c:	e9bff0ef          	jal	ra,80000226 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000390:	0000f797          	auipc	a5,0xf
    80000394:	63078793          	addi	a5,a5,1584 # 8000f9c0 <cons>
    80000398:	0a07a703          	lw	a4,160(a5)
    8000039c:	0017069b          	addiw	a3,a4,1
    800003a0:	0006861b          	sext.w	a2,a3
    800003a4:	0ad7a023          	sw	a3,160(a5)
    800003a8:	07f77713          	andi	a4,a4,127
    800003ac:	97ba                	add	a5,a5,a4
    800003ae:	4729                	li	a4,10
    800003b0:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003b4:	0000f797          	auipc	a5,0xf
    800003b8:	6ac7a423          	sw	a2,1704(a5) # 8000fa5c <cons+0x9c>
        wakeup(&cons.r);
    800003bc:	0000f517          	auipc	a0,0xf
    800003c0:	69c50513          	addi	a0,a0,1692 # 8000fa58 <cons+0x98>
    800003c4:	34d010ef          	jal	ra,80001f10 <wakeup>
    800003c8:	b5d1                	j	8000028c <consoleintr+0x34>

00000000800003ca <consoleinit>:

void
consoleinit(void)
{
    800003ca:	1141                	addi	sp,sp,-16
    800003cc:	e406                	sd	ra,8(sp)
    800003ce:	e022                	sd	s0,0(sp)
    800003d0:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800003d2:	00007597          	auipc	a1,0x7
    800003d6:	c3e58593          	addi	a1,a1,-962 # 80007010 <etext+0x10>
    800003da:	0000f517          	auipc	a0,0xf
    800003de:	5e650513          	addi	a0,a0,1510 # 8000f9c0 <cons>
    800003e2:	7e4000ef          	jal	ra,80000bc6 <initlock>

  uartinit();
    800003e6:	43a000ef          	jal	ra,80000820 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    800003ea:	00020797          	auipc	a5,0x20
    800003ee:	96678793          	addi	a5,a5,-1690 # 8001fd50 <devsw>
    800003f2:	00000717          	auipc	a4,0x0
    800003f6:	d3870713          	addi	a4,a4,-712 # 8000012a <consoleread>
    800003fa:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800003fc:	00000717          	auipc	a4,0x0
    80000400:	cd470713          	addi	a4,a4,-812 # 800000d0 <consolewrite>
    80000404:	ef98                	sd	a4,24(a5)
}
    80000406:	60a2                	ld	ra,8(sp)
    80000408:	6402                	ld	s0,0(sp)
    8000040a:	0141                	addi	sp,sp,16
    8000040c:	8082                	ret

000000008000040e <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    8000040e:	7139                	addi	sp,sp,-64
    80000410:	fc06                	sd	ra,56(sp)
    80000412:	f822                	sd	s0,48(sp)
    80000414:	f426                	sd	s1,40(sp)
    80000416:	f04a                	sd	s2,32(sp)
    80000418:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000041a:	c219                	beqz	a2,80000420 <printint+0x12>
    8000041c:	06054f63          	bltz	a0,8000049a <printint+0x8c>
    x = -xx;
  else
    x = xx;
    80000420:	4881                	li	a7,0
    80000422:	fc840693          	addi	a3,s0,-56

  i = 0;
    80000426:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    80000428:	00007617          	auipc	a2,0x7
    8000042c:	c2860613          	addi	a2,a2,-984 # 80007050 <digits>
    80000430:	883e                	mv	a6,a5
    80000432:	2785                	addiw	a5,a5,1
    80000434:	02b57733          	remu	a4,a0,a1
    80000438:	9732                	add	a4,a4,a2
    8000043a:	00074703          	lbu	a4,0(a4)
    8000043e:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000442:	872a                	mv	a4,a0
    80000444:	02b55533          	divu	a0,a0,a1
    80000448:	0685                	addi	a3,a3,1
    8000044a:	feb773e3          	bgeu	a4,a1,80000430 <printint+0x22>

  if(sign)
    8000044e:	00088b63          	beqz	a7,80000464 <printint+0x56>
    buf[i++] = '-';
    80000452:	fe040713          	addi	a4,s0,-32
    80000456:	97ba                	add	a5,a5,a4
    80000458:	02d00713          	li	a4,45
    8000045c:	fee78423          	sb	a4,-24(a5)
    80000460:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    80000464:	02f05563          	blez	a5,8000048e <printint+0x80>
    80000468:	fc840713          	addi	a4,s0,-56
    8000046c:	00f704b3          	add	s1,a4,a5
    80000470:	fff70913          	addi	s2,a4,-1
    80000474:	993e                	add	s2,s2,a5
    80000476:	37fd                	addiw	a5,a5,-1
    80000478:	1782                	slli	a5,a5,0x20
    8000047a:	9381                	srli	a5,a5,0x20
    8000047c:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    80000480:	fff4c503          	lbu	a0,-1(s1)
    80000484:	da3ff0ef          	jal	ra,80000226 <consputc>
  while(--i >= 0)
    80000488:	14fd                	addi	s1,s1,-1
    8000048a:	ff249be3          	bne	s1,s2,80000480 <printint+0x72>
}
    8000048e:	70e2                	ld	ra,56(sp)
    80000490:	7442                	ld	s0,48(sp)
    80000492:	74a2                	ld	s1,40(sp)
    80000494:	7902                	ld	s2,32(sp)
    80000496:	6121                	addi	sp,sp,64
    80000498:	8082                	ret
    x = -xx;
    8000049a:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000049e:	4885                	li	a7,1
    x = -xx;
    800004a0:	b749                	j	80000422 <printint+0x14>

00000000800004a2 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004a2:	7131                	addi	sp,sp,-192
    800004a4:	fc86                	sd	ra,120(sp)
    800004a6:	f8a2                	sd	s0,112(sp)
    800004a8:	f4a6                	sd	s1,104(sp)
    800004aa:	f0ca                	sd	s2,96(sp)
    800004ac:	ecce                	sd	s3,88(sp)
    800004ae:	e8d2                	sd	s4,80(sp)
    800004b0:	e4d6                	sd	s5,72(sp)
    800004b2:	e0da                	sd	s6,64(sp)
    800004b4:	fc5e                	sd	s7,56(sp)
    800004b6:	f862                	sd	s8,48(sp)
    800004b8:	f466                	sd	s9,40(sp)
    800004ba:	f06a                	sd	s10,32(sp)
    800004bc:	ec6e                	sd	s11,24(sp)
    800004be:	0100                	addi	s0,sp,128
    800004c0:	8a2a                	mv	s4,a0
    800004c2:	e40c                	sd	a1,8(s0)
    800004c4:	e810                	sd	a2,16(s0)
    800004c6:	ec14                	sd	a3,24(s0)
    800004c8:	f018                	sd	a4,32(s0)
    800004ca:	f41c                	sd	a5,40(s0)
    800004cc:	03043823          	sd	a6,48(s0)
    800004d0:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    800004d4:	00007797          	auipc	a5,0x7
    800004d8:	4b07a783          	lw	a5,1200(a5) # 80007984 <panicking>
    800004dc:	cb9d                	beqz	a5,80000512 <printf+0x70>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800004de:	00840793          	addi	a5,s0,8
    800004e2:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800004e6:	000a4503          	lbu	a0,0(s4)
    800004ea:	24050363          	beqz	a0,80000730 <printf+0x28e>
    800004ee:	4981                	li	s3,0
    if(cx != '%'){
    800004f0:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    800004f4:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    800004f8:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800004fc:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000500:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000504:	07000d93          	li	s11,112
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000508:	00007b97          	auipc	s7,0x7
    8000050c:	b48b8b93          	addi	s7,s7,-1208 # 80007050 <digits>
    80000510:	a01d                	j	80000536 <printf+0x94>
    acquire(&pr.lock);
    80000512:	0000f517          	auipc	a0,0xf
    80000516:	55650513          	addi	a0,a0,1366 # 8000fa68 <pr>
    8000051a:	72c000ef          	jal	ra,80000c46 <acquire>
    8000051e:	b7c1                	j	800004de <printf+0x3c>
      consputc(cx);
    80000520:	d07ff0ef          	jal	ra,80000226 <consputc>
      continue;
    80000524:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000526:	0014899b          	addiw	s3,s1,1
    8000052a:	013a07b3          	add	a5,s4,s3
    8000052e:	0007c503          	lbu	a0,0(a5)
    80000532:	1e050f63          	beqz	a0,80000730 <printf+0x28e>
    if(cx != '%'){
    80000536:	ff5515e3          	bne	a0,s5,80000520 <printf+0x7e>
    i++;
    8000053a:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000053e:	009a07b3          	add	a5,s4,s1
    80000542:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000546:	1e090563          	beqz	s2,80000730 <printf+0x28e>
    8000054a:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000054e:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    80000550:	c789                	beqz	a5,8000055a <printf+0xb8>
    80000552:	009a0733          	add	a4,s4,s1
    80000556:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    8000055a:	03690863          	beq	s2,s6,8000058a <printf+0xe8>
    } else if(c0 == 'l' && c1 == 'd'){
    8000055e:	05890263          	beq	s2,s8,800005a2 <printf+0x100>
    } else if(c0 == 'u'){
    80000562:	0d990163          	beq	s2,s9,80000624 <printf+0x182>
    } else if(c0 == 'x'){
    80000566:	11a90863          	beq	s2,s10,80000676 <printf+0x1d4>
    } else if(c0 == 'p'){
    8000056a:	15b90163          	beq	s2,s11,800006ac <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    8000056e:	06300793          	li	a5,99
    80000572:	16f90963          	beq	s2,a5,800006e4 <printf+0x242>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    80000576:	07300793          	li	a5,115
    8000057a:	16f90f63          	beq	s2,a5,800006f8 <printf+0x256>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    8000057e:	03591c63          	bne	s2,s5,800005b6 <printf+0x114>
      consputc('%');
    80000582:	8556                	mv	a0,s5
    80000584:	ca3ff0ef          	jal	ra,80000226 <consputc>
    80000588:	bf79                	j	80000526 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    8000058a:	f8843783          	ld	a5,-120(s0)
    8000058e:	00878713          	addi	a4,a5,8
    80000592:	f8e43423          	sd	a4,-120(s0)
    80000596:	4605                	li	a2,1
    80000598:	45a9                	li	a1,10
    8000059a:	4388                	lw	a0,0(a5)
    8000059c:	e73ff0ef          	jal	ra,8000040e <printint>
    800005a0:	b759                	j	80000526 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	03678163          	beq	a5,s6,800005c4 <printf+0x122>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005a6:	03878d63          	beq	a5,s8,800005e0 <printf+0x13e>
    } else if(c0 == 'l' && c1 == 'u'){
    800005aa:	09978a63          	beq	a5,s9,8000063e <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800005ae:	03878b63          	beq	a5,s8,800005e4 <printf+0x142>
    } else if(c0 == 'l' && c1 == 'x'){
    800005b2:	0da78f63          	beq	a5,s10,80000690 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    800005b6:	8556                	mv	a0,s5
    800005b8:	c6fff0ef          	jal	ra,80000226 <consputc>
      consputc(c0);
    800005bc:	854a                	mv	a0,s2
    800005be:	c69ff0ef          	jal	ra,80000226 <consputc>
    800005c2:	b795                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    800005c4:	f8843783          	ld	a5,-120(s0)
    800005c8:	00878713          	addi	a4,a5,8
    800005cc:	f8e43423          	sd	a4,-120(s0)
    800005d0:	4605                	li	a2,1
    800005d2:	45a9                	li	a1,10
    800005d4:	6388                	ld	a0,0(a5)
    800005d6:	e39ff0ef          	jal	ra,8000040e <printint>
      i += 1;
    800005da:	0029849b          	addiw	s1,s3,2
    800005de:	b7a1                	j	80000526 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005e0:	03668463          	beq	a3,s6,80000608 <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800005e4:	07968b63          	beq	a3,s9,8000065a <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800005e8:	fda697e3          	bne	a3,s10,800005b6 <printf+0x114>
      printint(va_arg(ap, uint64), 16, 0);
    800005ec:	f8843783          	ld	a5,-120(s0)
    800005f0:	00878713          	addi	a4,a5,8
    800005f4:	f8e43423          	sd	a4,-120(s0)
    800005f8:	4601                	li	a2,0
    800005fa:	45c1                	li	a1,16
    800005fc:	6388                	ld	a0,0(a5)
    800005fe:	e11ff0ef          	jal	ra,8000040e <printint>
      i += 2;
    80000602:	0039849b          	addiw	s1,s3,3
    80000606:	b705                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    80000608:	f8843783          	ld	a5,-120(s0)
    8000060c:	00878713          	addi	a4,a5,8
    80000610:	f8e43423          	sd	a4,-120(s0)
    80000614:	4605                	li	a2,1
    80000616:	45a9                	li	a1,10
    80000618:	6388                	ld	a0,0(a5)
    8000061a:	df5ff0ef          	jal	ra,8000040e <printint>
      i += 2;
    8000061e:	0039849b          	addiw	s1,s3,3
    80000622:	b711                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint32), 10, 0);
    80000624:	f8843783          	ld	a5,-120(s0)
    80000628:	00878713          	addi	a4,a5,8
    8000062c:	f8e43423          	sd	a4,-120(s0)
    80000630:	4601                	li	a2,0
    80000632:	45a9                	li	a1,10
    80000634:	0007e503          	lwu	a0,0(a5)
    80000638:	dd7ff0ef          	jal	ra,8000040e <printint>
    8000063c:	b5ed                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    8000063e:	f8843783          	ld	a5,-120(s0)
    80000642:	00878713          	addi	a4,a5,8
    80000646:	f8e43423          	sd	a4,-120(s0)
    8000064a:	4601                	li	a2,0
    8000064c:	45a9                	li	a1,10
    8000064e:	6388                	ld	a0,0(a5)
    80000650:	dbfff0ef          	jal	ra,8000040e <printint>
      i += 1;
    80000654:	0029849b          	addiw	s1,s3,2
    80000658:	b5f9                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    8000065a:	f8843783          	ld	a5,-120(s0)
    8000065e:	00878713          	addi	a4,a5,8
    80000662:	f8e43423          	sd	a4,-120(s0)
    80000666:	4601                	li	a2,0
    80000668:	45a9                	li	a1,10
    8000066a:	6388                	ld	a0,0(a5)
    8000066c:	da3ff0ef          	jal	ra,8000040e <printint>
      i += 2;
    80000670:	0039849b          	addiw	s1,s3,3
    80000674:	bd4d                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint32), 16, 0);
    80000676:	f8843783          	ld	a5,-120(s0)
    8000067a:	00878713          	addi	a4,a5,8
    8000067e:	f8e43423          	sd	a4,-120(s0)
    80000682:	4601                	li	a2,0
    80000684:	45c1                	li	a1,16
    80000686:	0007e503          	lwu	a0,0(a5)
    8000068a:	d85ff0ef          	jal	ra,8000040e <printint>
    8000068e:	bd61                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 16, 0);
    80000690:	f8843783          	ld	a5,-120(s0)
    80000694:	00878713          	addi	a4,a5,8
    80000698:	f8e43423          	sd	a4,-120(s0)
    8000069c:	4601                	li	a2,0
    8000069e:	45c1                	li	a1,16
    800006a0:	6388                	ld	a0,0(a5)
    800006a2:	d6dff0ef          	jal	ra,8000040e <printint>
      i += 1;
    800006a6:	0029849b          	addiw	s1,s3,2
    800006aa:	bdb5                	j	80000526 <printf+0x84>
      printptr(va_arg(ap, uint64));
    800006ac:	f8843783          	ld	a5,-120(s0)
    800006b0:	00878713          	addi	a4,a5,8
    800006b4:	f8e43423          	sd	a4,-120(s0)
    800006b8:	0007b983          	ld	s3,0(a5)
  consputc('0');
    800006bc:	03000513          	li	a0,48
    800006c0:	b67ff0ef          	jal	ra,80000226 <consputc>
  consputc('x');
    800006c4:	856a                	mv	a0,s10
    800006c6:	b61ff0ef          	jal	ra,80000226 <consputc>
    800006ca:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006cc:	03c9d793          	srli	a5,s3,0x3c
    800006d0:	97de                	add	a5,a5,s7
    800006d2:	0007c503          	lbu	a0,0(a5)
    800006d6:	b51ff0ef          	jal	ra,80000226 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006da:	0992                	slli	s3,s3,0x4
    800006dc:	397d                	addiw	s2,s2,-1
    800006de:	fe0917e3          	bnez	s2,800006cc <printf+0x22a>
    800006e2:	b591                	j	80000526 <printf+0x84>
      consputc(va_arg(ap, uint));
    800006e4:	f8843783          	ld	a5,-120(s0)
    800006e8:	00878713          	addi	a4,a5,8
    800006ec:	f8e43423          	sd	a4,-120(s0)
    800006f0:	4388                	lw	a0,0(a5)
    800006f2:	b35ff0ef          	jal	ra,80000226 <consputc>
    800006f6:	bd05                	j	80000526 <printf+0x84>
      if((s = va_arg(ap, char*)) == 0)
    800006f8:	f8843783          	ld	a5,-120(s0)
    800006fc:	00878713          	addi	a4,a5,8
    80000700:	f8e43423          	sd	a4,-120(s0)
    80000704:	0007b903          	ld	s2,0(a5)
    80000708:	00090d63          	beqz	s2,80000722 <printf+0x280>
      for(; *s; s++)
    8000070c:	00094503          	lbu	a0,0(s2)
    80000710:	e0050be3          	beqz	a0,80000526 <printf+0x84>
        consputc(*s);
    80000714:	b13ff0ef          	jal	ra,80000226 <consputc>
      for(; *s; s++)
    80000718:	0905                	addi	s2,s2,1
    8000071a:	00094503          	lbu	a0,0(s2)
    8000071e:	f97d                	bnez	a0,80000714 <printf+0x272>
    80000720:	b519                	j	80000526 <printf+0x84>
        s = "(null)";
    80000722:	00007917          	auipc	s2,0x7
    80000726:	8f690913          	addi	s2,s2,-1802 # 80007018 <etext+0x18>
      for(; *s; s++)
    8000072a:	02800513          	li	a0,40
    8000072e:	b7dd                	j	80000714 <printf+0x272>
    }

  }
  va_end(ap);

  if(panicking == 0)
    80000730:	00007797          	auipc	a5,0x7
    80000734:	2547a783          	lw	a5,596(a5) # 80007984 <panicking>
    80000738:	c38d                	beqz	a5,8000075a <printf+0x2b8>
    release(&pr.lock);

  return 0;
}
    8000073a:	4501                	li	a0,0
    8000073c:	70e6                	ld	ra,120(sp)
    8000073e:	7446                	ld	s0,112(sp)
    80000740:	74a6                	ld	s1,104(sp)
    80000742:	7906                	ld	s2,96(sp)
    80000744:	69e6                	ld	s3,88(sp)
    80000746:	6a46                	ld	s4,80(sp)
    80000748:	6aa6                	ld	s5,72(sp)
    8000074a:	6b06                	ld	s6,64(sp)
    8000074c:	7be2                	ld	s7,56(sp)
    8000074e:	7c42                	ld	s8,48(sp)
    80000750:	7ca2                	ld	s9,40(sp)
    80000752:	7d02                	ld	s10,32(sp)
    80000754:	6de2                	ld	s11,24(sp)
    80000756:	6129                	addi	sp,sp,192
    80000758:	8082                	ret
    release(&pr.lock);
    8000075a:	0000f517          	auipc	a0,0xf
    8000075e:	30e50513          	addi	a0,a0,782 # 8000fa68 <pr>
    80000762:	57c000ef          	jal	ra,80000cde <release>
  return 0;
    80000766:	bfd1                	j	8000073a <printf+0x298>

0000000080000768 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000768:	1141                	addi	sp,sp,-16
    8000076a:	e406                	sd	ra,8(sp)
    8000076c:	e022                	sd	s0,0(sp)
    8000076e:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000770:	00007597          	auipc	a1,0x7
    80000774:	8b058593          	addi	a1,a1,-1872 # 80007020 <etext+0x20>
    80000778:	0000f517          	auipc	a0,0xf
    8000077c:	2f050513          	addi	a0,a0,752 # 8000fa68 <pr>
    80000780:	446000ef          	jal	ra,80000bc6 <initlock>
}
    80000784:	60a2                	ld	ra,8(sp)
    80000786:	6402                	ld	s0,0(sp)
    80000788:	0141                	addi	sp,sp,16
    8000078a:	8082                	ret

000000008000078c <backtrace>:

void
backtrace(void){
    8000078c:	7179                	addi	sp,sp,-48
    8000078e:	f406                	sd	ra,40(sp)
    80000790:	f022                	sd	s0,32(sp)
    80000792:	ec26                	sd	s1,24(sp)
    80000794:	e84a                	sd	s2,16(sp)
    80000796:	e44e                	sd	s3,8(sp)
    80000798:	e052                	sd	s4,0(sp)
    8000079a:	1800                	addi	s0,sp,48
//This uses inline assembly to copy the s0 register into a C variable.
static inline uint64
r_fp()
{
  uint64 x;
  asm volatile("mv %0, s0" : "=r" (x) );
    8000079c:	84a2                	mv	s1,s0
    uint64 fp = r_fp(); //gets the current frame pointer
    uint64 low = PGROUNDDOWN(fp); //gets the bottom of the current stack page
    8000079e:	797d                	lui	s2,0xfffff
    800007a0:	0124f933          	and	s2,s1,s2
    printf("backtrace:\n"); //because the output format showed this
    800007a4:	00007517          	auipc	a0,0x7
    800007a8:	88450513          	addi	a0,a0,-1916 # 80007028 <etext+0x28>
    800007ac:	cf7ff0ef          	jal	ra,800004a2 <printf>
    while (PGROUNDDOWN(fp)==low){
        uint64 ra = *((uint64 *)(fp-8)); //gets the return address from fp-8
        printf("%p\n",(void*)ra); // prints the return address
    800007b0:	00007a17          	auipc	s4,0x7
    800007b4:	888a0a13          	addi	s4,s4,-1912 # 80007038 <etext+0x38>
    while (PGROUNDDOWN(fp)==low){
    800007b8:	79fd                	lui	s3,0xfffff
        printf("%p\n",(void*)ra); // prints the return address
    800007ba:	ff84b583          	ld	a1,-8(s1)
    800007be:	8552                	mv	a0,s4
    800007c0:	ce3ff0ef          	jal	ra,800004a2 <printf>
        fp = *((uint64 *)(fp-16)); //updates the frame pointer to the previous frame pointer
    800007c4:	ff04b483          	ld	s1,-16(s1)
    while (PGROUNDDOWN(fp)==low){
    800007c8:	0134f7b3          	and	a5,s1,s3
    800007cc:	ff2787e3          	beq	a5,s2,800007ba <backtrace+0x2e>
    }
}
    800007d0:	70a2                	ld	ra,40(sp)
    800007d2:	7402                	ld	s0,32(sp)
    800007d4:	64e2                	ld	s1,24(sp)
    800007d6:	6942                	ld	s2,16(sp)
    800007d8:	69a2                	ld	s3,8(sp)
    800007da:	6a02                	ld	s4,0(sp)
    800007dc:	6145                	addi	sp,sp,48
    800007de:	8082                	ret

00000000800007e0 <panic>:
{
    800007e0:	1101                	addi	sp,sp,-32
    800007e2:	ec06                	sd	ra,24(sp)
    800007e4:	e822                	sd	s0,16(sp)
    800007e6:	e426                	sd	s1,8(sp)
    800007e8:	e04a                	sd	s2,0(sp)
    800007ea:	1000                	addi	s0,sp,32
    800007ec:	84aa                	mv	s1,a0
  panicking = 1;
    800007ee:	4905                	li	s2,1
    800007f0:	00007797          	auipc	a5,0x7
    800007f4:	1927aa23          	sw	s2,404(a5) # 80007984 <panicking>
  printf("panic: ");
    800007f8:	00007517          	auipc	a0,0x7
    800007fc:	84850513          	addi	a0,a0,-1976 # 80007040 <etext+0x40>
    80000800:	ca3ff0ef          	jal	ra,800004a2 <printf>
  printf("%s\n", s);
    80000804:	85a6                	mv	a1,s1
    80000806:	00007517          	auipc	a0,0x7
    8000080a:	84250513          	addi	a0,a0,-1982 # 80007048 <etext+0x48>
    8000080e:	c95ff0ef          	jal	ra,800004a2 <printf>
  backtrace(); //This line was added by Ashish CS23B099
    80000812:	f7bff0ef          	jal	ra,8000078c <backtrace>
  panicked = 1; // freeze uart output from other CPUs
    80000816:	00007797          	auipc	a5,0x7
    8000081a:	1727a523          	sw	s2,362(a5) # 80007980 <panicked>
  for(;;)
    8000081e:	a001                	j	8000081e <panic+0x3e>

0000000080000820 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80000820:	1141                	addi	sp,sp,-16
    80000822:	e406                	sd	ra,8(sp)
    80000824:	e022                	sd	s0,0(sp)
    80000826:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000828:	100007b7          	lui	a5,0x10000
    8000082c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000830:	f8000713          	li	a4,-128
    80000834:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000838:	470d                	li	a4,3
    8000083a:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000083e:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80000842:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80000846:	469d                	li	a3,7
    80000848:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000084c:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    80000850:	00007597          	auipc	a1,0x7
    80000854:	81858593          	addi	a1,a1,-2024 # 80007068 <digits+0x18>
    80000858:	0000f517          	auipc	a0,0xf
    8000085c:	22850513          	addi	a0,a0,552 # 8000fa80 <uart_tx_lock>
    80000860:	366000ef          	jal	ra,80000bc6 <initlock>
}
    80000864:	60a2                	ld	ra,8(sp)
    80000866:	6402                	ld	s0,0(sp)
    80000868:	0141                	addi	sp,sp,16
    8000086a:	8082                	ret

000000008000086c <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000086c:	1101                	addi	sp,sp,-32
    8000086e:	ec06                	sd	ra,24(sp)
    80000870:	e822                	sd	s0,16(sp)
    80000872:	e426                	sd	s1,8(sp)
    80000874:	1000                	addi	s0,sp,32
    80000876:	84aa                	mv	s1,a0
  if(panicking == 0)
    80000878:	00007797          	auipc	a5,0x7
    8000087c:	10c7a783          	lw	a5,268(a5) # 80007984 <panicking>
    80000880:	cb89                	beqz	a5,80000892 <uartputc_sync+0x26>
    push_off();

  if(panicked){
    80000882:	00007797          	auipc	a5,0x7
    80000886:	0fe7a783          	lw	a5,254(a5) # 80007980 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000088a:	10000737          	lui	a4,0x10000
  if(panicked){
    8000088e:	c789                	beqz	a5,80000898 <uartputc_sync+0x2c>
    for(;;)
    80000890:	a001                	j	80000890 <uartputc_sync+0x24>
    push_off();
    80000892:	374000ef          	jal	ra,80000c06 <push_off>
    80000896:	b7f5                	j	80000882 <uartputc_sync+0x16>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000898:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    8000089c:	0207f793          	andi	a5,a5,32
    800008a0:	dfe5                	beqz	a5,80000898 <uartputc_sync+0x2c>
    ;
  WriteReg(THR, c);
    800008a2:	0ff4f513          	zext.b	a0,s1
    800008a6:	100007b7          	lui	a5,0x10000
    800008aa:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    800008ae:	00007797          	auipc	a5,0x7
    800008b2:	0d67a783          	lw	a5,214(a5) # 80007984 <panicking>
    800008b6:	c791                	beqz	a5,800008c2 <uartputc_sync+0x56>
    pop_off();
}
    800008b8:	60e2                	ld	ra,24(sp)
    800008ba:	6442                	ld	s0,16(sp)
    800008bc:	64a2                	ld	s1,8(sp)
    800008be:	6105                	addi	sp,sp,32
    800008c0:	8082                	ret
    pop_off();
    800008c2:	3c8000ef          	jal	ra,80000c8a <pop_off>
}
    800008c6:	bfcd                	j	800008b8 <uartputc_sync+0x4c>

00000000800008c8 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800008c8:	00007797          	auipc	a5,0x7
    800008cc:	0c07b783          	ld	a5,192(a5) # 80007988 <uart_tx_r>
    800008d0:	00007717          	auipc	a4,0x7
    800008d4:	0c073703          	ld	a4,192(a4) # 80007990 <uart_tx_w>
    800008d8:	06f70863          	beq	a4,a5,80000948 <uartstart+0x80>
{
    800008dc:	7139                	addi	sp,sp,-64
    800008de:	fc06                	sd	ra,56(sp)
    800008e0:	f822                	sd	s0,48(sp)
    800008e2:	f426                	sd	s1,40(sp)
    800008e4:	f04a                	sd	s2,32(sp)
    800008e6:	ec4e                	sd	s3,24(sp)
    800008e8:	e852                	sd	s4,16(sp)
    800008ea:	e456                	sd	s5,8(sp)
    800008ec:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800008ee:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800008f2:	0000fa17          	auipc	s4,0xf
    800008f6:	18ea0a13          	addi	s4,s4,398 # 8000fa80 <uart_tx_lock>
    uart_tx_r += 1;
    800008fa:	00007497          	auipc	s1,0x7
    800008fe:	08e48493          	addi	s1,s1,142 # 80007988 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80000902:	00007997          	auipc	s3,0x7
    80000906:	08e98993          	addi	s3,s3,142 # 80007990 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000090a:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    8000090e:	02077713          	andi	a4,a4,32
    80000912:	c315                	beqz	a4,80000936 <uartstart+0x6e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000914:	01f7f713          	andi	a4,a5,31
    80000918:	9752                	add	a4,a4,s4
    8000091a:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    8000091e:	0785                	addi	a5,a5,1
    80000920:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80000922:	8526                	mv	a0,s1
    80000924:	5ec010ef          	jal	ra,80001f10 <wakeup>
    
    WriteReg(THR, c);
    80000928:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    8000092c:	609c                	ld	a5,0(s1)
    8000092e:	0009b703          	ld	a4,0(s3)
    80000932:	fcf71ce3          	bne	a4,a5,8000090a <uartstart+0x42>
  }
}
    80000936:	70e2                	ld	ra,56(sp)
    80000938:	7442                	ld	s0,48(sp)
    8000093a:	74a2                	ld	s1,40(sp)
    8000093c:	7902                	ld	s2,32(sp)
    8000093e:	69e2                	ld	s3,24(sp)
    80000940:	6a42                	ld	s4,16(sp)
    80000942:	6aa2                	ld	s5,8(sp)
    80000944:	6121                	addi	sp,sp,64
    80000946:	8082                	ret
    80000948:	8082                	ret

000000008000094a <uartputc>:
{
    8000094a:	7179                	addi	sp,sp,-48
    8000094c:	f406                	sd	ra,40(sp)
    8000094e:	f022                	sd	s0,32(sp)
    80000950:	ec26                	sd	s1,24(sp)
    80000952:	e84a                	sd	s2,16(sp)
    80000954:	e44e                	sd	s3,8(sp)
    80000956:	e052                	sd	s4,0(sp)
    80000958:	1800                	addi	s0,sp,48
    8000095a:	8a2a                	mv	s4,a0
  if(panicking == 0)
    8000095c:	00007797          	auipc	a5,0x7
    80000960:	0287a783          	lw	a5,40(a5) # 80007984 <panicking>
    80000964:	c7d1                	beqz	a5,800009f0 <uartputc+0xa6>
  if(panicked){
    80000966:	00007797          	auipc	a5,0x7
    8000096a:	01a7a783          	lw	a5,26(a5) # 80007980 <panicked>
    8000096e:	ebc1                	bnez	a5,800009fe <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000970:	00007717          	auipc	a4,0x7
    80000974:	02073703          	ld	a4,32(a4) # 80007990 <uart_tx_w>
    80000978:	00007797          	auipc	a5,0x7
    8000097c:	0107b783          	ld	a5,16(a5) # 80007988 <uart_tx_r>
    80000980:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    80000984:	0000f997          	auipc	s3,0xf
    80000988:	0fc98993          	addi	s3,s3,252 # 8000fa80 <uart_tx_lock>
    8000098c:	00007497          	auipc	s1,0x7
    80000990:	ffc48493          	addi	s1,s1,-4 # 80007988 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000994:	00007917          	auipc	s2,0x7
    80000998:	ffc90913          	addi	s2,s2,-4 # 80007990 <uart_tx_w>
    8000099c:	00e79d63          	bne	a5,a4,800009b6 <uartputc+0x6c>
    sleep(&uart_tx_r, &uart_tx_lock);
    800009a0:	85ce                	mv	a1,s3
    800009a2:	8526                	mv	a0,s1
    800009a4:	520010ef          	jal	ra,80001ec4 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009a8:	00093703          	ld	a4,0(s2)
    800009ac:	609c                	ld	a5,0(s1)
    800009ae:	02078793          	addi	a5,a5,32
    800009b2:	fee787e3          	beq	a5,a4,800009a0 <uartputc+0x56>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800009b6:	01f77693          	andi	a3,a4,31
    800009ba:	0000f797          	auipc	a5,0xf
    800009be:	0c678793          	addi	a5,a5,198 # 8000fa80 <uart_tx_lock>
    800009c2:	97b6                	add	a5,a5,a3
    800009c4:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800009c8:	0705                	addi	a4,a4,1
    800009ca:	00007797          	auipc	a5,0x7
    800009ce:	fce7b323          	sd	a4,-58(a5) # 80007990 <uart_tx_w>
  uartstart();
    800009d2:	ef7ff0ef          	jal	ra,800008c8 <uartstart>
  if(panicking == 0)
    800009d6:	00007797          	auipc	a5,0x7
    800009da:	fae7a783          	lw	a5,-82(a5) # 80007984 <panicking>
    800009de:	c38d                	beqz	a5,80000a00 <uartputc+0xb6>
}
    800009e0:	70a2                	ld	ra,40(sp)
    800009e2:	7402                	ld	s0,32(sp)
    800009e4:	64e2                	ld	s1,24(sp)
    800009e6:	6942                	ld	s2,16(sp)
    800009e8:	69a2                	ld	s3,8(sp)
    800009ea:	6a02                	ld	s4,0(sp)
    800009ec:	6145                	addi	sp,sp,48
    800009ee:	8082                	ret
    acquire(&uart_tx_lock);
    800009f0:	0000f517          	auipc	a0,0xf
    800009f4:	09050513          	addi	a0,a0,144 # 8000fa80 <uart_tx_lock>
    800009f8:	24e000ef          	jal	ra,80000c46 <acquire>
    800009fc:	b7ad                	j	80000966 <uartputc+0x1c>
    for(;;)
    800009fe:	a001                	j	800009fe <uartputc+0xb4>
    release(&uart_tx_lock);
    80000a00:	0000f517          	auipc	a0,0xf
    80000a04:	08050513          	addi	a0,a0,128 # 8000fa80 <uart_tx_lock>
    80000a08:	2d6000ef          	jal	ra,80000cde <release>
}
    80000a0c:	bfd1                	j	800009e0 <uartputc+0x96>

0000000080000a0e <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000a0e:	1141                	addi	sp,sp,-16
    80000a10:	e422                	sd	s0,8(sp)
    80000a12:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    80000a14:	100007b7          	lui	a5,0x10000
    80000a18:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a1c:	8b85                	andi	a5,a5,1
    80000a1e:	cb91                	beqz	a5,80000a32 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80000a20:	100007b7          	lui	a5,0x10000
    80000a24:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    80000a28:	0ff57513          	zext.b	a0,a0
  } else {
    return -1;
  }
}
    80000a2c:	6422                	ld	s0,8(sp)
    80000a2e:	0141                	addi	sp,sp,16
    80000a30:	8082                	ret
    return -1;
    80000a32:	557d                	li	a0,-1
    80000a34:	bfe5                	j	80000a2c <uartgetc+0x1e>

0000000080000a36 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000a36:	1101                	addi	sp,sp,-32
    80000a38:	ec06                	sd	ra,24(sp)
    80000a3a:	e822                	sd	s0,16(sp)
    80000a3c:	e426                	sd	s1,8(sp)
    80000a3e:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    80000a40:	100007b7          	lui	a5,0x10000
    80000a44:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a48:	54fd                	li	s1,-1
    80000a4a:	a019                	j	80000a50 <uartintr+0x1a>
      break;
    consoleintr(c);
    80000a4c:	80dff0ef          	jal	ra,80000258 <consoleintr>
    int c = uartgetc();
    80000a50:	fbfff0ef          	jal	ra,80000a0e <uartgetc>
    if(c == -1)
    80000a54:	fe951ce3          	bne	a0,s1,80000a4c <uartintr+0x16>
  }

  // send buffered characters.
  if(panicking == 0)
    80000a58:	00007797          	auipc	a5,0x7
    80000a5c:	f2c7a783          	lw	a5,-212(a5) # 80007984 <panicking>
    80000a60:	cf89                	beqz	a5,80000a7a <uartintr+0x44>
    acquire(&uart_tx_lock);
  uartstart();
    80000a62:	e67ff0ef          	jal	ra,800008c8 <uartstart>
  if(panicking == 0)
    80000a66:	00007797          	auipc	a5,0x7
    80000a6a:	f1e7a783          	lw	a5,-226(a5) # 80007984 <panicking>
    80000a6e:	cf89                	beqz	a5,80000a88 <uartintr+0x52>
    release(&uart_tx_lock);
}
    80000a70:	60e2                	ld	ra,24(sp)
    80000a72:	6442                	ld	s0,16(sp)
    80000a74:	64a2                	ld	s1,8(sp)
    80000a76:	6105                	addi	sp,sp,32
    80000a78:	8082                	ret
    acquire(&uart_tx_lock);
    80000a7a:	0000f517          	auipc	a0,0xf
    80000a7e:	00650513          	addi	a0,a0,6 # 8000fa80 <uart_tx_lock>
    80000a82:	1c4000ef          	jal	ra,80000c46 <acquire>
    80000a86:	bff1                	j	80000a62 <uartintr+0x2c>
    release(&uart_tx_lock);
    80000a88:	0000f517          	auipc	a0,0xf
    80000a8c:	ff850513          	addi	a0,a0,-8 # 8000fa80 <uart_tx_lock>
    80000a90:	24e000ef          	jal	ra,80000cde <release>
}
    80000a94:	bff1                	j	80000a70 <uartintr+0x3a>

0000000080000a96 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a96:	1101                	addi	sp,sp,-32
    80000a98:	ec06                	sd	ra,24(sp)
    80000a9a:	e822                	sd	s0,16(sp)
    80000a9c:	e426                	sd	s1,8(sp)
    80000a9e:	e04a                	sd	s2,0(sp)
    80000aa0:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000aa2:	03451793          	slli	a5,a0,0x34
    80000aa6:	e7a9                	bnez	a5,80000af0 <kfree+0x5a>
    80000aa8:	84aa                	mv	s1,a0
    80000aaa:	00020797          	auipc	a5,0x20
    80000aae:	43e78793          	addi	a5,a5,1086 # 80020ee8 <end>
    80000ab2:	02f56f63          	bltu	a0,a5,80000af0 <kfree+0x5a>
    80000ab6:	47c5                	li	a5,17
    80000ab8:	07ee                	slli	a5,a5,0x1b
    80000aba:	02f57b63          	bgeu	a0,a5,80000af0 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000abe:	6605                	lui	a2,0x1
    80000ac0:	4585                	li	a1,1
    80000ac2:	258000ef          	jal	ra,80000d1a <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000ac6:	0000f917          	auipc	s2,0xf
    80000aca:	ff290913          	addi	s2,s2,-14 # 8000fab8 <kmem>
    80000ace:	854a                	mv	a0,s2
    80000ad0:	176000ef          	jal	ra,80000c46 <acquire>
  r->next = kmem.freelist;
    80000ad4:	01893783          	ld	a5,24(s2)
    80000ad8:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000ada:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000ade:	854a                	mv	a0,s2
    80000ae0:	1fe000ef          	jal	ra,80000cde <release>
}
    80000ae4:	60e2                	ld	ra,24(sp)
    80000ae6:	6442                	ld	s0,16(sp)
    80000ae8:	64a2                	ld	s1,8(sp)
    80000aea:	6902                	ld	s2,0(sp)
    80000aec:	6105                	addi	sp,sp,32
    80000aee:	8082                	ret
    panic("kfree");
    80000af0:	00006517          	auipc	a0,0x6
    80000af4:	58050513          	addi	a0,a0,1408 # 80007070 <digits+0x20>
    80000af8:	ce9ff0ef          	jal	ra,800007e0 <panic>

0000000080000afc <freerange>:
{
    80000afc:	7179                	addi	sp,sp,-48
    80000afe:	f406                	sd	ra,40(sp)
    80000b00:	f022                	sd	s0,32(sp)
    80000b02:	ec26                	sd	s1,24(sp)
    80000b04:	e84a                	sd	s2,16(sp)
    80000b06:	e44e                	sd	s3,8(sp)
    80000b08:	e052                	sd	s4,0(sp)
    80000b0a:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000b0c:	6785                	lui	a5,0x1
    80000b0e:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000b12:	94aa                	add	s1,s1,a0
    80000b14:	757d                	lui	a0,0xfffff
    80000b16:	8ce9                	and	s1,s1,a0
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b18:	94be                	add	s1,s1,a5
    80000b1a:	0095ec63          	bltu	a1,s1,80000b32 <freerange+0x36>
    80000b1e:	892e                	mv	s2,a1
    kfree(p);
    80000b20:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b22:	6985                	lui	s3,0x1
    kfree(p);
    80000b24:	01448533          	add	a0,s1,s4
    80000b28:	f6fff0ef          	jal	ra,80000a96 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b2c:	94ce                	add	s1,s1,s3
    80000b2e:	fe997be3          	bgeu	s2,s1,80000b24 <freerange+0x28>
}
    80000b32:	70a2                	ld	ra,40(sp)
    80000b34:	7402                	ld	s0,32(sp)
    80000b36:	64e2                	ld	s1,24(sp)
    80000b38:	6942                	ld	s2,16(sp)
    80000b3a:	69a2                	ld	s3,8(sp)
    80000b3c:	6a02                	ld	s4,0(sp)
    80000b3e:	6145                	addi	sp,sp,48
    80000b40:	8082                	ret

0000000080000b42 <kinit>:
{
    80000b42:	1141                	addi	sp,sp,-16
    80000b44:	e406                	sd	ra,8(sp)
    80000b46:	e022                	sd	s0,0(sp)
    80000b48:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b4a:	00006597          	auipc	a1,0x6
    80000b4e:	52e58593          	addi	a1,a1,1326 # 80007078 <digits+0x28>
    80000b52:	0000f517          	auipc	a0,0xf
    80000b56:	f6650513          	addi	a0,a0,-154 # 8000fab8 <kmem>
    80000b5a:	06c000ef          	jal	ra,80000bc6 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b5e:	45c5                	li	a1,17
    80000b60:	05ee                	slli	a1,a1,0x1b
    80000b62:	00020517          	auipc	a0,0x20
    80000b66:	38650513          	addi	a0,a0,902 # 80020ee8 <end>
    80000b6a:	f93ff0ef          	jal	ra,80000afc <freerange>
}
    80000b6e:	60a2                	ld	ra,8(sp)
    80000b70:	6402                	ld	s0,0(sp)
    80000b72:	0141                	addi	sp,sp,16
    80000b74:	8082                	ret

0000000080000b76 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b76:	1101                	addi	sp,sp,-32
    80000b78:	ec06                	sd	ra,24(sp)
    80000b7a:	e822                	sd	s0,16(sp)
    80000b7c:	e426                	sd	s1,8(sp)
    80000b7e:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b80:	0000f497          	auipc	s1,0xf
    80000b84:	f3848493          	addi	s1,s1,-200 # 8000fab8 <kmem>
    80000b88:	8526                	mv	a0,s1
    80000b8a:	0bc000ef          	jal	ra,80000c46 <acquire>
  r = kmem.freelist;
    80000b8e:	6c84                	ld	s1,24(s1)
  if(r)
    80000b90:	c485                	beqz	s1,80000bb8 <kalloc+0x42>
    kmem.freelist = r->next;
    80000b92:	609c                	ld	a5,0(s1)
    80000b94:	0000f517          	auipc	a0,0xf
    80000b98:	f2450513          	addi	a0,a0,-220 # 8000fab8 <kmem>
    80000b9c:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b9e:	140000ef          	jal	ra,80000cde <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000ba2:	6605                	lui	a2,0x1
    80000ba4:	4595                	li	a1,5
    80000ba6:	8526                	mv	a0,s1
    80000ba8:	172000ef          	jal	ra,80000d1a <memset>
  return (void*)r;
}
    80000bac:	8526                	mv	a0,s1
    80000bae:	60e2                	ld	ra,24(sp)
    80000bb0:	6442                	ld	s0,16(sp)
    80000bb2:	64a2                	ld	s1,8(sp)
    80000bb4:	6105                	addi	sp,sp,32
    80000bb6:	8082                	ret
  release(&kmem.lock);
    80000bb8:	0000f517          	auipc	a0,0xf
    80000bbc:	f0050513          	addi	a0,a0,-256 # 8000fab8 <kmem>
    80000bc0:	11e000ef          	jal	ra,80000cde <release>
  if(r)
    80000bc4:	b7e5                	j	80000bac <kalloc+0x36>

0000000080000bc6 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000bc6:	1141                	addi	sp,sp,-16
    80000bc8:	e422                	sd	s0,8(sp)
    80000bca:	0800                	addi	s0,sp,16
  lk->name = name;
    80000bcc:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000bce:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bd2:	00053823          	sd	zero,16(a0)
}
    80000bd6:	6422                	ld	s0,8(sp)
    80000bd8:	0141                	addi	sp,sp,16
    80000bda:	8082                	ret

0000000080000bdc <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bdc:	411c                	lw	a5,0(a0)
    80000bde:	e399                	bnez	a5,80000be4 <holding+0x8>
    80000be0:	4501                	li	a0,0
  return r;
}
    80000be2:	8082                	ret
{
    80000be4:	1101                	addi	sp,sp,-32
    80000be6:	ec06                	sd	ra,24(sp)
    80000be8:	e822                	sd	s0,16(sp)
    80000bea:	e426                	sd	s1,8(sp)
    80000bec:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bee:	6904                	ld	s1,16(a0)
    80000bf0:	4d3000ef          	jal	ra,800018c2 <mycpu>
    80000bf4:	40a48533          	sub	a0,s1,a0
    80000bf8:	00153513          	seqz	a0,a0
}
    80000bfc:	60e2                	ld	ra,24(sp)
    80000bfe:	6442                	ld	s0,16(sp)
    80000c00:	64a2                	ld	s1,8(sp)
    80000c02:	6105                	addi	sp,sp,32
    80000c04:	8082                	ret

0000000080000c06 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000c06:	1101                	addi	sp,sp,-32
    80000c08:	ec06                	sd	ra,24(sp)
    80000c0a:	e822                	sd	s0,16(sp)
    80000c0c:	e426                	sd	s1,8(sp)
    80000c0e:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c10:	100024f3          	csrr	s1,sstatus
    80000c14:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000c18:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c1a:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000c1e:	4a5000ef          	jal	ra,800018c2 <mycpu>
    80000c22:	5d3c                	lw	a5,120(a0)
    80000c24:	cb99                	beqz	a5,80000c3a <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c26:	49d000ef          	jal	ra,800018c2 <mycpu>
    80000c2a:	5d3c                	lw	a5,120(a0)
    80000c2c:	2785                	addiw	a5,a5,1
    80000c2e:	dd3c                	sw	a5,120(a0)
}
    80000c30:	60e2                	ld	ra,24(sp)
    80000c32:	6442                	ld	s0,16(sp)
    80000c34:	64a2                	ld	s1,8(sp)
    80000c36:	6105                	addi	sp,sp,32
    80000c38:	8082                	ret
    mycpu()->intena = old;
    80000c3a:	489000ef          	jal	ra,800018c2 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c3e:	8085                	srli	s1,s1,0x1
    80000c40:	8885                	andi	s1,s1,1
    80000c42:	dd64                	sw	s1,124(a0)
    80000c44:	b7cd                	j	80000c26 <push_off+0x20>

0000000080000c46 <acquire>:
{
    80000c46:	1101                	addi	sp,sp,-32
    80000c48:	ec06                	sd	ra,24(sp)
    80000c4a:	e822                	sd	s0,16(sp)
    80000c4c:	e426                	sd	s1,8(sp)
    80000c4e:	1000                	addi	s0,sp,32
    80000c50:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c52:	fb5ff0ef          	jal	ra,80000c06 <push_off>
  if(holding(lk))
    80000c56:	8526                	mv	a0,s1
    80000c58:	f85ff0ef          	jal	ra,80000bdc <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c5c:	4705                	li	a4,1
  if(holding(lk))
    80000c5e:	e105                	bnez	a0,80000c7e <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c60:	87ba                	mv	a5,a4
    80000c62:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c66:	2781                	sext.w	a5,a5
    80000c68:	ffe5                	bnez	a5,80000c60 <acquire+0x1a>
  __sync_synchronize();
    80000c6a:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000c6e:	455000ef          	jal	ra,800018c2 <mycpu>
    80000c72:	e888                	sd	a0,16(s1)
}
    80000c74:	60e2                	ld	ra,24(sp)
    80000c76:	6442                	ld	s0,16(sp)
    80000c78:	64a2                	ld	s1,8(sp)
    80000c7a:	6105                	addi	sp,sp,32
    80000c7c:	8082                	ret
    panic("acquire");
    80000c7e:	00006517          	auipc	a0,0x6
    80000c82:	40250513          	addi	a0,a0,1026 # 80007080 <digits+0x30>
    80000c86:	b5bff0ef          	jal	ra,800007e0 <panic>

0000000080000c8a <pop_off>:

void
pop_off(void)
{
    80000c8a:	1141                	addi	sp,sp,-16
    80000c8c:	e406                	sd	ra,8(sp)
    80000c8e:	e022                	sd	s0,0(sp)
    80000c90:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c92:	431000ef          	jal	ra,800018c2 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c96:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c9a:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c9c:	e78d                	bnez	a5,80000cc6 <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c9e:	5d3c                	lw	a5,120(a0)
    80000ca0:	02f05963          	blez	a5,80000cd2 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000ca4:	37fd                	addiw	a5,a5,-1
    80000ca6:	0007871b          	sext.w	a4,a5
    80000caa:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000cac:	eb09                	bnez	a4,80000cbe <pop_off+0x34>
    80000cae:	5d7c                	lw	a5,124(a0)
    80000cb0:	c799                	beqz	a5,80000cbe <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cb2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000cb6:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000cba:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000cbe:	60a2                	ld	ra,8(sp)
    80000cc0:	6402                	ld	s0,0(sp)
    80000cc2:	0141                	addi	sp,sp,16
    80000cc4:	8082                	ret
    panic("pop_off - interruptible");
    80000cc6:	00006517          	auipc	a0,0x6
    80000cca:	3c250513          	addi	a0,a0,962 # 80007088 <digits+0x38>
    80000cce:	b13ff0ef          	jal	ra,800007e0 <panic>
    panic("pop_off");
    80000cd2:	00006517          	auipc	a0,0x6
    80000cd6:	3ce50513          	addi	a0,a0,974 # 800070a0 <digits+0x50>
    80000cda:	b07ff0ef          	jal	ra,800007e0 <panic>

0000000080000cde <release>:
{
    80000cde:	1101                	addi	sp,sp,-32
    80000ce0:	ec06                	sd	ra,24(sp)
    80000ce2:	e822                	sd	s0,16(sp)
    80000ce4:	e426                	sd	s1,8(sp)
    80000ce6:	1000                	addi	s0,sp,32
    80000ce8:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cea:	ef3ff0ef          	jal	ra,80000bdc <holding>
    80000cee:	c105                	beqz	a0,80000d0e <release+0x30>
  lk->cpu = 0;
    80000cf0:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000cf4:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000cf8:	0f50000f          	fence	iorw,ow
    80000cfc:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000d00:	f8bff0ef          	jal	ra,80000c8a <pop_off>
}
    80000d04:	60e2                	ld	ra,24(sp)
    80000d06:	6442                	ld	s0,16(sp)
    80000d08:	64a2                	ld	s1,8(sp)
    80000d0a:	6105                	addi	sp,sp,32
    80000d0c:	8082                	ret
    panic("release");
    80000d0e:	00006517          	auipc	a0,0x6
    80000d12:	39a50513          	addi	a0,a0,922 # 800070a8 <digits+0x58>
    80000d16:	acbff0ef          	jal	ra,800007e0 <panic>

0000000080000d1a <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000d1a:	1141                	addi	sp,sp,-16
    80000d1c:	e422                	sd	s0,8(sp)
    80000d1e:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d20:	ca19                	beqz	a2,80000d36 <memset+0x1c>
    80000d22:	87aa                	mv	a5,a0
    80000d24:	1602                	slli	a2,a2,0x20
    80000d26:	9201                	srli	a2,a2,0x20
    80000d28:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d2c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d30:	0785                	addi	a5,a5,1
    80000d32:	fee79de3          	bne	a5,a4,80000d2c <memset+0x12>
  }
  return dst;
}
    80000d36:	6422                	ld	s0,8(sp)
    80000d38:	0141                	addi	sp,sp,16
    80000d3a:	8082                	ret

0000000080000d3c <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d3c:	1141                	addi	sp,sp,-16
    80000d3e:	e422                	sd	s0,8(sp)
    80000d40:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d42:	ca05                	beqz	a2,80000d72 <memcmp+0x36>
    80000d44:	fff6069b          	addiw	a3,a2,-1
    80000d48:	1682                	slli	a3,a3,0x20
    80000d4a:	9281                	srli	a3,a3,0x20
    80000d4c:	0685                	addi	a3,a3,1
    80000d4e:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000d50:	00054783          	lbu	a5,0(a0)
    80000d54:	0005c703          	lbu	a4,0(a1)
    80000d58:	00e79863          	bne	a5,a4,80000d68 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d5c:	0505                	addi	a0,a0,1
    80000d5e:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d60:	fed518e3          	bne	a0,a3,80000d50 <memcmp+0x14>
  }

  return 0;
    80000d64:	4501                	li	a0,0
    80000d66:	a019                	j	80000d6c <memcmp+0x30>
      return *s1 - *s2;
    80000d68:	40e7853b          	subw	a0,a5,a4
}
    80000d6c:	6422                	ld	s0,8(sp)
    80000d6e:	0141                	addi	sp,sp,16
    80000d70:	8082                	ret
  return 0;
    80000d72:	4501                	li	a0,0
    80000d74:	bfe5                	j	80000d6c <memcmp+0x30>

0000000080000d76 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d76:	1141                	addi	sp,sp,-16
    80000d78:	e422                	sd	s0,8(sp)
    80000d7a:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d7c:	c205                	beqz	a2,80000d9c <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d7e:	02a5e263          	bltu	a1,a0,80000da2 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d82:	1602                	slli	a2,a2,0x20
    80000d84:	9201                	srli	a2,a2,0x20
    80000d86:	00c587b3          	add	a5,a1,a2
{
    80000d8a:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d8c:	0585                	addi	a1,a1,1
    80000d8e:	0705                	addi	a4,a4,1
    80000d90:	fff5c683          	lbu	a3,-1(a1)
    80000d94:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d98:	fef59ae3          	bne	a1,a5,80000d8c <memmove+0x16>

  return dst;
}
    80000d9c:	6422                	ld	s0,8(sp)
    80000d9e:	0141                	addi	sp,sp,16
    80000da0:	8082                	ret
  if(s < d && s + n > d){
    80000da2:	02061693          	slli	a3,a2,0x20
    80000da6:	9281                	srli	a3,a3,0x20
    80000da8:	00d58733          	add	a4,a1,a3
    80000dac:	fce57be3          	bgeu	a0,a4,80000d82 <memmove+0xc>
    d += n;
    80000db0:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000db2:	fff6079b          	addiw	a5,a2,-1
    80000db6:	1782                	slli	a5,a5,0x20
    80000db8:	9381                	srli	a5,a5,0x20
    80000dba:	fff7c793          	not	a5,a5
    80000dbe:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000dc0:	177d                	addi	a4,a4,-1
    80000dc2:	16fd                	addi	a3,a3,-1
    80000dc4:	00074603          	lbu	a2,0(a4)
    80000dc8:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000dcc:	fee79ae3          	bne	a5,a4,80000dc0 <memmove+0x4a>
    80000dd0:	b7f1                	j	80000d9c <memmove+0x26>

0000000080000dd2 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000dd2:	1141                	addi	sp,sp,-16
    80000dd4:	e406                	sd	ra,8(sp)
    80000dd6:	e022                	sd	s0,0(sp)
    80000dd8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000dda:	f9dff0ef          	jal	ra,80000d76 <memmove>
}
    80000dde:	60a2                	ld	ra,8(sp)
    80000de0:	6402                	ld	s0,0(sp)
    80000de2:	0141                	addi	sp,sp,16
    80000de4:	8082                	ret

0000000080000de6 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000de6:	1141                	addi	sp,sp,-16
    80000de8:	e422                	sd	s0,8(sp)
    80000dea:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000dec:	ce11                	beqz	a2,80000e08 <strncmp+0x22>
    80000dee:	00054783          	lbu	a5,0(a0)
    80000df2:	cf89                	beqz	a5,80000e0c <strncmp+0x26>
    80000df4:	0005c703          	lbu	a4,0(a1)
    80000df8:	00f71a63          	bne	a4,a5,80000e0c <strncmp+0x26>
    n--, p++, q++;
    80000dfc:	367d                	addiw	a2,a2,-1
    80000dfe:	0505                	addi	a0,a0,1
    80000e00:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000e02:	f675                	bnez	a2,80000dee <strncmp+0x8>
  if(n == 0)
    return 0;
    80000e04:	4501                	li	a0,0
    80000e06:	a809                	j	80000e18 <strncmp+0x32>
    80000e08:	4501                	li	a0,0
    80000e0a:	a039                	j	80000e18 <strncmp+0x32>
  if(n == 0)
    80000e0c:	ca09                	beqz	a2,80000e1e <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000e0e:	00054503          	lbu	a0,0(a0)
    80000e12:	0005c783          	lbu	a5,0(a1)
    80000e16:	9d1d                	subw	a0,a0,a5
}
    80000e18:	6422                	ld	s0,8(sp)
    80000e1a:	0141                	addi	sp,sp,16
    80000e1c:	8082                	ret
    return 0;
    80000e1e:	4501                	li	a0,0
    80000e20:	bfe5                	j	80000e18 <strncmp+0x32>

0000000080000e22 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e22:	1141                	addi	sp,sp,-16
    80000e24:	e422                	sd	s0,8(sp)
    80000e26:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e28:	872a                	mv	a4,a0
    80000e2a:	8832                	mv	a6,a2
    80000e2c:	367d                	addiw	a2,a2,-1
    80000e2e:	01005963          	blez	a6,80000e40 <strncpy+0x1e>
    80000e32:	0705                	addi	a4,a4,1
    80000e34:	0005c783          	lbu	a5,0(a1)
    80000e38:	fef70fa3          	sb	a5,-1(a4)
    80000e3c:	0585                	addi	a1,a1,1
    80000e3e:	f7f5                	bnez	a5,80000e2a <strncpy+0x8>
    ;
  while(n-- > 0)
    80000e40:	86ba                	mv	a3,a4
    80000e42:	00c05c63          	blez	a2,80000e5a <strncpy+0x38>
    *s++ = 0;
    80000e46:	0685                	addi	a3,a3,1
    80000e48:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000e4c:	fff6c793          	not	a5,a3
    80000e50:	9fb9                	addw	a5,a5,a4
    80000e52:	010787bb          	addw	a5,a5,a6
    80000e56:	fef048e3          	bgtz	a5,80000e46 <strncpy+0x24>
  return os;
}
    80000e5a:	6422                	ld	s0,8(sp)
    80000e5c:	0141                	addi	sp,sp,16
    80000e5e:	8082                	ret

0000000080000e60 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e60:	1141                	addi	sp,sp,-16
    80000e62:	e422                	sd	s0,8(sp)
    80000e64:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e66:	02c05363          	blez	a2,80000e8c <safestrcpy+0x2c>
    80000e6a:	fff6069b          	addiw	a3,a2,-1
    80000e6e:	1682                	slli	a3,a3,0x20
    80000e70:	9281                	srli	a3,a3,0x20
    80000e72:	96ae                	add	a3,a3,a1
    80000e74:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e76:	00d58963          	beq	a1,a3,80000e88 <safestrcpy+0x28>
    80000e7a:	0585                	addi	a1,a1,1
    80000e7c:	0785                	addi	a5,a5,1
    80000e7e:	fff5c703          	lbu	a4,-1(a1)
    80000e82:	fee78fa3          	sb	a4,-1(a5)
    80000e86:	fb65                	bnez	a4,80000e76 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e88:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e8c:	6422                	ld	s0,8(sp)
    80000e8e:	0141                	addi	sp,sp,16
    80000e90:	8082                	ret

0000000080000e92 <strlen>:

int
strlen(const char *s)
{
    80000e92:	1141                	addi	sp,sp,-16
    80000e94:	e422                	sd	s0,8(sp)
    80000e96:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e98:	00054783          	lbu	a5,0(a0)
    80000e9c:	cf91                	beqz	a5,80000eb8 <strlen+0x26>
    80000e9e:	0505                	addi	a0,a0,1
    80000ea0:	87aa                	mv	a5,a0
    80000ea2:	4685                	li	a3,1
    80000ea4:	9e89                	subw	a3,a3,a0
    80000ea6:	00f6853b          	addw	a0,a3,a5
    80000eaa:	0785                	addi	a5,a5,1
    80000eac:	fff7c703          	lbu	a4,-1(a5)
    80000eb0:	fb7d                	bnez	a4,80000ea6 <strlen+0x14>
    ;
  return n;
}
    80000eb2:	6422                	ld	s0,8(sp)
    80000eb4:	0141                	addi	sp,sp,16
    80000eb6:	8082                	ret
  for(n = 0; s[n]; n++)
    80000eb8:	4501                	li	a0,0
    80000eba:	bfe5                	j	80000eb2 <strlen+0x20>

0000000080000ebc <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000ebc:	1141                	addi	sp,sp,-16
    80000ebe:	e406                	sd	ra,8(sp)
    80000ec0:	e022                	sd	s0,0(sp)
    80000ec2:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000ec4:	1ef000ef          	jal	ra,800018b2 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000ec8:	00007717          	auipc	a4,0x7
    80000ecc:	ad070713          	addi	a4,a4,-1328 # 80007998 <started>
  if(cpuid() == 0){
    80000ed0:	c51d                	beqz	a0,80000efe <main+0x42>
    while(started == 0)
    80000ed2:	431c                	lw	a5,0(a4)
    80000ed4:	2781                	sext.w	a5,a5
    80000ed6:	dff5                	beqz	a5,80000ed2 <main+0x16>
      ;
    __sync_synchronize();
    80000ed8:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000edc:	1d7000ef          	jal	ra,800018b2 <cpuid>
    80000ee0:	85aa                	mv	a1,a0
    80000ee2:	00006517          	auipc	a0,0x6
    80000ee6:	1e650513          	addi	a0,a0,486 # 800070c8 <digits+0x78>
    80000eea:	db8ff0ef          	jal	ra,800004a2 <printf>
    kvminithart();    // turn on paging
    80000eee:	080000ef          	jal	ra,80000f6e <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ef2:	4f4010ef          	jal	ra,800023e6 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ef6:	32e040ef          	jal	ra,80005224 <plicinithart>
  }

  scheduler();        
    80000efa:	633000ef          	jal	ra,80001d2c <scheduler>
    consoleinit();
    80000efe:	cccff0ef          	jal	ra,800003ca <consoleinit>
    printfinit();
    80000f02:	867ff0ef          	jal	ra,80000768 <printfinit>
    printf("\n");
    80000f06:	00006517          	auipc	a0,0x6
    80000f0a:	1d250513          	addi	a0,a0,466 # 800070d8 <digits+0x88>
    80000f0e:	d94ff0ef          	jal	ra,800004a2 <printf>
    printf("xv6 kernel is booting\n");
    80000f12:	00006517          	auipc	a0,0x6
    80000f16:	19e50513          	addi	a0,a0,414 # 800070b0 <digits+0x60>
    80000f1a:	d88ff0ef          	jal	ra,800004a2 <printf>
    printf("\n");
    80000f1e:	00006517          	auipc	a0,0x6
    80000f22:	1ba50513          	addi	a0,a0,442 # 800070d8 <digits+0x88>
    80000f26:	d7cff0ef          	jal	ra,800004a2 <printf>
    kinit();         // physical page allocator
    80000f2a:	c19ff0ef          	jal	ra,80000b42 <kinit>
    kvminit();       // create kernel page table
    80000f2e:	2ca000ef          	jal	ra,800011f8 <kvminit>
    kvminithart();   // turn on paging
    80000f32:	03c000ef          	jal	ra,80000f6e <kvminithart>
    procinit();      // process table
    80000f36:	0d5000ef          	jal	ra,8000180a <procinit>
    trapinit();      // trap vectors
    80000f3a:	488010ef          	jal	ra,800023c2 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f3e:	4a8010ef          	jal	ra,800023e6 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f42:	2cc040ef          	jal	ra,8000520e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f46:	2de040ef          	jal	ra,80005224 <plicinithart>
    binit();         // buffer cache
    80000f4a:	35b010ef          	jal	ra,80002aa4 <binit>
    iinit();         // inode table
    80000f4e:	13c020ef          	jal	ra,8000308a <iinit>
    fileinit();      // file table
    80000f52:	6db020ef          	jal	ra,80003e2c <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f56:	3be040ef          	jal	ra,80005314 <virtio_disk_init>
    userinit();      // first user process
    80000f5a:	44b000ef          	jal	ra,80001ba4 <userinit>
    __sync_synchronize();
    80000f5e:	0ff0000f          	fence
    started = 1;
    80000f62:	4785                	li	a5,1
    80000f64:	00007717          	auipc	a4,0x7
    80000f68:	a2f72a23          	sw	a5,-1484(a4) # 80007998 <started>
    80000f6c:	b779                	j	80000efa <main+0x3e>

0000000080000f6e <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000f6e:	1141                	addi	sp,sp,-16
    80000f70:	e422                	sd	s0,8(sp)
    80000f72:	0800                	addi	s0,sp,16
  asm volatile("sfence.vma zero, zero");
    80000f74:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f78:	00007797          	auipc	a5,0x7
    80000f7c:	a287b783          	ld	a5,-1496(a5) # 800079a0 <kernel_pagetable>
    80000f80:	83b1                	srli	a5,a5,0xc
    80000f82:	577d                	li	a4,-1
    80000f84:	177e                	slli	a4,a4,0x3f
    80000f86:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f88:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f8c:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f90:	6422                	ld	s0,8(sp)
    80000f92:	0141                	addi	sp,sp,16
    80000f94:	8082                	ret

0000000080000f96 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f96:	7139                	addi	sp,sp,-64
    80000f98:	fc06                	sd	ra,56(sp)
    80000f9a:	f822                	sd	s0,48(sp)
    80000f9c:	f426                	sd	s1,40(sp)
    80000f9e:	f04a                	sd	s2,32(sp)
    80000fa0:	ec4e                	sd	s3,24(sp)
    80000fa2:	e852                	sd	s4,16(sp)
    80000fa4:	e456                	sd	s5,8(sp)
    80000fa6:	e05a                	sd	s6,0(sp)
    80000fa8:	0080                	addi	s0,sp,64
    80000faa:	84aa                	mv	s1,a0
    80000fac:	89ae                	mv	s3,a1
    80000fae:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000fb0:	57fd                	li	a5,-1
    80000fb2:	83e9                	srli	a5,a5,0x1a
    80000fb4:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fb6:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000fb8:	02b7fc63          	bgeu	a5,a1,80000ff0 <walk+0x5a>
    panic("walk");
    80000fbc:	00006517          	auipc	a0,0x6
    80000fc0:	12450513          	addi	a0,a0,292 # 800070e0 <digits+0x90>
    80000fc4:	81dff0ef          	jal	ra,800007e0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000fc8:	060a8263          	beqz	s5,8000102c <walk+0x96>
    80000fcc:	babff0ef          	jal	ra,80000b76 <kalloc>
    80000fd0:	84aa                	mv	s1,a0
    80000fd2:	c139                	beqz	a0,80001018 <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000fd4:	6605                	lui	a2,0x1
    80000fd6:	4581                	li	a1,0
    80000fd8:	d43ff0ef          	jal	ra,80000d1a <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000fdc:	00c4d793          	srli	a5,s1,0xc
    80000fe0:	07aa                	slli	a5,a5,0xa
    80000fe2:	0017e793          	ori	a5,a5,1
    80000fe6:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000fea:	3a5d                	addiw	s4,s4,-9
    80000fec:	036a0063          	beq	s4,s6,8000100c <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000ff0:	0149d933          	srl	s2,s3,s4
    80000ff4:	1ff97913          	andi	s2,s2,511
    80000ff8:	090e                	slli	s2,s2,0x3
    80000ffa:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000ffc:	00093483          	ld	s1,0(s2)
    80001000:	0014f793          	andi	a5,s1,1
    80001004:	d3f1                	beqz	a5,80000fc8 <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80001006:	80a9                	srli	s1,s1,0xa
    80001008:	04b2                	slli	s1,s1,0xc
    8000100a:	b7c5                	j	80000fea <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    8000100c:	00c9d513          	srli	a0,s3,0xc
    80001010:	1ff57513          	andi	a0,a0,511
    80001014:	050e                	slli	a0,a0,0x3
    80001016:	9526                	add	a0,a0,s1
}
    80001018:	70e2                	ld	ra,56(sp)
    8000101a:	7442                	ld	s0,48(sp)
    8000101c:	74a2                	ld	s1,40(sp)
    8000101e:	7902                	ld	s2,32(sp)
    80001020:	69e2                	ld	s3,24(sp)
    80001022:	6a42                	ld	s4,16(sp)
    80001024:	6aa2                	ld	s5,8(sp)
    80001026:	6b02                	ld	s6,0(sp)
    80001028:	6121                	addi	sp,sp,64
    8000102a:	8082                	ret
        return 0;
    8000102c:	4501                	li	a0,0
    8000102e:	b7ed                	j	80001018 <walk+0x82>

0000000080001030 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001030:	57fd                	li	a5,-1
    80001032:	83e9                	srli	a5,a5,0x1a
    80001034:	00b7f463          	bgeu	a5,a1,8000103c <walkaddr+0xc>
    return 0;
    80001038:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    8000103a:	8082                	ret
{
    8000103c:	1141                	addi	sp,sp,-16
    8000103e:	e406                	sd	ra,8(sp)
    80001040:	e022                	sd	s0,0(sp)
    80001042:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001044:	4601                	li	a2,0
    80001046:	f51ff0ef          	jal	ra,80000f96 <walk>
  if(pte == 0)
    8000104a:	c105                	beqz	a0,8000106a <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    8000104c:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000104e:	0117f693          	andi	a3,a5,17
    80001052:	4745                	li	a4,17
    return 0;
    80001054:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80001056:	00e68663          	beq	a3,a4,80001062 <walkaddr+0x32>
}
    8000105a:	60a2                	ld	ra,8(sp)
    8000105c:	6402                	ld	s0,0(sp)
    8000105e:	0141                	addi	sp,sp,16
    80001060:	8082                	ret
  pa = PTE2PA(*pte);
    80001062:	00a7d513          	srli	a0,a5,0xa
    80001066:	0532                	slli	a0,a0,0xc
  return pa;
    80001068:	bfcd                	j	8000105a <walkaddr+0x2a>
    return 0;
    8000106a:	4501                	li	a0,0
    8000106c:	b7fd                	j	8000105a <walkaddr+0x2a>

000000008000106e <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    8000106e:	715d                	addi	sp,sp,-80
    80001070:	e486                	sd	ra,72(sp)
    80001072:	e0a2                	sd	s0,64(sp)
    80001074:	fc26                	sd	s1,56(sp)
    80001076:	f84a                	sd	s2,48(sp)
    80001078:	f44e                	sd	s3,40(sp)
    8000107a:	f052                	sd	s4,32(sp)
    8000107c:	ec56                	sd	s5,24(sp)
    8000107e:	e85a                	sd	s6,16(sp)
    80001080:	e45e                	sd	s7,8(sp)
    80001082:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001084:	03459793          	slli	a5,a1,0x34
    80001088:	e7a9                	bnez	a5,800010d2 <mappages+0x64>
    8000108a:	8aaa                	mv	s5,a0
    8000108c:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    8000108e:	03461793          	slli	a5,a2,0x34
    80001092:	e7b1                	bnez	a5,800010de <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    80001094:	ca39                	beqz	a2,800010ea <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001096:	79fd                	lui	s3,0xfffff
    80001098:	964e                	add	a2,a2,s3
    8000109a:	00b609b3          	add	s3,a2,a1
  a = va;
    8000109e:	892e                	mv	s2,a1
    800010a0:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800010a4:	6b85                	lui	s7,0x1
    800010a6:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    800010aa:	4605                	li	a2,1
    800010ac:	85ca                	mv	a1,s2
    800010ae:	8556                	mv	a0,s5
    800010b0:	ee7ff0ef          	jal	ra,80000f96 <walk>
    800010b4:	c539                	beqz	a0,80001102 <mappages+0x94>
    if(*pte & PTE_V)
    800010b6:	611c                	ld	a5,0(a0)
    800010b8:	8b85                	andi	a5,a5,1
    800010ba:	ef95                	bnez	a5,800010f6 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010bc:	80b1                	srli	s1,s1,0xc
    800010be:	04aa                	slli	s1,s1,0xa
    800010c0:	0164e4b3          	or	s1,s1,s6
    800010c4:	0014e493          	ori	s1,s1,1
    800010c8:	e104                	sd	s1,0(a0)
    if(a == last)
    800010ca:	05390863          	beq	s2,s3,8000111a <mappages+0xac>
    a += PGSIZE;
    800010ce:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010d0:	bfd9                	j	800010a6 <mappages+0x38>
    panic("mappages: va not aligned");
    800010d2:	00006517          	auipc	a0,0x6
    800010d6:	01650513          	addi	a0,a0,22 # 800070e8 <digits+0x98>
    800010da:	f06ff0ef          	jal	ra,800007e0 <panic>
    panic("mappages: size not aligned");
    800010de:	00006517          	auipc	a0,0x6
    800010e2:	02a50513          	addi	a0,a0,42 # 80007108 <digits+0xb8>
    800010e6:	efaff0ef          	jal	ra,800007e0 <panic>
    panic("mappages: size");
    800010ea:	00006517          	auipc	a0,0x6
    800010ee:	03e50513          	addi	a0,a0,62 # 80007128 <digits+0xd8>
    800010f2:	eeeff0ef          	jal	ra,800007e0 <panic>
      panic("mappages: remap");
    800010f6:	00006517          	auipc	a0,0x6
    800010fa:	04250513          	addi	a0,a0,66 # 80007138 <digits+0xe8>
    800010fe:	ee2ff0ef          	jal	ra,800007e0 <panic>
      return -1;
    80001102:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001104:	60a6                	ld	ra,72(sp)
    80001106:	6406                	ld	s0,64(sp)
    80001108:	74e2                	ld	s1,56(sp)
    8000110a:	7942                	ld	s2,48(sp)
    8000110c:	79a2                	ld	s3,40(sp)
    8000110e:	7a02                	ld	s4,32(sp)
    80001110:	6ae2                	ld	s5,24(sp)
    80001112:	6b42                	ld	s6,16(sp)
    80001114:	6ba2                	ld	s7,8(sp)
    80001116:	6161                	addi	sp,sp,80
    80001118:	8082                	ret
  return 0;
    8000111a:	4501                	li	a0,0
    8000111c:	b7e5                	j	80001104 <mappages+0x96>

000000008000111e <kvmmap>:
{
    8000111e:	1141                	addi	sp,sp,-16
    80001120:	e406                	sd	ra,8(sp)
    80001122:	e022                	sd	s0,0(sp)
    80001124:	0800                	addi	s0,sp,16
    80001126:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001128:	86b2                	mv	a3,a2
    8000112a:	863e                	mv	a2,a5
    8000112c:	f43ff0ef          	jal	ra,8000106e <mappages>
    80001130:	e509                	bnez	a0,8000113a <kvmmap+0x1c>
}
    80001132:	60a2                	ld	ra,8(sp)
    80001134:	6402                	ld	s0,0(sp)
    80001136:	0141                	addi	sp,sp,16
    80001138:	8082                	ret
    panic("kvmmap");
    8000113a:	00006517          	auipc	a0,0x6
    8000113e:	00e50513          	addi	a0,a0,14 # 80007148 <digits+0xf8>
    80001142:	e9eff0ef          	jal	ra,800007e0 <panic>

0000000080001146 <kvmmake>:
{
    80001146:	1101                	addi	sp,sp,-32
    80001148:	ec06                	sd	ra,24(sp)
    8000114a:	e822                	sd	s0,16(sp)
    8000114c:	e426                	sd	s1,8(sp)
    8000114e:	e04a                	sd	s2,0(sp)
    80001150:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001152:	a25ff0ef          	jal	ra,80000b76 <kalloc>
    80001156:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001158:	6605                	lui	a2,0x1
    8000115a:	4581                	li	a1,0
    8000115c:	bbfff0ef          	jal	ra,80000d1a <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001160:	4719                	li	a4,6
    80001162:	6685                	lui	a3,0x1
    80001164:	10000637          	lui	a2,0x10000
    80001168:	100005b7          	lui	a1,0x10000
    8000116c:	8526                	mv	a0,s1
    8000116e:	fb1ff0ef          	jal	ra,8000111e <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001172:	4719                	li	a4,6
    80001174:	6685                	lui	a3,0x1
    80001176:	10001637          	lui	a2,0x10001
    8000117a:	100015b7          	lui	a1,0x10001
    8000117e:	8526                	mv	a0,s1
    80001180:	f9fff0ef          	jal	ra,8000111e <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001184:	4719                	li	a4,6
    80001186:	040006b7          	lui	a3,0x4000
    8000118a:	0c000637          	lui	a2,0xc000
    8000118e:	0c0005b7          	lui	a1,0xc000
    80001192:	8526                	mv	a0,s1
    80001194:	f8bff0ef          	jal	ra,8000111e <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001198:	00006917          	auipc	s2,0x6
    8000119c:	e6890913          	addi	s2,s2,-408 # 80007000 <etext>
    800011a0:	4729                	li	a4,10
    800011a2:	80006697          	auipc	a3,0x80006
    800011a6:	e5e68693          	addi	a3,a3,-418 # 7000 <_entry-0x7fff9000>
    800011aa:	4605                	li	a2,1
    800011ac:	067e                	slli	a2,a2,0x1f
    800011ae:	85b2                	mv	a1,a2
    800011b0:	8526                	mv	a0,s1
    800011b2:	f6dff0ef          	jal	ra,8000111e <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800011b6:	4719                	li	a4,6
    800011b8:	46c5                	li	a3,17
    800011ba:	06ee                	slli	a3,a3,0x1b
    800011bc:	412686b3          	sub	a3,a3,s2
    800011c0:	864a                	mv	a2,s2
    800011c2:	85ca                	mv	a1,s2
    800011c4:	8526                	mv	a0,s1
    800011c6:	f59ff0ef          	jal	ra,8000111e <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011ca:	4729                	li	a4,10
    800011cc:	6685                	lui	a3,0x1
    800011ce:	00005617          	auipc	a2,0x5
    800011d2:	e3260613          	addi	a2,a2,-462 # 80006000 <_trampoline>
    800011d6:	040005b7          	lui	a1,0x4000
    800011da:	15fd                	addi	a1,a1,-1
    800011dc:	05b2                	slli	a1,a1,0xc
    800011de:	8526                	mv	a0,s1
    800011e0:	f3fff0ef          	jal	ra,8000111e <kvmmap>
  proc_mapstacks(kpgtbl);
    800011e4:	8526                	mv	a0,s1
    800011e6:	59a000ef          	jal	ra,80001780 <proc_mapstacks>
}
    800011ea:	8526                	mv	a0,s1
    800011ec:	60e2                	ld	ra,24(sp)
    800011ee:	6442                	ld	s0,16(sp)
    800011f0:	64a2                	ld	s1,8(sp)
    800011f2:	6902                	ld	s2,0(sp)
    800011f4:	6105                	addi	sp,sp,32
    800011f6:	8082                	ret

00000000800011f8 <kvminit>:
{
    800011f8:	1141                	addi	sp,sp,-16
    800011fa:	e406                	sd	ra,8(sp)
    800011fc:	e022                	sd	s0,0(sp)
    800011fe:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001200:	f47ff0ef          	jal	ra,80001146 <kvmmake>
    80001204:	00006797          	auipc	a5,0x6
    80001208:	78a7be23          	sd	a0,1948(a5) # 800079a0 <kernel_pagetable>
}
    8000120c:	60a2                	ld	ra,8(sp)
    8000120e:	6402                	ld	s0,0(sp)
    80001210:	0141                	addi	sp,sp,16
    80001212:	8082                	ret

0000000080001214 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001214:	7139                	addi	sp,sp,-64
    80001216:	fc06                	sd	ra,56(sp)
    80001218:	f822                	sd	s0,48(sp)
    8000121a:	f426                	sd	s1,40(sp)
    8000121c:	f04a                	sd	s2,32(sp)
    8000121e:	ec4e                	sd	s3,24(sp)
    80001220:	e852                	sd	s4,16(sp)
    80001222:	e456                	sd	s5,8(sp)
    80001224:	e05a                	sd	s6,0(sp)
    80001226:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001228:	03459793          	slli	a5,a1,0x34
    8000122c:	e785                	bnez	a5,80001254 <uvmunmap+0x40>
    8000122e:	8a2a                	mv	s4,a0
    80001230:	892e                	mv	s2,a1
    80001232:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001234:	0632                	slli	a2,a2,0xc
    80001236:	00b609b3          	add	s3,a2,a1
    8000123a:	6b05                	lui	s6,0x1
    8000123c:	0335e763          	bltu	a1,s3,8000126a <uvmunmap+0x56>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    80001240:	70e2                	ld	ra,56(sp)
    80001242:	7442                	ld	s0,48(sp)
    80001244:	74a2                	ld	s1,40(sp)
    80001246:	7902                	ld	s2,32(sp)
    80001248:	69e2                	ld	s3,24(sp)
    8000124a:	6a42                	ld	s4,16(sp)
    8000124c:	6aa2                	ld	s5,8(sp)
    8000124e:	6b02                	ld	s6,0(sp)
    80001250:	6121                	addi	sp,sp,64
    80001252:	8082                	ret
    panic("uvmunmap: not aligned");
    80001254:	00006517          	auipc	a0,0x6
    80001258:	efc50513          	addi	a0,a0,-260 # 80007150 <digits+0x100>
    8000125c:	d84ff0ef          	jal	ra,800007e0 <panic>
    *pte = 0;
    80001260:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001264:	995a                	add	s2,s2,s6
    80001266:	fd397de3          	bgeu	s2,s3,80001240 <uvmunmap+0x2c>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000126a:	4601                	li	a2,0
    8000126c:	85ca                	mv	a1,s2
    8000126e:	8552                	mv	a0,s4
    80001270:	d27ff0ef          	jal	ra,80000f96 <walk>
    80001274:	84aa                	mv	s1,a0
    80001276:	d57d                	beqz	a0,80001264 <uvmunmap+0x50>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    80001278:	611c                	ld	a5,0(a0)
    8000127a:	0017f713          	andi	a4,a5,1
    8000127e:	d37d                	beqz	a4,80001264 <uvmunmap+0x50>
    if(do_free){
    80001280:	fe0a80e3          	beqz	s5,80001260 <uvmunmap+0x4c>
      uint64 pa = PTE2PA(*pte);
    80001284:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    80001286:	00c79513          	slli	a0,a5,0xc
    8000128a:	80dff0ef          	jal	ra,80000a96 <kfree>
    8000128e:	bfc9                	j	80001260 <uvmunmap+0x4c>

0000000080001290 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001290:	1101                	addi	sp,sp,-32
    80001292:	ec06                	sd	ra,24(sp)
    80001294:	e822                	sd	s0,16(sp)
    80001296:	e426                	sd	s1,8(sp)
    80001298:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000129a:	8ddff0ef          	jal	ra,80000b76 <kalloc>
    8000129e:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800012a0:	c509                	beqz	a0,800012aa <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800012a2:	6605                	lui	a2,0x1
    800012a4:	4581                	li	a1,0
    800012a6:	a75ff0ef          	jal	ra,80000d1a <memset>
  return pagetable;
}
    800012aa:	8526                	mv	a0,s1
    800012ac:	60e2                	ld	ra,24(sp)
    800012ae:	6442                	ld	s0,16(sp)
    800012b0:	64a2                	ld	s1,8(sp)
    800012b2:	6105                	addi	sp,sp,32
    800012b4:	8082                	ret

00000000800012b6 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012b6:	1101                	addi	sp,sp,-32
    800012b8:	ec06                	sd	ra,24(sp)
    800012ba:	e822                	sd	s0,16(sp)
    800012bc:	e426                	sd	s1,8(sp)
    800012be:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800012c0:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800012c2:	00b67d63          	bgeu	a2,a1,800012dc <uvmdealloc+0x26>
    800012c6:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800012c8:	6785                	lui	a5,0x1
    800012ca:	17fd                	addi	a5,a5,-1
    800012cc:	00f60733          	add	a4,a2,a5
    800012d0:	767d                	lui	a2,0xfffff
    800012d2:	8f71                	and	a4,a4,a2
    800012d4:	97ae                	add	a5,a5,a1
    800012d6:	8ff1                	and	a5,a5,a2
    800012d8:	00f76863          	bltu	a4,a5,800012e8 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800012dc:	8526                	mv	a0,s1
    800012de:	60e2                	ld	ra,24(sp)
    800012e0:	6442                	ld	s0,16(sp)
    800012e2:	64a2                	ld	s1,8(sp)
    800012e4:	6105                	addi	sp,sp,32
    800012e6:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012e8:	8f99                	sub	a5,a5,a4
    800012ea:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012ec:	4685                	li	a3,1
    800012ee:	0007861b          	sext.w	a2,a5
    800012f2:	85ba                	mv	a1,a4
    800012f4:	f21ff0ef          	jal	ra,80001214 <uvmunmap>
    800012f8:	b7d5                	j	800012dc <uvmdealloc+0x26>

00000000800012fa <uvmalloc>:
  if(newsz < oldsz)
    800012fa:	08b66963          	bltu	a2,a1,8000138c <uvmalloc+0x92>
{
    800012fe:	7139                	addi	sp,sp,-64
    80001300:	fc06                	sd	ra,56(sp)
    80001302:	f822                	sd	s0,48(sp)
    80001304:	f426                	sd	s1,40(sp)
    80001306:	f04a                	sd	s2,32(sp)
    80001308:	ec4e                	sd	s3,24(sp)
    8000130a:	e852                	sd	s4,16(sp)
    8000130c:	e456                	sd	s5,8(sp)
    8000130e:	e05a                	sd	s6,0(sp)
    80001310:	0080                	addi	s0,sp,64
    80001312:	8aaa                	mv	s5,a0
    80001314:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001316:	6985                	lui	s3,0x1
    80001318:	19fd                	addi	s3,s3,-1
    8000131a:	95ce                	add	a1,a1,s3
    8000131c:	79fd                	lui	s3,0xfffff
    8000131e:	0135f9b3          	and	s3,a1,s3
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001322:	06c9f763          	bgeu	s3,a2,80001390 <uvmalloc+0x96>
    80001326:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001328:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    8000132c:	84bff0ef          	jal	ra,80000b76 <kalloc>
    80001330:	84aa                	mv	s1,a0
    if(mem == 0){
    80001332:	c11d                	beqz	a0,80001358 <uvmalloc+0x5e>
    memset(mem, 0, PGSIZE);
    80001334:	6605                	lui	a2,0x1
    80001336:	4581                	li	a1,0
    80001338:	9e3ff0ef          	jal	ra,80000d1a <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000133c:	875a                	mv	a4,s6
    8000133e:	86a6                	mv	a3,s1
    80001340:	6605                	lui	a2,0x1
    80001342:	85ca                	mv	a1,s2
    80001344:	8556                	mv	a0,s5
    80001346:	d29ff0ef          	jal	ra,8000106e <mappages>
    8000134a:	e51d                	bnez	a0,80001378 <uvmalloc+0x7e>
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000134c:	6785                	lui	a5,0x1
    8000134e:	993e                	add	s2,s2,a5
    80001350:	fd496ee3          	bltu	s2,s4,8000132c <uvmalloc+0x32>
  return newsz;
    80001354:	8552                	mv	a0,s4
    80001356:	a039                	j	80001364 <uvmalloc+0x6a>
      uvmdealloc(pagetable, a, oldsz);
    80001358:	864e                	mv	a2,s3
    8000135a:	85ca                	mv	a1,s2
    8000135c:	8556                	mv	a0,s5
    8000135e:	f59ff0ef          	jal	ra,800012b6 <uvmdealloc>
      return 0;
    80001362:	4501                	li	a0,0
}
    80001364:	70e2                	ld	ra,56(sp)
    80001366:	7442                	ld	s0,48(sp)
    80001368:	74a2                	ld	s1,40(sp)
    8000136a:	7902                	ld	s2,32(sp)
    8000136c:	69e2                	ld	s3,24(sp)
    8000136e:	6a42                	ld	s4,16(sp)
    80001370:	6aa2                	ld	s5,8(sp)
    80001372:	6b02                	ld	s6,0(sp)
    80001374:	6121                	addi	sp,sp,64
    80001376:	8082                	ret
      kfree(mem);
    80001378:	8526                	mv	a0,s1
    8000137a:	f1cff0ef          	jal	ra,80000a96 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000137e:	864e                	mv	a2,s3
    80001380:	85ca                	mv	a1,s2
    80001382:	8556                	mv	a0,s5
    80001384:	f33ff0ef          	jal	ra,800012b6 <uvmdealloc>
      return 0;
    80001388:	4501                	li	a0,0
    8000138a:	bfe9                	j	80001364 <uvmalloc+0x6a>
    return oldsz;
    8000138c:	852e                	mv	a0,a1
}
    8000138e:	8082                	ret
  return newsz;
    80001390:	8532                	mv	a0,a2
    80001392:	bfc9                	j	80001364 <uvmalloc+0x6a>

0000000080001394 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001394:	7179                	addi	sp,sp,-48
    80001396:	f406                	sd	ra,40(sp)
    80001398:	f022                	sd	s0,32(sp)
    8000139a:	ec26                	sd	s1,24(sp)
    8000139c:	e84a                	sd	s2,16(sp)
    8000139e:	e44e                	sd	s3,8(sp)
    800013a0:	e052                	sd	s4,0(sp)
    800013a2:	1800                	addi	s0,sp,48
    800013a4:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800013a6:	84aa                	mv	s1,a0
    800013a8:	6905                	lui	s2,0x1
    800013aa:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013ac:	4985                	li	s3,1
    800013ae:	a811                	j	800013c2 <freewalk+0x2e>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800013b0:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    800013b2:	0532                	slli	a0,a0,0xc
    800013b4:	fe1ff0ef          	jal	ra,80001394 <freewalk>
      pagetable[i] = 0;
    800013b8:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    800013bc:	04a1                	addi	s1,s1,8
    800013be:	01248f63          	beq	s1,s2,800013dc <freewalk+0x48>
    pte_t pte = pagetable[i];
    800013c2:	6088                	ld	a0,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013c4:	00f57793          	andi	a5,a0,15
    800013c8:	ff3784e3          	beq	a5,s3,800013b0 <freewalk+0x1c>
    } else if(pte & PTE_V){
    800013cc:	8905                	andi	a0,a0,1
    800013ce:	d57d                	beqz	a0,800013bc <freewalk+0x28>
      panic("freewalk: leaf");
    800013d0:	00006517          	auipc	a0,0x6
    800013d4:	d9850513          	addi	a0,a0,-616 # 80007168 <digits+0x118>
    800013d8:	c08ff0ef          	jal	ra,800007e0 <panic>
    }
  }
  kfree((void*)pagetable);
    800013dc:	8552                	mv	a0,s4
    800013de:	eb8ff0ef          	jal	ra,80000a96 <kfree>
}
    800013e2:	70a2                	ld	ra,40(sp)
    800013e4:	7402                	ld	s0,32(sp)
    800013e6:	64e2                	ld	s1,24(sp)
    800013e8:	6942                	ld	s2,16(sp)
    800013ea:	69a2                	ld	s3,8(sp)
    800013ec:	6a02                	ld	s4,0(sp)
    800013ee:	6145                	addi	sp,sp,48
    800013f0:	8082                	ret

00000000800013f2 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800013f2:	1101                	addi	sp,sp,-32
    800013f4:	ec06                	sd	ra,24(sp)
    800013f6:	e822                	sd	s0,16(sp)
    800013f8:	e426                	sd	s1,8(sp)
    800013fa:	1000                	addi	s0,sp,32
    800013fc:	84aa                	mv	s1,a0
  if(sz > 0)
    800013fe:	e989                	bnez	a1,80001410 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001400:	8526                	mv	a0,s1
    80001402:	f93ff0ef          	jal	ra,80001394 <freewalk>
}
    80001406:	60e2                	ld	ra,24(sp)
    80001408:	6442                	ld	s0,16(sp)
    8000140a:	64a2                	ld	s1,8(sp)
    8000140c:	6105                	addi	sp,sp,32
    8000140e:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001410:	6605                	lui	a2,0x1
    80001412:	167d                	addi	a2,a2,-1
    80001414:	962e                	add	a2,a2,a1
    80001416:	4685                	li	a3,1
    80001418:	8231                	srli	a2,a2,0xc
    8000141a:	4581                	li	a1,0
    8000141c:	df9ff0ef          	jal	ra,80001214 <uvmunmap>
    80001420:	b7c5                	j	80001400 <uvmfree+0xe>

0000000080001422 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001422:	ce49                	beqz	a2,800014bc <uvmcopy+0x9a>
{
    80001424:	715d                	addi	sp,sp,-80
    80001426:	e486                	sd	ra,72(sp)
    80001428:	e0a2                	sd	s0,64(sp)
    8000142a:	fc26                	sd	s1,56(sp)
    8000142c:	f84a                	sd	s2,48(sp)
    8000142e:	f44e                	sd	s3,40(sp)
    80001430:	f052                	sd	s4,32(sp)
    80001432:	ec56                	sd	s5,24(sp)
    80001434:	e85a                	sd	s6,16(sp)
    80001436:	e45e                	sd	s7,8(sp)
    80001438:	0880                	addi	s0,sp,80
    8000143a:	8aaa                	mv	s5,a0
    8000143c:	8b2e                	mv	s6,a1
    8000143e:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001440:	4481                	li	s1,0
    80001442:	a029                	j	8000144c <uvmcopy+0x2a>
    80001444:	6785                	lui	a5,0x1
    80001446:	94be                	add	s1,s1,a5
    80001448:	0544fe63          	bgeu	s1,s4,800014a4 <uvmcopy+0x82>
    if((pte = walk(old, i, 0)) == 0)
    8000144c:	4601                	li	a2,0
    8000144e:	85a6                	mv	a1,s1
    80001450:	8556                	mv	a0,s5
    80001452:	b45ff0ef          	jal	ra,80000f96 <walk>
    80001456:	d57d                	beqz	a0,80001444 <uvmcopy+0x22>
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
    80001458:	6118                	ld	a4,0(a0)
    8000145a:	00177793          	andi	a5,a4,1
    8000145e:	d3fd                	beqz	a5,80001444 <uvmcopy+0x22>
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    80001460:	00a75593          	srli	a1,a4,0xa
    80001464:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80001468:	3ff77913          	andi	s2,a4,1023
    if((mem = kalloc()) == 0)
    8000146c:	f0aff0ef          	jal	ra,80000b76 <kalloc>
    80001470:	89aa                	mv	s3,a0
    80001472:	c105                	beqz	a0,80001492 <uvmcopy+0x70>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001474:	6605                	lui	a2,0x1
    80001476:	85de                	mv	a1,s7
    80001478:	8ffff0ef          	jal	ra,80000d76 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000147c:	874a                	mv	a4,s2
    8000147e:	86ce                	mv	a3,s3
    80001480:	6605                	lui	a2,0x1
    80001482:	85a6                	mv	a1,s1
    80001484:	855a                	mv	a0,s6
    80001486:	be9ff0ef          	jal	ra,8000106e <mappages>
    8000148a:	dd4d                	beqz	a0,80001444 <uvmcopy+0x22>
      kfree(mem);
    8000148c:	854e                	mv	a0,s3
    8000148e:	e08ff0ef          	jal	ra,80000a96 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001492:	4685                	li	a3,1
    80001494:	00c4d613          	srli	a2,s1,0xc
    80001498:	4581                	li	a1,0
    8000149a:	855a                	mv	a0,s6
    8000149c:	d79ff0ef          	jal	ra,80001214 <uvmunmap>
  return -1;
    800014a0:	557d                	li	a0,-1
    800014a2:	a011                	j	800014a6 <uvmcopy+0x84>
  return 0;
    800014a4:	4501                	li	a0,0
}
    800014a6:	60a6                	ld	ra,72(sp)
    800014a8:	6406                	ld	s0,64(sp)
    800014aa:	74e2                	ld	s1,56(sp)
    800014ac:	7942                	ld	s2,48(sp)
    800014ae:	79a2                	ld	s3,40(sp)
    800014b0:	7a02                	ld	s4,32(sp)
    800014b2:	6ae2                	ld	s5,24(sp)
    800014b4:	6b42                	ld	s6,16(sp)
    800014b6:	6ba2                	ld	s7,8(sp)
    800014b8:	6161                	addi	sp,sp,80
    800014ba:	8082                	ret
  return 0;
    800014bc:	4501                	li	a0,0
}
    800014be:	8082                	ret

00000000800014c0 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014c0:	1141                	addi	sp,sp,-16
    800014c2:	e406                	sd	ra,8(sp)
    800014c4:	e022                	sd	s0,0(sp)
    800014c6:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800014c8:	4601                	li	a2,0
    800014ca:	acdff0ef          	jal	ra,80000f96 <walk>
  if(pte == 0)
    800014ce:	c901                	beqz	a0,800014de <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800014d0:	611c                	ld	a5,0(a0)
    800014d2:	9bbd                	andi	a5,a5,-17
    800014d4:	e11c                	sd	a5,0(a0)
}
    800014d6:	60a2                	ld	ra,8(sp)
    800014d8:	6402                	ld	s0,0(sp)
    800014da:	0141                	addi	sp,sp,16
    800014dc:	8082                	ret
    panic("uvmclear");
    800014de:	00006517          	auipc	a0,0x6
    800014e2:	c9a50513          	addi	a0,a0,-870 # 80007178 <digits+0x128>
    800014e6:	afaff0ef          	jal	ra,800007e0 <panic>

00000000800014ea <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800014ea:	c2d5                	beqz	a3,8000158e <copyinstr+0xa4>
{
    800014ec:	715d                	addi	sp,sp,-80
    800014ee:	e486                	sd	ra,72(sp)
    800014f0:	e0a2                	sd	s0,64(sp)
    800014f2:	fc26                	sd	s1,56(sp)
    800014f4:	f84a                	sd	s2,48(sp)
    800014f6:	f44e                	sd	s3,40(sp)
    800014f8:	f052                	sd	s4,32(sp)
    800014fa:	ec56                	sd	s5,24(sp)
    800014fc:	e85a                	sd	s6,16(sp)
    800014fe:	e45e                	sd	s7,8(sp)
    80001500:	0880                	addi	s0,sp,80
    80001502:	8a2a                	mv	s4,a0
    80001504:	8b2e                	mv	s6,a1
    80001506:	8bb2                	mv	s7,a2
    80001508:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    8000150a:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000150c:	6985                	lui	s3,0x1
    8000150e:	a035                	j	8000153a <copyinstr+0x50>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80001510:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80001514:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001516:	0017b793          	seqz	a5,a5
    8000151a:	40f00533          	neg	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000151e:	60a6                	ld	ra,72(sp)
    80001520:	6406                	ld	s0,64(sp)
    80001522:	74e2                	ld	s1,56(sp)
    80001524:	7942                	ld	s2,48(sp)
    80001526:	79a2                	ld	s3,40(sp)
    80001528:	7a02                	ld	s4,32(sp)
    8000152a:	6ae2                	ld	s5,24(sp)
    8000152c:	6b42                	ld	s6,16(sp)
    8000152e:	6ba2                	ld	s7,8(sp)
    80001530:	6161                	addi	sp,sp,80
    80001532:	8082                	ret
    srcva = va0 + PGSIZE;
    80001534:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    80001538:	c4b9                	beqz	s1,80001586 <copyinstr+0x9c>
    va0 = PGROUNDDOWN(srcva);
    8000153a:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    8000153e:	85ca                	mv	a1,s2
    80001540:	8552                	mv	a0,s4
    80001542:	aefff0ef          	jal	ra,80001030 <walkaddr>
    if(pa0 == 0)
    80001546:	c131                	beqz	a0,8000158a <copyinstr+0xa0>
    n = PGSIZE - (srcva - va0);
    80001548:	41790833          	sub	a6,s2,s7
    8000154c:	984e                	add	a6,a6,s3
    if(n > max)
    8000154e:	0104f363          	bgeu	s1,a6,80001554 <copyinstr+0x6a>
    80001552:	8826                	mv	a6,s1
    char *p = (char *) (pa0 + (srcva - va0));
    80001554:	955e                	add	a0,a0,s7
    80001556:	41250533          	sub	a0,a0,s2
    while(n > 0){
    8000155a:	fc080de3          	beqz	a6,80001534 <copyinstr+0x4a>
    8000155e:	985a                	add	a6,a6,s6
    80001560:	87da                	mv	a5,s6
      if(*p == '\0'){
    80001562:	41650633          	sub	a2,a0,s6
    80001566:	14fd                	addi	s1,s1,-1
    80001568:	9b26                	add	s6,s6,s1
    8000156a:	00f60733          	add	a4,a2,a5
    8000156e:	00074703          	lbu	a4,0(a4)
    80001572:	df59                	beqz	a4,80001510 <copyinstr+0x26>
        *dst = *p;
    80001574:	00e78023          	sb	a4,0(a5)
      --max;
    80001578:	40fb04b3          	sub	s1,s6,a5
      dst++;
    8000157c:	0785                	addi	a5,a5,1
    while(n > 0){
    8000157e:	ff0796e3          	bne	a5,a6,8000156a <copyinstr+0x80>
      dst++;
    80001582:	8b42                	mv	s6,a6
    80001584:	bf45                	j	80001534 <copyinstr+0x4a>
    80001586:	4781                	li	a5,0
    80001588:	b779                	j	80001516 <copyinstr+0x2c>
      return -1;
    8000158a:	557d                	li	a0,-1
    8000158c:	bf49                	j	8000151e <copyinstr+0x34>
  int got_null = 0;
    8000158e:	4781                	li	a5,0
  if(got_null){
    80001590:	0017b793          	seqz	a5,a5
    80001594:	40f00533          	neg	a0,a5
}
    80001598:	8082                	ret

000000008000159a <ismapped>:
  return ka;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    8000159a:	1141                	addi	sp,sp,-16
    8000159c:	e406                	sd	ra,8(sp)
    8000159e:	e022                	sd	s0,0(sp)
    800015a0:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800015a2:	4601                	li	a2,0
    800015a4:	9f3ff0ef          	jal	ra,80000f96 <walk>
  if (pte == 0) {
    800015a8:	c519                	beqz	a0,800015b6 <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    800015aa:	6108                	ld	a0,0(a0)
    return 0;
    800015ac:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800015ae:	60a2                	ld	ra,8(sp)
    800015b0:	6402                	ld	s0,0(sp)
    800015b2:	0141                	addi	sp,sp,16
    800015b4:	8082                	ret
    return 0;
    800015b6:	4501                	li	a0,0
    800015b8:	bfdd                	j	800015ae <ismapped+0x14>

00000000800015ba <vmfault>:
{
    800015ba:	7179                	addi	sp,sp,-48
    800015bc:	f406                	sd	ra,40(sp)
    800015be:	f022                	sd	s0,32(sp)
    800015c0:	ec26                	sd	s1,24(sp)
    800015c2:	e84a                	sd	s2,16(sp)
    800015c4:	e44e                	sd	s3,8(sp)
    800015c6:	e052                	sd	s4,0(sp)
    800015c8:	1800                	addi	s0,sp,48
    800015ca:	89aa                	mv	s3,a0
    800015cc:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    800015ce:	310000ef          	jal	ra,800018de <myproc>
  if (va >= p->sz)
    800015d2:	653c                	ld	a5,72(a0)
    800015d4:	00f4ec63          	bltu	s1,a5,800015ec <vmfault+0x32>
    return 0;
    800015d8:	4981                	li	s3,0
}
    800015da:	854e                	mv	a0,s3
    800015dc:	70a2                	ld	ra,40(sp)
    800015de:	7402                	ld	s0,32(sp)
    800015e0:	64e2                	ld	s1,24(sp)
    800015e2:	6942                	ld	s2,16(sp)
    800015e4:	69a2                	ld	s3,8(sp)
    800015e6:	6a02                	ld	s4,0(sp)
    800015e8:	6145                	addi	sp,sp,48
    800015ea:	8082                	ret
    800015ec:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    800015ee:	75fd                	lui	a1,0xfffff
    800015f0:	8ced                	and	s1,s1,a1
  if(ismapped(pagetable, va)) {
    800015f2:	85a6                	mv	a1,s1
    800015f4:	854e                	mv	a0,s3
    800015f6:	fa5ff0ef          	jal	ra,8000159a <ismapped>
    return 0;
    800015fa:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    800015fc:	fd79                	bnez	a0,800015da <vmfault+0x20>
  ka = (uint64) kalloc();
    800015fe:	d78ff0ef          	jal	ra,80000b76 <kalloc>
    80001602:	8a2a                	mv	s4,a0
  if(ka == 0)
    80001604:	d979                	beqz	a0,800015da <vmfault+0x20>
  ka = (uint64) kalloc();
    80001606:	89aa                	mv	s3,a0
  memset((void *) ka, 0, PGSIZE);
    80001608:	6605                	lui	a2,0x1
    8000160a:	4581                	li	a1,0
    8000160c:	f0eff0ef          	jal	ra,80000d1a <memset>
  if (mappages(p->pagetable, va, PGSIZE, ka, PTE_W|PTE_U|PTE_R) != 0) {
    80001610:	4759                	li	a4,22
    80001612:	86d2                	mv	a3,s4
    80001614:	6605                	lui	a2,0x1
    80001616:	85a6                	mv	a1,s1
    80001618:	05093503          	ld	a0,80(s2) # 1050 <_entry-0x7fffefb0>
    8000161c:	a53ff0ef          	jal	ra,8000106e <mappages>
    80001620:	dd4d                	beqz	a0,800015da <vmfault+0x20>
    kfree((void *)ka);
    80001622:	8552                	mv	a0,s4
    80001624:	c72ff0ef          	jal	ra,80000a96 <kfree>
    return 0;
    80001628:	4981                	li	s3,0
    8000162a:	bf45                	j	800015da <vmfault+0x20>

000000008000162c <copyout>:
  while(len > 0){
    8000162c:	cec1                	beqz	a3,800016c4 <copyout+0x98>
{
    8000162e:	711d                	addi	sp,sp,-96
    80001630:	ec86                	sd	ra,88(sp)
    80001632:	e8a2                	sd	s0,80(sp)
    80001634:	e4a6                	sd	s1,72(sp)
    80001636:	e0ca                	sd	s2,64(sp)
    80001638:	fc4e                	sd	s3,56(sp)
    8000163a:	f852                	sd	s4,48(sp)
    8000163c:	f456                	sd	s5,40(sp)
    8000163e:	f05a                	sd	s6,32(sp)
    80001640:	ec5e                	sd	s7,24(sp)
    80001642:	e862                	sd	s8,16(sp)
    80001644:	e466                	sd	s9,8(sp)
    80001646:	e06a                	sd	s10,0(sp)
    80001648:	1080                	addi	s0,sp,96
    8000164a:	8c2a                	mv	s8,a0
    8000164c:	8b2e                	mv	s6,a1
    8000164e:	8bb2                	mv	s7,a2
    80001650:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    80001652:	74fd                	lui	s1,0xfffff
    80001654:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    80001656:	57fd                	li	a5,-1
    80001658:	83e9                	srli	a5,a5,0x1a
    8000165a:	0697e763          	bltu	a5,s1,800016c8 <copyout+0x9c>
    8000165e:	6d05                	lui	s10,0x1
    80001660:	8cbe                	mv	s9,a5
    80001662:	a015                	j	80001686 <copyout+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001664:	409b0533          	sub	a0,s6,s1
    80001668:	0009861b          	sext.w	a2,s3
    8000166c:	85de                	mv	a1,s7
    8000166e:	954a                	add	a0,a0,s2
    80001670:	f06ff0ef          	jal	ra,80000d76 <memmove>
    len -= n;
    80001674:	413a0a33          	sub	s4,s4,s3
    src += n;
    80001678:	9bce                	add	s7,s7,s3
  while(len > 0){
    8000167a:	040a0363          	beqz	s4,800016c0 <copyout+0x94>
    if(va0 >= MAXVA)
    8000167e:	055ce763          	bltu	s9,s5,800016cc <copyout+0xa0>
    va0 = PGROUNDDOWN(dstva);
    80001682:	84d6                	mv	s1,s5
    dstva = va0 + PGSIZE;
    80001684:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    80001686:	85a6                	mv	a1,s1
    80001688:	8562                	mv	a0,s8
    8000168a:	9a7ff0ef          	jal	ra,80001030 <walkaddr>
    8000168e:	892a                	mv	s2,a0
    if(pa0 == 0) {
    80001690:	e901                	bnez	a0,800016a0 <copyout+0x74>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001692:	4601                	li	a2,0
    80001694:	85a6                	mv	a1,s1
    80001696:	8562                	mv	a0,s8
    80001698:	f23ff0ef          	jal	ra,800015ba <vmfault>
    8000169c:	892a                	mv	s2,a0
    8000169e:	c90d                	beqz	a0,800016d0 <copyout+0xa4>
    pte = walk(pagetable, va0, 0);
    800016a0:	4601                	li	a2,0
    800016a2:	85a6                	mv	a1,s1
    800016a4:	8562                	mv	a0,s8
    800016a6:	8f1ff0ef          	jal	ra,80000f96 <walk>
    if((*pte & PTE_W) == 0)
    800016aa:	611c                	ld	a5,0(a0)
    800016ac:	8b91                	andi	a5,a5,4
    800016ae:	c39d                	beqz	a5,800016d4 <copyout+0xa8>
    n = PGSIZE - (dstva - va0);
    800016b0:	01a48ab3          	add	s5,s1,s10
    800016b4:	416a89b3          	sub	s3,s5,s6
    if(n > len)
    800016b8:	fb3a76e3          	bgeu	s4,s3,80001664 <copyout+0x38>
    800016bc:	89d2                	mv	s3,s4
    800016be:	b75d                	j	80001664 <copyout+0x38>
  return 0;
    800016c0:	4501                	li	a0,0
    800016c2:	a811                	j	800016d6 <copyout+0xaa>
    800016c4:	4501                	li	a0,0
}
    800016c6:	8082                	ret
      return -1;
    800016c8:	557d                	li	a0,-1
    800016ca:	a031                	j	800016d6 <copyout+0xaa>
    800016cc:	557d                	li	a0,-1
    800016ce:	a021                	j	800016d6 <copyout+0xaa>
        return -1;
    800016d0:	557d                	li	a0,-1
    800016d2:	a011                	j	800016d6 <copyout+0xaa>
      return -1;
    800016d4:	557d                	li	a0,-1
}
    800016d6:	60e6                	ld	ra,88(sp)
    800016d8:	6446                	ld	s0,80(sp)
    800016da:	64a6                	ld	s1,72(sp)
    800016dc:	6906                	ld	s2,64(sp)
    800016de:	79e2                	ld	s3,56(sp)
    800016e0:	7a42                	ld	s4,48(sp)
    800016e2:	7aa2                	ld	s5,40(sp)
    800016e4:	7b02                	ld	s6,32(sp)
    800016e6:	6be2                	ld	s7,24(sp)
    800016e8:	6c42                	ld	s8,16(sp)
    800016ea:	6ca2                	ld	s9,8(sp)
    800016ec:	6d02                	ld	s10,0(sp)
    800016ee:	6125                	addi	sp,sp,96
    800016f0:	8082                	ret

00000000800016f2 <copyin>:
  while(len > 0){
    800016f2:	c6c9                	beqz	a3,8000177c <copyin+0x8a>
{
    800016f4:	715d                	addi	sp,sp,-80
    800016f6:	e486                	sd	ra,72(sp)
    800016f8:	e0a2                	sd	s0,64(sp)
    800016fa:	fc26                	sd	s1,56(sp)
    800016fc:	f84a                	sd	s2,48(sp)
    800016fe:	f44e                	sd	s3,40(sp)
    80001700:	f052                	sd	s4,32(sp)
    80001702:	ec56                	sd	s5,24(sp)
    80001704:	e85a                	sd	s6,16(sp)
    80001706:	e45e                	sd	s7,8(sp)
    80001708:	e062                	sd	s8,0(sp)
    8000170a:	0880                	addi	s0,sp,80
    8000170c:	8baa                	mv	s7,a0
    8000170e:	8aae                	mv	s5,a1
    80001710:	8932                	mv	s2,a2
    80001712:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    80001714:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    80001716:	6b05                	lui	s6,0x1
    80001718:	a035                	j	80001744 <copyin+0x52>
    8000171a:	412984b3          	sub	s1,s3,s2
    8000171e:	94da                	add	s1,s1,s6
    if(n > len)
    80001720:	009a7363          	bgeu	s4,s1,80001726 <copyin+0x34>
    80001724:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001726:	413905b3          	sub	a1,s2,s3
    8000172a:	0004861b          	sext.w	a2,s1
    8000172e:	95aa                	add	a1,a1,a0
    80001730:	8556                	mv	a0,s5
    80001732:	e44ff0ef          	jal	ra,80000d76 <memmove>
    len -= n;
    80001736:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000173a:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000173c:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001740:	020a0163          	beqz	s4,80001762 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001744:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001748:	85ce                	mv	a1,s3
    8000174a:	855e                	mv	a0,s7
    8000174c:	8e5ff0ef          	jal	ra,80001030 <walkaddr>
    if(pa0 == 0) {
    80001750:	f569                	bnez	a0,8000171a <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001752:	4601                	li	a2,0
    80001754:	85ce                	mv	a1,s3
    80001756:	855e                	mv	a0,s7
    80001758:	e63ff0ef          	jal	ra,800015ba <vmfault>
    8000175c:	fd5d                	bnez	a0,8000171a <copyin+0x28>
        return -1;
    8000175e:	557d                	li	a0,-1
    80001760:	a011                	j	80001764 <copyin+0x72>
  return 0;
    80001762:	4501                	li	a0,0
}
    80001764:	60a6                	ld	ra,72(sp)
    80001766:	6406                	ld	s0,64(sp)
    80001768:	74e2                	ld	s1,56(sp)
    8000176a:	7942                	ld	s2,48(sp)
    8000176c:	79a2                	ld	s3,40(sp)
    8000176e:	7a02                	ld	s4,32(sp)
    80001770:	6ae2                	ld	s5,24(sp)
    80001772:	6b42                	ld	s6,16(sp)
    80001774:	6ba2                	ld	s7,8(sp)
    80001776:	6c02                	ld	s8,0(sp)
    80001778:	6161                	addi	sp,sp,80
    8000177a:	8082                	ret
  return 0;
    8000177c:	4501                	li	a0,0
}
    8000177e:	8082                	ret

0000000080001780 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001780:	7139                	addi	sp,sp,-64
    80001782:	fc06                	sd	ra,56(sp)
    80001784:	f822                	sd	s0,48(sp)
    80001786:	f426                	sd	s1,40(sp)
    80001788:	f04a                	sd	s2,32(sp)
    8000178a:	ec4e                	sd	s3,24(sp)
    8000178c:	e852                	sd	s4,16(sp)
    8000178e:	e456                	sd	s5,8(sp)
    80001790:	e05a                	sd	s6,0(sp)
    80001792:	0080                	addi	s0,sp,64
    80001794:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001796:	0000e497          	auipc	s1,0xe
    8000179a:	77248493          	addi	s1,s1,1906 # 8000ff08 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    8000179e:	8b26                	mv	s6,s1
    800017a0:	00006a97          	auipc	s5,0x6
    800017a4:	860a8a93          	addi	s5,s5,-1952 # 80007000 <etext>
    800017a8:	04000937          	lui	s2,0x4000
    800017ac:	197d                	addi	s2,s2,-1
    800017ae:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800017b0:	00014a17          	auipc	s4,0x14
    800017b4:	358a0a13          	addi	s4,s4,856 # 80015b08 <tickslock>
    char *pa = kalloc();
    800017b8:	bbeff0ef          	jal	ra,80000b76 <kalloc>
    800017bc:	862a                	mv	a2,a0
    if(pa == 0)
    800017be:	c121                	beqz	a0,800017fe <proc_mapstacks+0x7e>
    uint64 va = KSTACK((int) (p - proc));
    800017c0:	416485b3          	sub	a1,s1,s6
    800017c4:	8591                	srai	a1,a1,0x4
    800017c6:	000ab783          	ld	a5,0(s5)
    800017ca:	02f585b3          	mul	a1,a1,a5
    800017ce:	2585                	addiw	a1,a1,1
    800017d0:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017d4:	4719                	li	a4,6
    800017d6:	6685                	lui	a3,0x1
    800017d8:	40b905b3          	sub	a1,s2,a1
    800017dc:	854e                	mv	a0,s3
    800017de:	941ff0ef          	jal	ra,8000111e <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    800017e2:	17048493          	addi	s1,s1,368
    800017e6:	fd4499e3          	bne	s1,s4,800017b8 <proc_mapstacks+0x38>
  }
}
    800017ea:	70e2                	ld	ra,56(sp)
    800017ec:	7442                	ld	s0,48(sp)
    800017ee:	74a2                	ld	s1,40(sp)
    800017f0:	7902                	ld	s2,32(sp)
    800017f2:	69e2                	ld	s3,24(sp)
    800017f4:	6a42                	ld	s4,16(sp)
    800017f6:	6aa2                	ld	s5,8(sp)
    800017f8:	6b02                	ld	s6,0(sp)
    800017fa:	6121                	addi	sp,sp,64
    800017fc:	8082                	ret
      panic("kalloc");
    800017fe:	00006517          	auipc	a0,0x6
    80001802:	98a50513          	addi	a0,a0,-1654 # 80007188 <digits+0x138>
    80001806:	fdbfe0ef          	jal	ra,800007e0 <panic>

000000008000180a <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000180a:	7139                	addi	sp,sp,-64
    8000180c:	fc06                	sd	ra,56(sp)
    8000180e:	f822                	sd	s0,48(sp)
    80001810:	f426                	sd	s1,40(sp)
    80001812:	f04a                	sd	s2,32(sp)
    80001814:	ec4e                	sd	s3,24(sp)
    80001816:	e852                	sd	s4,16(sp)
    80001818:	e456                	sd	s5,8(sp)
    8000181a:	e05a                	sd	s6,0(sp)
    8000181c:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    8000181e:	00006597          	auipc	a1,0x6
    80001822:	97258593          	addi	a1,a1,-1678 # 80007190 <digits+0x140>
    80001826:	0000e517          	auipc	a0,0xe
    8000182a:	2b250513          	addi	a0,a0,690 # 8000fad8 <pid_lock>
    8000182e:	b98ff0ef          	jal	ra,80000bc6 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001832:	00006597          	auipc	a1,0x6
    80001836:	96658593          	addi	a1,a1,-1690 # 80007198 <digits+0x148>
    8000183a:	0000e517          	auipc	a0,0xe
    8000183e:	2b650513          	addi	a0,a0,694 # 8000faf0 <wait_lock>
    80001842:	b84ff0ef          	jal	ra,80000bc6 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001846:	0000e497          	auipc	s1,0xe
    8000184a:	6c248493          	addi	s1,s1,1730 # 8000ff08 <proc>
      initlock(&p->lock, "proc");
    8000184e:	00006b17          	auipc	s6,0x6
    80001852:	95ab0b13          	addi	s6,s6,-1702 # 800071a8 <digits+0x158>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001856:	8aa6                	mv	s5,s1
    80001858:	00005a17          	auipc	s4,0x5
    8000185c:	7a8a0a13          	addi	s4,s4,1960 # 80007000 <etext>
    80001860:	04000937          	lui	s2,0x4000
    80001864:	197d                	addi	s2,s2,-1
    80001866:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001868:	00014997          	auipc	s3,0x14
    8000186c:	2a098993          	addi	s3,s3,672 # 80015b08 <tickslock>
      initlock(&p->lock, "proc");
    80001870:	85da                	mv	a1,s6
    80001872:	8526                	mv	a0,s1
    80001874:	b52ff0ef          	jal	ra,80000bc6 <initlock>
      p->state = UNUSED;
    80001878:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    8000187c:	415487b3          	sub	a5,s1,s5
    80001880:	8791                	srai	a5,a5,0x4
    80001882:	000a3703          	ld	a4,0(s4)
    80001886:	02e787b3          	mul	a5,a5,a4
    8000188a:	2785                	addiw	a5,a5,1
    8000188c:	00d7979b          	slliw	a5,a5,0xd
    80001890:	40f907b3          	sub	a5,s2,a5
    80001894:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001896:	17048493          	addi	s1,s1,368
    8000189a:	fd349be3          	bne	s1,s3,80001870 <procinit+0x66>
  }
}
    8000189e:	70e2                	ld	ra,56(sp)
    800018a0:	7442                	ld	s0,48(sp)
    800018a2:	74a2                	ld	s1,40(sp)
    800018a4:	7902                	ld	s2,32(sp)
    800018a6:	69e2                	ld	s3,24(sp)
    800018a8:	6a42                	ld	s4,16(sp)
    800018aa:	6aa2                	ld	s5,8(sp)
    800018ac:	6b02                	ld	s6,0(sp)
    800018ae:	6121                	addi	sp,sp,64
    800018b0:	8082                	ret

00000000800018b2 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018b2:	1141                	addi	sp,sp,-16
    800018b4:	e422                	sd	s0,8(sp)
    800018b6:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800018b8:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018ba:	2501                	sext.w	a0,a0
    800018bc:	6422                	ld	s0,8(sp)
    800018be:	0141                	addi	sp,sp,16
    800018c0:	8082                	ret

00000000800018c2 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800018c2:	1141                	addi	sp,sp,-16
    800018c4:	e422                	sd	s0,8(sp)
    800018c6:	0800                	addi	s0,sp,16
    800018c8:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018ca:	2781                	sext.w	a5,a5
    800018cc:	079e                	slli	a5,a5,0x7
  return c;
}
    800018ce:	0000e517          	auipc	a0,0xe
    800018d2:	23a50513          	addi	a0,a0,570 # 8000fb08 <cpus>
    800018d6:	953e                	add	a0,a0,a5
    800018d8:	6422                	ld	s0,8(sp)
    800018da:	0141                	addi	sp,sp,16
    800018dc:	8082                	ret

00000000800018de <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    800018de:	1101                	addi	sp,sp,-32
    800018e0:	ec06                	sd	ra,24(sp)
    800018e2:	e822                	sd	s0,16(sp)
    800018e4:	e426                	sd	s1,8(sp)
    800018e6:	1000                	addi	s0,sp,32
  push_off();
    800018e8:	b1eff0ef          	jal	ra,80000c06 <push_off>
    800018ec:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018ee:	2781                	sext.w	a5,a5
    800018f0:	079e                	slli	a5,a5,0x7
    800018f2:	0000e717          	auipc	a4,0xe
    800018f6:	1e670713          	addi	a4,a4,486 # 8000fad8 <pid_lock>
    800018fa:	97ba                	add	a5,a5,a4
    800018fc:	7b84                	ld	s1,48(a5)
  pop_off();
    800018fe:	b8cff0ef          	jal	ra,80000c8a <pop_off>
  return p;
}
    80001902:	8526                	mv	a0,s1
    80001904:	60e2                	ld	ra,24(sp)
    80001906:	6442                	ld	s0,16(sp)
    80001908:	64a2                	ld	s1,8(sp)
    8000190a:	6105                	addi	sp,sp,32
    8000190c:	8082                	ret

000000008000190e <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    8000190e:	7179                	addi	sp,sp,-48
    80001910:	f406                	sd	ra,40(sp)
    80001912:	f022                	sd	s0,32(sp)
    80001914:	ec26                	sd	s1,24(sp)
    80001916:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001918:	fc7ff0ef          	jal	ra,800018de <myproc>
    8000191c:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    8000191e:	bc0ff0ef          	jal	ra,80000cde <release>

  if (first) {
    80001922:	00006797          	auipc	a5,0x6
    80001926:	04e7a783          	lw	a5,78(a5) # 80007970 <first.1>
    8000192a:	cf8d                	beqz	a5,80001964 <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000192c:	4505                	li	a0,1
    8000192e:	6f0010ef          	jal	ra,8000301e <fsinit>

    first = 0;
    80001932:	00006797          	auipc	a5,0x6
    80001936:	0207af23          	sw	zero,62(a5) # 80007970 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    8000193a:	0ff0000f          	fence

    // We can invoke exec() now that file system is initialized.
    // Put the return value (argc) of exec into a0.
    p->trapframe->a0 = exec("/init", (char *[]){ "/init", 0 });
    8000193e:	00006517          	auipc	a0,0x6
    80001942:	87250513          	addi	a0,a0,-1934 # 800071b0 <digits+0x160>
    80001946:	fca43823          	sd	a0,-48(s0)
    8000194a:	fc043c23          	sd	zero,-40(s0)
    8000194e:	fd040593          	addi	a1,s0,-48
    80001952:	345020ef          	jal	ra,80004496 <exec>
    80001956:	6cbc                	ld	a5,88(s1)
    80001958:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    8000195a:	6cbc                	ld	a5,88(s1)
    8000195c:	7bb8                	ld	a4,112(a5)
    8000195e:	57fd                	li	a5,-1
    80001960:	02f70d63          	beq	a4,a5,8000199a <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001964:	29b000ef          	jal	ra,800023fe <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001968:	68a8                	ld	a0,80(s1)
    8000196a:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000196c:	04000737          	lui	a4,0x4000
    80001970:	00004797          	auipc	a5,0x4
    80001974:	72c78793          	addi	a5,a5,1836 # 8000609c <userret>
    80001978:	00004697          	auipc	a3,0x4
    8000197c:	68868693          	addi	a3,a3,1672 # 80006000 <_trampoline>
    80001980:	8f95                	sub	a5,a5,a3
    80001982:	177d                	addi	a4,a4,-1
    80001984:	0732                	slli	a4,a4,0xc
    80001986:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001988:	577d                	li	a4,-1
    8000198a:	177e                	slli	a4,a4,0x3f
    8000198c:	8d59                	or	a0,a0,a4
    8000198e:	9782                	jalr	a5
}
    80001990:	70a2                	ld	ra,40(sp)
    80001992:	7402                	ld	s0,32(sp)
    80001994:	64e2                	ld	s1,24(sp)
    80001996:	6145                	addi	sp,sp,48
    80001998:	8082                	ret
      panic("exec");
    8000199a:	00006517          	auipc	a0,0x6
    8000199e:	81e50513          	addi	a0,a0,-2018 # 800071b8 <digits+0x168>
    800019a2:	e3ffe0ef          	jal	ra,800007e0 <panic>

00000000800019a6 <allocpid>:
{
    800019a6:	1101                	addi	sp,sp,-32
    800019a8:	ec06                	sd	ra,24(sp)
    800019aa:	e822                	sd	s0,16(sp)
    800019ac:	e426                	sd	s1,8(sp)
    800019ae:	e04a                	sd	s2,0(sp)
    800019b0:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019b2:	0000e917          	auipc	s2,0xe
    800019b6:	12690913          	addi	s2,s2,294 # 8000fad8 <pid_lock>
    800019ba:	854a                	mv	a0,s2
    800019bc:	a8aff0ef          	jal	ra,80000c46 <acquire>
  pid = nextpid;
    800019c0:	00006797          	auipc	a5,0x6
    800019c4:	fb478793          	addi	a5,a5,-76 # 80007974 <nextpid>
    800019c8:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019ca:	0014871b          	addiw	a4,s1,1
    800019ce:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019d0:	854a                	mv	a0,s2
    800019d2:	b0cff0ef          	jal	ra,80000cde <release>
}
    800019d6:	8526                	mv	a0,s1
    800019d8:	60e2                	ld	ra,24(sp)
    800019da:	6442                	ld	s0,16(sp)
    800019dc:	64a2                	ld	s1,8(sp)
    800019de:	6902                	ld	s2,0(sp)
    800019e0:	6105                	addi	sp,sp,32
    800019e2:	8082                	ret

00000000800019e4 <proc_pagetable>:
{
    800019e4:	1101                	addi	sp,sp,-32
    800019e6:	ec06                	sd	ra,24(sp)
    800019e8:	e822                	sd	s0,16(sp)
    800019ea:	e426                	sd	s1,8(sp)
    800019ec:	e04a                	sd	s2,0(sp)
    800019ee:	1000                	addi	s0,sp,32
    800019f0:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019f2:	89fff0ef          	jal	ra,80001290 <uvmcreate>
    800019f6:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800019f8:	cd05                	beqz	a0,80001a30 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800019fa:	4729                	li	a4,10
    800019fc:	00004697          	auipc	a3,0x4
    80001a00:	60468693          	addi	a3,a3,1540 # 80006000 <_trampoline>
    80001a04:	6605                	lui	a2,0x1
    80001a06:	040005b7          	lui	a1,0x4000
    80001a0a:	15fd                	addi	a1,a1,-1
    80001a0c:	05b2                	slli	a1,a1,0xc
    80001a0e:	e60ff0ef          	jal	ra,8000106e <mappages>
    80001a12:	02054663          	bltz	a0,80001a3e <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a16:	4719                	li	a4,6
    80001a18:	05893683          	ld	a3,88(s2)
    80001a1c:	6605                	lui	a2,0x1
    80001a1e:	020005b7          	lui	a1,0x2000
    80001a22:	15fd                	addi	a1,a1,-1
    80001a24:	05b6                	slli	a1,a1,0xd
    80001a26:	8526                	mv	a0,s1
    80001a28:	e46ff0ef          	jal	ra,8000106e <mappages>
    80001a2c:	00054f63          	bltz	a0,80001a4a <proc_pagetable+0x66>
}
    80001a30:	8526                	mv	a0,s1
    80001a32:	60e2                	ld	ra,24(sp)
    80001a34:	6442                	ld	s0,16(sp)
    80001a36:	64a2                	ld	s1,8(sp)
    80001a38:	6902                	ld	s2,0(sp)
    80001a3a:	6105                	addi	sp,sp,32
    80001a3c:	8082                	ret
    uvmfree(pagetable, 0);
    80001a3e:	4581                	li	a1,0
    80001a40:	8526                	mv	a0,s1
    80001a42:	9b1ff0ef          	jal	ra,800013f2 <uvmfree>
    return 0;
    80001a46:	4481                	li	s1,0
    80001a48:	b7e5                	j	80001a30 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a4a:	4681                	li	a3,0
    80001a4c:	4605                	li	a2,1
    80001a4e:	040005b7          	lui	a1,0x4000
    80001a52:	15fd                	addi	a1,a1,-1
    80001a54:	05b2                	slli	a1,a1,0xc
    80001a56:	8526                	mv	a0,s1
    80001a58:	fbcff0ef          	jal	ra,80001214 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a5c:	4581                	li	a1,0
    80001a5e:	8526                	mv	a0,s1
    80001a60:	993ff0ef          	jal	ra,800013f2 <uvmfree>
    return 0;
    80001a64:	4481                	li	s1,0
    80001a66:	b7e9                	j	80001a30 <proc_pagetable+0x4c>

0000000080001a68 <proc_freepagetable>:
{
    80001a68:	1101                	addi	sp,sp,-32
    80001a6a:	ec06                	sd	ra,24(sp)
    80001a6c:	e822                	sd	s0,16(sp)
    80001a6e:	e426                	sd	s1,8(sp)
    80001a70:	e04a                	sd	s2,0(sp)
    80001a72:	1000                	addi	s0,sp,32
    80001a74:	84aa                	mv	s1,a0
    80001a76:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a78:	4681                	li	a3,0
    80001a7a:	4605                	li	a2,1
    80001a7c:	040005b7          	lui	a1,0x4000
    80001a80:	15fd                	addi	a1,a1,-1
    80001a82:	05b2                	slli	a1,a1,0xc
    80001a84:	f90ff0ef          	jal	ra,80001214 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a88:	4681                	li	a3,0
    80001a8a:	4605                	li	a2,1
    80001a8c:	020005b7          	lui	a1,0x2000
    80001a90:	15fd                	addi	a1,a1,-1
    80001a92:	05b6                	slli	a1,a1,0xd
    80001a94:	8526                	mv	a0,s1
    80001a96:	f7eff0ef          	jal	ra,80001214 <uvmunmap>
  uvmfree(pagetable, sz);
    80001a9a:	85ca                	mv	a1,s2
    80001a9c:	8526                	mv	a0,s1
    80001a9e:	955ff0ef          	jal	ra,800013f2 <uvmfree>
}
    80001aa2:	60e2                	ld	ra,24(sp)
    80001aa4:	6442                	ld	s0,16(sp)
    80001aa6:	64a2                	ld	s1,8(sp)
    80001aa8:	6902                	ld	s2,0(sp)
    80001aaa:	6105                	addi	sp,sp,32
    80001aac:	8082                	ret

0000000080001aae <freeproc>:
{
    80001aae:	1101                	addi	sp,sp,-32
    80001ab0:	ec06                	sd	ra,24(sp)
    80001ab2:	e822                	sd	s0,16(sp)
    80001ab4:	e426                	sd	s1,8(sp)
    80001ab6:	1000                	addi	s0,sp,32
    80001ab8:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001aba:	6d28                	ld	a0,88(a0)
    80001abc:	c119                	beqz	a0,80001ac2 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001abe:	fd9fe0ef          	jal	ra,80000a96 <kfree>
  p->trapframe = 0;
    80001ac2:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001ac6:	68a8                	ld	a0,80(s1)
    80001ac8:	c501                	beqz	a0,80001ad0 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001aca:	64ac                	ld	a1,72(s1)
    80001acc:	f9dff0ef          	jal	ra,80001a68 <proc_freepagetable>
  p->pagetable = 0;
    80001ad0:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001ad4:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001ad8:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001adc:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001ae0:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001ae4:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001ae8:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001aec:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001af0:	0004ac23          	sw	zero,24(s1)
}
    80001af4:	60e2                	ld	ra,24(sp)
    80001af6:	6442                	ld	s0,16(sp)
    80001af8:	64a2                	ld	s1,8(sp)
    80001afa:	6105                	addi	sp,sp,32
    80001afc:	8082                	ret

0000000080001afe <allocproc>:
{
    80001afe:	1101                	addi	sp,sp,-32
    80001b00:	ec06                	sd	ra,24(sp)
    80001b02:	e822                	sd	s0,16(sp)
    80001b04:	e426                	sd	s1,8(sp)
    80001b06:	e04a                	sd	s2,0(sp)
    80001b08:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b0a:	0000e497          	auipc	s1,0xe
    80001b0e:	3fe48493          	addi	s1,s1,1022 # 8000ff08 <proc>
    80001b12:	00014917          	auipc	s2,0x14
    80001b16:	ff690913          	addi	s2,s2,-10 # 80015b08 <tickslock>
    acquire(&p->lock);
    80001b1a:	8526                	mv	a0,s1
    80001b1c:	92aff0ef          	jal	ra,80000c46 <acquire>
    if(p->state == UNUSED) {
    80001b20:	4c9c                	lw	a5,24(s1)
    80001b22:	cb91                	beqz	a5,80001b36 <allocproc+0x38>
      release(&p->lock);
    80001b24:	8526                	mv	a0,s1
    80001b26:	9b8ff0ef          	jal	ra,80000cde <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b2a:	17048493          	addi	s1,s1,368
    80001b2e:	ff2496e3          	bne	s1,s2,80001b1a <allocproc+0x1c>
  return 0;
    80001b32:	4481                	li	s1,0
    80001b34:	a089                	j	80001b76 <allocproc+0x78>
  p->pid = allocpid();
    80001b36:	e71ff0ef          	jal	ra,800019a6 <allocpid>
    80001b3a:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b3c:	4785                	li	a5,1
    80001b3e:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b40:	836ff0ef          	jal	ra,80000b76 <kalloc>
    80001b44:	892a                	mv	s2,a0
    80001b46:	eca8                	sd	a0,88(s1)
    80001b48:	cd15                	beqz	a0,80001b84 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b4a:	8526                	mv	a0,s1
    80001b4c:	e99ff0ef          	jal	ra,800019e4 <proc_pagetable>
    80001b50:	892a                	mv	s2,a0
    80001b52:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b54:	c121                	beqz	a0,80001b94 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b56:	07000613          	li	a2,112
    80001b5a:	4581                	li	a1,0
    80001b5c:	06048513          	addi	a0,s1,96
    80001b60:	9baff0ef          	jal	ra,80000d1a <memset>
  p->context.ra = (uint64)forkret;
    80001b64:	00000797          	auipc	a5,0x0
    80001b68:	daa78793          	addi	a5,a5,-598 # 8000190e <forkret>
    80001b6c:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b6e:	60bc                	ld	a5,64(s1)
    80001b70:	6705                	lui	a4,0x1
    80001b72:	97ba                	add	a5,a5,a4
    80001b74:	f4bc                	sd	a5,104(s1)
}
    80001b76:	8526                	mv	a0,s1
    80001b78:	60e2                	ld	ra,24(sp)
    80001b7a:	6442                	ld	s0,16(sp)
    80001b7c:	64a2                	ld	s1,8(sp)
    80001b7e:	6902                	ld	s2,0(sp)
    80001b80:	6105                	addi	sp,sp,32
    80001b82:	8082                	ret
    freeproc(p);
    80001b84:	8526                	mv	a0,s1
    80001b86:	f29ff0ef          	jal	ra,80001aae <freeproc>
    release(&p->lock);
    80001b8a:	8526                	mv	a0,s1
    80001b8c:	952ff0ef          	jal	ra,80000cde <release>
    return 0;
    80001b90:	84ca                	mv	s1,s2
    80001b92:	b7d5                	j	80001b76 <allocproc+0x78>
    freeproc(p);
    80001b94:	8526                	mv	a0,s1
    80001b96:	f19ff0ef          	jal	ra,80001aae <freeproc>
    release(&p->lock);
    80001b9a:	8526                	mv	a0,s1
    80001b9c:	942ff0ef          	jal	ra,80000cde <release>
    return 0;
    80001ba0:	84ca                	mv	s1,s2
    80001ba2:	bfd1                	j	80001b76 <allocproc+0x78>

0000000080001ba4 <userinit>:
{
    80001ba4:	1101                	addi	sp,sp,-32
    80001ba6:	ec06                	sd	ra,24(sp)
    80001ba8:	e822                	sd	s0,16(sp)
    80001baa:	e426                	sd	s1,8(sp)
    80001bac:	1000                	addi	s0,sp,32
  p = allocproc();
    80001bae:	f51ff0ef          	jal	ra,80001afe <allocproc>
    80001bb2:	84aa                	mv	s1,a0
  initproc = p;
    80001bb4:	00006797          	auipc	a5,0x6
    80001bb8:	dea7ba23          	sd	a0,-524(a5) # 800079a8 <initproc>
  p->cwd = namei("/");
    80001bbc:	00005517          	auipc	a0,0x5
    80001bc0:	60450513          	addi	a0,a0,1540 # 800071c0 <digits+0x170>
    80001bc4:	539010ef          	jal	ra,800038fc <namei>
    80001bc8:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bcc:	478d                	li	a5,3
    80001bce:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bd0:	8526                	mv	a0,s1
    80001bd2:	90cff0ef          	jal	ra,80000cde <release>
}
    80001bd6:	60e2                	ld	ra,24(sp)
    80001bd8:	6442                	ld	s0,16(sp)
    80001bda:	64a2                	ld	s1,8(sp)
    80001bdc:	6105                	addi	sp,sp,32
    80001bde:	8082                	ret

0000000080001be0 <shrinkproc>:
{
    80001be0:	1101                	addi	sp,sp,-32
    80001be2:	ec06                	sd	ra,24(sp)
    80001be4:	e822                	sd	s0,16(sp)
    80001be6:	e426                	sd	s1,8(sp)
    80001be8:	e04a                	sd	s2,0(sp)
    80001bea:	1000                	addi	s0,sp,32
    80001bec:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001bee:	cf1ff0ef          	jal	ra,800018de <myproc>
  if(n > p->sz)
    80001bf2:	652c                	ld	a1,72(a0)
    80001bf4:	0325e063          	bltu	a1,s2,80001c14 <shrinkproc+0x34>
    80001bf8:	84aa                	mv	s1,a0
  sz = uvmdealloc(p->pagetable, sz, sz - n);
    80001bfa:	41258633          	sub	a2,a1,s2
    80001bfe:	6928                	ld	a0,80(a0)
    80001c00:	eb6ff0ef          	jal	ra,800012b6 <uvmdealloc>
  p->sz = sz;
    80001c04:	e4a8                	sd	a0,72(s1)
  return 0;
    80001c06:	4501                	li	a0,0
}
    80001c08:	60e2                	ld	ra,24(sp)
    80001c0a:	6442                	ld	s0,16(sp)
    80001c0c:	64a2                	ld	s1,8(sp)
    80001c0e:	6902                	ld	s2,0(sp)
    80001c10:	6105                	addi	sp,sp,32
    80001c12:	8082                	ret
    return -1;
    80001c14:	557d                	li	a0,-1
    80001c16:	bfcd                	j	80001c08 <shrinkproc+0x28>

0000000080001c18 <fork>:
{
    80001c18:	7139                	addi	sp,sp,-64
    80001c1a:	fc06                	sd	ra,56(sp)
    80001c1c:	f822                	sd	s0,48(sp)
    80001c1e:	f426                	sd	s1,40(sp)
    80001c20:	f04a                	sd	s2,32(sp)
    80001c22:	ec4e                	sd	s3,24(sp)
    80001c24:	e852                	sd	s4,16(sp)
    80001c26:	e456                	sd	s5,8(sp)
    80001c28:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c2a:	cb5ff0ef          	jal	ra,800018de <myproc>
    80001c2e:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c30:	ecfff0ef          	jal	ra,80001afe <allocproc>
    80001c34:	0e050a63          	beqz	a0,80001d28 <fork+0x110>
    80001c38:	89aa                	mv	s3,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c3a:	048ab603          	ld	a2,72(s5)
    80001c3e:	692c                	ld	a1,80(a0)
    80001c40:	050ab503          	ld	a0,80(s5)
    80001c44:	fdeff0ef          	jal	ra,80001422 <uvmcopy>
    80001c48:	04054863          	bltz	a0,80001c98 <fork+0x80>
  np->sz = p->sz;
    80001c4c:	048ab783          	ld	a5,72(s5)
    80001c50:	04f9b423          	sd	a5,72(s3)
  *(np->trapframe) = *(p->trapframe);
    80001c54:	058ab683          	ld	a3,88(s5)
    80001c58:	87b6                	mv	a5,a3
    80001c5a:	0589b703          	ld	a4,88(s3)
    80001c5e:	12068693          	addi	a3,a3,288
    80001c62:	0007b803          	ld	a6,0(a5)
    80001c66:	6788                	ld	a0,8(a5)
    80001c68:	6b8c                	ld	a1,16(a5)
    80001c6a:	6f90                	ld	a2,24(a5)
    80001c6c:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c70:	e708                	sd	a0,8(a4)
    80001c72:	eb0c                	sd	a1,16(a4)
    80001c74:	ef10                	sd	a2,24(a4)
    80001c76:	02078793          	addi	a5,a5,32
    80001c7a:	02070713          	addi	a4,a4,32
    80001c7e:	fed792e3          	bne	a5,a3,80001c62 <fork+0x4a>
  np->trapframe->a0 = 0;
    80001c82:	0589b783          	ld	a5,88(s3)
    80001c86:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001c8a:	0d0a8493          	addi	s1,s5,208
    80001c8e:	0d098913          	addi	s2,s3,208
    80001c92:	150a8a13          	addi	s4,s5,336
    80001c96:	a829                	j	80001cb0 <fork+0x98>
    freeproc(np);
    80001c98:	854e                	mv	a0,s3
    80001c9a:	e15ff0ef          	jal	ra,80001aae <freeproc>
    release(&np->lock);
    80001c9e:	854e                	mv	a0,s3
    80001ca0:	83eff0ef          	jal	ra,80000cde <release>
    return -1;
    80001ca4:	597d                	li	s2,-1
    80001ca6:	a0bd                	j	80001d14 <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001ca8:	04a1                	addi	s1,s1,8
    80001caa:	0921                	addi	s2,s2,8
    80001cac:	01448963          	beq	s1,s4,80001cbe <fork+0xa6>
    if(p->ofile[i])
    80001cb0:	6088                	ld	a0,0(s1)
    80001cb2:	d97d                	beqz	a0,80001ca8 <fork+0x90>
      np->ofile[i] = filedup(p->ofile[i]);
    80001cb4:	1fa020ef          	jal	ra,80003eae <filedup>
    80001cb8:	00a93023          	sd	a0,0(s2)
    80001cbc:	b7f5                	j	80001ca8 <fork+0x90>
  np->cwd = idup(p->cwd);
    80001cbe:	150ab503          	ld	a0,336(s5)
    80001cc2:	552010ef          	jal	ra,80003214 <idup>
    80001cc6:	14a9b823          	sd	a0,336(s3)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cca:	4641                	li	a2,16
    80001ccc:	158a8593          	addi	a1,s5,344
    80001cd0:	15898513          	addi	a0,s3,344
    80001cd4:	98cff0ef          	jal	ra,80000e60 <safestrcpy>
  np->tracemask = p->tracemask;
    80001cd8:	168aa783          	lw	a5,360(s5)
    80001cdc:	16f9a423          	sw	a5,360(s3)
  pid = np->pid;
    80001ce0:	0309a903          	lw	s2,48(s3)
  release(&np->lock);
    80001ce4:	854e                	mv	a0,s3
    80001ce6:	ff9fe0ef          	jal	ra,80000cde <release>
  acquire(&wait_lock);
    80001cea:	0000e497          	auipc	s1,0xe
    80001cee:	e0648493          	addi	s1,s1,-506 # 8000faf0 <wait_lock>
    80001cf2:	8526                	mv	a0,s1
    80001cf4:	f53fe0ef          	jal	ra,80000c46 <acquire>
  np->parent = p;
    80001cf8:	0359bc23          	sd	s5,56(s3)
  release(&wait_lock);
    80001cfc:	8526                	mv	a0,s1
    80001cfe:	fe1fe0ef          	jal	ra,80000cde <release>
  acquire(&np->lock);
    80001d02:	854e                	mv	a0,s3
    80001d04:	f43fe0ef          	jal	ra,80000c46 <acquire>
  np->state = RUNNABLE;
    80001d08:	478d                	li	a5,3
    80001d0a:	00f9ac23          	sw	a5,24(s3)
  release(&np->lock);
    80001d0e:	854e                	mv	a0,s3
    80001d10:	fcffe0ef          	jal	ra,80000cde <release>
}
    80001d14:	854a                	mv	a0,s2
    80001d16:	70e2                	ld	ra,56(sp)
    80001d18:	7442                	ld	s0,48(sp)
    80001d1a:	74a2                	ld	s1,40(sp)
    80001d1c:	7902                	ld	s2,32(sp)
    80001d1e:	69e2                	ld	s3,24(sp)
    80001d20:	6a42                	ld	s4,16(sp)
    80001d22:	6aa2                	ld	s5,8(sp)
    80001d24:	6121                	addi	sp,sp,64
    80001d26:	8082                	ret
    return -1;
    80001d28:	597d                	li	s2,-1
    80001d2a:	b7ed                	j	80001d14 <fork+0xfc>

0000000080001d2c <scheduler>:
{
    80001d2c:	715d                	addi	sp,sp,-80
    80001d2e:	e486                	sd	ra,72(sp)
    80001d30:	e0a2                	sd	s0,64(sp)
    80001d32:	fc26                	sd	s1,56(sp)
    80001d34:	f84a                	sd	s2,48(sp)
    80001d36:	f44e                	sd	s3,40(sp)
    80001d38:	f052                	sd	s4,32(sp)
    80001d3a:	ec56                	sd	s5,24(sp)
    80001d3c:	e85a                	sd	s6,16(sp)
    80001d3e:	e45e                	sd	s7,8(sp)
    80001d40:	e062                	sd	s8,0(sp)
    80001d42:	0880                	addi	s0,sp,80
    80001d44:	8792                	mv	a5,tp
  int id = r_tp();
    80001d46:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d48:	00779b13          	slli	s6,a5,0x7
    80001d4c:	0000e717          	auipc	a4,0xe
    80001d50:	d8c70713          	addi	a4,a4,-628 # 8000fad8 <pid_lock>
    80001d54:	975a                	add	a4,a4,s6
    80001d56:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d5a:	0000e717          	auipc	a4,0xe
    80001d5e:	db670713          	addi	a4,a4,-586 # 8000fb10 <cpus+0x8>
    80001d62:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001d64:	4c11                	li	s8,4
        c->proc = p;
    80001d66:	079e                	slli	a5,a5,0x7
    80001d68:	0000ea17          	auipc	s4,0xe
    80001d6c:	d70a0a13          	addi	s4,s4,-656 # 8000fad8 <pid_lock>
    80001d70:	9a3e                	add	s4,s4,a5
        found = 1;
    80001d72:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d74:	00014997          	auipc	s3,0x14
    80001d78:	d9498993          	addi	s3,s3,-620 # 80015b08 <tickslock>
    80001d7c:	a83d                	j	80001dba <scheduler+0x8e>
      release(&p->lock);
    80001d7e:	8526                	mv	a0,s1
    80001d80:	f5ffe0ef          	jal	ra,80000cde <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d84:	17048493          	addi	s1,s1,368
    80001d88:	03348563          	beq	s1,s3,80001db2 <scheduler+0x86>
      acquire(&p->lock);
    80001d8c:	8526                	mv	a0,s1
    80001d8e:	eb9fe0ef          	jal	ra,80000c46 <acquire>
      if(p->state == RUNNABLE) {
    80001d92:	4c9c                	lw	a5,24(s1)
    80001d94:	ff2795e3          	bne	a5,s2,80001d7e <scheduler+0x52>
        p->state = RUNNING;
    80001d98:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001d9c:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001da0:	06048593          	addi	a1,s1,96
    80001da4:	855a                	mv	a0,s6
    80001da6:	5b2000ef          	jal	ra,80002358 <swtch>
        c->proc = 0;
    80001daa:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001dae:	8ade                	mv	s5,s7
    80001db0:	b7f9                	j	80001d7e <scheduler+0x52>
    if(found == 0) {
    80001db2:	000a9463          	bnez	s5,80001dba <scheduler+0x8e>
      asm volatile("wfi");
    80001db6:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dba:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001dbe:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001dc2:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dc6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001dca:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001dcc:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001dd0:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001dd2:	0000e497          	auipc	s1,0xe
    80001dd6:	13648493          	addi	s1,s1,310 # 8000ff08 <proc>
      if(p->state == RUNNABLE) {
    80001dda:	490d                	li	s2,3
    80001ddc:	bf45                	j	80001d8c <scheduler+0x60>

0000000080001dde <sched>:
{
    80001dde:	7179                	addi	sp,sp,-48
    80001de0:	f406                	sd	ra,40(sp)
    80001de2:	f022                	sd	s0,32(sp)
    80001de4:	ec26                	sd	s1,24(sp)
    80001de6:	e84a                	sd	s2,16(sp)
    80001de8:	e44e                	sd	s3,8(sp)
    80001dea:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001dec:	af3ff0ef          	jal	ra,800018de <myproc>
    80001df0:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001df2:	debfe0ef          	jal	ra,80000bdc <holding>
    80001df6:	c92d                	beqz	a0,80001e68 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001df8:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001dfa:	2781                	sext.w	a5,a5
    80001dfc:	079e                	slli	a5,a5,0x7
    80001dfe:	0000e717          	auipc	a4,0xe
    80001e02:	cda70713          	addi	a4,a4,-806 # 8000fad8 <pid_lock>
    80001e06:	97ba                	add	a5,a5,a4
    80001e08:	0a87a703          	lw	a4,168(a5)
    80001e0c:	4785                	li	a5,1
    80001e0e:	06f71363          	bne	a4,a5,80001e74 <sched+0x96>
  if(p->state == RUNNING)
    80001e12:	4c98                	lw	a4,24(s1)
    80001e14:	4791                	li	a5,4
    80001e16:	06f70563          	beq	a4,a5,80001e80 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e1a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e1e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e20:	e7b5                	bnez	a5,80001e8c <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e22:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e24:	0000e917          	auipc	s2,0xe
    80001e28:	cb490913          	addi	s2,s2,-844 # 8000fad8 <pid_lock>
    80001e2c:	2781                	sext.w	a5,a5
    80001e2e:	079e                	slli	a5,a5,0x7
    80001e30:	97ca                	add	a5,a5,s2
    80001e32:	0ac7a983          	lw	s3,172(a5)
    80001e36:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e38:	2781                	sext.w	a5,a5
    80001e3a:	079e                	slli	a5,a5,0x7
    80001e3c:	0000e597          	auipc	a1,0xe
    80001e40:	cd458593          	addi	a1,a1,-812 # 8000fb10 <cpus+0x8>
    80001e44:	95be                	add	a1,a1,a5
    80001e46:	06048513          	addi	a0,s1,96
    80001e4a:	50e000ef          	jal	ra,80002358 <swtch>
    80001e4e:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e50:	2781                	sext.w	a5,a5
    80001e52:	079e                	slli	a5,a5,0x7
    80001e54:	97ca                	add	a5,a5,s2
    80001e56:	0b37a623          	sw	s3,172(a5)
}
    80001e5a:	70a2                	ld	ra,40(sp)
    80001e5c:	7402                	ld	s0,32(sp)
    80001e5e:	64e2                	ld	s1,24(sp)
    80001e60:	6942                	ld	s2,16(sp)
    80001e62:	69a2                	ld	s3,8(sp)
    80001e64:	6145                	addi	sp,sp,48
    80001e66:	8082                	ret
    panic("sched p->lock");
    80001e68:	00005517          	auipc	a0,0x5
    80001e6c:	36050513          	addi	a0,a0,864 # 800071c8 <digits+0x178>
    80001e70:	971fe0ef          	jal	ra,800007e0 <panic>
    panic("sched locks");
    80001e74:	00005517          	auipc	a0,0x5
    80001e78:	36450513          	addi	a0,a0,868 # 800071d8 <digits+0x188>
    80001e7c:	965fe0ef          	jal	ra,800007e0 <panic>
    panic("sched RUNNING");
    80001e80:	00005517          	auipc	a0,0x5
    80001e84:	36850513          	addi	a0,a0,872 # 800071e8 <digits+0x198>
    80001e88:	959fe0ef          	jal	ra,800007e0 <panic>
    panic("sched interruptible");
    80001e8c:	00005517          	auipc	a0,0x5
    80001e90:	36c50513          	addi	a0,a0,876 # 800071f8 <digits+0x1a8>
    80001e94:	94dfe0ef          	jal	ra,800007e0 <panic>

0000000080001e98 <yield>:
{
    80001e98:	1101                	addi	sp,sp,-32
    80001e9a:	ec06                	sd	ra,24(sp)
    80001e9c:	e822                	sd	s0,16(sp)
    80001e9e:	e426                	sd	s1,8(sp)
    80001ea0:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ea2:	a3dff0ef          	jal	ra,800018de <myproc>
    80001ea6:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ea8:	d9ffe0ef          	jal	ra,80000c46 <acquire>
  p->state = RUNNABLE;
    80001eac:	478d                	li	a5,3
    80001eae:	cc9c                	sw	a5,24(s1)
  sched();
    80001eb0:	f2fff0ef          	jal	ra,80001dde <sched>
  release(&p->lock);
    80001eb4:	8526                	mv	a0,s1
    80001eb6:	e29fe0ef          	jal	ra,80000cde <release>
}
    80001eba:	60e2                	ld	ra,24(sp)
    80001ebc:	6442                	ld	s0,16(sp)
    80001ebe:	64a2                	ld	s1,8(sp)
    80001ec0:	6105                	addi	sp,sp,32
    80001ec2:	8082                	ret

0000000080001ec4 <sleep>:

// Sleep on wait channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001ec4:	7179                	addi	sp,sp,-48
    80001ec6:	f406                	sd	ra,40(sp)
    80001ec8:	f022                	sd	s0,32(sp)
    80001eca:	ec26                	sd	s1,24(sp)
    80001ecc:	e84a                	sd	s2,16(sp)
    80001ece:	e44e                	sd	s3,8(sp)
    80001ed0:	1800                	addi	s0,sp,48
    80001ed2:	89aa                	mv	s3,a0
    80001ed4:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001ed6:	a09ff0ef          	jal	ra,800018de <myproc>
    80001eda:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001edc:	d6bfe0ef          	jal	ra,80000c46 <acquire>
  release(lk);
    80001ee0:	854a                	mv	a0,s2
    80001ee2:	dfdfe0ef          	jal	ra,80000cde <release>

  // Go to sleep.
  p->chan = chan;
    80001ee6:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001eea:	4789                	li	a5,2
    80001eec:	cc9c                	sw	a5,24(s1)

  sched();
    80001eee:	ef1ff0ef          	jal	ra,80001dde <sched>

  // Tidy up.
  p->chan = 0;
    80001ef2:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001ef6:	8526                	mv	a0,s1
    80001ef8:	de7fe0ef          	jal	ra,80000cde <release>
  acquire(lk);
    80001efc:	854a                	mv	a0,s2
    80001efe:	d49fe0ef          	jal	ra,80000c46 <acquire>
}
    80001f02:	70a2                	ld	ra,40(sp)
    80001f04:	7402                	ld	s0,32(sp)
    80001f06:	64e2                	ld	s1,24(sp)
    80001f08:	6942                	ld	s2,16(sp)
    80001f0a:	69a2                	ld	s3,8(sp)
    80001f0c:	6145                	addi	sp,sp,48
    80001f0e:	8082                	ret

0000000080001f10 <wakeup>:

// Wake up all processes sleeping on wait channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f10:	7139                	addi	sp,sp,-64
    80001f12:	fc06                	sd	ra,56(sp)
    80001f14:	f822                	sd	s0,48(sp)
    80001f16:	f426                	sd	s1,40(sp)
    80001f18:	f04a                	sd	s2,32(sp)
    80001f1a:	ec4e                	sd	s3,24(sp)
    80001f1c:	e852                	sd	s4,16(sp)
    80001f1e:	e456                	sd	s5,8(sp)
    80001f20:	0080                	addi	s0,sp,64
    80001f22:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f24:	0000e497          	auipc	s1,0xe
    80001f28:	fe448493          	addi	s1,s1,-28 # 8000ff08 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f2c:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f2e:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f30:	00014917          	auipc	s2,0x14
    80001f34:	bd890913          	addi	s2,s2,-1064 # 80015b08 <tickslock>
    80001f38:	a801                	j	80001f48 <wakeup+0x38>
      }
      release(&p->lock);
    80001f3a:	8526                	mv	a0,s1
    80001f3c:	da3fe0ef          	jal	ra,80000cde <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f40:	17048493          	addi	s1,s1,368
    80001f44:	03248263          	beq	s1,s2,80001f68 <wakeup+0x58>
    if(p != myproc()){
    80001f48:	997ff0ef          	jal	ra,800018de <myproc>
    80001f4c:	fea48ae3          	beq	s1,a0,80001f40 <wakeup+0x30>
      acquire(&p->lock);
    80001f50:	8526                	mv	a0,s1
    80001f52:	cf5fe0ef          	jal	ra,80000c46 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001f56:	4c9c                	lw	a5,24(s1)
    80001f58:	ff3791e3          	bne	a5,s3,80001f3a <wakeup+0x2a>
    80001f5c:	709c                	ld	a5,32(s1)
    80001f5e:	fd479ee3          	bne	a5,s4,80001f3a <wakeup+0x2a>
        p->state = RUNNABLE;
    80001f62:	0154ac23          	sw	s5,24(s1)
    80001f66:	bfd1                	j	80001f3a <wakeup+0x2a>
    }
  }
}
    80001f68:	70e2                	ld	ra,56(sp)
    80001f6a:	7442                	ld	s0,48(sp)
    80001f6c:	74a2                	ld	s1,40(sp)
    80001f6e:	7902                	ld	s2,32(sp)
    80001f70:	69e2                	ld	s3,24(sp)
    80001f72:	6a42                	ld	s4,16(sp)
    80001f74:	6aa2                	ld	s5,8(sp)
    80001f76:	6121                	addi	sp,sp,64
    80001f78:	8082                	ret

0000000080001f7a <reparent>:
{
    80001f7a:	7179                	addi	sp,sp,-48
    80001f7c:	f406                	sd	ra,40(sp)
    80001f7e:	f022                	sd	s0,32(sp)
    80001f80:	ec26                	sd	s1,24(sp)
    80001f82:	e84a                	sd	s2,16(sp)
    80001f84:	e44e                	sd	s3,8(sp)
    80001f86:	e052                	sd	s4,0(sp)
    80001f88:	1800                	addi	s0,sp,48
    80001f8a:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001f8c:	0000e497          	auipc	s1,0xe
    80001f90:	f7c48493          	addi	s1,s1,-132 # 8000ff08 <proc>
      pp->parent = initproc;
    80001f94:	00006a17          	auipc	s4,0x6
    80001f98:	a14a0a13          	addi	s4,s4,-1516 # 800079a8 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001f9c:	00014997          	auipc	s3,0x14
    80001fa0:	b6c98993          	addi	s3,s3,-1172 # 80015b08 <tickslock>
    80001fa4:	a029                	j	80001fae <reparent+0x34>
    80001fa6:	17048493          	addi	s1,s1,368
    80001faa:	01348b63          	beq	s1,s3,80001fc0 <reparent+0x46>
    if(pp->parent == p){
    80001fae:	7c9c                	ld	a5,56(s1)
    80001fb0:	ff279be3          	bne	a5,s2,80001fa6 <reparent+0x2c>
      pp->parent = initproc;
    80001fb4:	000a3503          	ld	a0,0(s4)
    80001fb8:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001fba:	f57ff0ef          	jal	ra,80001f10 <wakeup>
    80001fbe:	b7e5                	j	80001fa6 <reparent+0x2c>
}
    80001fc0:	70a2                	ld	ra,40(sp)
    80001fc2:	7402                	ld	s0,32(sp)
    80001fc4:	64e2                	ld	s1,24(sp)
    80001fc6:	6942                	ld	s2,16(sp)
    80001fc8:	69a2                	ld	s3,8(sp)
    80001fca:	6a02                	ld	s4,0(sp)
    80001fcc:	6145                	addi	sp,sp,48
    80001fce:	8082                	ret

0000000080001fd0 <exit>:
{
    80001fd0:	7179                	addi	sp,sp,-48
    80001fd2:	f406                	sd	ra,40(sp)
    80001fd4:	f022                	sd	s0,32(sp)
    80001fd6:	ec26                	sd	s1,24(sp)
    80001fd8:	e84a                	sd	s2,16(sp)
    80001fda:	e44e                	sd	s3,8(sp)
    80001fdc:	e052                	sd	s4,0(sp)
    80001fde:	1800                	addi	s0,sp,48
    80001fe0:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001fe2:	8fdff0ef          	jal	ra,800018de <myproc>
    80001fe6:	89aa                	mv	s3,a0
  if(p == initproc)
    80001fe8:	00006797          	auipc	a5,0x6
    80001fec:	9c07b783          	ld	a5,-1600(a5) # 800079a8 <initproc>
    80001ff0:	0d050493          	addi	s1,a0,208
    80001ff4:	15050913          	addi	s2,a0,336
    80001ff8:	00a79f63          	bne	a5,a0,80002016 <exit+0x46>
    panic("init exiting");
    80001ffc:	00005517          	auipc	a0,0x5
    80002000:	21450513          	addi	a0,a0,532 # 80007210 <digits+0x1c0>
    80002004:	fdcfe0ef          	jal	ra,800007e0 <panic>
      fileclose(f);
    80002008:	6ed010ef          	jal	ra,80003ef4 <fileclose>
      p->ofile[fd] = 0;
    8000200c:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    80002010:	04a1                	addi	s1,s1,8
    80002012:	01248563          	beq	s1,s2,8000201c <exit+0x4c>
    if(p->ofile[fd]){
    80002016:	6088                	ld	a0,0(s1)
    80002018:	f965                	bnez	a0,80002008 <exit+0x38>
    8000201a:	bfdd                	j	80002010 <exit+0x40>
  begin_op();
    8000201c:	2bd010ef          	jal	ra,80003ad8 <begin_op>
  iput(p->cwd);
    80002020:	1509b503          	ld	a0,336(s3)
    80002024:	3a4010ef          	jal	ra,800033c8 <iput>
  end_op();
    80002028:	321010ef          	jal	ra,80003b48 <end_op>
  p->cwd = 0;
    8000202c:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002030:	0000e497          	auipc	s1,0xe
    80002034:	ac048493          	addi	s1,s1,-1344 # 8000faf0 <wait_lock>
    80002038:	8526                	mv	a0,s1
    8000203a:	c0dfe0ef          	jal	ra,80000c46 <acquire>
  reparent(p);
    8000203e:	854e                	mv	a0,s3
    80002040:	f3bff0ef          	jal	ra,80001f7a <reparent>
  wakeup(p->parent);
    80002044:	0389b503          	ld	a0,56(s3)
    80002048:	ec9ff0ef          	jal	ra,80001f10 <wakeup>
  acquire(&p->lock);
    8000204c:	854e                	mv	a0,s3
    8000204e:	bf9fe0ef          	jal	ra,80000c46 <acquire>
  p->xstate = status;
    80002052:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002056:	4795                	li	a5,5
    80002058:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    8000205c:	8526                	mv	a0,s1
    8000205e:	c81fe0ef          	jal	ra,80000cde <release>
  sched();
    80002062:	d7dff0ef          	jal	ra,80001dde <sched>
  panic("zombie exit");
    80002066:	00005517          	auipc	a0,0x5
    8000206a:	1ba50513          	addi	a0,a0,442 # 80007220 <digits+0x1d0>
    8000206e:	f72fe0ef          	jal	ra,800007e0 <panic>

0000000080002072 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002072:	7179                	addi	sp,sp,-48
    80002074:	f406                	sd	ra,40(sp)
    80002076:	f022                	sd	s0,32(sp)
    80002078:	ec26                	sd	s1,24(sp)
    8000207a:	e84a                	sd	s2,16(sp)
    8000207c:	e44e                	sd	s3,8(sp)
    8000207e:	1800                	addi	s0,sp,48
    80002080:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002082:	0000e497          	auipc	s1,0xe
    80002086:	e8648493          	addi	s1,s1,-378 # 8000ff08 <proc>
    8000208a:	00014997          	auipc	s3,0x14
    8000208e:	a7e98993          	addi	s3,s3,-1410 # 80015b08 <tickslock>
    acquire(&p->lock);
    80002092:	8526                	mv	a0,s1
    80002094:	bb3fe0ef          	jal	ra,80000c46 <acquire>
    if(p->pid == pid){
    80002098:	589c                	lw	a5,48(s1)
    8000209a:	01278b63          	beq	a5,s2,800020b0 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000209e:	8526                	mv	a0,s1
    800020a0:	c3ffe0ef          	jal	ra,80000cde <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800020a4:	17048493          	addi	s1,s1,368
    800020a8:	ff3495e3          	bne	s1,s3,80002092 <kill+0x20>
  }
  return -1;
    800020ac:	557d                	li	a0,-1
    800020ae:	a819                	j	800020c4 <kill+0x52>
      p->killed = 1;
    800020b0:	4785                	li	a5,1
    800020b2:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800020b4:	4c98                	lw	a4,24(s1)
    800020b6:	4789                	li	a5,2
    800020b8:	00f70d63          	beq	a4,a5,800020d2 <kill+0x60>
      release(&p->lock);
    800020bc:	8526                	mv	a0,s1
    800020be:	c21fe0ef          	jal	ra,80000cde <release>
      return 0;
    800020c2:	4501                	li	a0,0
}
    800020c4:	70a2                	ld	ra,40(sp)
    800020c6:	7402                	ld	s0,32(sp)
    800020c8:	64e2                	ld	s1,24(sp)
    800020ca:	6942                	ld	s2,16(sp)
    800020cc:	69a2                	ld	s3,8(sp)
    800020ce:	6145                	addi	sp,sp,48
    800020d0:	8082                	ret
        p->state = RUNNABLE;
    800020d2:	478d                	li	a5,3
    800020d4:	cc9c                	sw	a5,24(s1)
    800020d6:	b7dd                	j	800020bc <kill+0x4a>

00000000800020d8 <setkilled>:

void
setkilled(struct proc *p)
{
    800020d8:	1101                	addi	sp,sp,-32
    800020da:	ec06                	sd	ra,24(sp)
    800020dc:	e822                	sd	s0,16(sp)
    800020de:	e426                	sd	s1,8(sp)
    800020e0:	1000                	addi	s0,sp,32
    800020e2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020e4:	b63fe0ef          	jal	ra,80000c46 <acquire>
  p->killed = 1;
    800020e8:	4785                	li	a5,1
    800020ea:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800020ec:	8526                	mv	a0,s1
    800020ee:	bf1fe0ef          	jal	ra,80000cde <release>
}
    800020f2:	60e2                	ld	ra,24(sp)
    800020f4:	6442                	ld	s0,16(sp)
    800020f6:	64a2                	ld	s1,8(sp)
    800020f8:	6105                	addi	sp,sp,32
    800020fa:	8082                	ret

00000000800020fc <killed>:

int
killed(struct proc *p)
{
    800020fc:	1101                	addi	sp,sp,-32
    800020fe:	ec06                	sd	ra,24(sp)
    80002100:	e822                	sd	s0,16(sp)
    80002102:	e426                	sd	s1,8(sp)
    80002104:	e04a                	sd	s2,0(sp)
    80002106:	1000                	addi	s0,sp,32
    80002108:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000210a:	b3dfe0ef          	jal	ra,80000c46 <acquire>
  k = p->killed;
    8000210e:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    80002112:	8526                	mv	a0,s1
    80002114:	bcbfe0ef          	jal	ra,80000cde <release>
  return k;
}
    80002118:	854a                	mv	a0,s2
    8000211a:	60e2                	ld	ra,24(sp)
    8000211c:	6442                	ld	s0,16(sp)
    8000211e:	64a2                	ld	s1,8(sp)
    80002120:	6902                	ld	s2,0(sp)
    80002122:	6105                	addi	sp,sp,32
    80002124:	8082                	ret

0000000080002126 <wait>:
{
    80002126:	715d                	addi	sp,sp,-80
    80002128:	e486                	sd	ra,72(sp)
    8000212a:	e0a2                	sd	s0,64(sp)
    8000212c:	fc26                	sd	s1,56(sp)
    8000212e:	f84a                	sd	s2,48(sp)
    80002130:	f44e                	sd	s3,40(sp)
    80002132:	f052                	sd	s4,32(sp)
    80002134:	ec56                	sd	s5,24(sp)
    80002136:	e85a                	sd	s6,16(sp)
    80002138:	e45e                	sd	s7,8(sp)
    8000213a:	e062                	sd	s8,0(sp)
    8000213c:	0880                	addi	s0,sp,80
    8000213e:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002140:	f9eff0ef          	jal	ra,800018de <myproc>
    80002144:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002146:	0000e517          	auipc	a0,0xe
    8000214a:	9aa50513          	addi	a0,a0,-1622 # 8000faf0 <wait_lock>
    8000214e:	af9fe0ef          	jal	ra,80000c46 <acquire>
    havekids = 0;
    80002152:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    80002154:	4a15                	li	s4,5
        havekids = 1;
    80002156:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002158:	00014997          	auipc	s3,0x14
    8000215c:	9b098993          	addi	s3,s3,-1616 # 80015b08 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002160:	0000ec17          	auipc	s8,0xe
    80002164:	990c0c13          	addi	s8,s8,-1648 # 8000faf0 <wait_lock>
    havekids = 0;
    80002168:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000216a:	0000e497          	auipc	s1,0xe
    8000216e:	d9e48493          	addi	s1,s1,-610 # 8000ff08 <proc>
    80002172:	a899                	j	800021c8 <wait+0xa2>
          pid = pp->pid;
    80002174:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002178:	000b0c63          	beqz	s6,80002190 <wait+0x6a>
    8000217c:	4691                	li	a3,4
    8000217e:	02c48613          	addi	a2,s1,44
    80002182:	85da                	mv	a1,s6
    80002184:	05093503          	ld	a0,80(s2)
    80002188:	ca4ff0ef          	jal	ra,8000162c <copyout>
    8000218c:	00054f63          	bltz	a0,800021aa <wait+0x84>
          freeproc(pp);
    80002190:	8526                	mv	a0,s1
    80002192:	91dff0ef          	jal	ra,80001aae <freeproc>
          release(&pp->lock);
    80002196:	8526                	mv	a0,s1
    80002198:	b47fe0ef          	jal	ra,80000cde <release>
          release(&wait_lock);
    8000219c:	0000e517          	auipc	a0,0xe
    800021a0:	95450513          	addi	a0,a0,-1708 # 8000faf0 <wait_lock>
    800021a4:	b3bfe0ef          	jal	ra,80000cde <release>
          return pid;
    800021a8:	a891                	j	800021fc <wait+0xd6>
            release(&pp->lock);
    800021aa:	8526                	mv	a0,s1
    800021ac:	b33fe0ef          	jal	ra,80000cde <release>
            release(&wait_lock);
    800021b0:	0000e517          	auipc	a0,0xe
    800021b4:	94050513          	addi	a0,a0,-1728 # 8000faf0 <wait_lock>
    800021b8:	b27fe0ef          	jal	ra,80000cde <release>
            return -1;
    800021bc:	59fd                	li	s3,-1
    800021be:	a83d                	j	800021fc <wait+0xd6>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021c0:	17048493          	addi	s1,s1,368
    800021c4:	03348063          	beq	s1,s3,800021e4 <wait+0xbe>
      if(pp->parent == p){
    800021c8:	7c9c                	ld	a5,56(s1)
    800021ca:	ff279be3          	bne	a5,s2,800021c0 <wait+0x9a>
        acquire(&pp->lock);
    800021ce:	8526                	mv	a0,s1
    800021d0:	a77fe0ef          	jal	ra,80000c46 <acquire>
        if(pp->state == ZOMBIE){
    800021d4:	4c9c                	lw	a5,24(s1)
    800021d6:	f9478fe3          	beq	a5,s4,80002174 <wait+0x4e>
        release(&pp->lock);
    800021da:	8526                	mv	a0,s1
    800021dc:	b03fe0ef          	jal	ra,80000cde <release>
        havekids = 1;
    800021e0:	8756                	mv	a4,s5
    800021e2:	bff9                	j	800021c0 <wait+0x9a>
    if(!havekids || killed(p)){
    800021e4:	c709                	beqz	a4,800021ee <wait+0xc8>
    800021e6:	854a                	mv	a0,s2
    800021e8:	f15ff0ef          	jal	ra,800020fc <killed>
    800021ec:	c50d                	beqz	a0,80002216 <wait+0xf0>
      release(&wait_lock);
    800021ee:	0000e517          	auipc	a0,0xe
    800021f2:	90250513          	addi	a0,a0,-1790 # 8000faf0 <wait_lock>
    800021f6:	ae9fe0ef          	jal	ra,80000cde <release>
      return -1;
    800021fa:	59fd                	li	s3,-1
}
    800021fc:	854e                	mv	a0,s3
    800021fe:	60a6                	ld	ra,72(sp)
    80002200:	6406                	ld	s0,64(sp)
    80002202:	74e2                	ld	s1,56(sp)
    80002204:	7942                	ld	s2,48(sp)
    80002206:	79a2                	ld	s3,40(sp)
    80002208:	7a02                	ld	s4,32(sp)
    8000220a:	6ae2                	ld	s5,24(sp)
    8000220c:	6b42                	ld	s6,16(sp)
    8000220e:	6ba2                	ld	s7,8(sp)
    80002210:	6c02                	ld	s8,0(sp)
    80002212:	6161                	addi	sp,sp,80
    80002214:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002216:	85e2                	mv	a1,s8
    80002218:	854a                	mv	a0,s2
    8000221a:	cabff0ef          	jal	ra,80001ec4 <sleep>
    havekids = 0;
    8000221e:	b7a9                	j	80002168 <wait+0x42>

0000000080002220 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002220:	7179                	addi	sp,sp,-48
    80002222:	f406                	sd	ra,40(sp)
    80002224:	f022                	sd	s0,32(sp)
    80002226:	ec26                	sd	s1,24(sp)
    80002228:	e84a                	sd	s2,16(sp)
    8000222a:	e44e                	sd	s3,8(sp)
    8000222c:	e052                	sd	s4,0(sp)
    8000222e:	1800                	addi	s0,sp,48
    80002230:	84aa                	mv	s1,a0
    80002232:	892e                	mv	s2,a1
    80002234:	89b2                	mv	s3,a2
    80002236:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002238:	ea6ff0ef          	jal	ra,800018de <myproc>
  if(user_dst){
    8000223c:	cc99                	beqz	s1,8000225a <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    8000223e:	86d2                	mv	a3,s4
    80002240:	864e                	mv	a2,s3
    80002242:	85ca                	mv	a1,s2
    80002244:	6928                	ld	a0,80(a0)
    80002246:	be6ff0ef          	jal	ra,8000162c <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    8000224a:	70a2                	ld	ra,40(sp)
    8000224c:	7402                	ld	s0,32(sp)
    8000224e:	64e2                	ld	s1,24(sp)
    80002250:	6942                	ld	s2,16(sp)
    80002252:	69a2                	ld	s3,8(sp)
    80002254:	6a02                	ld	s4,0(sp)
    80002256:	6145                	addi	sp,sp,48
    80002258:	8082                	ret
    memmove((char *)dst, src, len);
    8000225a:	000a061b          	sext.w	a2,s4
    8000225e:	85ce                	mv	a1,s3
    80002260:	854a                	mv	a0,s2
    80002262:	b15fe0ef          	jal	ra,80000d76 <memmove>
    return 0;
    80002266:	8526                	mv	a0,s1
    80002268:	b7cd                	j	8000224a <either_copyout+0x2a>

000000008000226a <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000226a:	7179                	addi	sp,sp,-48
    8000226c:	f406                	sd	ra,40(sp)
    8000226e:	f022                	sd	s0,32(sp)
    80002270:	ec26                	sd	s1,24(sp)
    80002272:	e84a                	sd	s2,16(sp)
    80002274:	e44e                	sd	s3,8(sp)
    80002276:	e052                	sd	s4,0(sp)
    80002278:	1800                	addi	s0,sp,48
    8000227a:	892a                	mv	s2,a0
    8000227c:	84ae                	mv	s1,a1
    8000227e:	89b2                	mv	s3,a2
    80002280:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002282:	e5cff0ef          	jal	ra,800018de <myproc>
  if(user_src){
    80002286:	cc99                	beqz	s1,800022a4 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80002288:	86d2                	mv	a3,s4
    8000228a:	864e                	mv	a2,s3
    8000228c:	85ca                	mv	a1,s2
    8000228e:	6928                	ld	a0,80(a0)
    80002290:	c62ff0ef          	jal	ra,800016f2 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002294:	70a2                	ld	ra,40(sp)
    80002296:	7402                	ld	s0,32(sp)
    80002298:	64e2                	ld	s1,24(sp)
    8000229a:	6942                	ld	s2,16(sp)
    8000229c:	69a2                	ld	s3,8(sp)
    8000229e:	6a02                	ld	s4,0(sp)
    800022a0:	6145                	addi	sp,sp,48
    800022a2:	8082                	ret
    memmove(dst, (char*)src, len);
    800022a4:	000a061b          	sext.w	a2,s4
    800022a8:	85ce                	mv	a1,s3
    800022aa:	854a                	mv	a0,s2
    800022ac:	acbfe0ef          	jal	ra,80000d76 <memmove>
    return 0;
    800022b0:	8526                	mv	a0,s1
    800022b2:	b7cd                	j	80002294 <either_copyin+0x2a>

00000000800022b4 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800022b4:	715d                	addi	sp,sp,-80
    800022b6:	e486                	sd	ra,72(sp)
    800022b8:	e0a2                	sd	s0,64(sp)
    800022ba:	fc26                	sd	s1,56(sp)
    800022bc:	f84a                	sd	s2,48(sp)
    800022be:	f44e                	sd	s3,40(sp)
    800022c0:	f052                	sd	s4,32(sp)
    800022c2:	ec56                	sd	s5,24(sp)
    800022c4:	e85a                	sd	s6,16(sp)
    800022c6:	e45e                	sd	s7,8(sp)
    800022c8:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800022ca:	00005517          	auipc	a0,0x5
    800022ce:	e0e50513          	addi	a0,a0,-498 # 800070d8 <digits+0x88>
    800022d2:	9d0fe0ef          	jal	ra,800004a2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800022d6:	0000e497          	auipc	s1,0xe
    800022da:	d8a48493          	addi	s1,s1,-630 # 80010060 <proc+0x158>
    800022de:	00014917          	auipc	s2,0x14
    800022e2:	98290913          	addi	s2,s2,-1662 # 80015c60 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800022e6:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800022e8:	00005997          	auipc	s3,0x5
    800022ec:	f4898993          	addi	s3,s3,-184 # 80007230 <digits+0x1e0>
    printf("%d %s %s", p->pid, state, p->name);
    800022f0:	00005a97          	auipc	s5,0x5
    800022f4:	f48a8a93          	addi	s5,s5,-184 # 80007238 <digits+0x1e8>
    printf("\n");
    800022f8:	00005a17          	auipc	s4,0x5
    800022fc:	de0a0a13          	addi	s4,s4,-544 # 800070d8 <digits+0x88>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002300:	00005b97          	auipc	s7,0x5
    80002304:	f78b8b93          	addi	s7,s7,-136 # 80007278 <states.0>
    80002308:	a829                	j	80002322 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    8000230a:	ed86a583          	lw	a1,-296(a3)
    8000230e:	8556                	mv	a0,s5
    80002310:	992fe0ef          	jal	ra,800004a2 <printf>
    printf("\n");
    80002314:	8552                	mv	a0,s4
    80002316:	98cfe0ef          	jal	ra,800004a2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000231a:	17048493          	addi	s1,s1,368
    8000231e:	03248263          	beq	s1,s2,80002342 <procdump+0x8e>
    if(p->state == UNUSED)
    80002322:	86a6                	mv	a3,s1
    80002324:	ec04a783          	lw	a5,-320(s1)
    80002328:	dbed                	beqz	a5,8000231a <procdump+0x66>
      state = "???";
    8000232a:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000232c:	fcfb6fe3          	bltu	s6,a5,8000230a <procdump+0x56>
    80002330:	02079713          	slli	a4,a5,0x20
    80002334:	01d75793          	srli	a5,a4,0x1d
    80002338:	97de                	add	a5,a5,s7
    8000233a:	6390                	ld	a2,0(a5)
    8000233c:	f679                	bnez	a2,8000230a <procdump+0x56>
      state = "???";
    8000233e:	864e                	mv	a2,s3
    80002340:	b7e9                	j	8000230a <procdump+0x56>
  }
}
    80002342:	60a6                	ld	ra,72(sp)
    80002344:	6406                	ld	s0,64(sp)
    80002346:	74e2                	ld	s1,56(sp)
    80002348:	7942                	ld	s2,48(sp)
    8000234a:	79a2                	ld	s3,40(sp)
    8000234c:	7a02                	ld	s4,32(sp)
    8000234e:	6ae2                	ld	s5,24(sp)
    80002350:	6b42                	ld	s6,16(sp)
    80002352:	6ba2                	ld	s7,8(sp)
    80002354:	6161                	addi	sp,sp,80
    80002356:	8082                	ret

0000000080002358 <swtch>:
    80002358:	00153023          	sd	ra,0(a0)
    8000235c:	00253423          	sd	sp,8(a0)
    80002360:	e900                	sd	s0,16(a0)
    80002362:	ed04                	sd	s1,24(a0)
    80002364:	03253023          	sd	s2,32(a0)
    80002368:	03353423          	sd	s3,40(a0)
    8000236c:	03453823          	sd	s4,48(a0)
    80002370:	03553c23          	sd	s5,56(a0)
    80002374:	05653023          	sd	s6,64(a0)
    80002378:	05753423          	sd	s7,72(a0)
    8000237c:	05853823          	sd	s8,80(a0)
    80002380:	05953c23          	sd	s9,88(a0)
    80002384:	07a53023          	sd	s10,96(a0)
    80002388:	07b53423          	sd	s11,104(a0)
    8000238c:	0005b083          	ld	ra,0(a1)
    80002390:	0085b103          	ld	sp,8(a1)
    80002394:	6980                	ld	s0,16(a1)
    80002396:	6d84                	ld	s1,24(a1)
    80002398:	0205b903          	ld	s2,32(a1)
    8000239c:	0285b983          	ld	s3,40(a1)
    800023a0:	0305ba03          	ld	s4,48(a1)
    800023a4:	0385ba83          	ld	s5,56(a1)
    800023a8:	0405bb03          	ld	s6,64(a1)
    800023ac:	0485bb83          	ld	s7,72(a1)
    800023b0:	0505bc03          	ld	s8,80(a1)
    800023b4:	0585bc83          	ld	s9,88(a1)
    800023b8:	0605bd03          	ld	s10,96(a1)
    800023bc:	0685bd83          	ld	s11,104(a1)
    800023c0:	8082                	ret

00000000800023c2 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800023c2:	1141                	addi	sp,sp,-16
    800023c4:	e406                	sd	ra,8(sp)
    800023c6:	e022                	sd	s0,0(sp)
    800023c8:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800023ca:	00005597          	auipc	a1,0x5
    800023ce:	ede58593          	addi	a1,a1,-290 # 800072a8 <states.0+0x30>
    800023d2:	00013517          	auipc	a0,0x13
    800023d6:	73650513          	addi	a0,a0,1846 # 80015b08 <tickslock>
    800023da:	fecfe0ef          	jal	ra,80000bc6 <initlock>
}
    800023de:	60a2                	ld	ra,8(sp)
    800023e0:	6402                	ld	s0,0(sp)
    800023e2:	0141                	addi	sp,sp,16
    800023e4:	8082                	ret

00000000800023e6 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800023e6:	1141                	addi	sp,sp,-16
    800023e8:	e422                	sd	s0,8(sp)
    800023ea:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800023ec:	00003797          	auipc	a5,0x3
    800023f0:	dc478793          	addi	a5,a5,-572 # 800051b0 <kernelvec>
    800023f4:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800023f8:	6422                	ld	s0,8(sp)
    800023fa:	0141                	addi	sp,sp,16
    800023fc:	8082                	ret

00000000800023fe <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800023fe:	1141                	addi	sp,sp,-16
    80002400:	e406                	sd	ra,8(sp)
    80002402:	e022                	sd	s0,0(sp)
    80002404:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002406:	cd8ff0ef          	jal	ra,800018de <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000240a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000240e:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002410:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002414:	04000737          	lui	a4,0x4000
    80002418:	00004797          	auipc	a5,0x4
    8000241c:	be878793          	addi	a5,a5,-1048 # 80006000 <_trampoline>
    80002420:	00004697          	auipc	a3,0x4
    80002424:	be068693          	addi	a3,a3,-1056 # 80006000 <_trampoline>
    80002428:	8f95                	sub	a5,a5,a3
    8000242a:	177d                	addi	a4,a4,-1
    8000242c:	0732                	slli	a4,a4,0xc
    8000242e:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002430:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002434:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002436:	18002773          	csrr	a4,satp
    8000243a:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000243c:	6d38                	ld	a4,88(a0)
    8000243e:	613c                	ld	a5,64(a0)
    80002440:	6685                	lui	a3,0x1
    80002442:	97b6                	add	a5,a5,a3
    80002444:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002446:	6d3c                	ld	a5,88(a0)
    80002448:	00000717          	auipc	a4,0x0
    8000244c:	0f470713          	addi	a4,a4,244 # 8000253c <usertrap>
    80002450:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002452:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002454:	8712                	mv	a4,tp
    80002456:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002458:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000245c:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002460:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002464:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002468:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000246a:	6f9c                	ld	a5,24(a5)
    8000246c:	14179073          	csrw	sepc,a5
}
    80002470:	60a2                	ld	ra,8(sp)
    80002472:	6402                	ld	s0,0(sp)
    80002474:	0141                	addi	sp,sp,16
    80002476:	8082                	ret

0000000080002478 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002478:	1101                	addi	sp,sp,-32
    8000247a:	ec06                	sd	ra,24(sp)
    8000247c:	e822                	sd	s0,16(sp)
    8000247e:	e426                	sd	s1,8(sp)
    80002480:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    80002482:	c30ff0ef          	jal	ra,800018b2 <cpuid>
    80002486:	cd19                	beqz	a0,800024a4 <clockintr+0x2c>
  asm volatile("csrr %0, time" : "=r" (x) );
    80002488:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000248c:	000f4737          	lui	a4,0xf4
    80002490:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002494:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002496:	14d79073          	csrw	0x14d,a5
}
    8000249a:	60e2                	ld	ra,24(sp)
    8000249c:	6442                	ld	s0,16(sp)
    8000249e:	64a2                	ld	s1,8(sp)
    800024a0:	6105                	addi	sp,sp,32
    800024a2:	8082                	ret
    acquire(&tickslock);
    800024a4:	00013497          	auipc	s1,0x13
    800024a8:	66448493          	addi	s1,s1,1636 # 80015b08 <tickslock>
    800024ac:	8526                	mv	a0,s1
    800024ae:	f98fe0ef          	jal	ra,80000c46 <acquire>
    ticks++;
    800024b2:	00005517          	auipc	a0,0x5
    800024b6:	4fe50513          	addi	a0,a0,1278 # 800079b0 <ticks>
    800024ba:	411c                	lw	a5,0(a0)
    800024bc:	2785                	addiw	a5,a5,1
    800024be:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800024c0:	a51ff0ef          	jal	ra,80001f10 <wakeup>
    release(&tickslock);
    800024c4:	8526                	mv	a0,s1
    800024c6:	819fe0ef          	jal	ra,80000cde <release>
    800024ca:	bf7d                	j	80002488 <clockintr+0x10>

00000000800024cc <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800024cc:	1101                	addi	sp,sp,-32
    800024ce:	ec06                	sd	ra,24(sp)
    800024d0:	e822                	sd	s0,16(sp)
    800024d2:	e426                	sd	s1,8(sp)
    800024d4:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    800024d6:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    800024da:	57fd                	li	a5,-1
    800024dc:	17fe                	slli	a5,a5,0x3f
    800024de:	07a5                	addi	a5,a5,9
    800024e0:	00f70d63          	beq	a4,a5,800024fa <devintr+0x2e>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    800024e4:	57fd                	li	a5,-1
    800024e6:	17fe                	slli	a5,a5,0x3f
    800024e8:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800024ea:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    800024ec:	04f70463          	beq	a4,a5,80002534 <devintr+0x68>
  }
}
    800024f0:	60e2                	ld	ra,24(sp)
    800024f2:	6442                	ld	s0,16(sp)
    800024f4:	64a2                	ld	s1,8(sp)
    800024f6:	6105                	addi	sp,sp,32
    800024f8:	8082                	ret
    int irq = plic_claim();
    800024fa:	55f020ef          	jal	ra,80005258 <plic_claim>
    800024fe:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002500:	47a9                	li	a5,10
    80002502:	02f50363          	beq	a0,a5,80002528 <devintr+0x5c>
    } else if(irq == VIRTIO0_IRQ){
    80002506:	4785                	li	a5,1
    80002508:	02f50363          	beq	a0,a5,8000252e <devintr+0x62>
    return 1;
    8000250c:	4505                	li	a0,1
    } else if(irq){
    8000250e:	d0ed                	beqz	s1,800024f0 <devintr+0x24>
      printf("unexpected interrupt irq=%d\n", irq);
    80002510:	85a6                	mv	a1,s1
    80002512:	00005517          	auipc	a0,0x5
    80002516:	d9e50513          	addi	a0,a0,-610 # 800072b0 <states.0+0x38>
    8000251a:	f89fd0ef          	jal	ra,800004a2 <printf>
      plic_complete(irq);
    8000251e:	8526                	mv	a0,s1
    80002520:	559020ef          	jal	ra,80005278 <plic_complete>
    return 1;
    80002524:	4505                	li	a0,1
    80002526:	b7e9                	j	800024f0 <devintr+0x24>
      uartintr();
    80002528:	d0efe0ef          	jal	ra,80000a36 <uartintr>
    8000252c:	bfcd                	j	8000251e <devintr+0x52>
      virtio_disk_intr();
    8000252e:	1ba030ef          	jal	ra,800056e8 <virtio_disk_intr>
    80002532:	b7f5                	j	8000251e <devintr+0x52>
    clockintr();
    80002534:	f45ff0ef          	jal	ra,80002478 <clockintr>
    return 2;
    80002538:	4509                	li	a0,2
    8000253a:	bf5d                	j	800024f0 <devintr+0x24>

000000008000253c <usertrap>:
{
    8000253c:	1101                	addi	sp,sp,-32
    8000253e:	ec06                	sd	ra,24(sp)
    80002540:	e822                	sd	s0,16(sp)
    80002542:	e426                	sd	s1,8(sp)
    80002544:	e04a                	sd	s2,0(sp)
    80002546:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002548:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    8000254c:	1007f793          	andi	a5,a5,256
    80002550:	eba5                	bnez	a5,800025c0 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002552:	00003797          	auipc	a5,0x3
    80002556:	c5e78793          	addi	a5,a5,-930 # 800051b0 <kernelvec>
    8000255a:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000255e:	b80ff0ef          	jal	ra,800018de <myproc>
    80002562:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002564:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002566:	14102773          	csrr	a4,sepc
    8000256a:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000256c:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80002570:	47a1                	li	a5,8
    80002572:	04f70d63          	beq	a4,a5,800025cc <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    80002576:	f57ff0ef          	jal	ra,800024cc <devintr>
    8000257a:	892a                	mv	s2,a0
    8000257c:	e945                	bnez	a0,8000262c <usertrap+0xf0>
    8000257e:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002582:	47bd                	li	a5,15
    80002584:	08f70863          	beq	a4,a5,80002614 <usertrap+0xd8>
    80002588:	14202773          	csrr	a4,scause
    8000258c:	47b5                	li	a5,13
    8000258e:	08f70363          	beq	a4,a5,80002614 <usertrap+0xd8>
    80002592:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002596:	5890                	lw	a2,48(s1)
    80002598:	00005517          	auipc	a0,0x5
    8000259c:	d5850513          	addi	a0,a0,-680 # 800072f0 <states.0+0x78>
    800025a0:	f03fd0ef          	jal	ra,800004a2 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800025a4:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800025a8:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800025ac:	00005517          	auipc	a0,0x5
    800025b0:	d7450513          	addi	a0,a0,-652 # 80007320 <states.0+0xa8>
    800025b4:	eeffd0ef          	jal	ra,800004a2 <printf>
    setkilled(p);
    800025b8:	8526                	mv	a0,s1
    800025ba:	b1fff0ef          	jal	ra,800020d8 <setkilled>
    800025be:	a035                	j	800025ea <usertrap+0xae>
    panic("usertrap: not from user mode");
    800025c0:	00005517          	auipc	a0,0x5
    800025c4:	d1050513          	addi	a0,a0,-752 # 800072d0 <states.0+0x58>
    800025c8:	a18fe0ef          	jal	ra,800007e0 <panic>
    if(killed(p))
    800025cc:	b31ff0ef          	jal	ra,800020fc <killed>
    800025d0:	ed15                	bnez	a0,8000260c <usertrap+0xd0>
    p->trapframe->epc += 4;
    800025d2:	6cb8                	ld	a4,88(s1)
    800025d4:	6f1c                	ld	a5,24(a4)
    800025d6:	0791                	addi	a5,a5,4
    800025d8:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025da:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800025de:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800025e2:	10079073          	csrw	sstatus,a5
    syscall();
    800025e6:	246000ef          	jal	ra,8000282c <syscall>
  if(killed(p))
    800025ea:	8526                	mv	a0,s1
    800025ec:	b11ff0ef          	jal	ra,800020fc <killed>
    800025f0:	e139                	bnez	a0,80002636 <usertrap+0xfa>
  prepare_return();
    800025f2:	e0dff0ef          	jal	ra,800023fe <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800025f6:	68a8                	ld	a0,80(s1)
    800025f8:	8131                	srli	a0,a0,0xc
    800025fa:	57fd                	li	a5,-1
    800025fc:	17fe                	slli	a5,a5,0x3f
    800025fe:	8d5d                	or	a0,a0,a5
}
    80002600:	60e2                	ld	ra,24(sp)
    80002602:	6442                	ld	s0,16(sp)
    80002604:	64a2                	ld	s1,8(sp)
    80002606:	6902                	ld	s2,0(sp)
    80002608:	6105                	addi	sp,sp,32
    8000260a:	8082                	ret
      exit(-1);
    8000260c:	557d                	li	a0,-1
    8000260e:	9c3ff0ef          	jal	ra,80001fd0 <exit>
    80002612:	b7c1                	j	800025d2 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002614:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002618:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    8000261c:	164d                	addi	a2,a2,-13
    8000261e:	00163613          	seqz	a2,a2
    80002622:	68a8                	ld	a0,80(s1)
    80002624:	f97fe0ef          	jal	ra,800015ba <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002628:	f169                	bnez	a0,800025ea <usertrap+0xae>
    8000262a:	b7a5                	j	80002592 <usertrap+0x56>
  if(killed(p))
    8000262c:	8526                	mv	a0,s1
    8000262e:	acfff0ef          	jal	ra,800020fc <killed>
    80002632:	c511                	beqz	a0,8000263e <usertrap+0x102>
    80002634:	a011                	j	80002638 <usertrap+0xfc>
    80002636:	4901                	li	s2,0
    exit(-1);
    80002638:	557d                	li	a0,-1
    8000263a:	997ff0ef          	jal	ra,80001fd0 <exit>
  if(which_dev == 2)
    8000263e:	4789                	li	a5,2
    80002640:	faf919e3          	bne	s2,a5,800025f2 <usertrap+0xb6>
    yield();
    80002644:	855ff0ef          	jal	ra,80001e98 <yield>
    80002648:	b76d                	j	800025f2 <usertrap+0xb6>

000000008000264a <kerneltrap>:
{
    8000264a:	7179                	addi	sp,sp,-48
    8000264c:	f406                	sd	ra,40(sp)
    8000264e:	f022                	sd	s0,32(sp)
    80002650:	ec26                	sd	s1,24(sp)
    80002652:	e84a                	sd	s2,16(sp)
    80002654:	e44e                	sd	s3,8(sp)
    80002656:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002658:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000265c:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002660:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80002664:	1004f793          	andi	a5,s1,256
    80002668:	c795                	beqz	a5,80002694 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000266a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000266e:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002670:	eb85                	bnez	a5,800026a0 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    80002672:	e5bff0ef          	jal	ra,800024cc <devintr>
    80002676:	c91d                	beqz	a0,800026ac <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    80002678:	4789                	li	a5,2
    8000267a:	04f50a63          	beq	a0,a5,800026ce <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000267e:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002682:	10049073          	csrw	sstatus,s1
}
    80002686:	70a2                	ld	ra,40(sp)
    80002688:	7402                	ld	s0,32(sp)
    8000268a:	64e2                	ld	s1,24(sp)
    8000268c:	6942                	ld	s2,16(sp)
    8000268e:	69a2                	ld	s3,8(sp)
    80002690:	6145                	addi	sp,sp,48
    80002692:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002694:	00005517          	auipc	a0,0x5
    80002698:	cb450513          	addi	a0,a0,-844 # 80007348 <states.0+0xd0>
    8000269c:	944fe0ef          	jal	ra,800007e0 <panic>
    panic("kerneltrap: interrupts enabled");
    800026a0:	00005517          	auipc	a0,0x5
    800026a4:	cd050513          	addi	a0,a0,-816 # 80007370 <states.0+0xf8>
    800026a8:	938fe0ef          	jal	ra,800007e0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026ac:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026b0:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800026b4:	85ce                	mv	a1,s3
    800026b6:	00005517          	auipc	a0,0x5
    800026ba:	cda50513          	addi	a0,a0,-806 # 80007390 <states.0+0x118>
    800026be:	de5fd0ef          	jal	ra,800004a2 <printf>
    panic("kerneltrap");
    800026c2:	00005517          	auipc	a0,0x5
    800026c6:	cf650513          	addi	a0,a0,-778 # 800073b8 <states.0+0x140>
    800026ca:	916fe0ef          	jal	ra,800007e0 <panic>
  if(which_dev == 2 && myproc() != 0)
    800026ce:	a10ff0ef          	jal	ra,800018de <myproc>
    800026d2:	d555                	beqz	a0,8000267e <kerneltrap+0x34>
    yield();
    800026d4:	fc4ff0ef          	jal	ra,80001e98 <yield>
    800026d8:	b75d                	j	8000267e <kerneltrap+0x34>

00000000800026da <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800026da:	1101                	addi	sp,sp,-32
    800026dc:	ec06                	sd	ra,24(sp)
    800026de:	e822                	sd	s0,16(sp)
    800026e0:	e426                	sd	s1,8(sp)
    800026e2:	1000                	addi	s0,sp,32
    800026e4:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800026e6:	9f8ff0ef          	jal	ra,800018de <myproc>
  switch (n) {
    800026ea:	4795                	li	a5,5
    800026ec:	0497e163          	bltu	a5,s1,8000272e <argraw+0x54>
    800026f0:	048a                	slli	s1,s1,0x2
    800026f2:	00005717          	auipc	a4,0x5
    800026f6:	db670713          	addi	a4,a4,-586 # 800074a8 <states.0+0x230>
    800026fa:	94ba                	add	s1,s1,a4
    800026fc:	409c                	lw	a5,0(s1)
    800026fe:	97ba                	add	a5,a5,a4
    80002700:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002702:	6d3c                	ld	a5,88(a0)
    80002704:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002706:	60e2                	ld	ra,24(sp)
    80002708:	6442                	ld	s0,16(sp)
    8000270a:	64a2                	ld	s1,8(sp)
    8000270c:	6105                	addi	sp,sp,32
    8000270e:	8082                	ret
    return p->trapframe->a1;
    80002710:	6d3c                	ld	a5,88(a0)
    80002712:	7fa8                	ld	a0,120(a5)
    80002714:	bfcd                	j	80002706 <argraw+0x2c>
    return p->trapframe->a2;
    80002716:	6d3c                	ld	a5,88(a0)
    80002718:	63c8                	ld	a0,128(a5)
    8000271a:	b7f5                	j	80002706 <argraw+0x2c>
    return p->trapframe->a3;
    8000271c:	6d3c                	ld	a5,88(a0)
    8000271e:	67c8                	ld	a0,136(a5)
    80002720:	b7dd                	j	80002706 <argraw+0x2c>
    return p->trapframe->a4;
    80002722:	6d3c                	ld	a5,88(a0)
    80002724:	6bc8                	ld	a0,144(a5)
    80002726:	b7c5                	j	80002706 <argraw+0x2c>
    return p->trapframe->a5;
    80002728:	6d3c                	ld	a5,88(a0)
    8000272a:	6fc8                	ld	a0,152(a5)
    8000272c:	bfe9                	j	80002706 <argraw+0x2c>
  panic("argraw");
    8000272e:	00005517          	auipc	a0,0x5
    80002732:	c9a50513          	addi	a0,a0,-870 # 800073c8 <states.0+0x150>
    80002736:	8aafe0ef          	jal	ra,800007e0 <panic>

000000008000273a <fetchaddr>:
{
    8000273a:	1101                	addi	sp,sp,-32
    8000273c:	ec06                	sd	ra,24(sp)
    8000273e:	e822                	sd	s0,16(sp)
    80002740:	e426                	sd	s1,8(sp)
    80002742:	e04a                	sd	s2,0(sp)
    80002744:	1000                	addi	s0,sp,32
    80002746:	84aa                	mv	s1,a0
    80002748:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000274a:	994ff0ef          	jal	ra,800018de <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    8000274e:	653c                	ld	a5,72(a0)
    80002750:	02f4f663          	bgeu	s1,a5,8000277c <fetchaddr+0x42>
    80002754:	00848713          	addi	a4,s1,8
    80002758:	02e7e463          	bltu	a5,a4,80002780 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000275c:	46a1                	li	a3,8
    8000275e:	8626                	mv	a2,s1
    80002760:	85ca                	mv	a1,s2
    80002762:	6928                	ld	a0,80(a0)
    80002764:	f8ffe0ef          	jal	ra,800016f2 <copyin>
    80002768:	00a03533          	snez	a0,a0
    8000276c:	40a00533          	neg	a0,a0
}
    80002770:	60e2                	ld	ra,24(sp)
    80002772:	6442                	ld	s0,16(sp)
    80002774:	64a2                	ld	s1,8(sp)
    80002776:	6902                	ld	s2,0(sp)
    80002778:	6105                	addi	sp,sp,32
    8000277a:	8082                	ret
    return -1;
    8000277c:	557d                	li	a0,-1
    8000277e:	bfcd                	j	80002770 <fetchaddr+0x36>
    80002780:	557d                	li	a0,-1
    80002782:	b7fd                	j	80002770 <fetchaddr+0x36>

0000000080002784 <fetchstr>:
{
    80002784:	7179                	addi	sp,sp,-48
    80002786:	f406                	sd	ra,40(sp)
    80002788:	f022                	sd	s0,32(sp)
    8000278a:	ec26                	sd	s1,24(sp)
    8000278c:	e84a                	sd	s2,16(sp)
    8000278e:	e44e                	sd	s3,8(sp)
    80002790:	1800                	addi	s0,sp,48
    80002792:	892a                	mv	s2,a0
    80002794:	84ae                	mv	s1,a1
    80002796:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002798:	946ff0ef          	jal	ra,800018de <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    8000279c:	86ce                	mv	a3,s3
    8000279e:	864a                	mv	a2,s2
    800027a0:	85a6                	mv	a1,s1
    800027a2:	6928                	ld	a0,80(a0)
    800027a4:	d47fe0ef          	jal	ra,800014ea <copyinstr>
    800027a8:	00054c63          	bltz	a0,800027c0 <fetchstr+0x3c>
  return strlen(buf);
    800027ac:	8526                	mv	a0,s1
    800027ae:	ee4fe0ef          	jal	ra,80000e92 <strlen>
}
    800027b2:	70a2                	ld	ra,40(sp)
    800027b4:	7402                	ld	s0,32(sp)
    800027b6:	64e2                	ld	s1,24(sp)
    800027b8:	6942                	ld	s2,16(sp)
    800027ba:	69a2                	ld	s3,8(sp)
    800027bc:	6145                	addi	sp,sp,48
    800027be:	8082                	ret
    return -1;
    800027c0:	557d                	li	a0,-1
    800027c2:	bfc5                	j	800027b2 <fetchstr+0x2e>

00000000800027c4 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800027c4:	1101                	addi	sp,sp,-32
    800027c6:	ec06                	sd	ra,24(sp)
    800027c8:	e822                	sd	s0,16(sp)
    800027ca:	e426                	sd	s1,8(sp)
    800027cc:	1000                	addi	s0,sp,32
    800027ce:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027d0:	f0bff0ef          	jal	ra,800026da <argraw>
    800027d4:	c088                	sw	a0,0(s1)
}
    800027d6:	60e2                	ld	ra,24(sp)
    800027d8:	6442                	ld	s0,16(sp)
    800027da:	64a2                	ld	s1,8(sp)
    800027dc:	6105                	addi	sp,sp,32
    800027de:	8082                	ret

00000000800027e0 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800027e0:	1101                	addi	sp,sp,-32
    800027e2:	ec06                	sd	ra,24(sp)
    800027e4:	e822                	sd	s0,16(sp)
    800027e6:	e426                	sd	s1,8(sp)
    800027e8:	1000                	addi	s0,sp,32
    800027ea:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027ec:	eefff0ef          	jal	ra,800026da <argraw>
    800027f0:	e088                	sd	a0,0(s1)
}
    800027f2:	60e2                	ld	ra,24(sp)
    800027f4:	6442                	ld	s0,16(sp)
    800027f6:	64a2                	ld	s1,8(sp)
    800027f8:	6105                	addi	sp,sp,32
    800027fa:	8082                	ret

00000000800027fc <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800027fc:	7179                	addi	sp,sp,-48
    800027fe:	f406                	sd	ra,40(sp)
    80002800:	f022                	sd	s0,32(sp)
    80002802:	ec26                	sd	s1,24(sp)
    80002804:	e84a                	sd	s2,16(sp)
    80002806:	1800                	addi	s0,sp,48
    80002808:	84ae                	mv	s1,a1
    8000280a:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    8000280c:	fd840593          	addi	a1,s0,-40
    80002810:	fd1ff0ef          	jal	ra,800027e0 <argaddr>
  return fetchstr(addr, buf, max);
    80002814:	864a                	mv	a2,s2
    80002816:	85a6                	mv	a1,s1
    80002818:	fd843503          	ld	a0,-40(s0)
    8000281c:	f69ff0ef          	jal	ra,80002784 <fetchstr>
}
    80002820:	70a2                	ld	ra,40(sp)
    80002822:	7402                	ld	s0,32(sp)
    80002824:	64e2                	ld	s1,24(sp)
    80002826:	6942                	ld	s2,16(sp)
    80002828:	6145                	addi	sp,sp,48
    8000282a:	8082                	ret

000000008000282c <syscall>:
[SYS_trace]   "trace",
};

void
syscall(void)
{
    8000282c:	7179                	addi	sp,sp,-48
    8000282e:	f406                	sd	ra,40(sp)
    80002830:	f022                	sd	s0,32(sp)
    80002832:	ec26                	sd	s1,24(sp)
    80002834:	e84a                	sd	s2,16(sp)
    80002836:	e44e                	sd	s3,8(sp)
    80002838:	1800                	addi	s0,sp,48
  int num;
  struct proc *p = myproc();
    8000283a:	8a4ff0ef          	jal	ra,800018de <myproc>
    8000283e:	84aa                	mv	s1,a0
  num = p->trapframe->a7;
    80002840:	05853903          	ld	s2,88(a0)
    80002844:	0a893783          	ld	a5,168(s2)
    80002848:	0007899b          	sext.w	s3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    8000284c:	37fd                	addiw	a5,a5,-1
    8000284e:	4755                	li	a4,21
    80002850:	04f76663          	bltu	a4,a5,8000289c <syscall+0x70>
    80002854:	00399713          	slli	a4,s3,0x3
    80002858:	00005797          	auipc	a5,0x5
    8000285c:	c6878793          	addi	a5,a5,-920 # 800074c0 <syscalls>
    80002860:	97ba                	add	a5,a5,a4
    80002862:	639c                	ld	a5,0(a5)
    80002864:	cf85                	beqz	a5,8000289c <syscall+0x70>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002866:	9782                	jalr	a5
    80002868:	06a93823          	sd	a0,112(s2)

    //Added code to print the trace if a syscall is enabled
    if(p->tracemask & (1 << num)) {
    8000286c:	1684a783          	lw	a5,360(s1)
    80002870:	4137d7bb          	sraw	a5,a5,s3
    80002874:	8b85                	andi	a5,a5,1
    80002876:	c3a1                	beqz	a5,800028b6 <syscall+0x8a>
      printf("%d: syscall %s -> %d\n", p->pid, syscall_names[num], (int)p->trapframe->a0);
    80002878:	6cb8                	ld	a4,88(s1)
    8000287a:	098e                	slli	s3,s3,0x3
    8000287c:	00005797          	auipc	a5,0x5
    80002880:	c4478793          	addi	a5,a5,-956 # 800074c0 <syscalls>
    80002884:	99be                	add	s3,s3,a5
    80002886:	5b34                	lw	a3,112(a4)
    80002888:	0b89b603          	ld	a2,184(s3)
    8000288c:	588c                	lw	a1,48(s1)
    8000288e:	00005517          	auipc	a0,0x5
    80002892:	b4250513          	addi	a0,a0,-1214 # 800073d0 <states.0+0x158>
    80002896:	c0dfd0ef          	jal	ra,800004a2 <printf>
    8000289a:	a831                	j	800028b6 <syscall+0x8a>
    }
  } else {
    printf("%d %s: unknown sys call %d\n",
    8000289c:	86ce                	mv	a3,s3
    8000289e:	15848613          	addi	a2,s1,344
    800028a2:	588c                	lw	a1,48(s1)
    800028a4:	00005517          	auipc	a0,0x5
    800028a8:	b4450513          	addi	a0,a0,-1212 # 800073e8 <states.0+0x170>
    800028ac:	bf7fd0ef          	jal	ra,800004a2 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    800028b0:	6cbc                	ld	a5,88(s1)
    800028b2:	577d                	li	a4,-1
    800028b4:	fbb8                	sd	a4,112(a5)
  }
}
    800028b6:	70a2                	ld	ra,40(sp)
    800028b8:	7402                	ld	s0,32(sp)
    800028ba:	64e2                	ld	s1,24(sp)
    800028bc:	6942                	ld	s2,16(sp)
    800028be:	69a2                	ld	s3,8(sp)
    800028c0:	6145                	addi	sp,sp,48
    800028c2:	8082                	ret

00000000800028c4 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    800028c4:	1101                	addi	sp,sp,-32
    800028c6:	ec06                	sd	ra,24(sp)
    800028c8:	e822                	sd	s0,16(sp)
    800028ca:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800028cc:	fec40593          	addi	a1,s0,-20
    800028d0:	4501                	li	a0,0
    800028d2:	ef3ff0ef          	jal	ra,800027c4 <argint>
  exit(n);
    800028d6:	fec42503          	lw	a0,-20(s0)
    800028da:	ef6ff0ef          	jal	ra,80001fd0 <exit>
  return 0;  // not reached
}
    800028de:	4501                	li	a0,0
    800028e0:	60e2                	ld	ra,24(sp)
    800028e2:	6442                	ld	s0,16(sp)
    800028e4:	6105                	addi	sp,sp,32
    800028e6:	8082                	ret

00000000800028e8 <sys_getpid>:

uint64
sys_getpid(void)
{
    800028e8:	1141                	addi	sp,sp,-16
    800028ea:	e406                	sd	ra,8(sp)
    800028ec:	e022                	sd	s0,0(sp)
    800028ee:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800028f0:	feffe0ef          	jal	ra,800018de <myproc>
}
    800028f4:	5908                	lw	a0,48(a0)
    800028f6:	60a2                	ld	ra,8(sp)
    800028f8:	6402                	ld	s0,0(sp)
    800028fa:	0141                	addi	sp,sp,16
    800028fc:	8082                	ret

00000000800028fe <sys_fork>:

uint64
sys_fork(void)
{
    800028fe:	1141                	addi	sp,sp,-16
    80002900:	e406                	sd	ra,8(sp)
    80002902:	e022                	sd	s0,0(sp)
    80002904:	0800                	addi	s0,sp,16
  return fork();
    80002906:	b12ff0ef          	jal	ra,80001c18 <fork>
}
    8000290a:	60a2                	ld	ra,8(sp)
    8000290c:	6402                	ld	s0,0(sp)
    8000290e:	0141                	addi	sp,sp,16
    80002910:	8082                	ret

0000000080002912 <sys_wait>:

uint64
sys_wait(void)
{
    80002912:	1101                	addi	sp,sp,-32
    80002914:	ec06                	sd	ra,24(sp)
    80002916:	e822                	sd	s0,16(sp)
    80002918:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    8000291a:	fe840593          	addi	a1,s0,-24
    8000291e:	4501                	li	a0,0
    80002920:	ec1ff0ef          	jal	ra,800027e0 <argaddr>
  return wait(p);
    80002924:	fe843503          	ld	a0,-24(s0)
    80002928:	ffeff0ef          	jal	ra,80002126 <wait>
}
    8000292c:	60e2                	ld	ra,24(sp)
    8000292e:	6442                	ld	s0,16(sp)
    80002930:	6105                	addi	sp,sp,32
    80002932:	8082                	ret

0000000080002934 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002934:	7179                	addi	sp,sp,-48
    80002936:	f406                	sd	ra,40(sp)
    80002938:	f022                	sd	s0,32(sp)
    8000293a:	ec26                	sd	s1,24(sp)
    8000293c:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    8000293e:	fdc40593          	addi	a1,s0,-36
    80002942:	4501                	li	a0,0
    80002944:	e81ff0ef          	jal	ra,800027c4 <argint>
  addr = myproc()->sz;
    80002948:	f97fe0ef          	jal	ra,800018de <myproc>
    8000294c:	6524                	ld	s1,72(a0)
  if(n < 0) {
    8000294e:	fdc42503          	lw	a0,-36(s0)
    80002952:	00054f63          	bltz	a0,80002970 <sys_sbrk+0x3c>
      return -1;
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    myproc()->sz += n;
    80002956:	f89fe0ef          	jal	ra,800018de <myproc>
    8000295a:	fdc42703          	lw	a4,-36(s0)
    8000295e:	653c                	ld	a5,72(a0)
    80002960:	97ba                	add	a5,a5,a4
    80002962:	e53c                	sd	a5,72(a0)
  }
  return addr;
}
    80002964:	8526                	mv	a0,s1
    80002966:	70a2                	ld	ra,40(sp)
    80002968:	7402                	ld	s0,32(sp)
    8000296a:	64e2                	ld	s1,24(sp)
    8000296c:	6145                	addi	sp,sp,48
    8000296e:	8082                	ret
    if(shrinkproc(-n) < 0)
    80002970:	40a0053b          	negw	a0,a0
    80002974:	a6cff0ef          	jal	ra,80001be0 <shrinkproc>
    80002978:	fe0556e3          	bgez	a0,80002964 <sys_sbrk+0x30>
      return -1;
    8000297c:	54fd                	li	s1,-1
    8000297e:	b7dd                	j	80002964 <sys_sbrk+0x30>

0000000080002980 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002980:	7139                	addi	sp,sp,-64
    80002982:	fc06                	sd	ra,56(sp)
    80002984:	f822                	sd	s0,48(sp)
    80002986:	f426                	sd	s1,40(sp)
    80002988:	f04a                	sd	s2,32(sp)
    8000298a:	ec4e                	sd	s3,24(sp)
    8000298c:	0080                	addi	s0,sp,64
  backtrace(); //This line was added by Ashish CS23B099
    8000298e:	dfffd0ef          	jal	ra,8000078c <backtrace>
  int n;
  uint ticks0;

  argint(0, &n);
    80002992:	fcc40593          	addi	a1,s0,-52
    80002996:	4501                	li	a0,0
    80002998:	e2dff0ef          	jal	ra,800027c4 <argint>
  if(n < 0)
    8000299c:	fcc42783          	lw	a5,-52(s0)
    800029a0:	0607c563          	bltz	a5,80002a0a <sys_sleep+0x8a>
    n = 0;
  acquire(&tickslock);
    800029a4:	00013517          	auipc	a0,0x13
    800029a8:	16450513          	addi	a0,a0,356 # 80015b08 <tickslock>
    800029ac:	a9afe0ef          	jal	ra,80000c46 <acquire>
  ticks0 = ticks;
    800029b0:	00005917          	auipc	s2,0x5
    800029b4:	00092903          	lw	s2,0(s2) # 800079b0 <ticks>
  while(ticks - ticks0 < n){
    800029b8:	fcc42783          	lw	a5,-52(s0)
    800029bc:	cb8d                	beqz	a5,800029ee <sys_sleep+0x6e>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    800029be:	00013997          	auipc	s3,0x13
    800029c2:	14a98993          	addi	s3,s3,330 # 80015b08 <tickslock>
    800029c6:	00005497          	auipc	s1,0x5
    800029ca:	fea48493          	addi	s1,s1,-22 # 800079b0 <ticks>
    if(killed(myproc())){
    800029ce:	f11fe0ef          	jal	ra,800018de <myproc>
    800029d2:	f2aff0ef          	jal	ra,800020fc <killed>
    800029d6:	ed0d                	bnez	a0,80002a10 <sys_sleep+0x90>
    sleep(&ticks, &tickslock);
    800029d8:	85ce                	mv	a1,s3
    800029da:	8526                	mv	a0,s1
    800029dc:	ce8ff0ef          	jal	ra,80001ec4 <sleep>
  while(ticks - ticks0 < n){
    800029e0:	409c                	lw	a5,0(s1)
    800029e2:	412787bb          	subw	a5,a5,s2
    800029e6:	fcc42703          	lw	a4,-52(s0)
    800029ea:	fee7e2e3          	bltu	a5,a4,800029ce <sys_sleep+0x4e>
  }
  release(&tickslock);
    800029ee:	00013517          	auipc	a0,0x13
    800029f2:	11a50513          	addi	a0,a0,282 # 80015b08 <tickslock>
    800029f6:	ae8fe0ef          	jal	ra,80000cde <release>
  //printf("%d\n", *(int *)(0)); //This line was added by Ashish CS23B099
  return 0;
    800029fa:	4501                	li	a0,0
}
    800029fc:	70e2                	ld	ra,56(sp)
    800029fe:	7442                	ld	s0,48(sp)
    80002a00:	74a2                	ld	s1,40(sp)
    80002a02:	7902                	ld	s2,32(sp)
    80002a04:	69e2                	ld	s3,24(sp)
    80002a06:	6121                	addi	sp,sp,64
    80002a08:	8082                	ret
    n = 0;
    80002a0a:	fc042623          	sw	zero,-52(s0)
    80002a0e:	bf59                	j	800029a4 <sys_sleep+0x24>
      release(&tickslock);
    80002a10:	00013517          	auipc	a0,0x13
    80002a14:	0f850513          	addi	a0,a0,248 # 80015b08 <tickslock>
    80002a18:	ac6fe0ef          	jal	ra,80000cde <release>
      return -1;
    80002a1c:	557d                	li	a0,-1
    80002a1e:	bff9                	j	800029fc <sys_sleep+0x7c>

0000000080002a20 <sys_kill>:

uint64
sys_kill(void)
{
    80002a20:	1101                	addi	sp,sp,-32
    80002a22:	ec06                	sd	ra,24(sp)
    80002a24:	e822                	sd	s0,16(sp)
    80002a26:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002a28:	fec40593          	addi	a1,s0,-20
    80002a2c:	4501                	li	a0,0
    80002a2e:	d97ff0ef          	jal	ra,800027c4 <argint>
  return kill(pid);
    80002a32:	fec42503          	lw	a0,-20(s0)
    80002a36:	e3cff0ef          	jal	ra,80002072 <kill>
}
    80002a3a:	60e2                	ld	ra,24(sp)
    80002a3c:	6442                	ld	s0,16(sp)
    80002a3e:	6105                	addi	sp,sp,32
    80002a40:	8082                	ret

0000000080002a42 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002a42:	1101                	addi	sp,sp,-32
    80002a44:	ec06                	sd	ra,24(sp)
    80002a46:	e822                	sd	s0,16(sp)
    80002a48:	e426                	sd	s1,8(sp)
    80002a4a:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002a4c:	00013517          	auipc	a0,0x13
    80002a50:	0bc50513          	addi	a0,a0,188 # 80015b08 <tickslock>
    80002a54:	9f2fe0ef          	jal	ra,80000c46 <acquire>
  xticks = ticks;
    80002a58:	00005497          	auipc	s1,0x5
    80002a5c:	f584a483          	lw	s1,-168(s1) # 800079b0 <ticks>
  release(&tickslock);
    80002a60:	00013517          	auipc	a0,0x13
    80002a64:	0a850513          	addi	a0,a0,168 # 80015b08 <tickslock>
    80002a68:	a76fe0ef          	jal	ra,80000cde <release>
  return xticks;
}
    80002a6c:	02049513          	slli	a0,s1,0x20
    80002a70:	9101                	srli	a0,a0,0x20
    80002a72:	60e2                	ld	ra,24(sp)
    80002a74:	6442                	ld	s0,16(sp)
    80002a76:	64a2                	ld	s1,8(sp)
    80002a78:	6105                	addi	sp,sp,32
    80002a7a:	8082                	ret

0000000080002a7c <sys_trace>:

uint64
sys_trace(void){
    80002a7c:	1101                	addi	sp,sp,-32
    80002a7e:	ec06                	sd	ra,24(sp)
    80002a80:	e822                	sd	s0,16(sp)
    80002a82:	1000                	addi	s0,sp,32
  int mask;
  argint(0, &mask);
    80002a84:	fec40593          	addi	a1,s0,-20
    80002a88:	4501                	li	a0,0
    80002a8a:	d3bff0ef          	jal	ra,800027c4 <argint>
  myproc()->tracemask = mask;
    80002a8e:	e51fe0ef          	jal	ra,800018de <myproc>
    80002a92:	fec42783          	lw	a5,-20(s0)
    80002a96:	16f52423          	sw	a5,360(a0)
  return 0;
    80002a9a:	4501                	li	a0,0
    80002a9c:	60e2                	ld	ra,24(sp)
    80002a9e:	6442                	ld	s0,16(sp)
    80002aa0:	6105                	addi	sp,sp,32
    80002aa2:	8082                	ret

0000000080002aa4 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002aa4:	7179                	addi	sp,sp,-48
    80002aa6:	f406                	sd	ra,40(sp)
    80002aa8:	f022                	sd	s0,32(sp)
    80002aaa:	ec26                	sd	s1,24(sp)
    80002aac:	e84a                	sd	s2,16(sp)
    80002aae:	e44e                	sd	s3,8(sp)
    80002ab0:	e052                	sd	s4,0(sp)
    80002ab2:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002ab4:	00005597          	auipc	a1,0x5
    80002ab8:	b7c58593          	addi	a1,a1,-1156 # 80007630 <syscall_names+0xb8>
    80002abc:	00013517          	auipc	a0,0x13
    80002ac0:	06450513          	addi	a0,a0,100 # 80015b20 <bcache>
    80002ac4:	902fe0ef          	jal	ra,80000bc6 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002ac8:	0001b797          	auipc	a5,0x1b
    80002acc:	05878793          	addi	a5,a5,88 # 8001db20 <bcache+0x8000>
    80002ad0:	0001b717          	auipc	a4,0x1b
    80002ad4:	2b870713          	addi	a4,a4,696 # 8001dd88 <bcache+0x8268>
    80002ad8:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002adc:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002ae0:	00013497          	auipc	s1,0x13
    80002ae4:	05848493          	addi	s1,s1,88 # 80015b38 <bcache+0x18>
    b->next = bcache.head.next;
    80002ae8:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002aea:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002aec:	00005a17          	auipc	s4,0x5
    80002af0:	b4ca0a13          	addi	s4,s4,-1204 # 80007638 <syscall_names+0xc0>
    b->next = bcache.head.next;
    80002af4:	2b893783          	ld	a5,696(s2)
    80002af8:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002afa:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002afe:	85d2                	mv	a1,s4
    80002b00:	01048513          	addi	a0,s1,16
    80002b04:	22a010ef          	jal	ra,80003d2e <initsleeplock>
    bcache.head.next->prev = b;
    80002b08:	2b893783          	ld	a5,696(s2)
    80002b0c:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002b0e:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002b12:	45848493          	addi	s1,s1,1112
    80002b16:	fd349fe3          	bne	s1,s3,80002af4 <binit+0x50>
  }
}
    80002b1a:	70a2                	ld	ra,40(sp)
    80002b1c:	7402                	ld	s0,32(sp)
    80002b1e:	64e2                	ld	s1,24(sp)
    80002b20:	6942                	ld	s2,16(sp)
    80002b22:	69a2                	ld	s3,8(sp)
    80002b24:	6a02                	ld	s4,0(sp)
    80002b26:	6145                	addi	sp,sp,48
    80002b28:	8082                	ret

0000000080002b2a <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002b2a:	7179                	addi	sp,sp,-48
    80002b2c:	f406                	sd	ra,40(sp)
    80002b2e:	f022                	sd	s0,32(sp)
    80002b30:	ec26                	sd	s1,24(sp)
    80002b32:	e84a                	sd	s2,16(sp)
    80002b34:	e44e                	sd	s3,8(sp)
    80002b36:	1800                	addi	s0,sp,48
    80002b38:	892a                	mv	s2,a0
    80002b3a:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002b3c:	00013517          	auipc	a0,0x13
    80002b40:	fe450513          	addi	a0,a0,-28 # 80015b20 <bcache>
    80002b44:	902fe0ef          	jal	ra,80000c46 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002b48:	0001b497          	auipc	s1,0x1b
    80002b4c:	2904b483          	ld	s1,656(s1) # 8001ddd8 <bcache+0x82b8>
    80002b50:	0001b797          	auipc	a5,0x1b
    80002b54:	23878793          	addi	a5,a5,568 # 8001dd88 <bcache+0x8268>
    80002b58:	02f48b63          	beq	s1,a5,80002b8e <bread+0x64>
    80002b5c:	873e                	mv	a4,a5
    80002b5e:	a021                	j	80002b66 <bread+0x3c>
    80002b60:	68a4                	ld	s1,80(s1)
    80002b62:	02e48663          	beq	s1,a4,80002b8e <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002b66:	449c                	lw	a5,8(s1)
    80002b68:	ff279ce3          	bne	a5,s2,80002b60 <bread+0x36>
    80002b6c:	44dc                	lw	a5,12(s1)
    80002b6e:	ff3799e3          	bne	a5,s3,80002b60 <bread+0x36>
      b->refcnt++;
    80002b72:	40bc                	lw	a5,64(s1)
    80002b74:	2785                	addiw	a5,a5,1
    80002b76:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002b78:	00013517          	auipc	a0,0x13
    80002b7c:	fa850513          	addi	a0,a0,-88 # 80015b20 <bcache>
    80002b80:	95efe0ef          	jal	ra,80000cde <release>
      acquiresleep(&b->lock);
    80002b84:	01048513          	addi	a0,s1,16
    80002b88:	1dc010ef          	jal	ra,80003d64 <acquiresleep>
      return b;
    80002b8c:	a889                	j	80002bde <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002b8e:	0001b497          	auipc	s1,0x1b
    80002b92:	2424b483          	ld	s1,578(s1) # 8001ddd0 <bcache+0x82b0>
    80002b96:	0001b797          	auipc	a5,0x1b
    80002b9a:	1f278793          	addi	a5,a5,498 # 8001dd88 <bcache+0x8268>
    80002b9e:	00f48863          	beq	s1,a5,80002bae <bread+0x84>
    80002ba2:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002ba4:	40bc                	lw	a5,64(s1)
    80002ba6:	cb91                	beqz	a5,80002bba <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002ba8:	64a4                	ld	s1,72(s1)
    80002baa:	fee49de3          	bne	s1,a4,80002ba4 <bread+0x7a>
  panic("bget: no buffers");
    80002bae:	00005517          	auipc	a0,0x5
    80002bb2:	a9250513          	addi	a0,a0,-1390 # 80007640 <syscall_names+0xc8>
    80002bb6:	c2bfd0ef          	jal	ra,800007e0 <panic>
      b->dev = dev;
    80002bba:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002bbe:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002bc2:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002bc6:	4785                	li	a5,1
    80002bc8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002bca:	00013517          	auipc	a0,0x13
    80002bce:	f5650513          	addi	a0,a0,-170 # 80015b20 <bcache>
    80002bd2:	90cfe0ef          	jal	ra,80000cde <release>
      acquiresleep(&b->lock);
    80002bd6:	01048513          	addi	a0,s1,16
    80002bda:	18a010ef          	jal	ra,80003d64 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002bde:	409c                	lw	a5,0(s1)
    80002be0:	cb89                	beqz	a5,80002bf2 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002be2:	8526                	mv	a0,s1
    80002be4:	70a2                	ld	ra,40(sp)
    80002be6:	7402                	ld	s0,32(sp)
    80002be8:	64e2                	ld	s1,24(sp)
    80002bea:	6942                	ld	s2,16(sp)
    80002bec:	69a2                	ld	s3,8(sp)
    80002bee:	6145                	addi	sp,sp,48
    80002bf0:	8082                	ret
    virtio_disk_rw(b, 0);
    80002bf2:	4581                	li	a1,0
    80002bf4:	8526                	mv	a0,s1
    80002bf6:	0d7020ef          	jal	ra,800054cc <virtio_disk_rw>
    b->valid = 1;
    80002bfa:	4785                	li	a5,1
    80002bfc:	c09c                	sw	a5,0(s1)
  return b;
    80002bfe:	b7d5                	j	80002be2 <bread+0xb8>

0000000080002c00 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002c00:	1101                	addi	sp,sp,-32
    80002c02:	ec06                	sd	ra,24(sp)
    80002c04:	e822                	sd	s0,16(sp)
    80002c06:	e426                	sd	s1,8(sp)
    80002c08:	1000                	addi	s0,sp,32
    80002c0a:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002c0c:	0541                	addi	a0,a0,16
    80002c0e:	1d4010ef          	jal	ra,80003de2 <holdingsleep>
    80002c12:	c911                	beqz	a0,80002c26 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002c14:	4585                	li	a1,1
    80002c16:	8526                	mv	a0,s1
    80002c18:	0b5020ef          	jal	ra,800054cc <virtio_disk_rw>
}
    80002c1c:	60e2                	ld	ra,24(sp)
    80002c1e:	6442                	ld	s0,16(sp)
    80002c20:	64a2                	ld	s1,8(sp)
    80002c22:	6105                	addi	sp,sp,32
    80002c24:	8082                	ret
    panic("bwrite");
    80002c26:	00005517          	auipc	a0,0x5
    80002c2a:	a3250513          	addi	a0,a0,-1486 # 80007658 <syscall_names+0xe0>
    80002c2e:	bb3fd0ef          	jal	ra,800007e0 <panic>

0000000080002c32 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002c32:	1101                	addi	sp,sp,-32
    80002c34:	ec06                	sd	ra,24(sp)
    80002c36:	e822                	sd	s0,16(sp)
    80002c38:	e426                	sd	s1,8(sp)
    80002c3a:	e04a                	sd	s2,0(sp)
    80002c3c:	1000                	addi	s0,sp,32
    80002c3e:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002c40:	01050913          	addi	s2,a0,16
    80002c44:	854a                	mv	a0,s2
    80002c46:	19c010ef          	jal	ra,80003de2 <holdingsleep>
    80002c4a:	c13d                	beqz	a0,80002cb0 <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
    80002c4c:	854a                	mv	a0,s2
    80002c4e:	15c010ef          	jal	ra,80003daa <releasesleep>

  acquire(&bcache.lock);
    80002c52:	00013517          	auipc	a0,0x13
    80002c56:	ece50513          	addi	a0,a0,-306 # 80015b20 <bcache>
    80002c5a:	fedfd0ef          	jal	ra,80000c46 <acquire>
  b->refcnt--;
    80002c5e:	40bc                	lw	a5,64(s1)
    80002c60:	37fd                	addiw	a5,a5,-1
    80002c62:	0007871b          	sext.w	a4,a5
    80002c66:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002c68:	eb05                	bnez	a4,80002c98 <brelse+0x66>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002c6a:	68bc                	ld	a5,80(s1)
    80002c6c:	64b8                	ld	a4,72(s1)
    80002c6e:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    80002c70:	64bc                	ld	a5,72(s1)
    80002c72:	68b8                	ld	a4,80(s1)
    80002c74:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002c76:	0001b797          	auipc	a5,0x1b
    80002c7a:	eaa78793          	addi	a5,a5,-342 # 8001db20 <bcache+0x8000>
    80002c7e:	2b87b703          	ld	a4,696(a5)
    80002c82:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002c84:	0001b717          	auipc	a4,0x1b
    80002c88:	10470713          	addi	a4,a4,260 # 8001dd88 <bcache+0x8268>
    80002c8c:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002c8e:	2b87b703          	ld	a4,696(a5)
    80002c92:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002c94:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002c98:	00013517          	auipc	a0,0x13
    80002c9c:	e8850513          	addi	a0,a0,-376 # 80015b20 <bcache>
    80002ca0:	83efe0ef          	jal	ra,80000cde <release>
}
    80002ca4:	60e2                	ld	ra,24(sp)
    80002ca6:	6442                	ld	s0,16(sp)
    80002ca8:	64a2                	ld	s1,8(sp)
    80002caa:	6902                	ld	s2,0(sp)
    80002cac:	6105                	addi	sp,sp,32
    80002cae:	8082                	ret
    panic("brelse");
    80002cb0:	00005517          	auipc	a0,0x5
    80002cb4:	9b050513          	addi	a0,a0,-1616 # 80007660 <syscall_names+0xe8>
    80002cb8:	b29fd0ef          	jal	ra,800007e0 <panic>

0000000080002cbc <bpin>:

void
bpin(struct buf *b) {
    80002cbc:	1101                	addi	sp,sp,-32
    80002cbe:	ec06                	sd	ra,24(sp)
    80002cc0:	e822                	sd	s0,16(sp)
    80002cc2:	e426                	sd	s1,8(sp)
    80002cc4:	1000                	addi	s0,sp,32
    80002cc6:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002cc8:	00013517          	auipc	a0,0x13
    80002ccc:	e5850513          	addi	a0,a0,-424 # 80015b20 <bcache>
    80002cd0:	f77fd0ef          	jal	ra,80000c46 <acquire>
  b->refcnt++;
    80002cd4:	40bc                	lw	a5,64(s1)
    80002cd6:	2785                	addiw	a5,a5,1
    80002cd8:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002cda:	00013517          	auipc	a0,0x13
    80002cde:	e4650513          	addi	a0,a0,-442 # 80015b20 <bcache>
    80002ce2:	ffdfd0ef          	jal	ra,80000cde <release>
}
    80002ce6:	60e2                	ld	ra,24(sp)
    80002ce8:	6442                	ld	s0,16(sp)
    80002cea:	64a2                	ld	s1,8(sp)
    80002cec:	6105                	addi	sp,sp,32
    80002cee:	8082                	ret

0000000080002cf0 <bunpin>:

void
bunpin(struct buf *b) {
    80002cf0:	1101                	addi	sp,sp,-32
    80002cf2:	ec06                	sd	ra,24(sp)
    80002cf4:	e822                	sd	s0,16(sp)
    80002cf6:	e426                	sd	s1,8(sp)
    80002cf8:	1000                	addi	s0,sp,32
    80002cfa:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002cfc:	00013517          	auipc	a0,0x13
    80002d00:	e2450513          	addi	a0,a0,-476 # 80015b20 <bcache>
    80002d04:	f43fd0ef          	jal	ra,80000c46 <acquire>
  b->refcnt--;
    80002d08:	40bc                	lw	a5,64(s1)
    80002d0a:	37fd                	addiw	a5,a5,-1
    80002d0c:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002d0e:	00013517          	auipc	a0,0x13
    80002d12:	e1250513          	addi	a0,a0,-494 # 80015b20 <bcache>
    80002d16:	fc9fd0ef          	jal	ra,80000cde <release>
}
    80002d1a:	60e2                	ld	ra,24(sp)
    80002d1c:	6442                	ld	s0,16(sp)
    80002d1e:	64a2                	ld	s1,8(sp)
    80002d20:	6105                	addi	sp,sp,32
    80002d22:	8082                	ret

0000000080002d24 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002d24:	1101                	addi	sp,sp,-32
    80002d26:	ec06                	sd	ra,24(sp)
    80002d28:	e822                	sd	s0,16(sp)
    80002d2a:	e426                	sd	s1,8(sp)
    80002d2c:	e04a                	sd	s2,0(sp)
    80002d2e:	1000                	addi	s0,sp,32
    80002d30:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002d32:	00d5d59b          	srliw	a1,a1,0xd
    80002d36:	0001b797          	auipc	a5,0x1b
    80002d3a:	4c67a783          	lw	a5,1222(a5) # 8001e1fc <sb+0x1c>
    80002d3e:	9dbd                	addw	a1,a1,a5
    80002d40:	debff0ef          	jal	ra,80002b2a <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002d44:	0074f713          	andi	a4,s1,7
    80002d48:	4785                	li	a5,1
    80002d4a:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    80002d4e:	14ce                	slli	s1,s1,0x33
    80002d50:	90d9                	srli	s1,s1,0x36
    80002d52:	00950733          	add	a4,a0,s1
    80002d56:	05874703          	lbu	a4,88(a4)
    80002d5a:	00e7f6b3          	and	a3,a5,a4
    80002d5e:	c29d                	beqz	a3,80002d84 <bfree+0x60>
    80002d60:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002d62:	94aa                	add	s1,s1,a0
    80002d64:	fff7c793          	not	a5,a5
    80002d68:	8ff9                	and	a5,a5,a4
    80002d6a:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    80002d6e:	6ef000ef          	jal	ra,80003c5c <log_write>
  brelse(bp);
    80002d72:	854a                	mv	a0,s2
    80002d74:	ebfff0ef          	jal	ra,80002c32 <brelse>
}
    80002d78:	60e2                	ld	ra,24(sp)
    80002d7a:	6442                	ld	s0,16(sp)
    80002d7c:	64a2                	ld	s1,8(sp)
    80002d7e:	6902                	ld	s2,0(sp)
    80002d80:	6105                	addi	sp,sp,32
    80002d82:	8082                	ret
    panic("freeing free block");
    80002d84:	00005517          	auipc	a0,0x5
    80002d88:	8e450513          	addi	a0,a0,-1820 # 80007668 <syscall_names+0xf0>
    80002d8c:	a55fd0ef          	jal	ra,800007e0 <panic>

0000000080002d90 <balloc>:
{
    80002d90:	711d                	addi	sp,sp,-96
    80002d92:	ec86                	sd	ra,88(sp)
    80002d94:	e8a2                	sd	s0,80(sp)
    80002d96:	e4a6                	sd	s1,72(sp)
    80002d98:	e0ca                	sd	s2,64(sp)
    80002d9a:	fc4e                	sd	s3,56(sp)
    80002d9c:	f852                	sd	s4,48(sp)
    80002d9e:	f456                	sd	s5,40(sp)
    80002da0:	f05a                	sd	s6,32(sp)
    80002da2:	ec5e                	sd	s7,24(sp)
    80002da4:	e862                	sd	s8,16(sp)
    80002da6:	e466                	sd	s9,8(sp)
    80002da8:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80002daa:	0001b797          	auipc	a5,0x1b
    80002dae:	43a7a783          	lw	a5,1082(a5) # 8001e1e4 <sb+0x4>
    80002db2:	0e078163          	beqz	a5,80002e94 <balloc+0x104>
    80002db6:	8baa                	mv	s7,a0
    80002db8:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002dba:	0001bb17          	auipc	s6,0x1b
    80002dbe:	426b0b13          	addi	s6,s6,1062 # 8001e1e0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002dc2:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80002dc4:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002dc6:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002dc8:	6c89                	lui	s9,0x2
    80002dca:	a0b5                	j	80002e36 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002dcc:	974a                	add	a4,a4,s2
    80002dce:	8fd5                	or	a5,a5,a3
    80002dd0:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    80002dd4:	854a                	mv	a0,s2
    80002dd6:	687000ef          	jal	ra,80003c5c <log_write>
        brelse(bp);
    80002dda:	854a                	mv	a0,s2
    80002ddc:	e57ff0ef          	jal	ra,80002c32 <brelse>
  bp = bread(dev, bno);
    80002de0:	85a6                	mv	a1,s1
    80002de2:	855e                	mv	a0,s7
    80002de4:	d47ff0ef          	jal	ra,80002b2a <bread>
    80002de8:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002dea:	40000613          	li	a2,1024
    80002dee:	4581                	li	a1,0
    80002df0:	05850513          	addi	a0,a0,88
    80002df4:	f27fd0ef          	jal	ra,80000d1a <memset>
  log_write(bp);
    80002df8:	854a                	mv	a0,s2
    80002dfa:	663000ef          	jal	ra,80003c5c <log_write>
  brelse(bp);
    80002dfe:	854a                	mv	a0,s2
    80002e00:	e33ff0ef          	jal	ra,80002c32 <brelse>
}
    80002e04:	8526                	mv	a0,s1
    80002e06:	60e6                	ld	ra,88(sp)
    80002e08:	6446                	ld	s0,80(sp)
    80002e0a:	64a6                	ld	s1,72(sp)
    80002e0c:	6906                	ld	s2,64(sp)
    80002e0e:	79e2                	ld	s3,56(sp)
    80002e10:	7a42                	ld	s4,48(sp)
    80002e12:	7aa2                	ld	s5,40(sp)
    80002e14:	7b02                	ld	s6,32(sp)
    80002e16:	6be2                	ld	s7,24(sp)
    80002e18:	6c42                	ld	s8,16(sp)
    80002e1a:	6ca2                	ld	s9,8(sp)
    80002e1c:	6125                	addi	sp,sp,96
    80002e1e:	8082                	ret
    brelse(bp);
    80002e20:	854a                	mv	a0,s2
    80002e22:	e11ff0ef          	jal	ra,80002c32 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002e26:	015c87bb          	addw	a5,s9,s5
    80002e2a:	00078a9b          	sext.w	s5,a5
    80002e2e:	004b2703          	lw	a4,4(s6)
    80002e32:	06eaf163          	bgeu	s5,a4,80002e94 <balloc+0x104>
    bp = bread(dev, BBLOCK(b, sb));
    80002e36:	41fad79b          	sraiw	a5,s5,0x1f
    80002e3a:	0137d79b          	srliw	a5,a5,0x13
    80002e3e:	015787bb          	addw	a5,a5,s5
    80002e42:	40d7d79b          	sraiw	a5,a5,0xd
    80002e46:	01cb2583          	lw	a1,28(s6)
    80002e4a:	9dbd                	addw	a1,a1,a5
    80002e4c:	855e                	mv	a0,s7
    80002e4e:	cddff0ef          	jal	ra,80002b2a <bread>
    80002e52:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e54:	004b2503          	lw	a0,4(s6)
    80002e58:	000a849b          	sext.w	s1,s5
    80002e5c:	8662                	mv	a2,s8
    80002e5e:	fca4f1e3          	bgeu	s1,a0,80002e20 <balloc+0x90>
      m = 1 << (bi % 8);
    80002e62:	41f6579b          	sraiw	a5,a2,0x1f
    80002e66:	01d7d69b          	srliw	a3,a5,0x1d
    80002e6a:	00c6873b          	addw	a4,a3,a2
    80002e6e:	00777793          	andi	a5,a4,7
    80002e72:	9f95                	subw	a5,a5,a3
    80002e74:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002e78:	4037571b          	sraiw	a4,a4,0x3
    80002e7c:	00e906b3          	add	a3,s2,a4
    80002e80:	0586c683          	lbu	a3,88(a3) # 1058 <_entry-0x7fffefa8>
    80002e84:	00d7f5b3          	and	a1,a5,a3
    80002e88:	d1b1                	beqz	a1,80002dcc <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e8a:	2605                	addiw	a2,a2,1
    80002e8c:	2485                	addiw	s1,s1,1
    80002e8e:	fd4618e3          	bne	a2,s4,80002e5e <balloc+0xce>
    80002e92:	b779                	j	80002e20 <balloc+0x90>
  printf("balloc: out of blocks\n");
    80002e94:	00004517          	auipc	a0,0x4
    80002e98:	7ec50513          	addi	a0,a0,2028 # 80007680 <syscall_names+0x108>
    80002e9c:	e06fd0ef          	jal	ra,800004a2 <printf>
  return 0;
    80002ea0:	4481                	li	s1,0
    80002ea2:	b78d                	j	80002e04 <balloc+0x74>

0000000080002ea4 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002ea4:	7179                	addi	sp,sp,-48
    80002ea6:	f406                	sd	ra,40(sp)
    80002ea8:	f022                	sd	s0,32(sp)
    80002eaa:	ec26                	sd	s1,24(sp)
    80002eac:	e84a                	sd	s2,16(sp)
    80002eae:	e44e                	sd	s3,8(sp)
    80002eb0:	e052                	sd	s4,0(sp)
    80002eb2:	1800                	addi	s0,sp,48
    80002eb4:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002eb6:	47ad                	li	a5,11
    80002eb8:	02b7e663          	bltu	a5,a1,80002ee4 <bmap+0x40>
    if((addr = ip->addrs[bn]) == 0){
    80002ebc:	02059793          	slli	a5,a1,0x20
    80002ec0:	01e7d593          	srli	a1,a5,0x1e
    80002ec4:	00b504b3          	add	s1,a0,a1
    80002ec8:	0504a903          	lw	s2,80(s1)
    80002ecc:	06091663          	bnez	s2,80002f38 <bmap+0x94>
      addr = balloc(ip->dev);
    80002ed0:	4108                	lw	a0,0(a0)
    80002ed2:	ebfff0ef          	jal	ra,80002d90 <balloc>
    80002ed6:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002eda:	04090f63          	beqz	s2,80002f38 <bmap+0x94>
        return 0;
      ip->addrs[bn] = addr;
    80002ede:	0524a823          	sw	s2,80(s1)
    80002ee2:	a899                	j	80002f38 <bmap+0x94>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002ee4:	ff45849b          	addiw	s1,a1,-12
    80002ee8:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80002eec:	0ff00793          	li	a5,255
    80002ef0:	06e7eb63          	bltu	a5,a4,80002f66 <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002ef4:	08052903          	lw	s2,128(a0)
    80002ef8:	00091b63          	bnez	s2,80002f0e <bmap+0x6a>
      addr = balloc(ip->dev);
    80002efc:	4108                	lw	a0,0(a0)
    80002efe:	e93ff0ef          	jal	ra,80002d90 <balloc>
    80002f02:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002f06:	02090963          	beqz	s2,80002f38 <bmap+0x94>
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002f0a:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80002f0e:	85ca                	mv	a1,s2
    80002f10:	0009a503          	lw	a0,0(s3)
    80002f14:	c17ff0ef          	jal	ra,80002b2a <bread>
    80002f18:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002f1a:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002f1e:	02049713          	slli	a4,s1,0x20
    80002f22:	01e75593          	srli	a1,a4,0x1e
    80002f26:	00b784b3          	add	s1,a5,a1
    80002f2a:	0004a903          	lw	s2,0(s1)
    80002f2e:	00090e63          	beqz	s2,80002f4a <bmap+0xa6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002f32:	8552                	mv	a0,s4
    80002f34:	cffff0ef          	jal	ra,80002c32 <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    80002f38:	854a                	mv	a0,s2
    80002f3a:	70a2                	ld	ra,40(sp)
    80002f3c:	7402                	ld	s0,32(sp)
    80002f3e:	64e2                	ld	s1,24(sp)
    80002f40:	6942                	ld	s2,16(sp)
    80002f42:	69a2                	ld	s3,8(sp)
    80002f44:	6a02                	ld	s4,0(sp)
    80002f46:	6145                	addi	sp,sp,48
    80002f48:	8082                	ret
      addr = balloc(ip->dev);
    80002f4a:	0009a503          	lw	a0,0(s3)
    80002f4e:	e43ff0ef          	jal	ra,80002d90 <balloc>
    80002f52:	0005091b          	sext.w	s2,a0
      if(addr){
    80002f56:	fc090ee3          	beqz	s2,80002f32 <bmap+0x8e>
        a[bn] = addr;
    80002f5a:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80002f5e:	8552                	mv	a0,s4
    80002f60:	4fd000ef          	jal	ra,80003c5c <log_write>
    80002f64:	b7f9                	j	80002f32 <bmap+0x8e>
  panic("bmap: out of range");
    80002f66:	00004517          	auipc	a0,0x4
    80002f6a:	73250513          	addi	a0,a0,1842 # 80007698 <syscall_names+0x120>
    80002f6e:	873fd0ef          	jal	ra,800007e0 <panic>

0000000080002f72 <iget>:
{
    80002f72:	7179                	addi	sp,sp,-48
    80002f74:	f406                	sd	ra,40(sp)
    80002f76:	f022                	sd	s0,32(sp)
    80002f78:	ec26                	sd	s1,24(sp)
    80002f7a:	e84a                	sd	s2,16(sp)
    80002f7c:	e44e                	sd	s3,8(sp)
    80002f7e:	e052                	sd	s4,0(sp)
    80002f80:	1800                	addi	s0,sp,48
    80002f82:	89aa                	mv	s3,a0
    80002f84:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002f86:	0001b517          	auipc	a0,0x1b
    80002f8a:	27a50513          	addi	a0,a0,634 # 8001e200 <itable>
    80002f8e:	cb9fd0ef          	jal	ra,80000c46 <acquire>
  empty = 0;
    80002f92:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002f94:	0001b497          	auipc	s1,0x1b
    80002f98:	28448493          	addi	s1,s1,644 # 8001e218 <itable+0x18>
    80002f9c:	0001d697          	auipc	a3,0x1d
    80002fa0:	d0c68693          	addi	a3,a3,-756 # 8001fca8 <log>
    80002fa4:	a039                	j	80002fb2 <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002fa6:	02090963          	beqz	s2,80002fd8 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002faa:	08848493          	addi	s1,s1,136
    80002fae:	02d48863          	beq	s1,a3,80002fde <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80002fb2:	449c                	lw	a5,8(s1)
    80002fb4:	fef059e3          	blez	a5,80002fa6 <iget+0x34>
    80002fb8:	4098                	lw	a4,0(s1)
    80002fba:	ff3716e3          	bne	a4,s3,80002fa6 <iget+0x34>
    80002fbe:	40d8                	lw	a4,4(s1)
    80002fc0:	ff4713e3          	bne	a4,s4,80002fa6 <iget+0x34>
      ip->ref++;
    80002fc4:	2785                	addiw	a5,a5,1
    80002fc6:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002fc8:	0001b517          	auipc	a0,0x1b
    80002fcc:	23850513          	addi	a0,a0,568 # 8001e200 <itable>
    80002fd0:	d0ffd0ef          	jal	ra,80000cde <release>
      return ip;
    80002fd4:	8926                	mv	s2,s1
    80002fd6:	a02d                	j	80003000 <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002fd8:	fbe9                	bnez	a5,80002faa <iget+0x38>
    80002fda:	8926                	mv	s2,s1
    80002fdc:	b7f9                	j	80002faa <iget+0x38>
  if(empty == 0)
    80002fde:	02090a63          	beqz	s2,80003012 <iget+0xa0>
  ip->dev = dev;
    80002fe2:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002fe6:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002fea:	4785                	li	a5,1
    80002fec:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80002ff0:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80002ff4:	0001b517          	auipc	a0,0x1b
    80002ff8:	20c50513          	addi	a0,a0,524 # 8001e200 <itable>
    80002ffc:	ce3fd0ef          	jal	ra,80000cde <release>
}
    80003000:	854a                	mv	a0,s2
    80003002:	70a2                	ld	ra,40(sp)
    80003004:	7402                	ld	s0,32(sp)
    80003006:	64e2                	ld	s1,24(sp)
    80003008:	6942                	ld	s2,16(sp)
    8000300a:	69a2                	ld	s3,8(sp)
    8000300c:	6a02                	ld	s4,0(sp)
    8000300e:	6145                	addi	sp,sp,48
    80003010:	8082                	ret
    panic("iget: no inodes");
    80003012:	00004517          	auipc	a0,0x4
    80003016:	69e50513          	addi	a0,a0,1694 # 800076b0 <syscall_names+0x138>
    8000301a:	fc6fd0ef          	jal	ra,800007e0 <panic>

000000008000301e <fsinit>:
fsinit(int dev) {
    8000301e:	7179                	addi	sp,sp,-48
    80003020:	f406                	sd	ra,40(sp)
    80003022:	f022                	sd	s0,32(sp)
    80003024:	ec26                	sd	s1,24(sp)
    80003026:	e84a                	sd	s2,16(sp)
    80003028:	e44e                	sd	s3,8(sp)
    8000302a:	1800                	addi	s0,sp,48
    8000302c:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    8000302e:	4585                	li	a1,1
    80003030:	afbff0ef          	jal	ra,80002b2a <bread>
    80003034:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003036:	0001b997          	auipc	s3,0x1b
    8000303a:	1aa98993          	addi	s3,s3,426 # 8001e1e0 <sb>
    8000303e:	02000613          	li	a2,32
    80003042:	05850593          	addi	a1,a0,88
    80003046:	854e                	mv	a0,s3
    80003048:	d2ffd0ef          	jal	ra,80000d76 <memmove>
  brelse(bp);
    8000304c:	8526                	mv	a0,s1
    8000304e:	be5ff0ef          	jal	ra,80002c32 <brelse>
  if(sb.magic != FSMAGIC)
    80003052:	0009a703          	lw	a4,0(s3)
    80003056:	102037b7          	lui	a5,0x10203
    8000305a:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000305e:	02f71063          	bne	a4,a5,8000307e <fsinit+0x60>
  initlog(dev, &sb);
    80003062:	0001b597          	auipc	a1,0x1b
    80003066:	17e58593          	addi	a1,a1,382 # 8001e1e0 <sb>
    8000306a:	854a                	mv	a0,s2
    8000306c:	1db000ef          	jal	ra,80003a46 <initlog>
}
    80003070:	70a2                	ld	ra,40(sp)
    80003072:	7402                	ld	s0,32(sp)
    80003074:	64e2                	ld	s1,24(sp)
    80003076:	6942                	ld	s2,16(sp)
    80003078:	69a2                	ld	s3,8(sp)
    8000307a:	6145                	addi	sp,sp,48
    8000307c:	8082                	ret
    panic("invalid file system");
    8000307e:	00004517          	auipc	a0,0x4
    80003082:	64250513          	addi	a0,a0,1602 # 800076c0 <syscall_names+0x148>
    80003086:	f5afd0ef          	jal	ra,800007e0 <panic>

000000008000308a <iinit>:
{
    8000308a:	7179                	addi	sp,sp,-48
    8000308c:	f406                	sd	ra,40(sp)
    8000308e:	f022                	sd	s0,32(sp)
    80003090:	ec26                	sd	s1,24(sp)
    80003092:	e84a                	sd	s2,16(sp)
    80003094:	e44e                	sd	s3,8(sp)
    80003096:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003098:	00004597          	auipc	a1,0x4
    8000309c:	64058593          	addi	a1,a1,1600 # 800076d8 <syscall_names+0x160>
    800030a0:	0001b517          	auipc	a0,0x1b
    800030a4:	16050513          	addi	a0,a0,352 # 8001e200 <itable>
    800030a8:	b1ffd0ef          	jal	ra,80000bc6 <initlock>
  for(i = 0; i < NINODE; i++) {
    800030ac:	0001b497          	auipc	s1,0x1b
    800030b0:	17c48493          	addi	s1,s1,380 # 8001e228 <itable+0x28>
    800030b4:	0001d997          	auipc	s3,0x1d
    800030b8:	c0498993          	addi	s3,s3,-1020 # 8001fcb8 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800030bc:	00004917          	auipc	s2,0x4
    800030c0:	62490913          	addi	s2,s2,1572 # 800076e0 <syscall_names+0x168>
    800030c4:	85ca                	mv	a1,s2
    800030c6:	8526                	mv	a0,s1
    800030c8:	467000ef          	jal	ra,80003d2e <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800030cc:	08848493          	addi	s1,s1,136
    800030d0:	ff349ae3          	bne	s1,s3,800030c4 <iinit+0x3a>
}
    800030d4:	70a2                	ld	ra,40(sp)
    800030d6:	7402                	ld	s0,32(sp)
    800030d8:	64e2                	ld	s1,24(sp)
    800030da:	6942                	ld	s2,16(sp)
    800030dc:	69a2                	ld	s3,8(sp)
    800030de:	6145                	addi	sp,sp,48
    800030e0:	8082                	ret

00000000800030e2 <ialloc>:
{
    800030e2:	715d                	addi	sp,sp,-80
    800030e4:	e486                	sd	ra,72(sp)
    800030e6:	e0a2                	sd	s0,64(sp)
    800030e8:	fc26                	sd	s1,56(sp)
    800030ea:	f84a                	sd	s2,48(sp)
    800030ec:	f44e                	sd	s3,40(sp)
    800030ee:	f052                	sd	s4,32(sp)
    800030f0:	ec56                	sd	s5,24(sp)
    800030f2:	e85a                	sd	s6,16(sp)
    800030f4:	e45e                	sd	s7,8(sp)
    800030f6:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    800030f8:	0001b717          	auipc	a4,0x1b
    800030fc:	0f472703          	lw	a4,244(a4) # 8001e1ec <sb+0xc>
    80003100:	4785                	li	a5,1
    80003102:	04e7f663          	bgeu	a5,a4,8000314e <ialloc+0x6c>
    80003106:	8aaa                	mv	s5,a0
    80003108:	8bae                	mv	s7,a1
    8000310a:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    8000310c:	0001ba17          	auipc	s4,0x1b
    80003110:	0d4a0a13          	addi	s4,s4,212 # 8001e1e0 <sb>
    80003114:	00048b1b          	sext.w	s6,s1
    80003118:	0044d793          	srli	a5,s1,0x4
    8000311c:	018a2583          	lw	a1,24(s4)
    80003120:	9dbd                	addw	a1,a1,a5
    80003122:	8556                	mv	a0,s5
    80003124:	a07ff0ef          	jal	ra,80002b2a <bread>
    80003128:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000312a:	05850993          	addi	s3,a0,88
    8000312e:	00f4f793          	andi	a5,s1,15
    80003132:	079a                	slli	a5,a5,0x6
    80003134:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80003136:	00099783          	lh	a5,0(s3)
    8000313a:	cf85                	beqz	a5,80003172 <ialloc+0x90>
    brelse(bp);
    8000313c:	af7ff0ef          	jal	ra,80002c32 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80003140:	0485                	addi	s1,s1,1
    80003142:	00ca2703          	lw	a4,12(s4)
    80003146:	0004879b          	sext.w	a5,s1
    8000314a:	fce7e5e3          	bltu	a5,a4,80003114 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    8000314e:	00004517          	auipc	a0,0x4
    80003152:	59a50513          	addi	a0,a0,1434 # 800076e8 <syscall_names+0x170>
    80003156:	b4cfd0ef          	jal	ra,800004a2 <printf>
  return 0;
    8000315a:	4501                	li	a0,0
}
    8000315c:	60a6                	ld	ra,72(sp)
    8000315e:	6406                	ld	s0,64(sp)
    80003160:	74e2                	ld	s1,56(sp)
    80003162:	7942                	ld	s2,48(sp)
    80003164:	79a2                	ld	s3,40(sp)
    80003166:	7a02                	ld	s4,32(sp)
    80003168:	6ae2                	ld	s5,24(sp)
    8000316a:	6b42                	ld	s6,16(sp)
    8000316c:	6ba2                	ld	s7,8(sp)
    8000316e:	6161                	addi	sp,sp,80
    80003170:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003172:	04000613          	li	a2,64
    80003176:	4581                	li	a1,0
    80003178:	854e                	mv	a0,s3
    8000317a:	ba1fd0ef          	jal	ra,80000d1a <memset>
      dip->type = type;
    8000317e:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003182:	854a                	mv	a0,s2
    80003184:	2d9000ef          	jal	ra,80003c5c <log_write>
      brelse(bp);
    80003188:	854a                	mv	a0,s2
    8000318a:	aa9ff0ef          	jal	ra,80002c32 <brelse>
      return iget(dev, inum);
    8000318e:	85da                	mv	a1,s6
    80003190:	8556                	mv	a0,s5
    80003192:	de1ff0ef          	jal	ra,80002f72 <iget>
    80003196:	b7d9                	j	8000315c <ialloc+0x7a>

0000000080003198 <iupdate>:
{
    80003198:	1101                	addi	sp,sp,-32
    8000319a:	ec06                	sd	ra,24(sp)
    8000319c:	e822                	sd	s0,16(sp)
    8000319e:	e426                	sd	s1,8(sp)
    800031a0:	e04a                	sd	s2,0(sp)
    800031a2:	1000                	addi	s0,sp,32
    800031a4:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800031a6:	415c                	lw	a5,4(a0)
    800031a8:	0047d79b          	srliw	a5,a5,0x4
    800031ac:	0001b597          	auipc	a1,0x1b
    800031b0:	04c5a583          	lw	a1,76(a1) # 8001e1f8 <sb+0x18>
    800031b4:	9dbd                	addw	a1,a1,a5
    800031b6:	4108                	lw	a0,0(a0)
    800031b8:	973ff0ef          	jal	ra,80002b2a <bread>
    800031bc:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800031be:	05850793          	addi	a5,a0,88
    800031c2:	40c8                	lw	a0,4(s1)
    800031c4:	893d                	andi	a0,a0,15
    800031c6:	051a                	slli	a0,a0,0x6
    800031c8:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    800031ca:	04449703          	lh	a4,68(s1)
    800031ce:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    800031d2:	04649703          	lh	a4,70(s1)
    800031d6:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    800031da:	04849703          	lh	a4,72(s1)
    800031de:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    800031e2:	04a49703          	lh	a4,74(s1)
    800031e6:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    800031ea:	44f8                	lw	a4,76(s1)
    800031ec:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800031ee:	03400613          	li	a2,52
    800031f2:	05048593          	addi	a1,s1,80
    800031f6:	0531                	addi	a0,a0,12
    800031f8:	b7ffd0ef          	jal	ra,80000d76 <memmove>
  log_write(bp);
    800031fc:	854a                	mv	a0,s2
    800031fe:	25f000ef          	jal	ra,80003c5c <log_write>
  brelse(bp);
    80003202:	854a                	mv	a0,s2
    80003204:	a2fff0ef          	jal	ra,80002c32 <brelse>
}
    80003208:	60e2                	ld	ra,24(sp)
    8000320a:	6442                	ld	s0,16(sp)
    8000320c:	64a2                	ld	s1,8(sp)
    8000320e:	6902                	ld	s2,0(sp)
    80003210:	6105                	addi	sp,sp,32
    80003212:	8082                	ret

0000000080003214 <idup>:
{
    80003214:	1101                	addi	sp,sp,-32
    80003216:	ec06                	sd	ra,24(sp)
    80003218:	e822                	sd	s0,16(sp)
    8000321a:	e426                	sd	s1,8(sp)
    8000321c:	1000                	addi	s0,sp,32
    8000321e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003220:	0001b517          	auipc	a0,0x1b
    80003224:	fe050513          	addi	a0,a0,-32 # 8001e200 <itable>
    80003228:	a1ffd0ef          	jal	ra,80000c46 <acquire>
  ip->ref++;
    8000322c:	449c                	lw	a5,8(s1)
    8000322e:	2785                	addiw	a5,a5,1
    80003230:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003232:	0001b517          	auipc	a0,0x1b
    80003236:	fce50513          	addi	a0,a0,-50 # 8001e200 <itable>
    8000323a:	aa5fd0ef          	jal	ra,80000cde <release>
}
    8000323e:	8526                	mv	a0,s1
    80003240:	60e2                	ld	ra,24(sp)
    80003242:	6442                	ld	s0,16(sp)
    80003244:	64a2                	ld	s1,8(sp)
    80003246:	6105                	addi	sp,sp,32
    80003248:	8082                	ret

000000008000324a <ilock>:
{
    8000324a:	1101                	addi	sp,sp,-32
    8000324c:	ec06                	sd	ra,24(sp)
    8000324e:	e822                	sd	s0,16(sp)
    80003250:	e426                	sd	s1,8(sp)
    80003252:	e04a                	sd	s2,0(sp)
    80003254:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003256:	c105                	beqz	a0,80003276 <ilock+0x2c>
    80003258:	84aa                	mv	s1,a0
    8000325a:	451c                	lw	a5,8(a0)
    8000325c:	00f05d63          	blez	a5,80003276 <ilock+0x2c>
  acquiresleep(&ip->lock);
    80003260:	0541                	addi	a0,a0,16
    80003262:	303000ef          	jal	ra,80003d64 <acquiresleep>
  if(ip->valid == 0){
    80003266:	40bc                	lw	a5,64(s1)
    80003268:	cf89                	beqz	a5,80003282 <ilock+0x38>
}
    8000326a:	60e2                	ld	ra,24(sp)
    8000326c:	6442                	ld	s0,16(sp)
    8000326e:	64a2                	ld	s1,8(sp)
    80003270:	6902                	ld	s2,0(sp)
    80003272:	6105                	addi	sp,sp,32
    80003274:	8082                	ret
    panic("ilock");
    80003276:	00004517          	auipc	a0,0x4
    8000327a:	48a50513          	addi	a0,a0,1162 # 80007700 <syscall_names+0x188>
    8000327e:	d62fd0ef          	jal	ra,800007e0 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003282:	40dc                	lw	a5,4(s1)
    80003284:	0047d79b          	srliw	a5,a5,0x4
    80003288:	0001b597          	auipc	a1,0x1b
    8000328c:	f705a583          	lw	a1,-144(a1) # 8001e1f8 <sb+0x18>
    80003290:	9dbd                	addw	a1,a1,a5
    80003292:	4088                	lw	a0,0(s1)
    80003294:	897ff0ef          	jal	ra,80002b2a <bread>
    80003298:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000329a:	05850593          	addi	a1,a0,88
    8000329e:	40dc                	lw	a5,4(s1)
    800032a0:	8bbd                	andi	a5,a5,15
    800032a2:	079a                	slli	a5,a5,0x6
    800032a4:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800032a6:	00059783          	lh	a5,0(a1)
    800032aa:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800032ae:	00259783          	lh	a5,2(a1)
    800032b2:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800032b6:	00459783          	lh	a5,4(a1)
    800032ba:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800032be:	00659783          	lh	a5,6(a1)
    800032c2:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800032c6:	459c                	lw	a5,8(a1)
    800032c8:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800032ca:	03400613          	li	a2,52
    800032ce:	05b1                	addi	a1,a1,12
    800032d0:	05048513          	addi	a0,s1,80
    800032d4:	aa3fd0ef          	jal	ra,80000d76 <memmove>
    brelse(bp);
    800032d8:	854a                	mv	a0,s2
    800032da:	959ff0ef          	jal	ra,80002c32 <brelse>
    ip->valid = 1;
    800032de:	4785                	li	a5,1
    800032e0:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800032e2:	04449783          	lh	a5,68(s1)
    800032e6:	f3d1                	bnez	a5,8000326a <ilock+0x20>
      panic("ilock: no type");
    800032e8:	00004517          	auipc	a0,0x4
    800032ec:	42050513          	addi	a0,a0,1056 # 80007708 <syscall_names+0x190>
    800032f0:	cf0fd0ef          	jal	ra,800007e0 <panic>

00000000800032f4 <iunlock>:
{
    800032f4:	1101                	addi	sp,sp,-32
    800032f6:	ec06                	sd	ra,24(sp)
    800032f8:	e822                	sd	s0,16(sp)
    800032fa:	e426                	sd	s1,8(sp)
    800032fc:	e04a                	sd	s2,0(sp)
    800032fe:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003300:	c505                	beqz	a0,80003328 <iunlock+0x34>
    80003302:	84aa                	mv	s1,a0
    80003304:	01050913          	addi	s2,a0,16
    80003308:	854a                	mv	a0,s2
    8000330a:	2d9000ef          	jal	ra,80003de2 <holdingsleep>
    8000330e:	cd09                	beqz	a0,80003328 <iunlock+0x34>
    80003310:	449c                	lw	a5,8(s1)
    80003312:	00f05b63          	blez	a5,80003328 <iunlock+0x34>
  releasesleep(&ip->lock);
    80003316:	854a                	mv	a0,s2
    80003318:	293000ef          	jal	ra,80003daa <releasesleep>
}
    8000331c:	60e2                	ld	ra,24(sp)
    8000331e:	6442                	ld	s0,16(sp)
    80003320:	64a2                	ld	s1,8(sp)
    80003322:	6902                	ld	s2,0(sp)
    80003324:	6105                	addi	sp,sp,32
    80003326:	8082                	ret
    panic("iunlock");
    80003328:	00004517          	auipc	a0,0x4
    8000332c:	3f050513          	addi	a0,a0,1008 # 80007718 <syscall_names+0x1a0>
    80003330:	cb0fd0ef          	jal	ra,800007e0 <panic>

0000000080003334 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003334:	7179                	addi	sp,sp,-48
    80003336:	f406                	sd	ra,40(sp)
    80003338:	f022                	sd	s0,32(sp)
    8000333a:	ec26                	sd	s1,24(sp)
    8000333c:	e84a                	sd	s2,16(sp)
    8000333e:	e44e                	sd	s3,8(sp)
    80003340:	e052                	sd	s4,0(sp)
    80003342:	1800                	addi	s0,sp,48
    80003344:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003346:	05050493          	addi	s1,a0,80
    8000334a:	08050913          	addi	s2,a0,128
    8000334e:	a021                	j	80003356 <itrunc+0x22>
    80003350:	0491                	addi	s1,s1,4
    80003352:	01248b63          	beq	s1,s2,80003368 <itrunc+0x34>
    if(ip->addrs[i]){
    80003356:	408c                	lw	a1,0(s1)
    80003358:	dde5                	beqz	a1,80003350 <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    8000335a:	0009a503          	lw	a0,0(s3)
    8000335e:	9c7ff0ef          	jal	ra,80002d24 <bfree>
      ip->addrs[i] = 0;
    80003362:	0004a023          	sw	zero,0(s1)
    80003366:	b7ed                	j	80003350 <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003368:	0809a583          	lw	a1,128(s3)
    8000336c:	ed91                	bnez	a1,80003388 <itrunc+0x54>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000336e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003372:	854e                	mv	a0,s3
    80003374:	e25ff0ef          	jal	ra,80003198 <iupdate>
}
    80003378:	70a2                	ld	ra,40(sp)
    8000337a:	7402                	ld	s0,32(sp)
    8000337c:	64e2                	ld	s1,24(sp)
    8000337e:	6942                	ld	s2,16(sp)
    80003380:	69a2                	ld	s3,8(sp)
    80003382:	6a02                	ld	s4,0(sp)
    80003384:	6145                	addi	sp,sp,48
    80003386:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003388:	0009a503          	lw	a0,0(s3)
    8000338c:	f9eff0ef          	jal	ra,80002b2a <bread>
    80003390:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003392:	05850493          	addi	s1,a0,88
    80003396:	45850913          	addi	s2,a0,1112
    8000339a:	a021                	j	800033a2 <itrunc+0x6e>
    8000339c:	0491                	addi	s1,s1,4
    8000339e:	01248963          	beq	s1,s2,800033b0 <itrunc+0x7c>
      if(a[j])
    800033a2:	408c                	lw	a1,0(s1)
    800033a4:	dde5                	beqz	a1,8000339c <itrunc+0x68>
        bfree(ip->dev, a[j]);
    800033a6:	0009a503          	lw	a0,0(s3)
    800033aa:	97bff0ef          	jal	ra,80002d24 <bfree>
    800033ae:	b7fd                	j	8000339c <itrunc+0x68>
    brelse(bp);
    800033b0:	8552                	mv	a0,s4
    800033b2:	881ff0ef          	jal	ra,80002c32 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800033b6:	0809a583          	lw	a1,128(s3)
    800033ba:	0009a503          	lw	a0,0(s3)
    800033be:	967ff0ef          	jal	ra,80002d24 <bfree>
    ip->addrs[NDIRECT] = 0;
    800033c2:	0809a023          	sw	zero,128(s3)
    800033c6:	b765                	j	8000336e <itrunc+0x3a>

00000000800033c8 <iput>:
{
    800033c8:	1101                	addi	sp,sp,-32
    800033ca:	ec06                	sd	ra,24(sp)
    800033cc:	e822                	sd	s0,16(sp)
    800033ce:	e426                	sd	s1,8(sp)
    800033d0:	e04a                	sd	s2,0(sp)
    800033d2:	1000                	addi	s0,sp,32
    800033d4:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800033d6:	0001b517          	auipc	a0,0x1b
    800033da:	e2a50513          	addi	a0,a0,-470 # 8001e200 <itable>
    800033de:	869fd0ef          	jal	ra,80000c46 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800033e2:	4498                	lw	a4,8(s1)
    800033e4:	4785                	li	a5,1
    800033e6:	02f70163          	beq	a4,a5,80003408 <iput+0x40>
  ip->ref--;
    800033ea:	449c                	lw	a5,8(s1)
    800033ec:	37fd                	addiw	a5,a5,-1
    800033ee:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800033f0:	0001b517          	auipc	a0,0x1b
    800033f4:	e1050513          	addi	a0,a0,-496 # 8001e200 <itable>
    800033f8:	8e7fd0ef          	jal	ra,80000cde <release>
}
    800033fc:	60e2                	ld	ra,24(sp)
    800033fe:	6442                	ld	s0,16(sp)
    80003400:	64a2                	ld	s1,8(sp)
    80003402:	6902                	ld	s2,0(sp)
    80003404:	6105                	addi	sp,sp,32
    80003406:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003408:	40bc                	lw	a5,64(s1)
    8000340a:	d3e5                	beqz	a5,800033ea <iput+0x22>
    8000340c:	04a49783          	lh	a5,74(s1)
    80003410:	ffe9                	bnez	a5,800033ea <iput+0x22>
    acquiresleep(&ip->lock);
    80003412:	01048913          	addi	s2,s1,16
    80003416:	854a                	mv	a0,s2
    80003418:	14d000ef          	jal	ra,80003d64 <acquiresleep>
    release(&itable.lock);
    8000341c:	0001b517          	auipc	a0,0x1b
    80003420:	de450513          	addi	a0,a0,-540 # 8001e200 <itable>
    80003424:	8bbfd0ef          	jal	ra,80000cde <release>
    itrunc(ip);
    80003428:	8526                	mv	a0,s1
    8000342a:	f0bff0ef          	jal	ra,80003334 <itrunc>
    ip->type = 0;
    8000342e:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003432:	8526                	mv	a0,s1
    80003434:	d65ff0ef          	jal	ra,80003198 <iupdate>
    ip->valid = 0;
    80003438:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000343c:	854a                	mv	a0,s2
    8000343e:	16d000ef          	jal	ra,80003daa <releasesleep>
    acquire(&itable.lock);
    80003442:	0001b517          	auipc	a0,0x1b
    80003446:	dbe50513          	addi	a0,a0,-578 # 8001e200 <itable>
    8000344a:	ffcfd0ef          	jal	ra,80000c46 <acquire>
    8000344e:	bf71                	j	800033ea <iput+0x22>

0000000080003450 <iunlockput>:
{
    80003450:	1101                	addi	sp,sp,-32
    80003452:	ec06                	sd	ra,24(sp)
    80003454:	e822                	sd	s0,16(sp)
    80003456:	e426                	sd	s1,8(sp)
    80003458:	1000                	addi	s0,sp,32
    8000345a:	84aa                	mv	s1,a0
  iunlock(ip);
    8000345c:	e99ff0ef          	jal	ra,800032f4 <iunlock>
  iput(ip);
    80003460:	8526                	mv	a0,s1
    80003462:	f67ff0ef          	jal	ra,800033c8 <iput>
}
    80003466:	60e2                	ld	ra,24(sp)
    80003468:	6442                	ld	s0,16(sp)
    8000346a:	64a2                	ld	s1,8(sp)
    8000346c:	6105                	addi	sp,sp,32
    8000346e:	8082                	ret

0000000080003470 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003470:	1141                	addi	sp,sp,-16
    80003472:	e422                	sd	s0,8(sp)
    80003474:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003476:	411c                	lw	a5,0(a0)
    80003478:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000347a:	415c                	lw	a5,4(a0)
    8000347c:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000347e:	04451783          	lh	a5,68(a0)
    80003482:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003486:	04a51783          	lh	a5,74(a0)
    8000348a:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000348e:	04c56783          	lwu	a5,76(a0)
    80003492:	e99c                	sd	a5,16(a1)
}
    80003494:	6422                	ld	s0,8(sp)
    80003496:	0141                	addi	sp,sp,16
    80003498:	8082                	ret

000000008000349a <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    8000349a:	457c                	lw	a5,76(a0)
    8000349c:	0cd7ef63          	bltu	a5,a3,8000357a <readi+0xe0>
{
    800034a0:	7159                	addi	sp,sp,-112
    800034a2:	f486                	sd	ra,104(sp)
    800034a4:	f0a2                	sd	s0,96(sp)
    800034a6:	eca6                	sd	s1,88(sp)
    800034a8:	e8ca                	sd	s2,80(sp)
    800034aa:	e4ce                	sd	s3,72(sp)
    800034ac:	e0d2                	sd	s4,64(sp)
    800034ae:	fc56                	sd	s5,56(sp)
    800034b0:	f85a                	sd	s6,48(sp)
    800034b2:	f45e                	sd	s7,40(sp)
    800034b4:	f062                	sd	s8,32(sp)
    800034b6:	ec66                	sd	s9,24(sp)
    800034b8:	e86a                	sd	s10,16(sp)
    800034ba:	e46e                	sd	s11,8(sp)
    800034bc:	1880                	addi	s0,sp,112
    800034be:	8b2a                	mv	s6,a0
    800034c0:	8bae                	mv	s7,a1
    800034c2:	8a32                	mv	s4,a2
    800034c4:	84b6                	mv	s1,a3
    800034c6:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    800034c8:	9f35                	addw	a4,a4,a3
    return 0;
    800034ca:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800034cc:	08d76663          	bltu	a4,a3,80003558 <readi+0xbe>
  if(off + n > ip->size)
    800034d0:	00e7f463          	bgeu	a5,a4,800034d8 <readi+0x3e>
    n = ip->size - off;
    800034d4:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800034d8:	080a8f63          	beqz	s5,80003576 <readi+0xdc>
    800034dc:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800034de:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800034e2:	5c7d                	li	s8,-1
    800034e4:	a80d                	j	80003516 <readi+0x7c>
    800034e6:	020d1d93          	slli	s11,s10,0x20
    800034ea:	020ddd93          	srli	s11,s11,0x20
    800034ee:	05890793          	addi	a5,s2,88
    800034f2:	86ee                	mv	a3,s11
    800034f4:	963e                	add	a2,a2,a5
    800034f6:	85d2                	mv	a1,s4
    800034f8:	855e                	mv	a0,s7
    800034fa:	d27fe0ef          	jal	ra,80002220 <either_copyout>
    800034fe:	05850763          	beq	a0,s8,8000354c <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003502:	854a                	mv	a0,s2
    80003504:	f2eff0ef          	jal	ra,80002c32 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003508:	013d09bb          	addw	s3,s10,s3
    8000350c:	009d04bb          	addw	s1,s10,s1
    80003510:	9a6e                	add	s4,s4,s11
    80003512:	0559f163          	bgeu	s3,s5,80003554 <readi+0xba>
    uint addr = bmap(ip, off/BSIZE);
    80003516:	00a4d59b          	srliw	a1,s1,0xa
    8000351a:	855a                	mv	a0,s6
    8000351c:	989ff0ef          	jal	ra,80002ea4 <bmap>
    80003520:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003524:	c985                	beqz	a1,80003554 <readi+0xba>
    bp = bread(ip->dev, addr);
    80003526:	000b2503          	lw	a0,0(s6)
    8000352a:	e00ff0ef          	jal	ra,80002b2a <bread>
    8000352e:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003530:	3ff4f613          	andi	a2,s1,1023
    80003534:	40cc87bb          	subw	a5,s9,a2
    80003538:	413a873b          	subw	a4,s5,s3
    8000353c:	8d3e                	mv	s10,a5
    8000353e:	2781                	sext.w	a5,a5
    80003540:	0007069b          	sext.w	a3,a4
    80003544:	faf6f1e3          	bgeu	a3,a5,800034e6 <readi+0x4c>
    80003548:	8d3a                	mv	s10,a4
    8000354a:	bf71                	j	800034e6 <readi+0x4c>
      brelse(bp);
    8000354c:	854a                	mv	a0,s2
    8000354e:	ee4ff0ef          	jal	ra,80002c32 <brelse>
      tot = -1;
    80003552:	59fd                	li	s3,-1
  }
  return tot;
    80003554:	0009851b          	sext.w	a0,s3
}
    80003558:	70a6                	ld	ra,104(sp)
    8000355a:	7406                	ld	s0,96(sp)
    8000355c:	64e6                	ld	s1,88(sp)
    8000355e:	6946                	ld	s2,80(sp)
    80003560:	69a6                	ld	s3,72(sp)
    80003562:	6a06                	ld	s4,64(sp)
    80003564:	7ae2                	ld	s5,56(sp)
    80003566:	7b42                	ld	s6,48(sp)
    80003568:	7ba2                	ld	s7,40(sp)
    8000356a:	7c02                	ld	s8,32(sp)
    8000356c:	6ce2                	ld	s9,24(sp)
    8000356e:	6d42                	ld	s10,16(sp)
    80003570:	6da2                	ld	s11,8(sp)
    80003572:	6165                	addi	sp,sp,112
    80003574:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003576:	89d6                	mv	s3,s5
    80003578:	bff1                	j	80003554 <readi+0xba>
    return 0;
    8000357a:	4501                	li	a0,0
}
    8000357c:	8082                	ret

000000008000357e <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    8000357e:	457c                	lw	a5,76(a0)
    80003580:	0ed7ea63          	bltu	a5,a3,80003674 <writei+0xf6>
{
    80003584:	7159                	addi	sp,sp,-112
    80003586:	f486                	sd	ra,104(sp)
    80003588:	f0a2                	sd	s0,96(sp)
    8000358a:	eca6                	sd	s1,88(sp)
    8000358c:	e8ca                	sd	s2,80(sp)
    8000358e:	e4ce                	sd	s3,72(sp)
    80003590:	e0d2                	sd	s4,64(sp)
    80003592:	fc56                	sd	s5,56(sp)
    80003594:	f85a                	sd	s6,48(sp)
    80003596:	f45e                	sd	s7,40(sp)
    80003598:	f062                	sd	s8,32(sp)
    8000359a:	ec66                	sd	s9,24(sp)
    8000359c:	e86a                	sd	s10,16(sp)
    8000359e:	e46e                	sd	s11,8(sp)
    800035a0:	1880                	addi	s0,sp,112
    800035a2:	8aaa                	mv	s5,a0
    800035a4:	8bae                	mv	s7,a1
    800035a6:	8a32                	mv	s4,a2
    800035a8:	8936                	mv	s2,a3
    800035aa:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800035ac:	00e687bb          	addw	a5,a3,a4
    800035b0:	0cd7e463          	bltu	a5,a3,80003678 <writei+0xfa>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800035b4:	00043737          	lui	a4,0x43
    800035b8:	0cf76263          	bltu	a4,a5,8000367c <writei+0xfe>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800035bc:	0a0b0a63          	beqz	s6,80003670 <writei+0xf2>
    800035c0:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800035c2:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800035c6:	5c7d                	li	s8,-1
    800035c8:	a825                	j	80003600 <writei+0x82>
    800035ca:	020d1d93          	slli	s11,s10,0x20
    800035ce:	020ddd93          	srli	s11,s11,0x20
    800035d2:	05848793          	addi	a5,s1,88
    800035d6:	86ee                	mv	a3,s11
    800035d8:	8652                	mv	a2,s4
    800035da:	85de                	mv	a1,s7
    800035dc:	953e                	add	a0,a0,a5
    800035de:	c8dfe0ef          	jal	ra,8000226a <either_copyin>
    800035e2:	05850a63          	beq	a0,s8,80003636 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    800035e6:	8526                	mv	a0,s1
    800035e8:	674000ef          	jal	ra,80003c5c <log_write>
    brelse(bp);
    800035ec:	8526                	mv	a0,s1
    800035ee:	e44ff0ef          	jal	ra,80002c32 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800035f2:	013d09bb          	addw	s3,s10,s3
    800035f6:	012d093b          	addw	s2,s10,s2
    800035fa:	9a6e                	add	s4,s4,s11
    800035fc:	0569f063          	bgeu	s3,s6,8000363c <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003600:	00a9559b          	srliw	a1,s2,0xa
    80003604:	8556                	mv	a0,s5
    80003606:	89fff0ef          	jal	ra,80002ea4 <bmap>
    8000360a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    8000360e:	c59d                	beqz	a1,8000363c <writei+0xbe>
    bp = bread(ip->dev, addr);
    80003610:	000aa503          	lw	a0,0(s5)
    80003614:	d16ff0ef          	jal	ra,80002b2a <bread>
    80003618:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000361a:	3ff97513          	andi	a0,s2,1023
    8000361e:	40ac87bb          	subw	a5,s9,a0
    80003622:	413b073b          	subw	a4,s6,s3
    80003626:	8d3e                	mv	s10,a5
    80003628:	2781                	sext.w	a5,a5
    8000362a:	0007069b          	sext.w	a3,a4
    8000362e:	f8f6fee3          	bgeu	a3,a5,800035ca <writei+0x4c>
    80003632:	8d3a                	mv	s10,a4
    80003634:	bf59                	j	800035ca <writei+0x4c>
      brelse(bp);
    80003636:	8526                	mv	a0,s1
    80003638:	dfaff0ef          	jal	ra,80002c32 <brelse>
  }

  if(off > ip->size)
    8000363c:	04caa783          	lw	a5,76(s5)
    80003640:	0127f463          	bgeu	a5,s2,80003648 <writei+0xca>
    ip->size = off;
    80003644:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003648:	8556                	mv	a0,s5
    8000364a:	b4fff0ef          	jal	ra,80003198 <iupdate>

  return tot;
    8000364e:	0009851b          	sext.w	a0,s3
}
    80003652:	70a6                	ld	ra,104(sp)
    80003654:	7406                	ld	s0,96(sp)
    80003656:	64e6                	ld	s1,88(sp)
    80003658:	6946                	ld	s2,80(sp)
    8000365a:	69a6                	ld	s3,72(sp)
    8000365c:	6a06                	ld	s4,64(sp)
    8000365e:	7ae2                	ld	s5,56(sp)
    80003660:	7b42                	ld	s6,48(sp)
    80003662:	7ba2                	ld	s7,40(sp)
    80003664:	7c02                	ld	s8,32(sp)
    80003666:	6ce2                	ld	s9,24(sp)
    80003668:	6d42                	ld	s10,16(sp)
    8000366a:	6da2                	ld	s11,8(sp)
    8000366c:	6165                	addi	sp,sp,112
    8000366e:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003670:	89da                	mv	s3,s6
    80003672:	bfd9                	j	80003648 <writei+0xca>
    return -1;
    80003674:	557d                	li	a0,-1
}
    80003676:	8082                	ret
    return -1;
    80003678:	557d                	li	a0,-1
    8000367a:	bfe1                	j	80003652 <writei+0xd4>
    return -1;
    8000367c:	557d                	li	a0,-1
    8000367e:	bfd1                	j	80003652 <writei+0xd4>

0000000080003680 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003680:	1141                	addi	sp,sp,-16
    80003682:	e406                	sd	ra,8(sp)
    80003684:	e022                	sd	s0,0(sp)
    80003686:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003688:	4639                	li	a2,14
    8000368a:	f5cfd0ef          	jal	ra,80000de6 <strncmp>
}
    8000368e:	60a2                	ld	ra,8(sp)
    80003690:	6402                	ld	s0,0(sp)
    80003692:	0141                	addi	sp,sp,16
    80003694:	8082                	ret

0000000080003696 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003696:	7139                	addi	sp,sp,-64
    80003698:	fc06                	sd	ra,56(sp)
    8000369a:	f822                	sd	s0,48(sp)
    8000369c:	f426                	sd	s1,40(sp)
    8000369e:	f04a                	sd	s2,32(sp)
    800036a0:	ec4e                	sd	s3,24(sp)
    800036a2:	e852                	sd	s4,16(sp)
    800036a4:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    800036a6:	04451703          	lh	a4,68(a0)
    800036aa:	4785                	li	a5,1
    800036ac:	00f71a63          	bne	a4,a5,800036c0 <dirlookup+0x2a>
    800036b0:	892a                	mv	s2,a0
    800036b2:	89ae                	mv	s3,a1
    800036b4:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    800036b6:	457c                	lw	a5,76(a0)
    800036b8:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    800036ba:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    800036bc:	e39d                	bnez	a5,800036e2 <dirlookup+0x4c>
    800036be:	a095                	j	80003722 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    800036c0:	00004517          	auipc	a0,0x4
    800036c4:	06050513          	addi	a0,a0,96 # 80007720 <syscall_names+0x1a8>
    800036c8:	918fd0ef          	jal	ra,800007e0 <panic>
      panic("dirlookup read");
    800036cc:	00004517          	auipc	a0,0x4
    800036d0:	06c50513          	addi	a0,a0,108 # 80007738 <syscall_names+0x1c0>
    800036d4:	90cfd0ef          	jal	ra,800007e0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800036d8:	24c1                	addiw	s1,s1,16
    800036da:	04c92783          	lw	a5,76(s2)
    800036de:	04f4f163          	bgeu	s1,a5,80003720 <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800036e2:	4741                	li	a4,16
    800036e4:	86a6                	mv	a3,s1
    800036e6:	fc040613          	addi	a2,s0,-64
    800036ea:	4581                	li	a1,0
    800036ec:	854a                	mv	a0,s2
    800036ee:	dadff0ef          	jal	ra,8000349a <readi>
    800036f2:	47c1                	li	a5,16
    800036f4:	fcf51ce3          	bne	a0,a5,800036cc <dirlookup+0x36>
    if(de.inum == 0)
    800036f8:	fc045783          	lhu	a5,-64(s0)
    800036fc:	dff1                	beqz	a5,800036d8 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    800036fe:	fc240593          	addi	a1,s0,-62
    80003702:	854e                	mv	a0,s3
    80003704:	f7dff0ef          	jal	ra,80003680 <namecmp>
    80003708:	f961                	bnez	a0,800036d8 <dirlookup+0x42>
      if(poff)
    8000370a:	000a0463          	beqz	s4,80003712 <dirlookup+0x7c>
        *poff = off;
    8000370e:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003712:	fc045583          	lhu	a1,-64(s0)
    80003716:	00092503          	lw	a0,0(s2)
    8000371a:	859ff0ef          	jal	ra,80002f72 <iget>
    8000371e:	a011                	j	80003722 <dirlookup+0x8c>
  return 0;
    80003720:	4501                	li	a0,0
}
    80003722:	70e2                	ld	ra,56(sp)
    80003724:	7442                	ld	s0,48(sp)
    80003726:	74a2                	ld	s1,40(sp)
    80003728:	7902                	ld	s2,32(sp)
    8000372a:	69e2                	ld	s3,24(sp)
    8000372c:	6a42                	ld	s4,16(sp)
    8000372e:	6121                	addi	sp,sp,64
    80003730:	8082                	ret

0000000080003732 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003732:	711d                	addi	sp,sp,-96
    80003734:	ec86                	sd	ra,88(sp)
    80003736:	e8a2                	sd	s0,80(sp)
    80003738:	e4a6                	sd	s1,72(sp)
    8000373a:	e0ca                	sd	s2,64(sp)
    8000373c:	fc4e                	sd	s3,56(sp)
    8000373e:	f852                	sd	s4,48(sp)
    80003740:	f456                	sd	s5,40(sp)
    80003742:	f05a                	sd	s6,32(sp)
    80003744:	ec5e                	sd	s7,24(sp)
    80003746:	e862                	sd	s8,16(sp)
    80003748:	e466                	sd	s9,8(sp)
    8000374a:	1080                	addi	s0,sp,96
    8000374c:	84aa                	mv	s1,a0
    8000374e:	8aae                	mv	s5,a1
    80003750:	8a32                	mv	s4,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003752:	00054703          	lbu	a4,0(a0)
    80003756:	02f00793          	li	a5,47
    8000375a:	00f70f63          	beq	a4,a5,80003778 <namex+0x46>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    8000375e:	980fe0ef          	jal	ra,800018de <myproc>
    80003762:	15053503          	ld	a0,336(a0)
    80003766:	aafff0ef          	jal	ra,80003214 <idup>
    8000376a:	89aa                	mv	s3,a0
  while(*path == '/')
    8000376c:	02f00913          	li	s2,47
  len = path - s;
    80003770:	4b01                	li	s6,0
  if(len >= DIRSIZ)
    80003772:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003774:	4b85                	li	s7,1
    80003776:	a861                	j	8000380e <namex+0xdc>
    ip = iget(ROOTDEV, ROOTINO);
    80003778:	4585                	li	a1,1
    8000377a:	4505                	li	a0,1
    8000377c:	ff6ff0ef          	jal	ra,80002f72 <iget>
    80003780:	89aa                	mv	s3,a0
    80003782:	b7ed                	j	8000376c <namex+0x3a>
      iunlockput(ip);
    80003784:	854e                	mv	a0,s3
    80003786:	ccbff0ef          	jal	ra,80003450 <iunlockput>
      return 0;
    8000378a:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    8000378c:	854e                	mv	a0,s3
    8000378e:	60e6                	ld	ra,88(sp)
    80003790:	6446                	ld	s0,80(sp)
    80003792:	64a6                	ld	s1,72(sp)
    80003794:	6906                	ld	s2,64(sp)
    80003796:	79e2                	ld	s3,56(sp)
    80003798:	7a42                	ld	s4,48(sp)
    8000379a:	7aa2                	ld	s5,40(sp)
    8000379c:	7b02                	ld	s6,32(sp)
    8000379e:	6be2                	ld	s7,24(sp)
    800037a0:	6c42                	ld	s8,16(sp)
    800037a2:	6ca2                	ld	s9,8(sp)
    800037a4:	6125                	addi	sp,sp,96
    800037a6:	8082                	ret
      iunlock(ip);
    800037a8:	854e                	mv	a0,s3
    800037aa:	b4bff0ef          	jal	ra,800032f4 <iunlock>
      return ip;
    800037ae:	bff9                	j	8000378c <namex+0x5a>
      iunlockput(ip);
    800037b0:	854e                	mv	a0,s3
    800037b2:	c9fff0ef          	jal	ra,80003450 <iunlockput>
      return 0;
    800037b6:	89e6                	mv	s3,s9
    800037b8:	bfd1                	j	8000378c <namex+0x5a>
  len = path - s;
    800037ba:	40b48633          	sub	a2,s1,a1
    800037be:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    800037c2:	079c5c63          	bge	s8,s9,8000383a <namex+0x108>
    memmove(name, s, DIRSIZ);
    800037c6:	4639                	li	a2,14
    800037c8:	8552                	mv	a0,s4
    800037ca:	dacfd0ef          	jal	ra,80000d76 <memmove>
  while(*path == '/')
    800037ce:	0004c783          	lbu	a5,0(s1)
    800037d2:	01279763          	bne	a5,s2,800037e0 <namex+0xae>
    path++;
    800037d6:	0485                	addi	s1,s1,1
  while(*path == '/')
    800037d8:	0004c783          	lbu	a5,0(s1)
    800037dc:	ff278de3          	beq	a5,s2,800037d6 <namex+0xa4>
    ilock(ip);
    800037e0:	854e                	mv	a0,s3
    800037e2:	a69ff0ef          	jal	ra,8000324a <ilock>
    if(ip->type != T_DIR){
    800037e6:	04499783          	lh	a5,68(s3)
    800037ea:	f9779de3          	bne	a5,s7,80003784 <namex+0x52>
    if(nameiparent && *path == '\0'){
    800037ee:	000a8563          	beqz	s5,800037f8 <namex+0xc6>
    800037f2:	0004c783          	lbu	a5,0(s1)
    800037f6:	dbcd                	beqz	a5,800037a8 <namex+0x76>
    if((next = dirlookup(ip, name, 0)) == 0){
    800037f8:	865a                	mv	a2,s6
    800037fa:	85d2                	mv	a1,s4
    800037fc:	854e                	mv	a0,s3
    800037fe:	e99ff0ef          	jal	ra,80003696 <dirlookup>
    80003802:	8caa                	mv	s9,a0
    80003804:	d555                	beqz	a0,800037b0 <namex+0x7e>
    iunlockput(ip);
    80003806:	854e                	mv	a0,s3
    80003808:	c49ff0ef          	jal	ra,80003450 <iunlockput>
    ip = next;
    8000380c:	89e6                	mv	s3,s9
  while(*path == '/')
    8000380e:	0004c783          	lbu	a5,0(s1)
    80003812:	05279363          	bne	a5,s2,80003858 <namex+0x126>
    path++;
    80003816:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003818:	0004c783          	lbu	a5,0(s1)
    8000381c:	ff278de3          	beq	a5,s2,80003816 <namex+0xe4>
  if(*path == 0)
    80003820:	c78d                	beqz	a5,8000384a <namex+0x118>
    path++;
    80003822:	85a6                	mv	a1,s1
  len = path - s;
    80003824:	8cda                	mv	s9,s6
    80003826:	865a                	mv	a2,s6
  while(*path != '/' && *path != 0)
    80003828:	01278963          	beq	a5,s2,8000383a <namex+0x108>
    8000382c:	d7d9                	beqz	a5,800037ba <namex+0x88>
    path++;
    8000382e:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80003830:	0004c783          	lbu	a5,0(s1)
    80003834:	ff279ce3          	bne	a5,s2,8000382c <namex+0xfa>
    80003838:	b749                	j	800037ba <namex+0x88>
    memmove(name, s, len);
    8000383a:	2601                	sext.w	a2,a2
    8000383c:	8552                	mv	a0,s4
    8000383e:	d38fd0ef          	jal	ra,80000d76 <memmove>
    name[len] = 0;
    80003842:	9cd2                	add	s9,s9,s4
    80003844:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003848:	b759                	j	800037ce <namex+0x9c>
  if(nameiparent){
    8000384a:	f40a81e3          	beqz	s5,8000378c <namex+0x5a>
    iput(ip);
    8000384e:	854e                	mv	a0,s3
    80003850:	b79ff0ef          	jal	ra,800033c8 <iput>
    return 0;
    80003854:	4981                	li	s3,0
    80003856:	bf1d                	j	8000378c <namex+0x5a>
  if(*path == 0)
    80003858:	dbed                	beqz	a5,8000384a <namex+0x118>
  while(*path != '/' && *path != 0)
    8000385a:	0004c783          	lbu	a5,0(s1)
    8000385e:	85a6                	mv	a1,s1
    80003860:	b7f1                	j	8000382c <namex+0xfa>

0000000080003862 <dirlink>:
{
    80003862:	7139                	addi	sp,sp,-64
    80003864:	fc06                	sd	ra,56(sp)
    80003866:	f822                	sd	s0,48(sp)
    80003868:	f426                	sd	s1,40(sp)
    8000386a:	f04a                	sd	s2,32(sp)
    8000386c:	ec4e                	sd	s3,24(sp)
    8000386e:	e852                	sd	s4,16(sp)
    80003870:	0080                	addi	s0,sp,64
    80003872:	892a                	mv	s2,a0
    80003874:	8a2e                	mv	s4,a1
    80003876:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003878:	4601                	li	a2,0
    8000387a:	e1dff0ef          	jal	ra,80003696 <dirlookup>
    8000387e:	e52d                	bnez	a0,800038e8 <dirlink+0x86>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003880:	04c92483          	lw	s1,76(s2)
    80003884:	c48d                	beqz	s1,800038ae <dirlink+0x4c>
    80003886:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003888:	4741                	li	a4,16
    8000388a:	86a6                	mv	a3,s1
    8000388c:	fc040613          	addi	a2,s0,-64
    80003890:	4581                	li	a1,0
    80003892:	854a                	mv	a0,s2
    80003894:	c07ff0ef          	jal	ra,8000349a <readi>
    80003898:	47c1                	li	a5,16
    8000389a:	04f51b63          	bne	a0,a5,800038f0 <dirlink+0x8e>
    if(de.inum == 0)
    8000389e:	fc045783          	lhu	a5,-64(s0)
    800038a2:	c791                	beqz	a5,800038ae <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800038a4:	24c1                	addiw	s1,s1,16
    800038a6:	04c92783          	lw	a5,76(s2)
    800038aa:	fcf4efe3          	bltu	s1,a5,80003888 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    800038ae:	4639                	li	a2,14
    800038b0:	85d2                	mv	a1,s4
    800038b2:	fc240513          	addi	a0,s0,-62
    800038b6:	d6cfd0ef          	jal	ra,80000e22 <strncpy>
  de.inum = inum;
    800038ba:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800038be:	4741                	li	a4,16
    800038c0:	86a6                	mv	a3,s1
    800038c2:	fc040613          	addi	a2,s0,-64
    800038c6:	4581                	li	a1,0
    800038c8:	854a                	mv	a0,s2
    800038ca:	cb5ff0ef          	jal	ra,8000357e <writei>
    800038ce:	1541                	addi	a0,a0,-16
    800038d0:	00a03533          	snez	a0,a0
    800038d4:	40a00533          	neg	a0,a0
}
    800038d8:	70e2                	ld	ra,56(sp)
    800038da:	7442                	ld	s0,48(sp)
    800038dc:	74a2                	ld	s1,40(sp)
    800038de:	7902                	ld	s2,32(sp)
    800038e0:	69e2                	ld	s3,24(sp)
    800038e2:	6a42                	ld	s4,16(sp)
    800038e4:	6121                	addi	sp,sp,64
    800038e6:	8082                	ret
    iput(ip);
    800038e8:	ae1ff0ef          	jal	ra,800033c8 <iput>
    return -1;
    800038ec:	557d                	li	a0,-1
    800038ee:	b7ed                	j	800038d8 <dirlink+0x76>
      panic("dirlink read");
    800038f0:	00004517          	auipc	a0,0x4
    800038f4:	e5850513          	addi	a0,a0,-424 # 80007748 <syscall_names+0x1d0>
    800038f8:	ee9fc0ef          	jal	ra,800007e0 <panic>

00000000800038fc <namei>:

struct inode*
namei(char *path)
{
    800038fc:	1101                	addi	sp,sp,-32
    800038fe:	ec06                	sd	ra,24(sp)
    80003900:	e822                	sd	s0,16(sp)
    80003902:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003904:	fe040613          	addi	a2,s0,-32
    80003908:	4581                	li	a1,0
    8000390a:	e29ff0ef          	jal	ra,80003732 <namex>
}
    8000390e:	60e2                	ld	ra,24(sp)
    80003910:	6442                	ld	s0,16(sp)
    80003912:	6105                	addi	sp,sp,32
    80003914:	8082                	ret

0000000080003916 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003916:	1141                	addi	sp,sp,-16
    80003918:	e406                	sd	ra,8(sp)
    8000391a:	e022                	sd	s0,0(sp)
    8000391c:	0800                	addi	s0,sp,16
    8000391e:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003920:	4585                	li	a1,1
    80003922:	e11ff0ef          	jal	ra,80003732 <namex>
}
    80003926:	60a2                	ld	ra,8(sp)
    80003928:	6402                	ld	s0,0(sp)
    8000392a:	0141                	addi	sp,sp,16
    8000392c:	8082                	ret

000000008000392e <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    8000392e:	1101                	addi	sp,sp,-32
    80003930:	ec06                	sd	ra,24(sp)
    80003932:	e822                	sd	s0,16(sp)
    80003934:	e426                	sd	s1,8(sp)
    80003936:	e04a                	sd	s2,0(sp)
    80003938:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    8000393a:	0001c917          	auipc	s2,0x1c
    8000393e:	36e90913          	addi	s2,s2,878 # 8001fca8 <log>
    80003942:	01892583          	lw	a1,24(s2)
    80003946:	02892503          	lw	a0,40(s2)
    8000394a:	9e0ff0ef          	jal	ra,80002b2a <bread>
    8000394e:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003950:	02c92683          	lw	a3,44(s2)
    80003954:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003956:	02d05863          	blez	a3,80003986 <write_head+0x58>
    8000395a:	0001c797          	auipc	a5,0x1c
    8000395e:	37e78793          	addi	a5,a5,894 # 8001fcd8 <log+0x30>
    80003962:	05c50713          	addi	a4,a0,92
    80003966:	36fd                	addiw	a3,a3,-1
    80003968:	02069613          	slli	a2,a3,0x20
    8000396c:	01e65693          	srli	a3,a2,0x1e
    80003970:	0001c617          	auipc	a2,0x1c
    80003974:	36c60613          	addi	a2,a2,876 # 8001fcdc <log+0x34>
    80003978:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    8000397a:	4390                	lw	a2,0(a5)
    8000397c:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    8000397e:	0791                	addi	a5,a5,4
    80003980:	0711                	addi	a4,a4,4
    80003982:	fed79ce3          	bne	a5,a3,8000397a <write_head+0x4c>
  }
  bwrite(buf);
    80003986:	8526                	mv	a0,s1
    80003988:	a78ff0ef          	jal	ra,80002c00 <bwrite>
  brelse(buf);
    8000398c:	8526                	mv	a0,s1
    8000398e:	aa4ff0ef          	jal	ra,80002c32 <brelse>
}
    80003992:	60e2                	ld	ra,24(sp)
    80003994:	6442                	ld	s0,16(sp)
    80003996:	64a2                	ld	s1,8(sp)
    80003998:	6902                	ld	s2,0(sp)
    8000399a:	6105                	addi	sp,sp,32
    8000399c:	8082                	ret

000000008000399e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    8000399e:	0001c797          	auipc	a5,0x1c
    800039a2:	3367a783          	lw	a5,822(a5) # 8001fcd4 <log+0x2c>
    800039a6:	08f05f63          	blez	a5,80003a44 <install_trans+0xa6>
{
    800039aa:	7139                	addi	sp,sp,-64
    800039ac:	fc06                	sd	ra,56(sp)
    800039ae:	f822                	sd	s0,48(sp)
    800039b0:	f426                	sd	s1,40(sp)
    800039b2:	f04a                	sd	s2,32(sp)
    800039b4:	ec4e                	sd	s3,24(sp)
    800039b6:	e852                	sd	s4,16(sp)
    800039b8:	e456                	sd	s5,8(sp)
    800039ba:	e05a                	sd	s6,0(sp)
    800039bc:	0080                	addi	s0,sp,64
    800039be:	8b2a                	mv	s6,a0
    800039c0:	0001ca97          	auipc	s5,0x1c
    800039c4:	318a8a93          	addi	s5,s5,792 # 8001fcd8 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    800039c8:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800039ca:	0001c997          	auipc	s3,0x1c
    800039ce:	2de98993          	addi	s3,s3,734 # 8001fca8 <log>
    800039d2:	a829                	j	800039ec <install_trans+0x4e>
    brelse(lbuf);
    800039d4:	854a                	mv	a0,s2
    800039d6:	a5cff0ef          	jal	ra,80002c32 <brelse>
    brelse(dbuf);
    800039da:	8526                	mv	a0,s1
    800039dc:	a56ff0ef          	jal	ra,80002c32 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800039e0:	2a05                	addiw	s4,s4,1
    800039e2:	0a91                	addi	s5,s5,4
    800039e4:	02c9a783          	lw	a5,44(s3)
    800039e8:	04fa5463          	bge	s4,a5,80003a30 <install_trans+0x92>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800039ec:	0189a583          	lw	a1,24(s3)
    800039f0:	014585bb          	addw	a1,a1,s4
    800039f4:	2585                	addiw	a1,a1,1
    800039f6:	0289a503          	lw	a0,40(s3)
    800039fa:	930ff0ef          	jal	ra,80002b2a <bread>
    800039fe:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003a00:	000aa583          	lw	a1,0(s5)
    80003a04:	0289a503          	lw	a0,40(s3)
    80003a08:	922ff0ef          	jal	ra,80002b2a <bread>
    80003a0c:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003a0e:	40000613          	li	a2,1024
    80003a12:	05890593          	addi	a1,s2,88
    80003a16:	05850513          	addi	a0,a0,88
    80003a1a:	b5cfd0ef          	jal	ra,80000d76 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003a1e:	8526                	mv	a0,s1
    80003a20:	9e0ff0ef          	jal	ra,80002c00 <bwrite>
    if(recovering == 0)
    80003a24:	fa0b18e3          	bnez	s6,800039d4 <install_trans+0x36>
      bunpin(dbuf);
    80003a28:	8526                	mv	a0,s1
    80003a2a:	ac6ff0ef          	jal	ra,80002cf0 <bunpin>
    80003a2e:	b75d                	j	800039d4 <install_trans+0x36>
}
    80003a30:	70e2                	ld	ra,56(sp)
    80003a32:	7442                	ld	s0,48(sp)
    80003a34:	74a2                	ld	s1,40(sp)
    80003a36:	7902                	ld	s2,32(sp)
    80003a38:	69e2                	ld	s3,24(sp)
    80003a3a:	6a42                	ld	s4,16(sp)
    80003a3c:	6aa2                	ld	s5,8(sp)
    80003a3e:	6b02                	ld	s6,0(sp)
    80003a40:	6121                	addi	sp,sp,64
    80003a42:	8082                	ret
    80003a44:	8082                	ret

0000000080003a46 <initlog>:
{
    80003a46:	7179                	addi	sp,sp,-48
    80003a48:	f406                	sd	ra,40(sp)
    80003a4a:	f022                	sd	s0,32(sp)
    80003a4c:	ec26                	sd	s1,24(sp)
    80003a4e:	e84a                	sd	s2,16(sp)
    80003a50:	e44e                	sd	s3,8(sp)
    80003a52:	1800                	addi	s0,sp,48
    80003a54:	892a                	mv	s2,a0
    80003a56:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003a58:	0001c497          	auipc	s1,0x1c
    80003a5c:	25048493          	addi	s1,s1,592 # 8001fca8 <log>
    80003a60:	00004597          	auipc	a1,0x4
    80003a64:	cf858593          	addi	a1,a1,-776 # 80007758 <syscall_names+0x1e0>
    80003a68:	8526                	mv	a0,s1
    80003a6a:	95cfd0ef          	jal	ra,80000bc6 <initlock>
  log.start = sb->logstart;
    80003a6e:	0149a583          	lw	a1,20(s3)
    80003a72:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80003a74:	0109a783          	lw	a5,16(s3)
    80003a78:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003a7a:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003a7e:	854a                	mv	a0,s2
    80003a80:	8aaff0ef          	jal	ra,80002b2a <bread>
  log.lh.n = lh->n;
    80003a84:	4d34                	lw	a3,88(a0)
    80003a86:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003a88:	02d05663          	blez	a3,80003ab4 <initlog+0x6e>
    80003a8c:	05c50793          	addi	a5,a0,92
    80003a90:	0001c717          	auipc	a4,0x1c
    80003a94:	24870713          	addi	a4,a4,584 # 8001fcd8 <log+0x30>
    80003a98:	36fd                	addiw	a3,a3,-1
    80003a9a:	02069613          	slli	a2,a3,0x20
    80003a9e:	01e65693          	srli	a3,a2,0x1e
    80003aa2:	06050613          	addi	a2,a0,96
    80003aa6:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    80003aa8:	4390                	lw	a2,0(a5)
    80003aaa:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003aac:	0791                	addi	a5,a5,4
    80003aae:	0711                	addi	a4,a4,4
    80003ab0:	fed79ce3          	bne	a5,a3,80003aa8 <initlog+0x62>
  brelse(buf);
    80003ab4:	97eff0ef          	jal	ra,80002c32 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003ab8:	4505                	li	a0,1
    80003aba:	ee5ff0ef          	jal	ra,8000399e <install_trans>
  log.lh.n = 0;
    80003abe:	0001c797          	auipc	a5,0x1c
    80003ac2:	2007ab23          	sw	zero,534(a5) # 8001fcd4 <log+0x2c>
  write_head(); // clear the log
    80003ac6:	e69ff0ef          	jal	ra,8000392e <write_head>
}
    80003aca:	70a2                	ld	ra,40(sp)
    80003acc:	7402                	ld	s0,32(sp)
    80003ace:	64e2                	ld	s1,24(sp)
    80003ad0:	6942                	ld	s2,16(sp)
    80003ad2:	69a2                	ld	s3,8(sp)
    80003ad4:	6145                	addi	sp,sp,48
    80003ad6:	8082                	ret

0000000080003ad8 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003ad8:	1101                	addi	sp,sp,-32
    80003ada:	ec06                	sd	ra,24(sp)
    80003adc:	e822                	sd	s0,16(sp)
    80003ade:	e426                	sd	s1,8(sp)
    80003ae0:	e04a                	sd	s2,0(sp)
    80003ae2:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003ae4:	0001c517          	auipc	a0,0x1c
    80003ae8:	1c450513          	addi	a0,a0,452 # 8001fca8 <log>
    80003aec:	95afd0ef          	jal	ra,80000c46 <acquire>
  while(1){
    if(log.committing){
    80003af0:	0001c497          	auipc	s1,0x1c
    80003af4:	1b848493          	addi	s1,s1,440 # 8001fca8 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003af8:	4979                	li	s2,30
    80003afa:	a029                	j	80003b04 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003afc:	85a6                	mv	a1,s1
    80003afe:	8526                	mv	a0,s1
    80003b00:	bc4fe0ef          	jal	ra,80001ec4 <sleep>
    if(log.committing){
    80003b04:	50dc                	lw	a5,36(s1)
    80003b06:	fbfd                	bnez	a5,80003afc <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003b08:	509c                	lw	a5,32(s1)
    80003b0a:	0017871b          	addiw	a4,a5,1
    80003b0e:	0007069b          	sext.w	a3,a4
    80003b12:	0027179b          	slliw	a5,a4,0x2
    80003b16:	9fb9                	addw	a5,a5,a4
    80003b18:	0017979b          	slliw	a5,a5,0x1
    80003b1c:	54d8                	lw	a4,44(s1)
    80003b1e:	9fb9                	addw	a5,a5,a4
    80003b20:	00f95763          	bge	s2,a5,80003b2e <begin_op+0x56>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003b24:	85a6                	mv	a1,s1
    80003b26:	8526                	mv	a0,s1
    80003b28:	b9cfe0ef          	jal	ra,80001ec4 <sleep>
    80003b2c:	bfe1                	j	80003b04 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003b2e:	0001c517          	auipc	a0,0x1c
    80003b32:	17a50513          	addi	a0,a0,378 # 8001fca8 <log>
    80003b36:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80003b38:	9a6fd0ef          	jal	ra,80000cde <release>
      break;
    }
  }
}
    80003b3c:	60e2                	ld	ra,24(sp)
    80003b3e:	6442                	ld	s0,16(sp)
    80003b40:	64a2                	ld	s1,8(sp)
    80003b42:	6902                	ld	s2,0(sp)
    80003b44:	6105                	addi	sp,sp,32
    80003b46:	8082                	ret

0000000080003b48 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003b48:	7139                	addi	sp,sp,-64
    80003b4a:	fc06                	sd	ra,56(sp)
    80003b4c:	f822                	sd	s0,48(sp)
    80003b4e:	f426                	sd	s1,40(sp)
    80003b50:	f04a                	sd	s2,32(sp)
    80003b52:	ec4e                	sd	s3,24(sp)
    80003b54:	e852                	sd	s4,16(sp)
    80003b56:	e456                	sd	s5,8(sp)
    80003b58:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003b5a:	0001c497          	auipc	s1,0x1c
    80003b5e:	14e48493          	addi	s1,s1,334 # 8001fca8 <log>
    80003b62:	8526                	mv	a0,s1
    80003b64:	8e2fd0ef          	jal	ra,80000c46 <acquire>
  log.outstanding -= 1;
    80003b68:	509c                	lw	a5,32(s1)
    80003b6a:	37fd                	addiw	a5,a5,-1
    80003b6c:	0007891b          	sext.w	s2,a5
    80003b70:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003b72:	50dc                	lw	a5,36(s1)
    80003b74:	ef9d                	bnez	a5,80003bb2 <end_op+0x6a>
    panic("log.committing");
  if(log.outstanding == 0){
    80003b76:	04091463          	bnez	s2,80003bbe <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003b7a:	0001c497          	auipc	s1,0x1c
    80003b7e:	12e48493          	addi	s1,s1,302 # 8001fca8 <log>
    80003b82:	4785                	li	a5,1
    80003b84:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003b86:	8526                	mv	a0,s1
    80003b88:	956fd0ef          	jal	ra,80000cde <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003b8c:	54dc                	lw	a5,44(s1)
    80003b8e:	04f04b63          	bgtz	a5,80003be4 <end_op+0x9c>
    acquire(&log.lock);
    80003b92:	0001c497          	auipc	s1,0x1c
    80003b96:	11648493          	addi	s1,s1,278 # 8001fca8 <log>
    80003b9a:	8526                	mv	a0,s1
    80003b9c:	8aafd0ef          	jal	ra,80000c46 <acquire>
    log.committing = 0;
    80003ba0:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    80003ba4:	8526                	mv	a0,s1
    80003ba6:	b6afe0ef          	jal	ra,80001f10 <wakeup>
    release(&log.lock);
    80003baa:	8526                	mv	a0,s1
    80003bac:	932fd0ef          	jal	ra,80000cde <release>
}
    80003bb0:	a00d                	j	80003bd2 <end_op+0x8a>
    panic("log.committing");
    80003bb2:	00004517          	auipc	a0,0x4
    80003bb6:	bae50513          	addi	a0,a0,-1106 # 80007760 <syscall_names+0x1e8>
    80003bba:	c27fc0ef          	jal	ra,800007e0 <panic>
    wakeup(&log);
    80003bbe:	0001c497          	auipc	s1,0x1c
    80003bc2:	0ea48493          	addi	s1,s1,234 # 8001fca8 <log>
    80003bc6:	8526                	mv	a0,s1
    80003bc8:	b48fe0ef          	jal	ra,80001f10 <wakeup>
  release(&log.lock);
    80003bcc:	8526                	mv	a0,s1
    80003bce:	910fd0ef          	jal	ra,80000cde <release>
}
    80003bd2:	70e2                	ld	ra,56(sp)
    80003bd4:	7442                	ld	s0,48(sp)
    80003bd6:	74a2                	ld	s1,40(sp)
    80003bd8:	7902                	ld	s2,32(sp)
    80003bda:	69e2                	ld	s3,24(sp)
    80003bdc:	6a42                	ld	s4,16(sp)
    80003bde:	6aa2                	ld	s5,8(sp)
    80003be0:	6121                	addi	sp,sp,64
    80003be2:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    80003be4:	0001ca97          	auipc	s5,0x1c
    80003be8:	0f4a8a93          	addi	s5,s5,244 # 8001fcd8 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003bec:	0001ca17          	auipc	s4,0x1c
    80003bf0:	0bca0a13          	addi	s4,s4,188 # 8001fca8 <log>
    80003bf4:	018a2583          	lw	a1,24(s4)
    80003bf8:	012585bb          	addw	a1,a1,s2
    80003bfc:	2585                	addiw	a1,a1,1
    80003bfe:	028a2503          	lw	a0,40(s4)
    80003c02:	f29fe0ef          	jal	ra,80002b2a <bread>
    80003c06:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003c08:	000aa583          	lw	a1,0(s5)
    80003c0c:	028a2503          	lw	a0,40(s4)
    80003c10:	f1bfe0ef          	jal	ra,80002b2a <bread>
    80003c14:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003c16:	40000613          	li	a2,1024
    80003c1a:	05850593          	addi	a1,a0,88
    80003c1e:	05848513          	addi	a0,s1,88
    80003c22:	954fd0ef          	jal	ra,80000d76 <memmove>
    bwrite(to);  // write the log
    80003c26:	8526                	mv	a0,s1
    80003c28:	fd9fe0ef          	jal	ra,80002c00 <bwrite>
    brelse(from);
    80003c2c:	854e                	mv	a0,s3
    80003c2e:	804ff0ef          	jal	ra,80002c32 <brelse>
    brelse(to);
    80003c32:	8526                	mv	a0,s1
    80003c34:	ffffe0ef          	jal	ra,80002c32 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c38:	2905                	addiw	s2,s2,1
    80003c3a:	0a91                	addi	s5,s5,4
    80003c3c:	02ca2783          	lw	a5,44(s4)
    80003c40:	faf94ae3          	blt	s2,a5,80003bf4 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003c44:	cebff0ef          	jal	ra,8000392e <write_head>
    install_trans(0); // Now install writes to home locations
    80003c48:	4501                	li	a0,0
    80003c4a:	d55ff0ef          	jal	ra,8000399e <install_trans>
    log.lh.n = 0;
    80003c4e:	0001c797          	auipc	a5,0x1c
    80003c52:	0807a323          	sw	zero,134(a5) # 8001fcd4 <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003c56:	cd9ff0ef          	jal	ra,8000392e <write_head>
    80003c5a:	bf25                	j	80003b92 <end_op+0x4a>

0000000080003c5c <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003c5c:	1101                	addi	sp,sp,-32
    80003c5e:	ec06                	sd	ra,24(sp)
    80003c60:	e822                	sd	s0,16(sp)
    80003c62:	e426                	sd	s1,8(sp)
    80003c64:	e04a                	sd	s2,0(sp)
    80003c66:	1000                	addi	s0,sp,32
    80003c68:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003c6a:	0001c917          	auipc	s2,0x1c
    80003c6e:	03e90913          	addi	s2,s2,62 # 8001fca8 <log>
    80003c72:	854a                	mv	a0,s2
    80003c74:	fd3fc0ef          	jal	ra,80000c46 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003c78:	02c92603          	lw	a2,44(s2)
    80003c7c:	47f5                	li	a5,29
    80003c7e:	06c7c363          	blt	a5,a2,80003ce4 <log_write+0x88>
    80003c82:	0001c797          	auipc	a5,0x1c
    80003c86:	0427a783          	lw	a5,66(a5) # 8001fcc4 <log+0x1c>
    80003c8a:	37fd                	addiw	a5,a5,-1
    80003c8c:	04f65c63          	bge	a2,a5,80003ce4 <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003c90:	0001c797          	auipc	a5,0x1c
    80003c94:	0387a783          	lw	a5,56(a5) # 8001fcc8 <log+0x20>
    80003c98:	04f05c63          	blez	a5,80003cf0 <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003c9c:	4781                	li	a5,0
    80003c9e:	04c05f63          	blez	a2,80003cfc <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003ca2:	44cc                	lw	a1,12(s1)
    80003ca4:	0001c717          	auipc	a4,0x1c
    80003ca8:	03470713          	addi	a4,a4,52 # 8001fcd8 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003cac:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003cae:	4314                	lw	a3,0(a4)
    80003cb0:	04b68663          	beq	a3,a1,80003cfc <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    80003cb4:	2785                	addiw	a5,a5,1
    80003cb6:	0711                	addi	a4,a4,4
    80003cb8:	fef61be3          	bne	a2,a5,80003cae <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003cbc:	0621                	addi	a2,a2,8
    80003cbe:	060a                	slli	a2,a2,0x2
    80003cc0:	0001c797          	auipc	a5,0x1c
    80003cc4:	fe878793          	addi	a5,a5,-24 # 8001fca8 <log>
    80003cc8:	963e                	add	a2,a2,a5
    80003cca:	44dc                	lw	a5,12(s1)
    80003ccc:	ca1c                	sw	a5,16(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003cce:	8526                	mv	a0,s1
    80003cd0:	fedfe0ef          	jal	ra,80002cbc <bpin>
    log.lh.n++;
    80003cd4:	0001c717          	auipc	a4,0x1c
    80003cd8:	fd470713          	addi	a4,a4,-44 # 8001fca8 <log>
    80003cdc:	575c                	lw	a5,44(a4)
    80003cde:	2785                	addiw	a5,a5,1
    80003ce0:	d75c                	sw	a5,44(a4)
    80003ce2:	a815                	j	80003d16 <log_write+0xba>
    panic("too big a transaction");
    80003ce4:	00004517          	auipc	a0,0x4
    80003ce8:	a8c50513          	addi	a0,a0,-1396 # 80007770 <syscall_names+0x1f8>
    80003cec:	af5fc0ef          	jal	ra,800007e0 <panic>
    panic("log_write outside of trans");
    80003cf0:	00004517          	auipc	a0,0x4
    80003cf4:	a9850513          	addi	a0,a0,-1384 # 80007788 <syscall_names+0x210>
    80003cf8:	ae9fc0ef          	jal	ra,800007e0 <panic>
  log.lh.block[i] = b->blockno;
    80003cfc:	00878713          	addi	a4,a5,8
    80003d00:	00271693          	slli	a3,a4,0x2
    80003d04:	0001c717          	auipc	a4,0x1c
    80003d08:	fa470713          	addi	a4,a4,-92 # 8001fca8 <log>
    80003d0c:	9736                	add	a4,a4,a3
    80003d0e:	44d4                	lw	a3,12(s1)
    80003d10:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003d12:	faf60ee3          	beq	a2,a5,80003cce <log_write+0x72>
  }
  release(&log.lock);
    80003d16:	0001c517          	auipc	a0,0x1c
    80003d1a:	f9250513          	addi	a0,a0,-110 # 8001fca8 <log>
    80003d1e:	fc1fc0ef          	jal	ra,80000cde <release>
}
    80003d22:	60e2                	ld	ra,24(sp)
    80003d24:	6442                	ld	s0,16(sp)
    80003d26:	64a2                	ld	s1,8(sp)
    80003d28:	6902                	ld	s2,0(sp)
    80003d2a:	6105                	addi	sp,sp,32
    80003d2c:	8082                	ret

0000000080003d2e <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003d2e:	1101                	addi	sp,sp,-32
    80003d30:	ec06                	sd	ra,24(sp)
    80003d32:	e822                	sd	s0,16(sp)
    80003d34:	e426                	sd	s1,8(sp)
    80003d36:	e04a                	sd	s2,0(sp)
    80003d38:	1000                	addi	s0,sp,32
    80003d3a:	84aa                	mv	s1,a0
    80003d3c:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003d3e:	00004597          	auipc	a1,0x4
    80003d42:	a6a58593          	addi	a1,a1,-1430 # 800077a8 <syscall_names+0x230>
    80003d46:	0521                	addi	a0,a0,8
    80003d48:	e7ffc0ef          	jal	ra,80000bc6 <initlock>
  lk->name = name;
    80003d4c:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003d50:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003d54:	0204a423          	sw	zero,40(s1)
}
    80003d58:	60e2                	ld	ra,24(sp)
    80003d5a:	6442                	ld	s0,16(sp)
    80003d5c:	64a2                	ld	s1,8(sp)
    80003d5e:	6902                	ld	s2,0(sp)
    80003d60:	6105                	addi	sp,sp,32
    80003d62:	8082                	ret

0000000080003d64 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003d64:	1101                	addi	sp,sp,-32
    80003d66:	ec06                	sd	ra,24(sp)
    80003d68:	e822                	sd	s0,16(sp)
    80003d6a:	e426                	sd	s1,8(sp)
    80003d6c:	e04a                	sd	s2,0(sp)
    80003d6e:	1000                	addi	s0,sp,32
    80003d70:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003d72:	00850913          	addi	s2,a0,8
    80003d76:	854a                	mv	a0,s2
    80003d78:	ecffc0ef          	jal	ra,80000c46 <acquire>
  while (lk->locked) {
    80003d7c:	409c                	lw	a5,0(s1)
    80003d7e:	c799                	beqz	a5,80003d8c <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003d80:	85ca                	mv	a1,s2
    80003d82:	8526                	mv	a0,s1
    80003d84:	940fe0ef          	jal	ra,80001ec4 <sleep>
  while (lk->locked) {
    80003d88:	409c                	lw	a5,0(s1)
    80003d8a:	fbfd                	bnez	a5,80003d80 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003d8c:	4785                	li	a5,1
    80003d8e:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003d90:	b4ffd0ef          	jal	ra,800018de <myproc>
    80003d94:	591c                	lw	a5,48(a0)
    80003d96:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003d98:	854a                	mv	a0,s2
    80003d9a:	f45fc0ef          	jal	ra,80000cde <release>
}
    80003d9e:	60e2                	ld	ra,24(sp)
    80003da0:	6442                	ld	s0,16(sp)
    80003da2:	64a2                	ld	s1,8(sp)
    80003da4:	6902                	ld	s2,0(sp)
    80003da6:	6105                	addi	sp,sp,32
    80003da8:	8082                	ret

0000000080003daa <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003daa:	1101                	addi	sp,sp,-32
    80003dac:	ec06                	sd	ra,24(sp)
    80003dae:	e822                	sd	s0,16(sp)
    80003db0:	e426                	sd	s1,8(sp)
    80003db2:	e04a                	sd	s2,0(sp)
    80003db4:	1000                	addi	s0,sp,32
    80003db6:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003db8:	00850913          	addi	s2,a0,8
    80003dbc:	854a                	mv	a0,s2
    80003dbe:	e89fc0ef          	jal	ra,80000c46 <acquire>
  lk->locked = 0;
    80003dc2:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003dc6:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003dca:	8526                	mv	a0,s1
    80003dcc:	944fe0ef          	jal	ra,80001f10 <wakeup>
  release(&lk->lk);
    80003dd0:	854a                	mv	a0,s2
    80003dd2:	f0dfc0ef          	jal	ra,80000cde <release>
}
    80003dd6:	60e2                	ld	ra,24(sp)
    80003dd8:	6442                	ld	s0,16(sp)
    80003dda:	64a2                	ld	s1,8(sp)
    80003ddc:	6902                	ld	s2,0(sp)
    80003dde:	6105                	addi	sp,sp,32
    80003de0:	8082                	ret

0000000080003de2 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003de2:	7179                	addi	sp,sp,-48
    80003de4:	f406                	sd	ra,40(sp)
    80003de6:	f022                	sd	s0,32(sp)
    80003de8:	ec26                	sd	s1,24(sp)
    80003dea:	e84a                	sd	s2,16(sp)
    80003dec:	e44e                	sd	s3,8(sp)
    80003dee:	1800                	addi	s0,sp,48
    80003df0:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003df2:	00850913          	addi	s2,a0,8
    80003df6:	854a                	mv	a0,s2
    80003df8:	e4ffc0ef          	jal	ra,80000c46 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003dfc:	409c                	lw	a5,0(s1)
    80003dfe:	ef89                	bnez	a5,80003e18 <holdingsleep+0x36>
    80003e00:	4481                	li	s1,0
  release(&lk->lk);
    80003e02:	854a                	mv	a0,s2
    80003e04:	edbfc0ef          	jal	ra,80000cde <release>
  return r;
}
    80003e08:	8526                	mv	a0,s1
    80003e0a:	70a2                	ld	ra,40(sp)
    80003e0c:	7402                	ld	s0,32(sp)
    80003e0e:	64e2                	ld	s1,24(sp)
    80003e10:	6942                	ld	s2,16(sp)
    80003e12:	69a2                	ld	s3,8(sp)
    80003e14:	6145                	addi	sp,sp,48
    80003e16:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80003e18:	0284a983          	lw	s3,40(s1)
    80003e1c:	ac3fd0ef          	jal	ra,800018de <myproc>
    80003e20:	5904                	lw	s1,48(a0)
    80003e22:	413484b3          	sub	s1,s1,s3
    80003e26:	0014b493          	seqz	s1,s1
    80003e2a:	bfe1                	j	80003e02 <holdingsleep+0x20>

0000000080003e2c <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003e2c:	1141                	addi	sp,sp,-16
    80003e2e:	e406                	sd	ra,8(sp)
    80003e30:	e022                	sd	s0,0(sp)
    80003e32:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003e34:	00004597          	auipc	a1,0x4
    80003e38:	98458593          	addi	a1,a1,-1660 # 800077b8 <syscall_names+0x240>
    80003e3c:	0001c517          	auipc	a0,0x1c
    80003e40:	fb450513          	addi	a0,a0,-76 # 8001fdf0 <ftable>
    80003e44:	d83fc0ef          	jal	ra,80000bc6 <initlock>
}
    80003e48:	60a2                	ld	ra,8(sp)
    80003e4a:	6402                	ld	s0,0(sp)
    80003e4c:	0141                	addi	sp,sp,16
    80003e4e:	8082                	ret

0000000080003e50 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003e50:	1101                	addi	sp,sp,-32
    80003e52:	ec06                	sd	ra,24(sp)
    80003e54:	e822                	sd	s0,16(sp)
    80003e56:	e426                	sd	s1,8(sp)
    80003e58:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003e5a:	0001c517          	auipc	a0,0x1c
    80003e5e:	f9650513          	addi	a0,a0,-106 # 8001fdf0 <ftable>
    80003e62:	de5fc0ef          	jal	ra,80000c46 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003e66:	0001c497          	auipc	s1,0x1c
    80003e6a:	fa248493          	addi	s1,s1,-94 # 8001fe08 <ftable+0x18>
    80003e6e:	0001d717          	auipc	a4,0x1d
    80003e72:	f3a70713          	addi	a4,a4,-198 # 80020da8 <disk>
    if(f->ref == 0){
    80003e76:	40dc                	lw	a5,4(s1)
    80003e78:	cf89                	beqz	a5,80003e92 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003e7a:	02848493          	addi	s1,s1,40
    80003e7e:	fee49ce3          	bne	s1,a4,80003e76 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003e82:	0001c517          	auipc	a0,0x1c
    80003e86:	f6e50513          	addi	a0,a0,-146 # 8001fdf0 <ftable>
    80003e8a:	e55fc0ef          	jal	ra,80000cde <release>
  return 0;
    80003e8e:	4481                	li	s1,0
    80003e90:	a809                	j	80003ea2 <filealloc+0x52>
      f->ref = 1;
    80003e92:	4785                	li	a5,1
    80003e94:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003e96:	0001c517          	auipc	a0,0x1c
    80003e9a:	f5a50513          	addi	a0,a0,-166 # 8001fdf0 <ftable>
    80003e9e:	e41fc0ef          	jal	ra,80000cde <release>
}
    80003ea2:	8526                	mv	a0,s1
    80003ea4:	60e2                	ld	ra,24(sp)
    80003ea6:	6442                	ld	s0,16(sp)
    80003ea8:	64a2                	ld	s1,8(sp)
    80003eaa:	6105                	addi	sp,sp,32
    80003eac:	8082                	ret

0000000080003eae <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003eae:	1101                	addi	sp,sp,-32
    80003eb0:	ec06                	sd	ra,24(sp)
    80003eb2:	e822                	sd	s0,16(sp)
    80003eb4:	e426                	sd	s1,8(sp)
    80003eb6:	1000                	addi	s0,sp,32
    80003eb8:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003eba:	0001c517          	auipc	a0,0x1c
    80003ebe:	f3650513          	addi	a0,a0,-202 # 8001fdf0 <ftable>
    80003ec2:	d85fc0ef          	jal	ra,80000c46 <acquire>
  if(f->ref < 1)
    80003ec6:	40dc                	lw	a5,4(s1)
    80003ec8:	02f05063          	blez	a5,80003ee8 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003ecc:	2785                	addiw	a5,a5,1
    80003ece:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003ed0:	0001c517          	auipc	a0,0x1c
    80003ed4:	f2050513          	addi	a0,a0,-224 # 8001fdf0 <ftable>
    80003ed8:	e07fc0ef          	jal	ra,80000cde <release>
  return f;
}
    80003edc:	8526                	mv	a0,s1
    80003ede:	60e2                	ld	ra,24(sp)
    80003ee0:	6442                	ld	s0,16(sp)
    80003ee2:	64a2                	ld	s1,8(sp)
    80003ee4:	6105                	addi	sp,sp,32
    80003ee6:	8082                	ret
    panic("filedup");
    80003ee8:	00004517          	auipc	a0,0x4
    80003eec:	8d850513          	addi	a0,a0,-1832 # 800077c0 <syscall_names+0x248>
    80003ef0:	8f1fc0ef          	jal	ra,800007e0 <panic>

0000000080003ef4 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003ef4:	7139                	addi	sp,sp,-64
    80003ef6:	fc06                	sd	ra,56(sp)
    80003ef8:	f822                	sd	s0,48(sp)
    80003efa:	f426                	sd	s1,40(sp)
    80003efc:	f04a                	sd	s2,32(sp)
    80003efe:	ec4e                	sd	s3,24(sp)
    80003f00:	e852                	sd	s4,16(sp)
    80003f02:	e456                	sd	s5,8(sp)
    80003f04:	0080                	addi	s0,sp,64
    80003f06:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003f08:	0001c517          	auipc	a0,0x1c
    80003f0c:	ee850513          	addi	a0,a0,-280 # 8001fdf0 <ftable>
    80003f10:	d37fc0ef          	jal	ra,80000c46 <acquire>
  if(f->ref < 1)
    80003f14:	40dc                	lw	a5,4(s1)
    80003f16:	04f05963          	blez	a5,80003f68 <fileclose+0x74>
    panic("fileclose");
  if(--f->ref > 0){
    80003f1a:	37fd                	addiw	a5,a5,-1
    80003f1c:	0007871b          	sext.w	a4,a5
    80003f20:	c0dc                	sw	a5,4(s1)
    80003f22:	04e04963          	bgtz	a4,80003f74 <fileclose+0x80>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003f26:	0004a903          	lw	s2,0(s1)
    80003f2a:	0094ca83          	lbu	s5,9(s1)
    80003f2e:	0104ba03          	ld	s4,16(s1)
    80003f32:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80003f36:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003f3a:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003f3e:	0001c517          	auipc	a0,0x1c
    80003f42:	eb250513          	addi	a0,a0,-334 # 8001fdf0 <ftable>
    80003f46:	d99fc0ef          	jal	ra,80000cde <release>

  if(ff.type == FD_PIPE){
    80003f4a:	4785                	li	a5,1
    80003f4c:	04f90363          	beq	s2,a5,80003f92 <fileclose+0x9e>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80003f50:	3979                	addiw	s2,s2,-2
    80003f52:	4785                	li	a5,1
    80003f54:	0327e663          	bltu	a5,s2,80003f80 <fileclose+0x8c>
    begin_op();
    80003f58:	b81ff0ef          	jal	ra,80003ad8 <begin_op>
    iput(ff.ip);
    80003f5c:	854e                	mv	a0,s3
    80003f5e:	c6aff0ef          	jal	ra,800033c8 <iput>
    end_op();
    80003f62:	be7ff0ef          	jal	ra,80003b48 <end_op>
    80003f66:	a829                	j	80003f80 <fileclose+0x8c>
    panic("fileclose");
    80003f68:	00004517          	auipc	a0,0x4
    80003f6c:	86050513          	addi	a0,a0,-1952 # 800077c8 <syscall_names+0x250>
    80003f70:	871fc0ef          	jal	ra,800007e0 <panic>
    release(&ftable.lock);
    80003f74:	0001c517          	auipc	a0,0x1c
    80003f78:	e7c50513          	addi	a0,a0,-388 # 8001fdf0 <ftable>
    80003f7c:	d63fc0ef          	jal	ra,80000cde <release>
  }
}
    80003f80:	70e2                	ld	ra,56(sp)
    80003f82:	7442                	ld	s0,48(sp)
    80003f84:	74a2                	ld	s1,40(sp)
    80003f86:	7902                	ld	s2,32(sp)
    80003f88:	69e2                	ld	s3,24(sp)
    80003f8a:	6a42                	ld	s4,16(sp)
    80003f8c:	6aa2                	ld	s5,8(sp)
    80003f8e:	6121                	addi	sp,sp,64
    80003f90:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80003f92:	85d6                	mv	a1,s5
    80003f94:	8552                	mv	a0,s4
    80003f96:	2ec000ef          	jal	ra,80004282 <pipeclose>
    80003f9a:	b7dd                	j	80003f80 <fileclose+0x8c>

0000000080003f9c <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80003f9c:	715d                	addi	sp,sp,-80
    80003f9e:	e486                	sd	ra,72(sp)
    80003fa0:	e0a2                	sd	s0,64(sp)
    80003fa2:	fc26                	sd	s1,56(sp)
    80003fa4:	f84a                	sd	s2,48(sp)
    80003fa6:	f44e                	sd	s3,40(sp)
    80003fa8:	0880                	addi	s0,sp,80
    80003faa:	84aa                	mv	s1,a0
    80003fac:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80003fae:	931fd0ef          	jal	ra,800018de <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003fb2:	409c                	lw	a5,0(s1)
    80003fb4:	37f9                	addiw	a5,a5,-2
    80003fb6:	4705                	li	a4,1
    80003fb8:	02f76f63          	bltu	a4,a5,80003ff6 <filestat+0x5a>
    80003fbc:	892a                	mv	s2,a0
    ilock(f->ip);
    80003fbe:	6c88                	ld	a0,24(s1)
    80003fc0:	a8aff0ef          	jal	ra,8000324a <ilock>
    stati(f->ip, &st);
    80003fc4:	fb840593          	addi	a1,s0,-72
    80003fc8:	6c88                	ld	a0,24(s1)
    80003fca:	ca6ff0ef          	jal	ra,80003470 <stati>
    iunlock(f->ip);
    80003fce:	6c88                	ld	a0,24(s1)
    80003fd0:	b24ff0ef          	jal	ra,800032f4 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003fd4:	46e1                	li	a3,24
    80003fd6:	fb840613          	addi	a2,s0,-72
    80003fda:	85ce                	mv	a1,s3
    80003fdc:	05093503          	ld	a0,80(s2)
    80003fe0:	e4cfd0ef          	jal	ra,8000162c <copyout>
    80003fe4:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    80003fe8:	60a6                	ld	ra,72(sp)
    80003fea:	6406                	ld	s0,64(sp)
    80003fec:	74e2                	ld	s1,56(sp)
    80003fee:	7942                	ld	s2,48(sp)
    80003ff0:	79a2                	ld	s3,40(sp)
    80003ff2:	6161                	addi	sp,sp,80
    80003ff4:	8082                	ret
  return -1;
    80003ff6:	557d                	li	a0,-1
    80003ff8:	bfc5                	j	80003fe8 <filestat+0x4c>

0000000080003ffa <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003ffa:	7179                	addi	sp,sp,-48
    80003ffc:	f406                	sd	ra,40(sp)
    80003ffe:	f022                	sd	s0,32(sp)
    80004000:	ec26                	sd	s1,24(sp)
    80004002:	e84a                	sd	s2,16(sp)
    80004004:	e44e                	sd	s3,8(sp)
    80004006:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004008:	00854783          	lbu	a5,8(a0)
    8000400c:	cbc1                	beqz	a5,8000409c <fileread+0xa2>
    8000400e:	84aa                	mv	s1,a0
    80004010:	89ae                	mv	s3,a1
    80004012:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80004014:	411c                	lw	a5,0(a0)
    80004016:	4705                	li	a4,1
    80004018:	04e78363          	beq	a5,a4,8000405e <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000401c:	470d                	li	a4,3
    8000401e:	04e78563          	beq	a5,a4,80004068 <fileread+0x6e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004022:	4709                	li	a4,2
    80004024:	06e79663          	bne	a5,a4,80004090 <fileread+0x96>
    ilock(f->ip);
    80004028:	6d08                	ld	a0,24(a0)
    8000402a:	a20ff0ef          	jal	ra,8000324a <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000402e:	874a                	mv	a4,s2
    80004030:	5094                	lw	a3,32(s1)
    80004032:	864e                	mv	a2,s3
    80004034:	4585                	li	a1,1
    80004036:	6c88                	ld	a0,24(s1)
    80004038:	c62ff0ef          	jal	ra,8000349a <readi>
    8000403c:	892a                	mv	s2,a0
    8000403e:	00a05563          	blez	a0,80004048 <fileread+0x4e>
      f->off += r;
    80004042:	509c                	lw	a5,32(s1)
    80004044:	9fa9                	addw	a5,a5,a0
    80004046:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004048:	6c88                	ld	a0,24(s1)
    8000404a:	aaaff0ef          	jal	ra,800032f4 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    8000404e:	854a                	mv	a0,s2
    80004050:	70a2                	ld	ra,40(sp)
    80004052:	7402                	ld	s0,32(sp)
    80004054:	64e2                	ld	s1,24(sp)
    80004056:	6942                	ld	s2,16(sp)
    80004058:	69a2                	ld	s3,8(sp)
    8000405a:	6145                	addi	sp,sp,48
    8000405c:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000405e:	6908                	ld	a0,16(a0)
    80004060:	34e000ef          	jal	ra,800043ae <piperead>
    80004064:	892a                	mv	s2,a0
    80004066:	b7e5                	j	8000404e <fileread+0x54>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004068:	02451783          	lh	a5,36(a0)
    8000406c:	03079693          	slli	a3,a5,0x30
    80004070:	92c1                	srli	a3,a3,0x30
    80004072:	4725                	li	a4,9
    80004074:	02d76663          	bltu	a4,a3,800040a0 <fileread+0xa6>
    80004078:	0792                	slli	a5,a5,0x4
    8000407a:	0001c717          	auipc	a4,0x1c
    8000407e:	cd670713          	addi	a4,a4,-810 # 8001fd50 <devsw>
    80004082:	97ba                	add	a5,a5,a4
    80004084:	639c                	ld	a5,0(a5)
    80004086:	cf99                	beqz	a5,800040a4 <fileread+0xaa>
    r = devsw[f->major].read(1, addr, n);
    80004088:	4505                	li	a0,1
    8000408a:	9782                	jalr	a5
    8000408c:	892a                	mv	s2,a0
    8000408e:	b7c1                	j	8000404e <fileread+0x54>
    panic("fileread");
    80004090:	00003517          	auipc	a0,0x3
    80004094:	74850513          	addi	a0,a0,1864 # 800077d8 <syscall_names+0x260>
    80004098:	f48fc0ef          	jal	ra,800007e0 <panic>
    return -1;
    8000409c:	597d                	li	s2,-1
    8000409e:	bf45                	j	8000404e <fileread+0x54>
      return -1;
    800040a0:	597d                	li	s2,-1
    800040a2:	b775                	j	8000404e <fileread+0x54>
    800040a4:	597d                	li	s2,-1
    800040a6:	b765                	j	8000404e <fileread+0x54>

00000000800040a8 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800040a8:	715d                	addi	sp,sp,-80
    800040aa:	e486                	sd	ra,72(sp)
    800040ac:	e0a2                	sd	s0,64(sp)
    800040ae:	fc26                	sd	s1,56(sp)
    800040b0:	f84a                	sd	s2,48(sp)
    800040b2:	f44e                	sd	s3,40(sp)
    800040b4:	f052                	sd	s4,32(sp)
    800040b6:	ec56                	sd	s5,24(sp)
    800040b8:	e85a                	sd	s6,16(sp)
    800040ba:	e45e                	sd	s7,8(sp)
    800040bc:	e062                	sd	s8,0(sp)
    800040be:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800040c0:	00954783          	lbu	a5,9(a0)
    800040c4:	0e078863          	beqz	a5,800041b4 <filewrite+0x10c>
    800040c8:	892a                	mv	s2,a0
    800040ca:	8aae                	mv	s5,a1
    800040cc:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800040ce:	411c                	lw	a5,0(a0)
    800040d0:	4705                	li	a4,1
    800040d2:	02e78263          	beq	a5,a4,800040f6 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800040d6:	470d                	li	a4,3
    800040d8:	02e78463          	beq	a5,a4,80004100 <filewrite+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800040dc:	4709                	li	a4,2
    800040de:	0ce79563          	bne	a5,a4,800041a8 <filewrite+0x100>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800040e2:	0ac05163          	blez	a2,80004184 <filewrite+0xdc>
    int i = 0;
    800040e6:	4981                	li	s3,0
    800040e8:	6b05                	lui	s6,0x1
    800040ea:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    800040ee:	6b85                	lui	s7,0x1
    800040f0:	c00b8b9b          	addiw	s7,s7,-1024
    800040f4:	a041                	j	80004174 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800040f6:	6908                	ld	a0,16(a0)
    800040f8:	1e2000ef          	jal	ra,800042da <pipewrite>
    800040fc:	8a2a                	mv	s4,a0
    800040fe:	a071                	j	8000418a <filewrite+0xe2>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004100:	02451783          	lh	a5,36(a0)
    80004104:	03079693          	slli	a3,a5,0x30
    80004108:	92c1                	srli	a3,a3,0x30
    8000410a:	4725                	li	a4,9
    8000410c:	0ad76663          	bltu	a4,a3,800041b8 <filewrite+0x110>
    80004110:	0792                	slli	a5,a5,0x4
    80004112:	0001c717          	auipc	a4,0x1c
    80004116:	c3e70713          	addi	a4,a4,-962 # 8001fd50 <devsw>
    8000411a:	97ba                	add	a5,a5,a4
    8000411c:	679c                	ld	a5,8(a5)
    8000411e:	cfd9                	beqz	a5,800041bc <filewrite+0x114>
    ret = devsw[f->major].write(1, addr, n);
    80004120:	4505                	li	a0,1
    80004122:	9782                	jalr	a5
    80004124:	8a2a                	mv	s4,a0
    80004126:	a095                	j	8000418a <filewrite+0xe2>
    80004128:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    8000412c:	9adff0ef          	jal	ra,80003ad8 <begin_op>
      ilock(f->ip);
    80004130:	01893503          	ld	a0,24(s2)
    80004134:	916ff0ef          	jal	ra,8000324a <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004138:	8762                	mv	a4,s8
    8000413a:	02092683          	lw	a3,32(s2)
    8000413e:	01598633          	add	a2,s3,s5
    80004142:	4585                	li	a1,1
    80004144:	01893503          	ld	a0,24(s2)
    80004148:	c36ff0ef          	jal	ra,8000357e <writei>
    8000414c:	84aa                	mv	s1,a0
    8000414e:	00a05763          	blez	a0,8000415c <filewrite+0xb4>
        f->off += r;
    80004152:	02092783          	lw	a5,32(s2)
    80004156:	9fa9                	addw	a5,a5,a0
    80004158:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000415c:	01893503          	ld	a0,24(s2)
    80004160:	994ff0ef          	jal	ra,800032f4 <iunlock>
      end_op();
    80004164:	9e5ff0ef          	jal	ra,80003b48 <end_op>

      if(r != n1){
    80004168:	009c1f63          	bne	s8,s1,80004186 <filewrite+0xde>
        // error from writei
        break;
      }
      i += r;
    8000416c:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80004170:	0149db63          	bge	s3,s4,80004186 <filewrite+0xde>
      int n1 = n - i;
    80004174:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    80004178:	84be                	mv	s1,a5
    8000417a:	2781                	sext.w	a5,a5
    8000417c:	fafb56e3          	bge	s6,a5,80004128 <filewrite+0x80>
    80004180:	84de                	mv	s1,s7
    80004182:	b75d                	j	80004128 <filewrite+0x80>
    int i = 0;
    80004184:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    80004186:	013a1f63          	bne	s4,s3,800041a4 <filewrite+0xfc>
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000418a:	8552                	mv	a0,s4
    8000418c:	60a6                	ld	ra,72(sp)
    8000418e:	6406                	ld	s0,64(sp)
    80004190:	74e2                	ld	s1,56(sp)
    80004192:	7942                	ld	s2,48(sp)
    80004194:	79a2                	ld	s3,40(sp)
    80004196:	7a02                	ld	s4,32(sp)
    80004198:	6ae2                	ld	s5,24(sp)
    8000419a:	6b42                	ld	s6,16(sp)
    8000419c:	6ba2                	ld	s7,8(sp)
    8000419e:	6c02                	ld	s8,0(sp)
    800041a0:	6161                	addi	sp,sp,80
    800041a2:	8082                	ret
    ret = (i == n ? n : -1);
    800041a4:	5a7d                	li	s4,-1
    800041a6:	b7d5                	j	8000418a <filewrite+0xe2>
    panic("filewrite");
    800041a8:	00003517          	auipc	a0,0x3
    800041ac:	64050513          	addi	a0,a0,1600 # 800077e8 <syscall_names+0x270>
    800041b0:	e30fc0ef          	jal	ra,800007e0 <panic>
    return -1;
    800041b4:	5a7d                	li	s4,-1
    800041b6:	bfd1                	j	8000418a <filewrite+0xe2>
      return -1;
    800041b8:	5a7d                	li	s4,-1
    800041ba:	bfc1                	j	8000418a <filewrite+0xe2>
    800041bc:	5a7d                	li	s4,-1
    800041be:	b7f1                	j	8000418a <filewrite+0xe2>

00000000800041c0 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800041c0:	7179                	addi	sp,sp,-48
    800041c2:	f406                	sd	ra,40(sp)
    800041c4:	f022                	sd	s0,32(sp)
    800041c6:	ec26                	sd	s1,24(sp)
    800041c8:	e84a                	sd	s2,16(sp)
    800041ca:	e44e                	sd	s3,8(sp)
    800041cc:	e052                	sd	s4,0(sp)
    800041ce:	1800                	addi	s0,sp,48
    800041d0:	84aa                	mv	s1,a0
    800041d2:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800041d4:	0005b023          	sd	zero,0(a1)
    800041d8:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800041dc:	c75ff0ef          	jal	ra,80003e50 <filealloc>
    800041e0:	e088                	sd	a0,0(s1)
    800041e2:	cd35                	beqz	a0,8000425e <pipealloc+0x9e>
    800041e4:	c6dff0ef          	jal	ra,80003e50 <filealloc>
    800041e8:	00aa3023          	sd	a0,0(s4)
    800041ec:	c52d                	beqz	a0,80004256 <pipealloc+0x96>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800041ee:	989fc0ef          	jal	ra,80000b76 <kalloc>
    800041f2:	892a                	mv	s2,a0
    800041f4:	cd31                	beqz	a0,80004250 <pipealloc+0x90>
    goto bad;
  pi->readopen = 1;
    800041f6:	4985                	li	s3,1
    800041f8:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800041fc:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004200:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004204:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004208:	00003597          	auipc	a1,0x3
    8000420c:	21858593          	addi	a1,a1,536 # 80007420 <states.0+0x1a8>
    80004210:	9b7fc0ef          	jal	ra,80000bc6 <initlock>
  (*f0)->type = FD_PIPE;
    80004214:	609c                	ld	a5,0(s1)
    80004216:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000421a:	609c                	ld	a5,0(s1)
    8000421c:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004220:	609c                	ld	a5,0(s1)
    80004222:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004226:	609c                	ld	a5,0(s1)
    80004228:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    8000422c:	000a3783          	ld	a5,0(s4)
    80004230:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004234:	000a3783          	ld	a5,0(s4)
    80004238:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    8000423c:	000a3783          	ld	a5,0(s4)
    80004240:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004244:	000a3783          	ld	a5,0(s4)
    80004248:	0127b823          	sd	s2,16(a5)
  return 0;
    8000424c:	4501                	li	a0,0
    8000424e:	a005                	j	8000426e <pipealloc+0xae>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004250:	6088                	ld	a0,0(s1)
    80004252:	e501                	bnez	a0,8000425a <pipealloc+0x9a>
    80004254:	a029                	j	8000425e <pipealloc+0x9e>
    80004256:	6088                	ld	a0,0(s1)
    80004258:	c11d                	beqz	a0,8000427e <pipealloc+0xbe>
    fileclose(*f0);
    8000425a:	c9bff0ef          	jal	ra,80003ef4 <fileclose>
  if(*f1)
    8000425e:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004262:	557d                	li	a0,-1
  if(*f1)
    80004264:	c789                	beqz	a5,8000426e <pipealloc+0xae>
    fileclose(*f1);
    80004266:	853e                	mv	a0,a5
    80004268:	c8dff0ef          	jal	ra,80003ef4 <fileclose>
  return -1;
    8000426c:	557d                	li	a0,-1
}
    8000426e:	70a2                	ld	ra,40(sp)
    80004270:	7402                	ld	s0,32(sp)
    80004272:	64e2                	ld	s1,24(sp)
    80004274:	6942                	ld	s2,16(sp)
    80004276:	69a2                	ld	s3,8(sp)
    80004278:	6a02                	ld	s4,0(sp)
    8000427a:	6145                	addi	sp,sp,48
    8000427c:	8082                	ret
  return -1;
    8000427e:	557d                	li	a0,-1
    80004280:	b7fd                	j	8000426e <pipealloc+0xae>

0000000080004282 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004282:	1101                	addi	sp,sp,-32
    80004284:	ec06                	sd	ra,24(sp)
    80004286:	e822                	sd	s0,16(sp)
    80004288:	e426                	sd	s1,8(sp)
    8000428a:	e04a                	sd	s2,0(sp)
    8000428c:	1000                	addi	s0,sp,32
    8000428e:	84aa                	mv	s1,a0
    80004290:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004292:	9b5fc0ef          	jal	ra,80000c46 <acquire>
  if(writable){
    80004296:	02090763          	beqz	s2,800042c4 <pipeclose+0x42>
    pi->writeopen = 0;
    8000429a:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    8000429e:	21848513          	addi	a0,s1,536
    800042a2:	c6ffd0ef          	jal	ra,80001f10 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800042a6:	2204b783          	ld	a5,544(s1)
    800042aa:	e785                	bnez	a5,800042d2 <pipeclose+0x50>
    release(&pi->lock);
    800042ac:	8526                	mv	a0,s1
    800042ae:	a31fc0ef          	jal	ra,80000cde <release>
    kfree((char*)pi);
    800042b2:	8526                	mv	a0,s1
    800042b4:	fe2fc0ef          	jal	ra,80000a96 <kfree>
  } else
    release(&pi->lock);
}
    800042b8:	60e2                	ld	ra,24(sp)
    800042ba:	6442                	ld	s0,16(sp)
    800042bc:	64a2                	ld	s1,8(sp)
    800042be:	6902                	ld	s2,0(sp)
    800042c0:	6105                	addi	sp,sp,32
    800042c2:	8082                	ret
    pi->readopen = 0;
    800042c4:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800042c8:	21c48513          	addi	a0,s1,540
    800042cc:	c45fd0ef          	jal	ra,80001f10 <wakeup>
    800042d0:	bfd9                	j	800042a6 <pipeclose+0x24>
    release(&pi->lock);
    800042d2:	8526                	mv	a0,s1
    800042d4:	a0bfc0ef          	jal	ra,80000cde <release>
}
    800042d8:	b7c5                	j	800042b8 <pipeclose+0x36>

00000000800042da <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800042da:	711d                	addi	sp,sp,-96
    800042dc:	ec86                	sd	ra,88(sp)
    800042de:	e8a2                	sd	s0,80(sp)
    800042e0:	e4a6                	sd	s1,72(sp)
    800042e2:	e0ca                	sd	s2,64(sp)
    800042e4:	fc4e                	sd	s3,56(sp)
    800042e6:	f852                	sd	s4,48(sp)
    800042e8:	f456                	sd	s5,40(sp)
    800042ea:	f05a                	sd	s6,32(sp)
    800042ec:	ec5e                	sd	s7,24(sp)
    800042ee:	e862                	sd	s8,16(sp)
    800042f0:	1080                	addi	s0,sp,96
    800042f2:	84aa                	mv	s1,a0
    800042f4:	8aae                	mv	s5,a1
    800042f6:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800042f8:	de6fd0ef          	jal	ra,800018de <myproc>
    800042fc:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800042fe:	8526                	mv	a0,s1
    80004300:	947fc0ef          	jal	ra,80000c46 <acquire>
  while(i < n){
    80004304:	09405c63          	blez	s4,8000439c <pipewrite+0xc2>
  int i = 0;
    80004308:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000430a:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000430c:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004310:	21c48b93          	addi	s7,s1,540
    80004314:	a81d                	j	8000434a <pipewrite+0x70>
      release(&pi->lock);
    80004316:	8526                	mv	a0,s1
    80004318:	9c7fc0ef          	jal	ra,80000cde <release>
      return -1;
    8000431c:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000431e:	854a                	mv	a0,s2
    80004320:	60e6                	ld	ra,88(sp)
    80004322:	6446                	ld	s0,80(sp)
    80004324:	64a6                	ld	s1,72(sp)
    80004326:	6906                	ld	s2,64(sp)
    80004328:	79e2                	ld	s3,56(sp)
    8000432a:	7a42                	ld	s4,48(sp)
    8000432c:	7aa2                	ld	s5,40(sp)
    8000432e:	7b02                	ld	s6,32(sp)
    80004330:	6be2                	ld	s7,24(sp)
    80004332:	6c42                	ld	s8,16(sp)
    80004334:	6125                	addi	sp,sp,96
    80004336:	8082                	ret
      wakeup(&pi->nread);
    80004338:	8562                	mv	a0,s8
    8000433a:	bd7fd0ef          	jal	ra,80001f10 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    8000433e:	85a6                	mv	a1,s1
    80004340:	855e                	mv	a0,s7
    80004342:	b83fd0ef          	jal	ra,80001ec4 <sleep>
  while(i < n){
    80004346:	05495c63          	bge	s2,s4,8000439e <pipewrite+0xc4>
    if(pi->readopen == 0 || killed(pr)){
    8000434a:	2204a783          	lw	a5,544(s1)
    8000434e:	d7e1                	beqz	a5,80004316 <pipewrite+0x3c>
    80004350:	854e                	mv	a0,s3
    80004352:	dabfd0ef          	jal	ra,800020fc <killed>
    80004356:	f161                	bnez	a0,80004316 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004358:	2184a783          	lw	a5,536(s1)
    8000435c:	21c4a703          	lw	a4,540(s1)
    80004360:	2007879b          	addiw	a5,a5,512
    80004364:	fcf70ae3          	beq	a4,a5,80004338 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004368:	4685                	li	a3,1
    8000436a:	01590633          	add	a2,s2,s5
    8000436e:	faf40593          	addi	a1,s0,-81
    80004372:	0509b503          	ld	a0,80(s3)
    80004376:	b7cfd0ef          	jal	ra,800016f2 <copyin>
    8000437a:	03650263          	beq	a0,s6,8000439e <pipewrite+0xc4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000437e:	21c4a783          	lw	a5,540(s1)
    80004382:	0017871b          	addiw	a4,a5,1
    80004386:	20e4ae23          	sw	a4,540(s1)
    8000438a:	1ff7f793          	andi	a5,a5,511
    8000438e:	97a6                	add	a5,a5,s1
    80004390:	faf44703          	lbu	a4,-81(s0)
    80004394:	00e78c23          	sb	a4,24(a5)
      i++;
    80004398:	2905                	addiw	s2,s2,1
    8000439a:	b775                	j	80004346 <pipewrite+0x6c>
  int i = 0;
    8000439c:	4901                	li	s2,0
  wakeup(&pi->nread);
    8000439e:	21848513          	addi	a0,s1,536
    800043a2:	b6ffd0ef          	jal	ra,80001f10 <wakeup>
  release(&pi->lock);
    800043a6:	8526                	mv	a0,s1
    800043a8:	937fc0ef          	jal	ra,80000cde <release>
  return i;
    800043ac:	bf8d                	j	8000431e <pipewrite+0x44>

00000000800043ae <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800043ae:	715d                	addi	sp,sp,-80
    800043b0:	e486                	sd	ra,72(sp)
    800043b2:	e0a2                	sd	s0,64(sp)
    800043b4:	fc26                	sd	s1,56(sp)
    800043b6:	f84a                	sd	s2,48(sp)
    800043b8:	f44e                	sd	s3,40(sp)
    800043ba:	f052                	sd	s4,32(sp)
    800043bc:	ec56                	sd	s5,24(sp)
    800043be:	e85a                	sd	s6,16(sp)
    800043c0:	0880                	addi	s0,sp,80
    800043c2:	84aa                	mv	s1,a0
    800043c4:	892e                	mv	s2,a1
    800043c6:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800043c8:	d16fd0ef          	jal	ra,800018de <myproc>
    800043cc:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800043ce:	8526                	mv	a0,s1
    800043d0:	877fc0ef          	jal	ra,80000c46 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800043d4:	2184a703          	lw	a4,536(s1)
    800043d8:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800043dc:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800043e0:	02f71363          	bne	a4,a5,80004406 <piperead+0x58>
    800043e4:	2244a783          	lw	a5,548(s1)
    800043e8:	cf99                	beqz	a5,80004406 <piperead+0x58>
    if(killed(pr)){
    800043ea:	8552                	mv	a0,s4
    800043ec:	d11fd0ef          	jal	ra,800020fc <killed>
    800043f0:	e141                	bnez	a0,80004470 <piperead+0xc2>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800043f2:	85a6                	mv	a1,s1
    800043f4:	854e                	mv	a0,s3
    800043f6:	acffd0ef          	jal	ra,80001ec4 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800043fa:	2184a703          	lw	a4,536(s1)
    800043fe:	21c4a783          	lw	a5,540(s1)
    80004402:	fef701e3          	beq	a4,a5,800043e4 <piperead+0x36>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004406:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004408:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000440a:	05505163          	blez	s5,8000444c <piperead+0x9e>
    if(pi->nread == pi->nwrite)
    8000440e:	2184a783          	lw	a5,536(s1)
    80004412:	21c4a703          	lw	a4,540(s1)
    80004416:	02f70b63          	beq	a4,a5,8000444c <piperead+0x9e>
    ch = pi->data[pi->nread++ % PIPESIZE];
    8000441a:	0017871b          	addiw	a4,a5,1
    8000441e:	20e4ac23          	sw	a4,536(s1)
    80004422:	1ff7f793          	andi	a5,a5,511
    80004426:	97a6                	add	a5,a5,s1
    80004428:	0187c783          	lbu	a5,24(a5)
    8000442c:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004430:	4685                	li	a3,1
    80004432:	fbf40613          	addi	a2,s0,-65
    80004436:	85ca                	mv	a1,s2
    80004438:	050a3503          	ld	a0,80(s4)
    8000443c:	9f0fd0ef          	jal	ra,8000162c <copyout>
    80004440:	01650663          	beq	a0,s6,8000444c <piperead+0x9e>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004444:	2985                	addiw	s3,s3,1
    80004446:	0905                	addi	s2,s2,1
    80004448:	fd3a93e3          	bne	s5,s3,8000440e <piperead+0x60>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    8000444c:	21c48513          	addi	a0,s1,540
    80004450:	ac1fd0ef          	jal	ra,80001f10 <wakeup>
  release(&pi->lock);
    80004454:	8526                	mv	a0,s1
    80004456:	889fc0ef          	jal	ra,80000cde <release>
  return i;
}
    8000445a:	854e                	mv	a0,s3
    8000445c:	60a6                	ld	ra,72(sp)
    8000445e:	6406                	ld	s0,64(sp)
    80004460:	74e2                	ld	s1,56(sp)
    80004462:	7942                	ld	s2,48(sp)
    80004464:	79a2                	ld	s3,40(sp)
    80004466:	7a02                	ld	s4,32(sp)
    80004468:	6ae2                	ld	s5,24(sp)
    8000446a:	6b42                	ld	s6,16(sp)
    8000446c:	6161                	addi	sp,sp,80
    8000446e:	8082                	ret
      release(&pi->lock);
    80004470:	8526                	mv	a0,s1
    80004472:	86dfc0ef          	jal	ra,80000cde <release>
      return -1;
    80004476:	59fd                	li	s3,-1
    80004478:	b7cd                	j	8000445a <piperead+0xac>

000000008000447a <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    8000447a:	1141                	addi	sp,sp,-16
    8000447c:	e422                	sd	s0,8(sp)
    8000447e:	0800                	addi	s0,sp,16
    80004480:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004482:	8905                	andi	a0,a0,1
    80004484:	c111                	beqz	a0,80004488 <flags2perm+0xe>
      perm = PTE_X;
    80004486:	4521                	li	a0,8
    if(flags & 0x2)
    80004488:	8b89                	andi	a5,a5,2
    8000448a:	c399                	beqz	a5,80004490 <flags2perm+0x16>
      perm |= PTE_W;
    8000448c:	00456513          	ori	a0,a0,4
    return perm;
}
    80004490:	6422                	ld	s0,8(sp)
    80004492:	0141                	addi	sp,sp,16
    80004494:	8082                	ret

0000000080004496 <exec>:

int
exec(char *path, char **argv)
{
    80004496:	de010113          	addi	sp,sp,-544
    8000449a:	20113c23          	sd	ra,536(sp)
    8000449e:	20813823          	sd	s0,528(sp)
    800044a2:	20913423          	sd	s1,520(sp)
    800044a6:	21213023          	sd	s2,512(sp)
    800044aa:	ffce                	sd	s3,504(sp)
    800044ac:	fbd2                	sd	s4,496(sp)
    800044ae:	f7d6                	sd	s5,488(sp)
    800044b0:	f3da                	sd	s6,480(sp)
    800044b2:	efde                	sd	s7,472(sp)
    800044b4:	ebe2                	sd	s8,464(sp)
    800044b6:	e7e6                	sd	s9,456(sp)
    800044b8:	e3ea                	sd	s10,448(sp)
    800044ba:	ff6e                	sd	s11,440(sp)
    800044bc:	1400                	addi	s0,sp,544
    800044be:	892a                	mv	s2,a0
    800044c0:	dea43423          	sd	a0,-536(s0)
    800044c4:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800044c8:	c16fd0ef          	jal	ra,800018de <myproc>
    800044cc:	84aa                	mv	s1,a0

  begin_op();
    800044ce:	e0aff0ef          	jal	ra,80003ad8 <begin_op>

  if((ip = namei(path)) == 0){
    800044d2:	854a                	mv	a0,s2
    800044d4:	c28ff0ef          	jal	ra,800038fc <namei>
    800044d8:	c13d                	beqz	a0,8000453e <exec+0xa8>
    800044da:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800044dc:	d6ffe0ef          	jal	ra,8000324a <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800044e0:	04000713          	li	a4,64
    800044e4:	4681                	li	a3,0
    800044e6:	e5040613          	addi	a2,s0,-432
    800044ea:	4581                	li	a1,0
    800044ec:	8556                	mv	a0,s5
    800044ee:	fadfe0ef          	jal	ra,8000349a <readi>
    800044f2:	04000793          	li	a5,64
    800044f6:	00f51a63          	bne	a0,a5,8000450a <exec+0x74>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    800044fa:	e5042703          	lw	a4,-432(s0)
    800044fe:	464c47b7          	lui	a5,0x464c4
    80004502:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004506:	04f70063          	beq	a4,a5,80004546 <exec+0xb0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    8000450a:	8556                	mv	a0,s5
    8000450c:	f45fe0ef          	jal	ra,80003450 <iunlockput>
    end_op();
    80004510:	e38ff0ef          	jal	ra,80003b48 <end_op>
  }
  return -1;
    80004514:	557d                	li	a0,-1
}
    80004516:	21813083          	ld	ra,536(sp)
    8000451a:	21013403          	ld	s0,528(sp)
    8000451e:	20813483          	ld	s1,520(sp)
    80004522:	20013903          	ld	s2,512(sp)
    80004526:	79fe                	ld	s3,504(sp)
    80004528:	7a5e                	ld	s4,496(sp)
    8000452a:	7abe                	ld	s5,488(sp)
    8000452c:	7b1e                	ld	s6,480(sp)
    8000452e:	6bfe                	ld	s7,472(sp)
    80004530:	6c5e                	ld	s8,464(sp)
    80004532:	6cbe                	ld	s9,456(sp)
    80004534:	6d1e                	ld	s10,448(sp)
    80004536:	7dfa                	ld	s11,440(sp)
    80004538:	22010113          	addi	sp,sp,544
    8000453c:	8082                	ret
    end_op();
    8000453e:	e0aff0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004542:	557d                	li	a0,-1
    80004544:	bfc9                	j	80004516 <exec+0x80>
  if((pagetable = proc_pagetable(p)) == 0)
    80004546:	8526                	mv	a0,s1
    80004548:	c9cfd0ef          	jal	ra,800019e4 <proc_pagetable>
    8000454c:	8b2a                	mv	s6,a0
    8000454e:	dd55                	beqz	a0,8000450a <exec+0x74>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004550:	e7042783          	lw	a5,-400(s0)
    80004554:	e8845703          	lhu	a4,-376(s0)
    80004558:	c325                	beqz	a4,800045b8 <exec+0x122>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000455a:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000455c:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80004560:	6a05                	lui	s4,0x1
    80004562:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80004566:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    8000456a:	6d85                	lui	s11,0x1
    8000456c:	7d7d                	lui	s10,0xfffff
    8000456e:	a411                	j	80004772 <exec+0x2dc>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004570:	00003517          	auipc	a0,0x3
    80004574:	28850513          	addi	a0,a0,648 # 800077f8 <syscall_names+0x280>
    80004578:	a68fc0ef          	jal	ra,800007e0 <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    8000457c:	874a                	mv	a4,s2
    8000457e:	009c86bb          	addw	a3,s9,s1
    80004582:	4581                	li	a1,0
    80004584:	8556                	mv	a0,s5
    80004586:	f15fe0ef          	jal	ra,8000349a <readi>
    8000458a:	2501                	sext.w	a0,a0
    8000458c:	18a91263          	bne	s2,a0,80004710 <exec+0x27a>
  for(i = 0; i < sz; i += PGSIZE){
    80004590:	009d84bb          	addw	s1,s11,s1
    80004594:	013d09bb          	addw	s3,s10,s3
    80004598:	1b74fd63          	bgeu	s1,s7,80004752 <exec+0x2bc>
    pa = walkaddr(pagetable, va + i);
    8000459c:	02049593          	slli	a1,s1,0x20
    800045a0:	9181                	srli	a1,a1,0x20
    800045a2:	95e2                	add	a1,a1,s8
    800045a4:	855a                	mv	a0,s6
    800045a6:	a8bfc0ef          	jal	ra,80001030 <walkaddr>
    800045aa:	862a                	mv	a2,a0
    if(pa == 0)
    800045ac:	d171                	beqz	a0,80004570 <exec+0xda>
      n = PGSIZE;
    800045ae:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    800045b0:	fd49f6e3          	bgeu	s3,s4,8000457c <exec+0xe6>
      n = sz - i;
    800045b4:	894e                	mv	s2,s3
    800045b6:	b7d9                	j	8000457c <exec+0xe6>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800045b8:	4901                	li	s2,0
  iunlockput(ip);
    800045ba:	8556                	mv	a0,s5
    800045bc:	e95fe0ef          	jal	ra,80003450 <iunlockput>
  end_op();
    800045c0:	d88ff0ef          	jal	ra,80003b48 <end_op>
  p = myproc();
    800045c4:	b1afd0ef          	jal	ra,800018de <myproc>
    800045c8:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    800045ca:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    800045ce:	6785                	lui	a5,0x1
    800045d0:	17fd                	addi	a5,a5,-1
    800045d2:	993e                	add	s2,s2,a5
    800045d4:	77fd                	lui	a5,0xfffff
    800045d6:	00f977b3          	and	a5,s2,a5
    800045da:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800045de:	4691                	li	a3,4
    800045e0:	6609                	lui	a2,0x2
    800045e2:	963e                	add	a2,a2,a5
    800045e4:	85be                	mv	a1,a5
    800045e6:	855a                	mv	a0,s6
    800045e8:	d13fc0ef          	jal	ra,800012fa <uvmalloc>
    800045ec:	8c2a                	mv	s8,a0
  ip = 0;
    800045ee:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800045f0:	12050063          	beqz	a0,80004710 <exec+0x27a>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800045f4:	75f9                	lui	a1,0xffffe
    800045f6:	95aa                	add	a1,a1,a0
    800045f8:	855a                	mv	a0,s6
    800045fa:	ec7fc0ef          	jal	ra,800014c0 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800045fe:	7afd                	lui	s5,0xfffff
    80004600:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80004602:	df043783          	ld	a5,-528(s0)
    80004606:	6388                	ld	a0,0(a5)
    80004608:	c135                	beqz	a0,8000466c <exec+0x1d6>
    8000460a:	e9040993          	addi	s3,s0,-368
    8000460e:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80004612:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004614:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004616:	87dfc0ef          	jal	ra,80000e92 <strlen>
    8000461a:	0015079b          	addiw	a5,a0,1
    8000461e:	40f90933          	sub	s2,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004622:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    80004626:	11596a63          	bltu	s2,s5,8000473a <exec+0x2a4>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    8000462a:	df043d83          	ld	s11,-528(s0)
    8000462e:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80004632:	8552                	mv	a0,s4
    80004634:	85ffc0ef          	jal	ra,80000e92 <strlen>
    80004638:	0015069b          	addiw	a3,a0,1
    8000463c:	8652                	mv	a2,s4
    8000463e:	85ca                	mv	a1,s2
    80004640:	855a                	mv	a0,s6
    80004642:	febfc0ef          	jal	ra,8000162c <copyout>
    80004646:	0e054e63          	bltz	a0,80004742 <exec+0x2ac>
    ustack[argc] = sp;
    8000464a:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    8000464e:	0485                	addi	s1,s1,1
    80004650:	008d8793          	addi	a5,s11,8
    80004654:	def43823          	sd	a5,-528(s0)
    80004658:	008db503          	ld	a0,8(s11)
    8000465c:	c911                	beqz	a0,80004670 <exec+0x1da>
    if(argc >= MAXARG)
    8000465e:	09a1                	addi	s3,s3,8
    80004660:	fb3c9be3          	bne	s9,s3,80004616 <exec+0x180>
  sz = sz1;
    80004664:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004668:	4a81                	li	s5,0
    8000466a:	a05d                	j	80004710 <exec+0x27a>
  sp = sz;
    8000466c:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    8000466e:	4481                	li	s1,0
  ustack[argc] = 0;
    80004670:	00349793          	slli	a5,s1,0x3
    80004674:	f9040713          	addi	a4,s0,-112
    80004678:	97ba                	add	a5,a5,a4
    8000467a:	f007b023          	sd	zero,-256(a5) # ffffffffffffef00 <end+0xffffffff7ffde018>
  sp -= (argc+1) * sizeof(uint64);
    8000467e:	00148693          	addi	a3,s1,1
    80004682:	068e                	slli	a3,a3,0x3
    80004684:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004688:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    8000468c:	01597663          	bgeu	s2,s5,80004698 <exec+0x202>
  sz = sz1;
    80004690:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004694:	4a81                	li	s5,0
    80004696:	a8ad                	j	80004710 <exec+0x27a>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004698:	e9040613          	addi	a2,s0,-368
    8000469c:	85ca                	mv	a1,s2
    8000469e:	855a                	mv	a0,s6
    800046a0:	f8dfc0ef          	jal	ra,8000162c <copyout>
    800046a4:	0a054363          	bltz	a0,8000474a <exec+0x2b4>
  p->trapframe->a1 = sp;
    800046a8:	058bb783          	ld	a5,88(s7) # 1058 <_entry-0x7fffefa8>
    800046ac:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    800046b0:	de843783          	ld	a5,-536(s0)
    800046b4:	0007c703          	lbu	a4,0(a5)
    800046b8:	cf11                	beqz	a4,800046d4 <exec+0x23e>
    800046ba:	0785                	addi	a5,a5,1
    if(*s == '/')
    800046bc:	02f00693          	li	a3,47
    800046c0:	a039                	j	800046ce <exec+0x238>
      last = s+1;
    800046c2:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    800046c6:	0785                	addi	a5,a5,1
    800046c8:	fff7c703          	lbu	a4,-1(a5)
    800046cc:	c701                	beqz	a4,800046d4 <exec+0x23e>
    if(*s == '/')
    800046ce:	fed71ce3          	bne	a4,a3,800046c6 <exec+0x230>
    800046d2:	bfc5                	j	800046c2 <exec+0x22c>
  safestrcpy(p->name, last, sizeof(p->name));
    800046d4:	4641                	li	a2,16
    800046d6:	de843583          	ld	a1,-536(s0)
    800046da:	158b8513          	addi	a0,s7,344
    800046de:	f82fc0ef          	jal	ra,80000e60 <safestrcpy>
  oldpagetable = p->pagetable;
    800046e2:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    800046e6:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    800046ea:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    800046ee:	058bb783          	ld	a5,88(s7)
    800046f2:	e6843703          	ld	a4,-408(s0)
    800046f6:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800046f8:	058bb783          	ld	a5,88(s7)
    800046fc:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004700:	85ea                	mv	a1,s10
    80004702:	b66fd0ef          	jal	ra,80001a68 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004706:	0004851b          	sext.w	a0,s1
    8000470a:	b531                	j	80004516 <exec+0x80>
    8000470c:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004710:	df843583          	ld	a1,-520(s0)
    80004714:	855a                	mv	a0,s6
    80004716:	b52fd0ef          	jal	ra,80001a68 <proc_freepagetable>
  if(ip){
    8000471a:	de0a98e3          	bnez	s5,8000450a <exec+0x74>
  return -1;
    8000471e:	557d                	li	a0,-1
    80004720:	bbdd                	j	80004516 <exec+0x80>
    80004722:	df243c23          	sd	s2,-520(s0)
    80004726:	b7ed                	j	80004710 <exec+0x27a>
    80004728:	df243c23          	sd	s2,-520(s0)
    8000472c:	b7d5                	j	80004710 <exec+0x27a>
    8000472e:	df243c23          	sd	s2,-520(s0)
    80004732:	bff9                	j	80004710 <exec+0x27a>
    80004734:	df243c23          	sd	s2,-520(s0)
    80004738:	bfe1                	j	80004710 <exec+0x27a>
  sz = sz1;
    8000473a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    8000473e:	4a81                	li	s5,0
    80004740:	bfc1                	j	80004710 <exec+0x27a>
  sz = sz1;
    80004742:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004746:	4a81                	li	s5,0
    80004748:	b7e1                	j	80004710 <exec+0x27a>
  sz = sz1;
    8000474a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    8000474e:	4a81                	li	s5,0
    80004750:	b7c1                	j	80004710 <exec+0x27a>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004752:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004756:	e0843783          	ld	a5,-504(s0)
    8000475a:	0017869b          	addiw	a3,a5,1
    8000475e:	e0d43423          	sd	a3,-504(s0)
    80004762:	e0043783          	ld	a5,-512(s0)
    80004766:	0387879b          	addiw	a5,a5,56
    8000476a:	e8845703          	lhu	a4,-376(s0)
    8000476e:	e4e6d6e3          	bge	a3,a4,800045ba <exec+0x124>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004772:	2781                	sext.w	a5,a5
    80004774:	e0f43023          	sd	a5,-512(s0)
    80004778:	03800713          	li	a4,56
    8000477c:	86be                	mv	a3,a5
    8000477e:	e1840613          	addi	a2,s0,-488
    80004782:	4581                	li	a1,0
    80004784:	8556                	mv	a0,s5
    80004786:	d15fe0ef          	jal	ra,8000349a <readi>
    8000478a:	03800793          	li	a5,56
    8000478e:	f6f51fe3          	bne	a0,a5,8000470c <exec+0x276>
    if(ph.type != ELF_PROG_LOAD)
    80004792:	e1842783          	lw	a5,-488(s0)
    80004796:	4705                	li	a4,1
    80004798:	fae79fe3          	bne	a5,a4,80004756 <exec+0x2c0>
    if(ph.memsz < ph.filesz)
    8000479c:	e4043483          	ld	s1,-448(s0)
    800047a0:	e3843783          	ld	a5,-456(s0)
    800047a4:	f6f4efe3          	bltu	s1,a5,80004722 <exec+0x28c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    800047a8:	e2843783          	ld	a5,-472(s0)
    800047ac:	94be                	add	s1,s1,a5
    800047ae:	f6f4ede3          	bltu	s1,a5,80004728 <exec+0x292>
    if(ph.vaddr % PGSIZE != 0)
    800047b2:	de043703          	ld	a4,-544(s0)
    800047b6:	8ff9                	and	a5,a5,a4
    800047b8:	fbbd                	bnez	a5,8000472e <exec+0x298>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    800047ba:	e1c42503          	lw	a0,-484(s0)
    800047be:	cbdff0ef          	jal	ra,8000447a <flags2perm>
    800047c2:	86aa                	mv	a3,a0
    800047c4:	8626                	mv	a2,s1
    800047c6:	85ca                	mv	a1,s2
    800047c8:	855a                	mv	a0,s6
    800047ca:	b31fc0ef          	jal	ra,800012fa <uvmalloc>
    800047ce:	dea43c23          	sd	a0,-520(s0)
    800047d2:	d12d                	beqz	a0,80004734 <exec+0x29e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800047d4:	e2843c03          	ld	s8,-472(s0)
    800047d8:	e2042c83          	lw	s9,-480(s0)
    800047dc:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    800047e0:	f60b89e3          	beqz	s7,80004752 <exec+0x2bc>
    800047e4:	89de                	mv	s3,s7
    800047e6:	4481                	li	s1,0
    800047e8:	bb55                	j	8000459c <exec+0x106>

00000000800047ea <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    800047ea:	7179                	addi	sp,sp,-48
    800047ec:	f406                	sd	ra,40(sp)
    800047ee:	f022                	sd	s0,32(sp)
    800047f0:	ec26                	sd	s1,24(sp)
    800047f2:	e84a                	sd	s2,16(sp)
    800047f4:	1800                	addi	s0,sp,48
    800047f6:	892e                	mv	s2,a1
    800047f8:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    800047fa:	fdc40593          	addi	a1,s0,-36
    800047fe:	fc7fd0ef          	jal	ra,800027c4 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004802:	fdc42703          	lw	a4,-36(s0)
    80004806:	47bd                	li	a5,15
    80004808:	02e7e963          	bltu	a5,a4,8000483a <argfd+0x50>
    8000480c:	8d2fd0ef          	jal	ra,800018de <myproc>
    80004810:	fdc42703          	lw	a4,-36(s0)
    80004814:	01a70793          	addi	a5,a4,26
    80004818:	078e                	slli	a5,a5,0x3
    8000481a:	953e                	add	a0,a0,a5
    8000481c:	611c                	ld	a5,0(a0)
    8000481e:	c385                	beqz	a5,8000483e <argfd+0x54>
    return -1;
  if(pfd)
    80004820:	00090463          	beqz	s2,80004828 <argfd+0x3e>
    *pfd = fd;
    80004824:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004828:	4501                	li	a0,0
  if(pf)
    8000482a:	c091                	beqz	s1,8000482e <argfd+0x44>
    *pf = f;
    8000482c:	e09c                	sd	a5,0(s1)
}
    8000482e:	70a2                	ld	ra,40(sp)
    80004830:	7402                	ld	s0,32(sp)
    80004832:	64e2                	ld	s1,24(sp)
    80004834:	6942                	ld	s2,16(sp)
    80004836:	6145                	addi	sp,sp,48
    80004838:	8082                	ret
    return -1;
    8000483a:	557d                	li	a0,-1
    8000483c:	bfcd                	j	8000482e <argfd+0x44>
    8000483e:	557d                	li	a0,-1
    80004840:	b7fd                	j	8000482e <argfd+0x44>

0000000080004842 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004842:	1101                	addi	sp,sp,-32
    80004844:	ec06                	sd	ra,24(sp)
    80004846:	e822                	sd	s0,16(sp)
    80004848:	e426                	sd	s1,8(sp)
    8000484a:	1000                	addi	s0,sp,32
    8000484c:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    8000484e:	890fd0ef          	jal	ra,800018de <myproc>
    80004852:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004854:	0d050793          	addi	a5,a0,208
    80004858:	4501                	li	a0,0
    8000485a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000485c:	6398                	ld	a4,0(a5)
    8000485e:	cb19                	beqz	a4,80004874 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004860:	2505                	addiw	a0,a0,1
    80004862:	07a1                	addi	a5,a5,8
    80004864:	fed51ce3          	bne	a0,a3,8000485c <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004868:	557d                	li	a0,-1
}
    8000486a:	60e2                	ld	ra,24(sp)
    8000486c:	6442                	ld	s0,16(sp)
    8000486e:	64a2                	ld	s1,8(sp)
    80004870:	6105                	addi	sp,sp,32
    80004872:	8082                	ret
      p->ofile[fd] = f;
    80004874:	01a50793          	addi	a5,a0,26
    80004878:	078e                	slli	a5,a5,0x3
    8000487a:	963e                	add	a2,a2,a5
    8000487c:	e204                	sd	s1,0(a2)
      return fd;
    8000487e:	b7f5                	j	8000486a <fdalloc+0x28>

0000000080004880 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004880:	715d                	addi	sp,sp,-80
    80004882:	e486                	sd	ra,72(sp)
    80004884:	e0a2                	sd	s0,64(sp)
    80004886:	fc26                	sd	s1,56(sp)
    80004888:	f84a                	sd	s2,48(sp)
    8000488a:	f44e                	sd	s3,40(sp)
    8000488c:	f052                	sd	s4,32(sp)
    8000488e:	ec56                	sd	s5,24(sp)
    80004890:	e85a                	sd	s6,16(sp)
    80004892:	0880                	addi	s0,sp,80
    80004894:	8b2e                	mv	s6,a1
    80004896:	89b2                	mv	s3,a2
    80004898:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    8000489a:	fb040593          	addi	a1,s0,-80
    8000489e:	878ff0ef          	jal	ra,80003916 <nameiparent>
    800048a2:	84aa                	mv	s1,a0
    800048a4:	10050b63          	beqz	a0,800049ba <create+0x13a>
    return 0;

  ilock(dp);
    800048a8:	9a3fe0ef          	jal	ra,8000324a <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800048ac:	4601                	li	a2,0
    800048ae:	fb040593          	addi	a1,s0,-80
    800048b2:	8526                	mv	a0,s1
    800048b4:	de3fe0ef          	jal	ra,80003696 <dirlookup>
    800048b8:	8aaa                	mv	s5,a0
    800048ba:	c521                	beqz	a0,80004902 <create+0x82>
    iunlockput(dp);
    800048bc:	8526                	mv	a0,s1
    800048be:	b93fe0ef          	jal	ra,80003450 <iunlockput>
    ilock(ip);
    800048c2:	8556                	mv	a0,s5
    800048c4:	987fe0ef          	jal	ra,8000324a <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    800048c8:	000b059b          	sext.w	a1,s6
    800048cc:	4789                	li	a5,2
    800048ce:	02f59563          	bne	a1,a5,800048f8 <create+0x78>
    800048d2:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffde15c>
    800048d6:	37f9                	addiw	a5,a5,-2
    800048d8:	17c2                	slli	a5,a5,0x30
    800048da:	93c1                	srli	a5,a5,0x30
    800048dc:	4705                	li	a4,1
    800048de:	00f76d63          	bltu	a4,a5,800048f8 <create+0x78>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    800048e2:	8556                	mv	a0,s5
    800048e4:	60a6                	ld	ra,72(sp)
    800048e6:	6406                	ld	s0,64(sp)
    800048e8:	74e2                	ld	s1,56(sp)
    800048ea:	7942                	ld	s2,48(sp)
    800048ec:	79a2                	ld	s3,40(sp)
    800048ee:	7a02                	ld	s4,32(sp)
    800048f0:	6ae2                	ld	s5,24(sp)
    800048f2:	6b42                	ld	s6,16(sp)
    800048f4:	6161                	addi	sp,sp,80
    800048f6:	8082                	ret
    iunlockput(ip);
    800048f8:	8556                	mv	a0,s5
    800048fa:	b57fe0ef          	jal	ra,80003450 <iunlockput>
    return 0;
    800048fe:	4a81                	li	s5,0
    80004900:	b7cd                	j	800048e2 <create+0x62>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004902:	85da                	mv	a1,s6
    80004904:	4088                	lw	a0,0(s1)
    80004906:	fdcfe0ef          	jal	ra,800030e2 <ialloc>
    8000490a:	8a2a                	mv	s4,a0
    8000490c:	cd1d                	beqz	a0,8000494a <create+0xca>
  ilock(ip);
    8000490e:	93dfe0ef          	jal	ra,8000324a <ilock>
  ip->major = major;
    80004912:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004916:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    8000491a:	4905                	li	s2,1
    8000491c:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004920:	8552                	mv	a0,s4
    80004922:	877fe0ef          	jal	ra,80003198 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004926:	000b059b          	sext.w	a1,s6
    8000492a:	03258563          	beq	a1,s2,80004954 <create+0xd4>
  if(dirlink(dp, name, ip->inum) < 0)
    8000492e:	004a2603          	lw	a2,4(s4)
    80004932:	fb040593          	addi	a1,s0,-80
    80004936:	8526                	mv	a0,s1
    80004938:	f2bfe0ef          	jal	ra,80003862 <dirlink>
    8000493c:	06054363          	bltz	a0,800049a2 <create+0x122>
  iunlockput(dp);
    80004940:	8526                	mv	a0,s1
    80004942:	b0ffe0ef          	jal	ra,80003450 <iunlockput>
  return ip;
    80004946:	8ad2                	mv	s5,s4
    80004948:	bf69                	j	800048e2 <create+0x62>
    iunlockput(dp);
    8000494a:	8526                	mv	a0,s1
    8000494c:	b05fe0ef          	jal	ra,80003450 <iunlockput>
    return 0;
    80004950:	8ad2                	mv	s5,s4
    80004952:	bf41                	j	800048e2 <create+0x62>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004954:	004a2603          	lw	a2,4(s4)
    80004958:	00003597          	auipc	a1,0x3
    8000495c:	ec058593          	addi	a1,a1,-320 # 80007818 <syscall_names+0x2a0>
    80004960:	8552                	mv	a0,s4
    80004962:	f01fe0ef          	jal	ra,80003862 <dirlink>
    80004966:	02054e63          	bltz	a0,800049a2 <create+0x122>
    8000496a:	40d0                	lw	a2,4(s1)
    8000496c:	00003597          	auipc	a1,0x3
    80004970:	eb458593          	addi	a1,a1,-332 # 80007820 <syscall_names+0x2a8>
    80004974:	8552                	mv	a0,s4
    80004976:	eedfe0ef          	jal	ra,80003862 <dirlink>
    8000497a:	02054463          	bltz	a0,800049a2 <create+0x122>
  if(dirlink(dp, name, ip->inum) < 0)
    8000497e:	004a2603          	lw	a2,4(s4)
    80004982:	fb040593          	addi	a1,s0,-80
    80004986:	8526                	mv	a0,s1
    80004988:	edbfe0ef          	jal	ra,80003862 <dirlink>
    8000498c:	00054b63          	bltz	a0,800049a2 <create+0x122>
    dp->nlink++;  // for ".."
    80004990:	04a4d783          	lhu	a5,74(s1)
    80004994:	2785                	addiw	a5,a5,1
    80004996:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000499a:	8526                	mv	a0,s1
    8000499c:	ffcfe0ef          	jal	ra,80003198 <iupdate>
    800049a0:	b745                	j	80004940 <create+0xc0>
  ip->nlink = 0;
    800049a2:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    800049a6:	8552                	mv	a0,s4
    800049a8:	ff0fe0ef          	jal	ra,80003198 <iupdate>
  iunlockput(ip);
    800049ac:	8552                	mv	a0,s4
    800049ae:	aa3fe0ef          	jal	ra,80003450 <iunlockput>
  iunlockput(dp);
    800049b2:	8526                	mv	a0,s1
    800049b4:	a9dfe0ef          	jal	ra,80003450 <iunlockput>
  return 0;
    800049b8:	b72d                	j	800048e2 <create+0x62>
    return 0;
    800049ba:	8aaa                	mv	s5,a0
    800049bc:	b71d                	j	800048e2 <create+0x62>

00000000800049be <sys_dup>:
{
    800049be:	7179                	addi	sp,sp,-48
    800049c0:	f406                	sd	ra,40(sp)
    800049c2:	f022                	sd	s0,32(sp)
    800049c4:	ec26                	sd	s1,24(sp)
    800049c6:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    800049c8:	fd840613          	addi	a2,s0,-40
    800049cc:	4581                	li	a1,0
    800049ce:	4501                	li	a0,0
    800049d0:	e1bff0ef          	jal	ra,800047ea <argfd>
    return -1;
    800049d4:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    800049d6:	00054f63          	bltz	a0,800049f4 <sys_dup+0x36>
  if((fd=fdalloc(f)) < 0)
    800049da:	fd843503          	ld	a0,-40(s0)
    800049de:	e65ff0ef          	jal	ra,80004842 <fdalloc>
    800049e2:	84aa                	mv	s1,a0
    return -1;
    800049e4:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    800049e6:	00054763          	bltz	a0,800049f4 <sys_dup+0x36>
  filedup(f);
    800049ea:	fd843503          	ld	a0,-40(s0)
    800049ee:	cc0ff0ef          	jal	ra,80003eae <filedup>
  return fd;
    800049f2:	87a6                	mv	a5,s1
}
    800049f4:	853e                	mv	a0,a5
    800049f6:	70a2                	ld	ra,40(sp)
    800049f8:	7402                	ld	s0,32(sp)
    800049fa:	64e2                	ld	s1,24(sp)
    800049fc:	6145                	addi	sp,sp,48
    800049fe:	8082                	ret

0000000080004a00 <sys_read>:
{
    80004a00:	7179                	addi	sp,sp,-48
    80004a02:	f406                	sd	ra,40(sp)
    80004a04:	f022                	sd	s0,32(sp)
    80004a06:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004a08:	fd840593          	addi	a1,s0,-40
    80004a0c:	4505                	li	a0,1
    80004a0e:	dd3fd0ef          	jal	ra,800027e0 <argaddr>
  argint(2, &n);
    80004a12:	fe440593          	addi	a1,s0,-28
    80004a16:	4509                	li	a0,2
    80004a18:	dadfd0ef          	jal	ra,800027c4 <argint>
  if(argfd(0, 0, &f) < 0)
    80004a1c:	fe840613          	addi	a2,s0,-24
    80004a20:	4581                	li	a1,0
    80004a22:	4501                	li	a0,0
    80004a24:	dc7ff0ef          	jal	ra,800047ea <argfd>
    80004a28:	87aa                	mv	a5,a0
    return -1;
    80004a2a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004a2c:	0007ca63          	bltz	a5,80004a40 <sys_read+0x40>
  return fileread(f, p, n);
    80004a30:	fe442603          	lw	a2,-28(s0)
    80004a34:	fd843583          	ld	a1,-40(s0)
    80004a38:	fe843503          	ld	a0,-24(s0)
    80004a3c:	dbeff0ef          	jal	ra,80003ffa <fileread>
}
    80004a40:	70a2                	ld	ra,40(sp)
    80004a42:	7402                	ld	s0,32(sp)
    80004a44:	6145                	addi	sp,sp,48
    80004a46:	8082                	ret

0000000080004a48 <sys_write>:
{
    80004a48:	7179                	addi	sp,sp,-48
    80004a4a:	f406                	sd	ra,40(sp)
    80004a4c:	f022                	sd	s0,32(sp)
    80004a4e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004a50:	fd840593          	addi	a1,s0,-40
    80004a54:	4505                	li	a0,1
    80004a56:	d8bfd0ef          	jal	ra,800027e0 <argaddr>
  argint(2, &n);
    80004a5a:	fe440593          	addi	a1,s0,-28
    80004a5e:	4509                	li	a0,2
    80004a60:	d65fd0ef          	jal	ra,800027c4 <argint>
  if(argfd(0, 0, &f) < 0)
    80004a64:	fe840613          	addi	a2,s0,-24
    80004a68:	4581                	li	a1,0
    80004a6a:	4501                	li	a0,0
    80004a6c:	d7fff0ef          	jal	ra,800047ea <argfd>
    80004a70:	87aa                	mv	a5,a0
    return -1;
    80004a72:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004a74:	0007ca63          	bltz	a5,80004a88 <sys_write+0x40>
  return filewrite(f, p, n);
    80004a78:	fe442603          	lw	a2,-28(s0)
    80004a7c:	fd843583          	ld	a1,-40(s0)
    80004a80:	fe843503          	ld	a0,-24(s0)
    80004a84:	e24ff0ef          	jal	ra,800040a8 <filewrite>
}
    80004a88:	70a2                	ld	ra,40(sp)
    80004a8a:	7402                	ld	s0,32(sp)
    80004a8c:	6145                	addi	sp,sp,48
    80004a8e:	8082                	ret

0000000080004a90 <sys_close>:
{
    80004a90:	1101                	addi	sp,sp,-32
    80004a92:	ec06                	sd	ra,24(sp)
    80004a94:	e822                	sd	s0,16(sp)
    80004a96:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004a98:	fe040613          	addi	a2,s0,-32
    80004a9c:	fec40593          	addi	a1,s0,-20
    80004aa0:	4501                	li	a0,0
    80004aa2:	d49ff0ef          	jal	ra,800047ea <argfd>
    return -1;
    80004aa6:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004aa8:	02054063          	bltz	a0,80004ac8 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004aac:	e33fc0ef          	jal	ra,800018de <myproc>
    80004ab0:	fec42783          	lw	a5,-20(s0)
    80004ab4:	07e9                	addi	a5,a5,26
    80004ab6:	078e                	slli	a5,a5,0x3
    80004ab8:	97aa                	add	a5,a5,a0
    80004aba:	0007b023          	sd	zero,0(a5)
  fileclose(f);
    80004abe:	fe043503          	ld	a0,-32(s0)
    80004ac2:	c32ff0ef          	jal	ra,80003ef4 <fileclose>
  return 0;
    80004ac6:	4781                	li	a5,0
}
    80004ac8:	853e                	mv	a0,a5
    80004aca:	60e2                	ld	ra,24(sp)
    80004acc:	6442                	ld	s0,16(sp)
    80004ace:	6105                	addi	sp,sp,32
    80004ad0:	8082                	ret

0000000080004ad2 <sys_fstat>:
{
    80004ad2:	1101                	addi	sp,sp,-32
    80004ad4:	ec06                	sd	ra,24(sp)
    80004ad6:	e822                	sd	s0,16(sp)
    80004ad8:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004ada:	fe040593          	addi	a1,s0,-32
    80004ade:	4505                	li	a0,1
    80004ae0:	d01fd0ef          	jal	ra,800027e0 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004ae4:	fe840613          	addi	a2,s0,-24
    80004ae8:	4581                	li	a1,0
    80004aea:	4501                	li	a0,0
    80004aec:	cffff0ef          	jal	ra,800047ea <argfd>
    80004af0:	87aa                	mv	a5,a0
    return -1;
    80004af2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004af4:	0007c863          	bltz	a5,80004b04 <sys_fstat+0x32>
  return filestat(f, st);
    80004af8:	fe043583          	ld	a1,-32(s0)
    80004afc:	fe843503          	ld	a0,-24(s0)
    80004b00:	c9cff0ef          	jal	ra,80003f9c <filestat>
}
    80004b04:	60e2                	ld	ra,24(sp)
    80004b06:	6442                	ld	s0,16(sp)
    80004b08:	6105                	addi	sp,sp,32
    80004b0a:	8082                	ret

0000000080004b0c <sys_link>:
{
    80004b0c:	7169                	addi	sp,sp,-304
    80004b0e:	f606                	sd	ra,296(sp)
    80004b10:	f222                	sd	s0,288(sp)
    80004b12:	ee26                	sd	s1,280(sp)
    80004b14:	ea4a                	sd	s2,272(sp)
    80004b16:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004b18:	08000613          	li	a2,128
    80004b1c:	ed040593          	addi	a1,s0,-304
    80004b20:	4501                	li	a0,0
    80004b22:	cdbfd0ef          	jal	ra,800027fc <argstr>
    return -1;
    80004b26:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004b28:	0c054663          	bltz	a0,80004bf4 <sys_link+0xe8>
    80004b2c:	08000613          	li	a2,128
    80004b30:	f5040593          	addi	a1,s0,-176
    80004b34:	4505                	li	a0,1
    80004b36:	cc7fd0ef          	jal	ra,800027fc <argstr>
    return -1;
    80004b3a:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004b3c:	0a054c63          	bltz	a0,80004bf4 <sys_link+0xe8>
  begin_op();
    80004b40:	f99fe0ef          	jal	ra,80003ad8 <begin_op>
  if((ip = namei(old)) == 0){
    80004b44:	ed040513          	addi	a0,s0,-304
    80004b48:	db5fe0ef          	jal	ra,800038fc <namei>
    80004b4c:	84aa                	mv	s1,a0
    80004b4e:	c525                	beqz	a0,80004bb6 <sys_link+0xaa>
  ilock(ip);
    80004b50:	efafe0ef          	jal	ra,8000324a <ilock>
  if(ip->type == T_DIR){
    80004b54:	04449703          	lh	a4,68(s1)
    80004b58:	4785                	li	a5,1
    80004b5a:	06f70263          	beq	a4,a5,80004bbe <sys_link+0xb2>
  ip->nlink++;
    80004b5e:	04a4d783          	lhu	a5,74(s1)
    80004b62:	2785                	addiw	a5,a5,1
    80004b64:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004b68:	8526                	mv	a0,s1
    80004b6a:	e2efe0ef          	jal	ra,80003198 <iupdate>
  iunlock(ip);
    80004b6e:	8526                	mv	a0,s1
    80004b70:	f84fe0ef          	jal	ra,800032f4 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004b74:	fd040593          	addi	a1,s0,-48
    80004b78:	f5040513          	addi	a0,s0,-176
    80004b7c:	d9bfe0ef          	jal	ra,80003916 <nameiparent>
    80004b80:	892a                	mv	s2,a0
    80004b82:	c921                	beqz	a0,80004bd2 <sys_link+0xc6>
  ilock(dp);
    80004b84:	ec6fe0ef          	jal	ra,8000324a <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004b88:	00092703          	lw	a4,0(s2)
    80004b8c:	409c                	lw	a5,0(s1)
    80004b8e:	02f71f63          	bne	a4,a5,80004bcc <sys_link+0xc0>
    80004b92:	40d0                	lw	a2,4(s1)
    80004b94:	fd040593          	addi	a1,s0,-48
    80004b98:	854a                	mv	a0,s2
    80004b9a:	cc9fe0ef          	jal	ra,80003862 <dirlink>
    80004b9e:	02054763          	bltz	a0,80004bcc <sys_link+0xc0>
  iunlockput(dp);
    80004ba2:	854a                	mv	a0,s2
    80004ba4:	8adfe0ef          	jal	ra,80003450 <iunlockput>
  iput(ip);
    80004ba8:	8526                	mv	a0,s1
    80004baa:	81ffe0ef          	jal	ra,800033c8 <iput>
  end_op();
    80004bae:	f9bfe0ef          	jal	ra,80003b48 <end_op>
  return 0;
    80004bb2:	4781                	li	a5,0
    80004bb4:	a081                	j	80004bf4 <sys_link+0xe8>
    end_op();
    80004bb6:	f93fe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004bba:	57fd                	li	a5,-1
    80004bbc:	a825                	j	80004bf4 <sys_link+0xe8>
    iunlockput(ip);
    80004bbe:	8526                	mv	a0,s1
    80004bc0:	891fe0ef          	jal	ra,80003450 <iunlockput>
    end_op();
    80004bc4:	f85fe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004bc8:	57fd                	li	a5,-1
    80004bca:	a02d                	j	80004bf4 <sys_link+0xe8>
    iunlockput(dp);
    80004bcc:	854a                	mv	a0,s2
    80004bce:	883fe0ef          	jal	ra,80003450 <iunlockput>
  ilock(ip);
    80004bd2:	8526                	mv	a0,s1
    80004bd4:	e76fe0ef          	jal	ra,8000324a <ilock>
  ip->nlink--;
    80004bd8:	04a4d783          	lhu	a5,74(s1)
    80004bdc:	37fd                	addiw	a5,a5,-1
    80004bde:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004be2:	8526                	mv	a0,s1
    80004be4:	db4fe0ef          	jal	ra,80003198 <iupdate>
  iunlockput(ip);
    80004be8:	8526                	mv	a0,s1
    80004bea:	867fe0ef          	jal	ra,80003450 <iunlockput>
  end_op();
    80004bee:	f5bfe0ef          	jal	ra,80003b48 <end_op>
  return -1;
    80004bf2:	57fd                	li	a5,-1
}
    80004bf4:	853e                	mv	a0,a5
    80004bf6:	70b2                	ld	ra,296(sp)
    80004bf8:	7412                	ld	s0,288(sp)
    80004bfa:	64f2                	ld	s1,280(sp)
    80004bfc:	6952                	ld	s2,272(sp)
    80004bfe:	6155                	addi	sp,sp,304
    80004c00:	8082                	ret

0000000080004c02 <sys_unlink>:
{
    80004c02:	7151                	addi	sp,sp,-240
    80004c04:	f586                	sd	ra,232(sp)
    80004c06:	f1a2                	sd	s0,224(sp)
    80004c08:	eda6                	sd	s1,216(sp)
    80004c0a:	e9ca                	sd	s2,208(sp)
    80004c0c:	e5ce                	sd	s3,200(sp)
    80004c0e:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004c10:	08000613          	li	a2,128
    80004c14:	f3040593          	addi	a1,s0,-208
    80004c18:	4501                	li	a0,0
    80004c1a:	be3fd0ef          	jal	ra,800027fc <argstr>
    80004c1e:	12054b63          	bltz	a0,80004d54 <sys_unlink+0x152>
  begin_op();
    80004c22:	eb7fe0ef          	jal	ra,80003ad8 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004c26:	fb040593          	addi	a1,s0,-80
    80004c2a:	f3040513          	addi	a0,s0,-208
    80004c2e:	ce9fe0ef          	jal	ra,80003916 <nameiparent>
    80004c32:	84aa                	mv	s1,a0
    80004c34:	c54d                	beqz	a0,80004cde <sys_unlink+0xdc>
  ilock(dp);
    80004c36:	e14fe0ef          	jal	ra,8000324a <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004c3a:	00003597          	auipc	a1,0x3
    80004c3e:	bde58593          	addi	a1,a1,-1058 # 80007818 <syscall_names+0x2a0>
    80004c42:	fb040513          	addi	a0,s0,-80
    80004c46:	a3bfe0ef          	jal	ra,80003680 <namecmp>
    80004c4a:	10050a63          	beqz	a0,80004d5e <sys_unlink+0x15c>
    80004c4e:	00003597          	auipc	a1,0x3
    80004c52:	bd258593          	addi	a1,a1,-1070 # 80007820 <syscall_names+0x2a8>
    80004c56:	fb040513          	addi	a0,s0,-80
    80004c5a:	a27fe0ef          	jal	ra,80003680 <namecmp>
    80004c5e:	10050063          	beqz	a0,80004d5e <sys_unlink+0x15c>
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004c62:	f2c40613          	addi	a2,s0,-212
    80004c66:	fb040593          	addi	a1,s0,-80
    80004c6a:	8526                	mv	a0,s1
    80004c6c:	a2bfe0ef          	jal	ra,80003696 <dirlookup>
    80004c70:	892a                	mv	s2,a0
    80004c72:	0e050663          	beqz	a0,80004d5e <sys_unlink+0x15c>
  ilock(ip);
    80004c76:	dd4fe0ef          	jal	ra,8000324a <ilock>
  if(ip->nlink < 1)
    80004c7a:	04a91783          	lh	a5,74(s2)
    80004c7e:	06f05463          	blez	a5,80004ce6 <sys_unlink+0xe4>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004c82:	04491703          	lh	a4,68(s2)
    80004c86:	4785                	li	a5,1
    80004c88:	06f70563          	beq	a4,a5,80004cf2 <sys_unlink+0xf0>
  memset(&de, 0, sizeof(de));
    80004c8c:	4641                	li	a2,16
    80004c8e:	4581                	li	a1,0
    80004c90:	fc040513          	addi	a0,s0,-64
    80004c94:	886fc0ef          	jal	ra,80000d1a <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004c98:	4741                	li	a4,16
    80004c9a:	f2c42683          	lw	a3,-212(s0)
    80004c9e:	fc040613          	addi	a2,s0,-64
    80004ca2:	4581                	li	a1,0
    80004ca4:	8526                	mv	a0,s1
    80004ca6:	8d9fe0ef          	jal	ra,8000357e <writei>
    80004caa:	47c1                	li	a5,16
    80004cac:	08f51563          	bne	a0,a5,80004d36 <sys_unlink+0x134>
  if(ip->type == T_DIR){
    80004cb0:	04491703          	lh	a4,68(s2)
    80004cb4:	4785                	li	a5,1
    80004cb6:	08f70663          	beq	a4,a5,80004d42 <sys_unlink+0x140>
  iunlockput(dp);
    80004cba:	8526                	mv	a0,s1
    80004cbc:	f94fe0ef          	jal	ra,80003450 <iunlockput>
  ip->nlink--;
    80004cc0:	04a95783          	lhu	a5,74(s2)
    80004cc4:	37fd                	addiw	a5,a5,-1
    80004cc6:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004cca:	854a                	mv	a0,s2
    80004ccc:	cccfe0ef          	jal	ra,80003198 <iupdate>
  iunlockput(ip);
    80004cd0:	854a                	mv	a0,s2
    80004cd2:	f7efe0ef          	jal	ra,80003450 <iunlockput>
  end_op();
    80004cd6:	e73fe0ef          	jal	ra,80003b48 <end_op>
  return 0;
    80004cda:	4501                	li	a0,0
    80004cdc:	a079                	j	80004d6a <sys_unlink+0x168>
    end_op();
    80004cde:	e6bfe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004ce2:	557d                	li	a0,-1
    80004ce4:	a059                	j	80004d6a <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004ce6:	00003517          	auipc	a0,0x3
    80004cea:	b4250513          	addi	a0,a0,-1214 # 80007828 <syscall_names+0x2b0>
    80004cee:	af3fb0ef          	jal	ra,800007e0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004cf2:	04c92703          	lw	a4,76(s2)
    80004cf6:	02000793          	li	a5,32
    80004cfa:	f8e7f9e3          	bgeu	a5,a4,80004c8c <sys_unlink+0x8a>
    80004cfe:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004d02:	4741                	li	a4,16
    80004d04:	86ce                	mv	a3,s3
    80004d06:	f1840613          	addi	a2,s0,-232
    80004d0a:	4581                	li	a1,0
    80004d0c:	854a                	mv	a0,s2
    80004d0e:	f8cfe0ef          	jal	ra,8000349a <readi>
    80004d12:	47c1                	li	a5,16
    80004d14:	00f51b63          	bne	a0,a5,80004d2a <sys_unlink+0x128>
    if(de.inum != 0)
    80004d18:	f1845783          	lhu	a5,-232(s0)
    80004d1c:	ef95                	bnez	a5,80004d58 <sys_unlink+0x156>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004d1e:	29c1                	addiw	s3,s3,16
    80004d20:	04c92783          	lw	a5,76(s2)
    80004d24:	fcf9efe3          	bltu	s3,a5,80004d02 <sys_unlink+0x100>
    80004d28:	b795                	j	80004c8c <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004d2a:	00003517          	auipc	a0,0x3
    80004d2e:	b1650513          	addi	a0,a0,-1258 # 80007840 <syscall_names+0x2c8>
    80004d32:	aaffb0ef          	jal	ra,800007e0 <panic>
    panic("unlink: writei");
    80004d36:	00003517          	auipc	a0,0x3
    80004d3a:	b2250513          	addi	a0,a0,-1246 # 80007858 <syscall_names+0x2e0>
    80004d3e:	aa3fb0ef          	jal	ra,800007e0 <panic>
    dp->nlink--;
    80004d42:	04a4d783          	lhu	a5,74(s1)
    80004d46:	37fd                	addiw	a5,a5,-1
    80004d48:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004d4c:	8526                	mv	a0,s1
    80004d4e:	c4afe0ef          	jal	ra,80003198 <iupdate>
    80004d52:	b7a5                	j	80004cba <sys_unlink+0xb8>
    return -1;
    80004d54:	557d                	li	a0,-1
    80004d56:	a811                	j	80004d6a <sys_unlink+0x168>
    iunlockput(ip);
    80004d58:	854a                	mv	a0,s2
    80004d5a:	ef6fe0ef          	jal	ra,80003450 <iunlockput>
  iunlockput(dp);
    80004d5e:	8526                	mv	a0,s1
    80004d60:	ef0fe0ef          	jal	ra,80003450 <iunlockput>
  end_op();
    80004d64:	de5fe0ef          	jal	ra,80003b48 <end_op>
  return -1;
    80004d68:	557d                	li	a0,-1
}
    80004d6a:	70ae                	ld	ra,232(sp)
    80004d6c:	740e                	ld	s0,224(sp)
    80004d6e:	64ee                	ld	s1,216(sp)
    80004d70:	694e                	ld	s2,208(sp)
    80004d72:	69ae                	ld	s3,200(sp)
    80004d74:	616d                	addi	sp,sp,240
    80004d76:	8082                	ret

0000000080004d78 <sys_open>:

uint64
sys_open(void)
{
    80004d78:	7131                	addi	sp,sp,-192
    80004d7a:	fd06                	sd	ra,184(sp)
    80004d7c:	f922                	sd	s0,176(sp)
    80004d7e:	f526                	sd	s1,168(sp)
    80004d80:	f14a                	sd	s2,160(sp)
    80004d82:	ed4e                	sd	s3,152(sp)
    80004d84:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004d86:	f4c40593          	addi	a1,s0,-180
    80004d8a:	4505                	li	a0,1
    80004d8c:	a39fd0ef          	jal	ra,800027c4 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004d90:	08000613          	li	a2,128
    80004d94:	f5040593          	addi	a1,s0,-176
    80004d98:	4501                	li	a0,0
    80004d9a:	a63fd0ef          	jal	ra,800027fc <argstr>
    80004d9e:	87aa                	mv	a5,a0
    return -1;
    80004da0:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004da2:	0807cd63          	bltz	a5,80004e3c <sys_open+0xc4>

  begin_op();
    80004da6:	d33fe0ef          	jal	ra,80003ad8 <begin_op>

  if(omode & O_CREATE){
    80004daa:	f4c42783          	lw	a5,-180(s0)
    80004dae:	2007f793          	andi	a5,a5,512
    80004db2:	c3c5                	beqz	a5,80004e52 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80004db4:	4681                	li	a3,0
    80004db6:	4601                	li	a2,0
    80004db8:	4589                	li	a1,2
    80004dba:	f5040513          	addi	a0,s0,-176
    80004dbe:	ac3ff0ef          	jal	ra,80004880 <create>
    80004dc2:	84aa                	mv	s1,a0
    if(ip == 0){
    80004dc4:	c159                	beqz	a0,80004e4a <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004dc6:	04449703          	lh	a4,68(s1)
    80004dca:	478d                	li	a5,3
    80004dcc:	00f71763          	bne	a4,a5,80004dda <sys_open+0x62>
    80004dd0:	0464d703          	lhu	a4,70(s1)
    80004dd4:	47a5                	li	a5,9
    80004dd6:	0ae7e963          	bltu	a5,a4,80004e88 <sys_open+0x110>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004dda:	876ff0ef          	jal	ra,80003e50 <filealloc>
    80004dde:	89aa                	mv	s3,a0
    80004de0:	0c050963          	beqz	a0,80004eb2 <sys_open+0x13a>
    80004de4:	a5fff0ef          	jal	ra,80004842 <fdalloc>
    80004de8:	892a                	mv	s2,a0
    80004dea:	0c054163          	bltz	a0,80004eac <sys_open+0x134>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004dee:	04449703          	lh	a4,68(s1)
    80004df2:	478d                	li	a5,3
    80004df4:	0af70163          	beq	a4,a5,80004e96 <sys_open+0x11e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004df8:	4789                	li	a5,2
    80004dfa:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80004dfe:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80004e02:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80004e06:	f4c42783          	lw	a5,-180(s0)
    80004e0a:	0017c713          	xori	a4,a5,1
    80004e0e:	8b05                	andi	a4,a4,1
    80004e10:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004e14:	0037f713          	andi	a4,a5,3
    80004e18:	00e03733          	snez	a4,a4
    80004e1c:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004e20:	4007f793          	andi	a5,a5,1024
    80004e24:	c791                	beqz	a5,80004e30 <sys_open+0xb8>
    80004e26:	04449703          	lh	a4,68(s1)
    80004e2a:	4789                	li	a5,2
    80004e2c:	06f70c63          	beq	a4,a5,80004ea4 <sys_open+0x12c>
    itrunc(ip);
  }

  iunlock(ip);
    80004e30:	8526                	mv	a0,s1
    80004e32:	cc2fe0ef          	jal	ra,800032f4 <iunlock>
  end_op();
    80004e36:	d13fe0ef          	jal	ra,80003b48 <end_op>

  return fd;
    80004e3a:	854a                	mv	a0,s2
}
    80004e3c:	70ea                	ld	ra,184(sp)
    80004e3e:	744a                	ld	s0,176(sp)
    80004e40:	74aa                	ld	s1,168(sp)
    80004e42:	790a                	ld	s2,160(sp)
    80004e44:	69ea                	ld	s3,152(sp)
    80004e46:	6129                	addi	sp,sp,192
    80004e48:	8082                	ret
      end_op();
    80004e4a:	cfffe0ef          	jal	ra,80003b48 <end_op>
      return -1;
    80004e4e:	557d                	li	a0,-1
    80004e50:	b7f5                	j	80004e3c <sys_open+0xc4>
    if((ip = namei(path)) == 0){
    80004e52:	f5040513          	addi	a0,s0,-176
    80004e56:	aa7fe0ef          	jal	ra,800038fc <namei>
    80004e5a:	84aa                	mv	s1,a0
    80004e5c:	c115                	beqz	a0,80004e80 <sys_open+0x108>
    ilock(ip);
    80004e5e:	becfe0ef          	jal	ra,8000324a <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004e62:	04449703          	lh	a4,68(s1)
    80004e66:	4785                	li	a5,1
    80004e68:	f4f71fe3          	bne	a4,a5,80004dc6 <sys_open+0x4e>
    80004e6c:	f4c42783          	lw	a5,-180(s0)
    80004e70:	d7ad                	beqz	a5,80004dda <sys_open+0x62>
      iunlockput(ip);
    80004e72:	8526                	mv	a0,s1
    80004e74:	ddcfe0ef          	jal	ra,80003450 <iunlockput>
      end_op();
    80004e78:	cd1fe0ef          	jal	ra,80003b48 <end_op>
      return -1;
    80004e7c:	557d                	li	a0,-1
    80004e7e:	bf7d                	j	80004e3c <sys_open+0xc4>
      end_op();
    80004e80:	cc9fe0ef          	jal	ra,80003b48 <end_op>
      return -1;
    80004e84:	557d                	li	a0,-1
    80004e86:	bf5d                	j	80004e3c <sys_open+0xc4>
    iunlockput(ip);
    80004e88:	8526                	mv	a0,s1
    80004e8a:	dc6fe0ef          	jal	ra,80003450 <iunlockput>
    end_op();
    80004e8e:	cbbfe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004e92:	557d                	li	a0,-1
    80004e94:	b765                	j	80004e3c <sys_open+0xc4>
    f->type = FD_DEVICE;
    80004e96:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    80004e9a:	04649783          	lh	a5,70(s1)
    80004e9e:	02f99223          	sh	a5,36(s3)
    80004ea2:	b785                	j	80004e02 <sys_open+0x8a>
    itrunc(ip);
    80004ea4:	8526                	mv	a0,s1
    80004ea6:	c8efe0ef          	jal	ra,80003334 <itrunc>
    80004eaa:	b759                	j	80004e30 <sys_open+0xb8>
      fileclose(f);
    80004eac:	854e                	mv	a0,s3
    80004eae:	846ff0ef          	jal	ra,80003ef4 <fileclose>
    iunlockput(ip);
    80004eb2:	8526                	mv	a0,s1
    80004eb4:	d9cfe0ef          	jal	ra,80003450 <iunlockput>
    end_op();
    80004eb8:	c91fe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004ebc:	557d                	li	a0,-1
    80004ebe:	bfbd                	j	80004e3c <sys_open+0xc4>

0000000080004ec0 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004ec0:	7175                	addi	sp,sp,-144
    80004ec2:	e506                	sd	ra,136(sp)
    80004ec4:	e122                	sd	s0,128(sp)
    80004ec6:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004ec8:	c11fe0ef          	jal	ra,80003ad8 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004ecc:	08000613          	li	a2,128
    80004ed0:	f7040593          	addi	a1,s0,-144
    80004ed4:	4501                	li	a0,0
    80004ed6:	927fd0ef          	jal	ra,800027fc <argstr>
    80004eda:	02054363          	bltz	a0,80004f00 <sys_mkdir+0x40>
    80004ede:	4681                	li	a3,0
    80004ee0:	4601                	li	a2,0
    80004ee2:	4585                	li	a1,1
    80004ee4:	f7040513          	addi	a0,s0,-144
    80004ee8:	999ff0ef          	jal	ra,80004880 <create>
    80004eec:	c911                	beqz	a0,80004f00 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004eee:	d62fe0ef          	jal	ra,80003450 <iunlockput>
  end_op();
    80004ef2:	c57fe0ef          	jal	ra,80003b48 <end_op>
  return 0;
    80004ef6:	4501                	li	a0,0
}
    80004ef8:	60aa                	ld	ra,136(sp)
    80004efa:	640a                	ld	s0,128(sp)
    80004efc:	6149                	addi	sp,sp,144
    80004efe:	8082                	ret
    end_op();
    80004f00:	c49fe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004f04:	557d                	li	a0,-1
    80004f06:	bfcd                	j	80004ef8 <sys_mkdir+0x38>

0000000080004f08 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004f08:	7135                	addi	sp,sp,-160
    80004f0a:	ed06                	sd	ra,152(sp)
    80004f0c:	e922                	sd	s0,144(sp)
    80004f0e:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004f10:	bc9fe0ef          	jal	ra,80003ad8 <begin_op>
  argint(1, &major);
    80004f14:	f6c40593          	addi	a1,s0,-148
    80004f18:	4505                	li	a0,1
    80004f1a:	8abfd0ef          	jal	ra,800027c4 <argint>
  argint(2, &minor);
    80004f1e:	f6840593          	addi	a1,s0,-152
    80004f22:	4509                	li	a0,2
    80004f24:	8a1fd0ef          	jal	ra,800027c4 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f28:	08000613          	li	a2,128
    80004f2c:	f7040593          	addi	a1,s0,-144
    80004f30:	4501                	li	a0,0
    80004f32:	8cbfd0ef          	jal	ra,800027fc <argstr>
    80004f36:	02054563          	bltz	a0,80004f60 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004f3a:	f6841683          	lh	a3,-152(s0)
    80004f3e:	f6c41603          	lh	a2,-148(s0)
    80004f42:	458d                	li	a1,3
    80004f44:	f7040513          	addi	a0,s0,-144
    80004f48:	939ff0ef          	jal	ra,80004880 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f4c:	c911                	beqz	a0,80004f60 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004f4e:	d02fe0ef          	jal	ra,80003450 <iunlockput>
  end_op();
    80004f52:	bf7fe0ef          	jal	ra,80003b48 <end_op>
  return 0;
    80004f56:	4501                	li	a0,0
}
    80004f58:	60ea                	ld	ra,152(sp)
    80004f5a:	644a                	ld	s0,144(sp)
    80004f5c:	610d                	addi	sp,sp,160
    80004f5e:	8082                	ret
    end_op();
    80004f60:	be9fe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004f64:	557d                	li	a0,-1
    80004f66:	bfcd                	j	80004f58 <sys_mknod+0x50>

0000000080004f68 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004f68:	7135                	addi	sp,sp,-160
    80004f6a:	ed06                	sd	ra,152(sp)
    80004f6c:	e922                	sd	s0,144(sp)
    80004f6e:	e526                	sd	s1,136(sp)
    80004f70:	e14a                	sd	s2,128(sp)
    80004f72:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80004f74:	96bfc0ef          	jal	ra,800018de <myproc>
    80004f78:	892a                	mv	s2,a0
  
  begin_op();
    80004f7a:	b5ffe0ef          	jal	ra,80003ad8 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80004f7e:	08000613          	li	a2,128
    80004f82:	f6040593          	addi	a1,s0,-160
    80004f86:	4501                	li	a0,0
    80004f88:	875fd0ef          	jal	ra,800027fc <argstr>
    80004f8c:	04054163          	bltz	a0,80004fce <sys_chdir+0x66>
    80004f90:	f6040513          	addi	a0,s0,-160
    80004f94:	969fe0ef          	jal	ra,800038fc <namei>
    80004f98:	84aa                	mv	s1,a0
    80004f9a:	c915                	beqz	a0,80004fce <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80004f9c:	aaefe0ef          	jal	ra,8000324a <ilock>
  if(ip->type != T_DIR){
    80004fa0:	04449703          	lh	a4,68(s1)
    80004fa4:	4785                	li	a5,1
    80004fa6:	02f71863          	bne	a4,a5,80004fd6 <sys_chdir+0x6e>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80004faa:	8526                	mv	a0,s1
    80004fac:	b48fe0ef          	jal	ra,800032f4 <iunlock>
  iput(p->cwd);
    80004fb0:	15093503          	ld	a0,336(s2)
    80004fb4:	c14fe0ef          	jal	ra,800033c8 <iput>
  end_op();
    80004fb8:	b91fe0ef          	jal	ra,80003b48 <end_op>
  p->cwd = ip;
    80004fbc:	14993823          	sd	s1,336(s2)
  return 0;
    80004fc0:	4501                	li	a0,0
}
    80004fc2:	60ea                	ld	ra,152(sp)
    80004fc4:	644a                	ld	s0,144(sp)
    80004fc6:	64aa                	ld	s1,136(sp)
    80004fc8:	690a                	ld	s2,128(sp)
    80004fca:	610d                	addi	sp,sp,160
    80004fcc:	8082                	ret
    end_op();
    80004fce:	b7bfe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004fd2:	557d                	li	a0,-1
    80004fd4:	b7fd                	j	80004fc2 <sys_chdir+0x5a>
    iunlockput(ip);
    80004fd6:	8526                	mv	a0,s1
    80004fd8:	c78fe0ef          	jal	ra,80003450 <iunlockput>
    end_op();
    80004fdc:	b6dfe0ef          	jal	ra,80003b48 <end_op>
    return -1;
    80004fe0:	557d                	li	a0,-1
    80004fe2:	b7c5                	j	80004fc2 <sys_chdir+0x5a>

0000000080004fe4 <sys_exec>:

uint64
sys_exec(void)
{
    80004fe4:	7145                	addi	sp,sp,-464
    80004fe6:	e786                	sd	ra,456(sp)
    80004fe8:	e3a2                	sd	s0,448(sp)
    80004fea:	ff26                	sd	s1,440(sp)
    80004fec:	fb4a                	sd	s2,432(sp)
    80004fee:	f74e                	sd	s3,424(sp)
    80004ff0:	f352                	sd	s4,416(sp)
    80004ff2:	ef56                	sd	s5,408(sp)
    80004ff4:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004ff6:	e3840593          	addi	a1,s0,-456
    80004ffa:	4505                	li	a0,1
    80004ffc:	fe4fd0ef          	jal	ra,800027e0 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005000:	08000613          	li	a2,128
    80005004:	f4040593          	addi	a1,s0,-192
    80005008:	4501                	li	a0,0
    8000500a:	ff2fd0ef          	jal	ra,800027fc <argstr>
    8000500e:	87aa                	mv	a5,a0
    return -1;
    80005010:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005012:	0a07c463          	bltz	a5,800050ba <sys_exec+0xd6>
  }
  memset(argv, 0, sizeof(argv));
    80005016:	10000613          	li	a2,256
    8000501a:	4581                	li	a1,0
    8000501c:	e4040513          	addi	a0,s0,-448
    80005020:	cfbfb0ef          	jal	ra,80000d1a <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005024:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80005028:	89a6                	mv	s3,s1
    8000502a:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    8000502c:	02000a13          	li	s4,32
    80005030:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005034:	00391793          	slli	a5,s2,0x3
    80005038:	e3040593          	addi	a1,s0,-464
    8000503c:	e3843503          	ld	a0,-456(s0)
    80005040:	953e                	add	a0,a0,a5
    80005042:	ef8fd0ef          	jal	ra,8000273a <fetchaddr>
    80005046:	02054663          	bltz	a0,80005072 <sys_exec+0x8e>
      goto bad;
    }
    if(uarg == 0){
    8000504a:	e3043783          	ld	a5,-464(s0)
    8000504e:	cf8d                	beqz	a5,80005088 <sys_exec+0xa4>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005050:	b27fb0ef          	jal	ra,80000b76 <kalloc>
    80005054:	85aa                	mv	a1,a0
    80005056:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000505a:	cd01                	beqz	a0,80005072 <sys_exec+0x8e>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000505c:	6605                	lui	a2,0x1
    8000505e:	e3043503          	ld	a0,-464(s0)
    80005062:	f22fd0ef          	jal	ra,80002784 <fetchstr>
    80005066:	00054663          	bltz	a0,80005072 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    8000506a:	0905                	addi	s2,s2,1
    8000506c:	09a1                	addi	s3,s3,8
    8000506e:	fd4911e3          	bne	s2,s4,80005030 <sys_exec+0x4c>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005072:	10048913          	addi	s2,s1,256
    80005076:	6088                	ld	a0,0(s1)
    80005078:	c121                	beqz	a0,800050b8 <sys_exec+0xd4>
    kfree(argv[i]);
    8000507a:	a1dfb0ef          	jal	ra,80000a96 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000507e:	04a1                	addi	s1,s1,8
    80005080:	ff249be3          	bne	s1,s2,80005076 <sys_exec+0x92>
  return -1;
    80005084:	557d                	li	a0,-1
    80005086:	a815                	j	800050ba <sys_exec+0xd6>
      argv[i] = 0;
    80005088:	0a8e                	slli	s5,s5,0x3
    8000508a:	fc040793          	addi	a5,s0,-64
    8000508e:	9abe                	add	s5,s5,a5
    80005090:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    80005094:	e4040593          	addi	a1,s0,-448
    80005098:	f4040513          	addi	a0,s0,-192
    8000509c:	bfaff0ef          	jal	ra,80004496 <exec>
    800050a0:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800050a2:	10048993          	addi	s3,s1,256
    800050a6:	6088                	ld	a0,0(s1)
    800050a8:	c511                	beqz	a0,800050b4 <sys_exec+0xd0>
    kfree(argv[i]);
    800050aa:	9edfb0ef          	jal	ra,80000a96 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800050ae:	04a1                	addi	s1,s1,8
    800050b0:	ff349be3          	bne	s1,s3,800050a6 <sys_exec+0xc2>
  return ret;
    800050b4:	854a                	mv	a0,s2
    800050b6:	a011                	j	800050ba <sys_exec+0xd6>
  return -1;
    800050b8:	557d                	li	a0,-1
}
    800050ba:	60be                	ld	ra,456(sp)
    800050bc:	641e                	ld	s0,448(sp)
    800050be:	74fa                	ld	s1,440(sp)
    800050c0:	795a                	ld	s2,432(sp)
    800050c2:	79ba                	ld	s3,424(sp)
    800050c4:	7a1a                	ld	s4,416(sp)
    800050c6:	6afa                	ld	s5,408(sp)
    800050c8:	6179                	addi	sp,sp,464
    800050ca:	8082                	ret

00000000800050cc <sys_pipe>:

uint64
sys_pipe(void)
{
    800050cc:	7139                	addi	sp,sp,-64
    800050ce:	fc06                	sd	ra,56(sp)
    800050d0:	f822                	sd	s0,48(sp)
    800050d2:	f426                	sd	s1,40(sp)
    800050d4:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800050d6:	809fc0ef          	jal	ra,800018de <myproc>
    800050da:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800050dc:	fd840593          	addi	a1,s0,-40
    800050e0:	4501                	li	a0,0
    800050e2:	efefd0ef          	jal	ra,800027e0 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    800050e6:	fc840593          	addi	a1,s0,-56
    800050ea:	fd040513          	addi	a0,s0,-48
    800050ee:	8d2ff0ef          	jal	ra,800041c0 <pipealloc>
    return -1;
    800050f2:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800050f4:	0a054463          	bltz	a0,8000519c <sys_pipe+0xd0>
  fd0 = -1;
    800050f8:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800050fc:	fd043503          	ld	a0,-48(s0)
    80005100:	f42ff0ef          	jal	ra,80004842 <fdalloc>
    80005104:	fca42223          	sw	a0,-60(s0)
    80005108:	08054163          	bltz	a0,8000518a <sys_pipe+0xbe>
    8000510c:	fc843503          	ld	a0,-56(s0)
    80005110:	f32ff0ef          	jal	ra,80004842 <fdalloc>
    80005114:	fca42023          	sw	a0,-64(s0)
    80005118:	06054063          	bltz	a0,80005178 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000511c:	4691                	li	a3,4
    8000511e:	fc440613          	addi	a2,s0,-60
    80005122:	fd843583          	ld	a1,-40(s0)
    80005126:	68a8                	ld	a0,80(s1)
    80005128:	d04fc0ef          	jal	ra,8000162c <copyout>
    8000512c:	00054e63          	bltz	a0,80005148 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005130:	4691                	li	a3,4
    80005132:	fc040613          	addi	a2,s0,-64
    80005136:	fd843583          	ld	a1,-40(s0)
    8000513a:	0591                	addi	a1,a1,4
    8000513c:	68a8                	ld	a0,80(s1)
    8000513e:	ceefc0ef          	jal	ra,8000162c <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005142:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005144:	04055c63          	bgez	a0,8000519c <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    80005148:	fc442783          	lw	a5,-60(s0)
    8000514c:	07e9                	addi	a5,a5,26
    8000514e:	078e                	slli	a5,a5,0x3
    80005150:	97a6                	add	a5,a5,s1
    80005152:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005156:	fc042503          	lw	a0,-64(s0)
    8000515a:	0569                	addi	a0,a0,26
    8000515c:	050e                	slli	a0,a0,0x3
    8000515e:	94aa                	add	s1,s1,a0
    80005160:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005164:	fd043503          	ld	a0,-48(s0)
    80005168:	d8dfe0ef          	jal	ra,80003ef4 <fileclose>
    fileclose(wf);
    8000516c:	fc843503          	ld	a0,-56(s0)
    80005170:	d85fe0ef          	jal	ra,80003ef4 <fileclose>
    return -1;
    80005174:	57fd                	li	a5,-1
    80005176:	a01d                	j	8000519c <sys_pipe+0xd0>
    if(fd0 >= 0)
    80005178:	fc442783          	lw	a5,-60(s0)
    8000517c:	0007c763          	bltz	a5,8000518a <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    80005180:	07e9                	addi	a5,a5,26
    80005182:	078e                	slli	a5,a5,0x3
    80005184:	94be                	add	s1,s1,a5
    80005186:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000518a:	fd043503          	ld	a0,-48(s0)
    8000518e:	d67fe0ef          	jal	ra,80003ef4 <fileclose>
    fileclose(wf);
    80005192:	fc843503          	ld	a0,-56(s0)
    80005196:	d5ffe0ef          	jal	ra,80003ef4 <fileclose>
    return -1;
    8000519a:	57fd                	li	a5,-1
}
    8000519c:	853e                	mv	a0,a5
    8000519e:	70e2                	ld	ra,56(sp)
    800051a0:	7442                	ld	s0,48(sp)
    800051a2:	74a2                	ld	s1,40(sp)
    800051a4:	6121                	addi	sp,sp,64
    800051a6:	8082                	ret
	...

00000000800051b0 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    800051b0:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    800051b2:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    800051b4:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    800051b6:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    800051b8:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    800051ba:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    800051bc:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    800051be:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    800051c0:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    800051c2:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    800051c4:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    800051c6:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    800051c8:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    800051ca:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    800051cc:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    800051ce:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    800051d0:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    800051d2:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    800051d4:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    800051d6:	c74fd0ef          	jal	ra,8000264a <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    800051da:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    800051dc:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    800051de:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800051e0:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800051e2:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800051e4:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800051e6:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800051e8:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800051ea:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800051ec:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800051ee:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800051f0:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800051f2:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800051f4:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800051f6:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800051f8:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800051fa:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800051fc:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800051fe:	10200073          	sret
	...

000000008000520e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000520e:	1141                	addi	sp,sp,-16
    80005210:	e422                	sd	s0,8(sp)
    80005212:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005214:	0c0007b7          	lui	a5,0xc000
    80005218:	4705                	li	a4,1
    8000521a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000521c:	c3d8                	sw	a4,4(a5)
}
    8000521e:	6422                	ld	s0,8(sp)
    80005220:	0141                	addi	sp,sp,16
    80005222:	8082                	ret

0000000080005224 <plicinithart>:

void
plicinithart(void)
{
    80005224:	1141                	addi	sp,sp,-16
    80005226:	e406                	sd	ra,8(sp)
    80005228:	e022                	sd	s0,0(sp)
    8000522a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    8000522c:	e86fc0ef          	jal	ra,800018b2 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005230:	0085171b          	slliw	a4,a0,0x8
    80005234:	0c0027b7          	lui	a5,0xc002
    80005238:	97ba                	add	a5,a5,a4
    8000523a:	40200713          	li	a4,1026
    8000523e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005242:	00d5151b          	slliw	a0,a0,0xd
    80005246:	0c2017b7          	lui	a5,0xc201
    8000524a:	953e                	add	a0,a0,a5
    8000524c:	00052023          	sw	zero,0(a0)
}
    80005250:	60a2                	ld	ra,8(sp)
    80005252:	6402                	ld	s0,0(sp)
    80005254:	0141                	addi	sp,sp,16
    80005256:	8082                	ret

0000000080005258 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005258:	1141                	addi	sp,sp,-16
    8000525a:	e406                	sd	ra,8(sp)
    8000525c:	e022                	sd	s0,0(sp)
    8000525e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005260:	e52fc0ef          	jal	ra,800018b2 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005264:	00d5179b          	slliw	a5,a0,0xd
    80005268:	0c201537          	lui	a0,0xc201
    8000526c:	953e                	add	a0,a0,a5
  return irq;
}
    8000526e:	4148                	lw	a0,4(a0)
    80005270:	60a2                	ld	ra,8(sp)
    80005272:	6402                	ld	s0,0(sp)
    80005274:	0141                	addi	sp,sp,16
    80005276:	8082                	ret

0000000080005278 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005278:	1101                	addi	sp,sp,-32
    8000527a:	ec06                	sd	ra,24(sp)
    8000527c:	e822                	sd	s0,16(sp)
    8000527e:	e426                	sd	s1,8(sp)
    80005280:	1000                	addi	s0,sp,32
    80005282:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005284:	e2efc0ef          	jal	ra,800018b2 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005288:	00d5151b          	slliw	a0,a0,0xd
    8000528c:	0c2017b7          	lui	a5,0xc201
    80005290:	97aa                	add	a5,a5,a0
    80005292:	c3c4                	sw	s1,4(a5)
}
    80005294:	60e2                	ld	ra,24(sp)
    80005296:	6442                	ld	s0,16(sp)
    80005298:	64a2                	ld	s1,8(sp)
    8000529a:	6105                	addi	sp,sp,32
    8000529c:	8082                	ret

000000008000529e <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    8000529e:	1141                	addi	sp,sp,-16
    800052a0:	e406                	sd	ra,8(sp)
    800052a2:	e022                	sd	s0,0(sp)
    800052a4:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800052a6:	479d                	li	a5,7
    800052a8:	04a7ca63          	blt	a5,a0,800052fc <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800052ac:	0001c797          	auipc	a5,0x1c
    800052b0:	afc78793          	addi	a5,a5,-1284 # 80020da8 <disk>
    800052b4:	97aa                	add	a5,a5,a0
    800052b6:	0187c783          	lbu	a5,24(a5)
    800052ba:	e7b9                	bnez	a5,80005308 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800052bc:	00451613          	slli	a2,a0,0x4
    800052c0:	0001c797          	auipc	a5,0x1c
    800052c4:	ae878793          	addi	a5,a5,-1304 # 80020da8 <disk>
    800052c8:	6394                	ld	a3,0(a5)
    800052ca:	96b2                	add	a3,a3,a2
    800052cc:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    800052d0:	6398                	ld	a4,0(a5)
    800052d2:	9732                	add	a4,a4,a2
    800052d4:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800052d8:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800052dc:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800052e0:	953e                	add	a0,a0,a5
    800052e2:	4785                	li	a5,1
    800052e4:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    800052e8:	0001c517          	auipc	a0,0x1c
    800052ec:	ad850513          	addi	a0,a0,-1320 # 80020dc0 <disk+0x18>
    800052f0:	c21fc0ef          	jal	ra,80001f10 <wakeup>
}
    800052f4:	60a2                	ld	ra,8(sp)
    800052f6:	6402                	ld	s0,0(sp)
    800052f8:	0141                	addi	sp,sp,16
    800052fa:	8082                	ret
    panic("free_desc 1");
    800052fc:	00002517          	auipc	a0,0x2
    80005300:	56c50513          	addi	a0,a0,1388 # 80007868 <syscall_names+0x2f0>
    80005304:	cdcfb0ef          	jal	ra,800007e0 <panic>
    panic("free_desc 2");
    80005308:	00002517          	auipc	a0,0x2
    8000530c:	57050513          	addi	a0,a0,1392 # 80007878 <syscall_names+0x300>
    80005310:	cd0fb0ef          	jal	ra,800007e0 <panic>

0000000080005314 <virtio_disk_init>:
{
    80005314:	1101                	addi	sp,sp,-32
    80005316:	ec06                	sd	ra,24(sp)
    80005318:	e822                	sd	s0,16(sp)
    8000531a:	e426                	sd	s1,8(sp)
    8000531c:	e04a                	sd	s2,0(sp)
    8000531e:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005320:	00002597          	auipc	a1,0x2
    80005324:	56858593          	addi	a1,a1,1384 # 80007888 <syscall_names+0x310>
    80005328:	0001c517          	auipc	a0,0x1c
    8000532c:	ba850513          	addi	a0,a0,-1112 # 80020ed0 <disk+0x128>
    80005330:	897fb0ef          	jal	ra,80000bc6 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005334:	100017b7          	lui	a5,0x10001
    80005338:	4398                	lw	a4,0(a5)
    8000533a:	2701                	sext.w	a4,a4
    8000533c:	747277b7          	lui	a5,0x74727
    80005340:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005344:	14f71063          	bne	a4,a5,80005484 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005348:	100017b7          	lui	a5,0x10001
    8000534c:	43dc                	lw	a5,4(a5)
    8000534e:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005350:	4709                	li	a4,2
    80005352:	12e79963          	bne	a5,a4,80005484 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005356:	100017b7          	lui	a5,0x10001
    8000535a:	479c                	lw	a5,8(a5)
    8000535c:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000535e:	12e79363          	bne	a5,a4,80005484 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005362:	100017b7          	lui	a5,0x10001
    80005366:	47d8                	lw	a4,12(a5)
    80005368:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000536a:	554d47b7          	lui	a5,0x554d4
    8000536e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005372:	10f71963          	bne	a4,a5,80005484 <virtio_disk_init+0x170>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005376:	100017b7          	lui	a5,0x10001
    8000537a:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000537e:	4705                	li	a4,1
    80005380:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005382:	470d                	li	a4,3
    80005384:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005386:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005388:	c7ffe737          	lui	a4,0xc7ffe
    8000538c:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd877>
    80005390:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005392:	2701                	sext.w	a4,a4
    80005394:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005396:	472d                	li	a4,11
    80005398:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    8000539a:	5bbc                	lw	a5,112(a5)
    8000539c:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800053a0:	8ba1                	andi	a5,a5,8
    800053a2:	0e078763          	beqz	a5,80005490 <virtio_disk_init+0x17c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800053a6:	100017b7          	lui	a5,0x10001
    800053aa:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800053ae:	43fc                	lw	a5,68(a5)
    800053b0:	2781                	sext.w	a5,a5
    800053b2:	0e079563          	bnez	a5,8000549c <virtio_disk_init+0x188>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800053b6:	100017b7          	lui	a5,0x10001
    800053ba:	5bdc                	lw	a5,52(a5)
    800053bc:	2781                	sext.w	a5,a5
  if(max == 0)
    800053be:	0e078563          	beqz	a5,800054a8 <virtio_disk_init+0x194>
  if(max < NUM)
    800053c2:	471d                	li	a4,7
    800053c4:	0ef77863          	bgeu	a4,a5,800054b4 <virtio_disk_init+0x1a0>
  disk.desc = kalloc();
    800053c8:	faefb0ef          	jal	ra,80000b76 <kalloc>
    800053cc:	0001c497          	auipc	s1,0x1c
    800053d0:	9dc48493          	addi	s1,s1,-1572 # 80020da8 <disk>
    800053d4:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800053d6:	fa0fb0ef          	jal	ra,80000b76 <kalloc>
    800053da:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800053dc:	f9afb0ef          	jal	ra,80000b76 <kalloc>
    800053e0:	87aa                	mv	a5,a0
    800053e2:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800053e4:	6088                	ld	a0,0(s1)
    800053e6:	cd69                	beqz	a0,800054c0 <virtio_disk_init+0x1ac>
    800053e8:	0001c717          	auipc	a4,0x1c
    800053ec:	9c873703          	ld	a4,-1592(a4) # 80020db0 <disk+0x8>
    800053f0:	cb61                	beqz	a4,800054c0 <virtio_disk_init+0x1ac>
    800053f2:	c7f9                	beqz	a5,800054c0 <virtio_disk_init+0x1ac>
  memset(disk.desc, 0, PGSIZE);
    800053f4:	6605                	lui	a2,0x1
    800053f6:	4581                	li	a1,0
    800053f8:	923fb0ef          	jal	ra,80000d1a <memset>
  memset(disk.avail, 0, PGSIZE);
    800053fc:	0001c497          	auipc	s1,0x1c
    80005400:	9ac48493          	addi	s1,s1,-1620 # 80020da8 <disk>
    80005404:	6605                	lui	a2,0x1
    80005406:	4581                	li	a1,0
    80005408:	6488                	ld	a0,8(s1)
    8000540a:	911fb0ef          	jal	ra,80000d1a <memset>
  memset(disk.used, 0, PGSIZE);
    8000540e:	6605                	lui	a2,0x1
    80005410:	4581                	li	a1,0
    80005412:	6888                	ld	a0,16(s1)
    80005414:	907fb0ef          	jal	ra,80000d1a <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005418:	100017b7          	lui	a5,0x10001
    8000541c:	4721                	li	a4,8
    8000541e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005420:	4098                	lw	a4,0(s1)
    80005422:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005426:	40d8                	lw	a4,4(s1)
    80005428:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    8000542c:	6498                	ld	a4,8(s1)
    8000542e:	0007069b          	sext.w	a3,a4
    80005432:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005436:	9701                	srai	a4,a4,0x20
    80005438:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    8000543c:	6898                	ld	a4,16(s1)
    8000543e:	0007069b          	sext.w	a3,a4
    80005442:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005446:	9701                	srai	a4,a4,0x20
    80005448:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    8000544c:	4705                	li	a4,1
    8000544e:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80005450:	00e48c23          	sb	a4,24(s1)
    80005454:	00e48ca3          	sb	a4,25(s1)
    80005458:	00e48d23          	sb	a4,26(s1)
    8000545c:	00e48da3          	sb	a4,27(s1)
    80005460:	00e48e23          	sb	a4,28(s1)
    80005464:	00e48ea3          	sb	a4,29(s1)
    80005468:	00e48f23          	sb	a4,30(s1)
    8000546c:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005470:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005474:	0727a823          	sw	s2,112(a5)
}
    80005478:	60e2                	ld	ra,24(sp)
    8000547a:	6442                	ld	s0,16(sp)
    8000547c:	64a2                	ld	s1,8(sp)
    8000547e:	6902                	ld	s2,0(sp)
    80005480:	6105                	addi	sp,sp,32
    80005482:	8082                	ret
    panic("could not find virtio disk");
    80005484:	00002517          	auipc	a0,0x2
    80005488:	41450513          	addi	a0,a0,1044 # 80007898 <syscall_names+0x320>
    8000548c:	b54fb0ef          	jal	ra,800007e0 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005490:	00002517          	auipc	a0,0x2
    80005494:	42850513          	addi	a0,a0,1064 # 800078b8 <syscall_names+0x340>
    80005498:	b48fb0ef          	jal	ra,800007e0 <panic>
    panic("virtio disk should not be ready");
    8000549c:	00002517          	auipc	a0,0x2
    800054a0:	43c50513          	addi	a0,a0,1084 # 800078d8 <syscall_names+0x360>
    800054a4:	b3cfb0ef          	jal	ra,800007e0 <panic>
    panic("virtio disk has no queue 0");
    800054a8:	00002517          	auipc	a0,0x2
    800054ac:	45050513          	addi	a0,a0,1104 # 800078f8 <syscall_names+0x380>
    800054b0:	b30fb0ef          	jal	ra,800007e0 <panic>
    panic("virtio disk max queue too short");
    800054b4:	00002517          	auipc	a0,0x2
    800054b8:	46450513          	addi	a0,a0,1124 # 80007918 <syscall_names+0x3a0>
    800054bc:	b24fb0ef          	jal	ra,800007e0 <panic>
    panic("virtio disk kalloc");
    800054c0:	00002517          	auipc	a0,0x2
    800054c4:	47850513          	addi	a0,a0,1144 # 80007938 <syscall_names+0x3c0>
    800054c8:	b18fb0ef          	jal	ra,800007e0 <panic>

00000000800054cc <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800054cc:	7119                	addi	sp,sp,-128
    800054ce:	fc86                	sd	ra,120(sp)
    800054d0:	f8a2                	sd	s0,112(sp)
    800054d2:	f4a6                	sd	s1,104(sp)
    800054d4:	f0ca                	sd	s2,96(sp)
    800054d6:	ecce                	sd	s3,88(sp)
    800054d8:	e8d2                	sd	s4,80(sp)
    800054da:	e4d6                	sd	s5,72(sp)
    800054dc:	e0da                	sd	s6,64(sp)
    800054de:	fc5e                	sd	s7,56(sp)
    800054e0:	f862                	sd	s8,48(sp)
    800054e2:	f466                	sd	s9,40(sp)
    800054e4:	f06a                	sd	s10,32(sp)
    800054e6:	ec6e                	sd	s11,24(sp)
    800054e8:	0100                	addi	s0,sp,128
    800054ea:	8aaa                	mv	s5,a0
    800054ec:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800054ee:	00c52d03          	lw	s10,12(a0)
    800054f2:	001d1d1b          	slliw	s10,s10,0x1
    800054f6:	1d02                	slli	s10,s10,0x20
    800054f8:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    800054fc:	0001c517          	auipc	a0,0x1c
    80005500:	9d450513          	addi	a0,a0,-1580 # 80020ed0 <disk+0x128>
    80005504:	f42fb0ef          	jal	ra,80000c46 <acquire>
  for(int i = 0; i < 3; i++){
    80005508:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    8000550a:	44a1                	li	s1,8
      disk.free[i] = 0;
    8000550c:	0001cb97          	auipc	s7,0x1c
    80005510:	89cb8b93          	addi	s7,s7,-1892 # 80020da8 <disk>
  for(int i = 0; i < 3; i++){
    80005514:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005516:	0001cc97          	auipc	s9,0x1c
    8000551a:	9bac8c93          	addi	s9,s9,-1606 # 80020ed0 <disk+0x128>
    8000551e:	a8a9                	j	80005578 <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80005520:	00fb8733          	add	a4,s7,a5
    80005524:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005528:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    8000552a:	0207c563          	bltz	a5,80005554 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    8000552e:	2905                	addiw	s2,s2,1
    80005530:	0611                	addi	a2,a2,4
    80005532:	05690863          	beq	s2,s6,80005582 <virtio_disk_rw+0xb6>
    idx[i] = alloc_desc();
    80005536:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005538:	0001c717          	auipc	a4,0x1c
    8000553c:	87070713          	addi	a4,a4,-1936 # 80020da8 <disk>
    80005540:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005542:	01874683          	lbu	a3,24(a4)
    80005546:	fee9                	bnez	a3,80005520 <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80005548:	2785                	addiw	a5,a5,1
    8000554a:	0705                	addi	a4,a4,1
    8000554c:	fe979be3          	bne	a5,s1,80005542 <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    80005550:	57fd                	li	a5,-1
    80005552:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005554:	01205b63          	blez	s2,8000556a <virtio_disk_rw+0x9e>
    80005558:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    8000555a:	000a2503          	lw	a0,0(s4)
    8000555e:	d41ff0ef          	jal	ra,8000529e <free_desc>
      for(int j = 0; j < i; j++)
    80005562:	2d85                	addiw	s11,s11,1
    80005564:	0a11                	addi	s4,s4,4
    80005566:	ffb91ae3          	bne	s2,s11,8000555a <virtio_disk_rw+0x8e>
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000556a:	85e6                	mv	a1,s9
    8000556c:	0001c517          	auipc	a0,0x1c
    80005570:	85450513          	addi	a0,a0,-1964 # 80020dc0 <disk+0x18>
    80005574:	951fc0ef          	jal	ra,80001ec4 <sleep>
  for(int i = 0; i < 3; i++){
    80005578:	f8040a13          	addi	s4,s0,-128
{
    8000557c:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    8000557e:	894e                	mv	s2,s3
    80005580:	bf5d                	j	80005536 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005582:	f8042583          	lw	a1,-128(s0)
    80005586:	00a58793          	addi	a5,a1,10
    8000558a:	0792                	slli	a5,a5,0x4

  if(write)
    8000558c:	0001c617          	auipc	a2,0x1c
    80005590:	81c60613          	addi	a2,a2,-2020 # 80020da8 <disk>
    80005594:	00f60733          	add	a4,a2,a5
    80005598:	018036b3          	snez	a3,s8
    8000559c:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    8000559e:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    800055a2:	01a73823          	sd	s10,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800055a6:	f6078693          	addi	a3,a5,-160
    800055aa:	6218                	ld	a4,0(a2)
    800055ac:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800055ae:	00878513          	addi	a0,a5,8
    800055b2:	9532                	add	a0,a0,a2
  disk.desc[idx[0]].addr = (uint64) buf0;
    800055b4:	e308                	sd	a0,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800055b6:	6208                	ld	a0,0(a2)
    800055b8:	96aa                	add	a3,a3,a0
    800055ba:	4741                	li	a4,16
    800055bc:	c698                	sw	a4,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800055be:	4705                	li	a4,1
    800055c0:	00e69623          	sh	a4,12(a3)
  disk.desc[idx[0]].next = idx[1];
    800055c4:	f8442703          	lw	a4,-124(s0)
    800055c8:	00e69723          	sh	a4,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800055cc:	0712                	slli	a4,a4,0x4
    800055ce:	953a                	add	a0,a0,a4
    800055d0:	058a8693          	addi	a3,s5,88
    800055d4:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    800055d6:	6208                	ld	a0,0(a2)
    800055d8:	972a                	add	a4,a4,a0
    800055da:	40000693          	li	a3,1024
    800055de:	c714                	sw	a3,8(a4)
  if(write)
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    800055e0:	001c3c13          	seqz	s8,s8
    800055e4:	0c06                	slli	s8,s8,0x1
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800055e6:	001c6c13          	ori	s8,s8,1
    800055ea:	01871623          	sh	s8,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800055ee:	f8842603          	lw	a2,-120(s0)
    800055f2:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800055f6:	0001b697          	auipc	a3,0x1b
    800055fa:	7b268693          	addi	a3,a3,1970 # 80020da8 <disk>
    800055fe:	00258713          	addi	a4,a1,2
    80005602:	0712                	slli	a4,a4,0x4
    80005604:	9736                	add	a4,a4,a3
    80005606:	587d                	li	a6,-1
    80005608:	01070823          	sb	a6,16(a4)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000560c:	0612                	slli	a2,a2,0x4
    8000560e:	9532                	add	a0,a0,a2
    80005610:	f9078793          	addi	a5,a5,-112
    80005614:	97b6                	add	a5,a5,a3
    80005616:	e11c                	sd	a5,0(a0)
  disk.desc[idx[2]].len = 1;
    80005618:	629c                	ld	a5,0(a3)
    8000561a:	97b2                	add	a5,a5,a2
    8000561c:	4605                	li	a2,1
    8000561e:	c790                	sw	a2,8(a5)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005620:	4509                	li	a0,2
    80005622:	00a79623          	sh	a0,12(a5)
  disk.desc[idx[2]].next = 0;
    80005626:	00079723          	sh	zero,14(a5)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000562a:	00caa223          	sw	a2,4(s5)
  disk.info[idx[0]].b = b;
    8000562e:	01573423          	sd	s5,8(a4)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005632:	6698                	ld	a4,8(a3)
    80005634:	00275783          	lhu	a5,2(a4)
    80005638:	8b9d                	andi	a5,a5,7
    8000563a:	0786                	slli	a5,a5,0x1
    8000563c:	97ba                	add	a5,a5,a4
    8000563e:	00b79223          	sh	a1,4(a5)

  __sync_synchronize();
    80005642:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005646:	6698                	ld	a4,8(a3)
    80005648:	00275783          	lhu	a5,2(a4)
    8000564c:	2785                	addiw	a5,a5,1
    8000564e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005652:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005656:	100017b7          	lui	a5,0x10001
    8000565a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    8000565e:	004aa783          	lw	a5,4(s5)
    80005662:	00c79f63          	bne	a5,a2,80005680 <virtio_disk_rw+0x1b4>
    sleep(b, &disk.vdisk_lock);
    80005666:	0001c917          	auipc	s2,0x1c
    8000566a:	86a90913          	addi	s2,s2,-1942 # 80020ed0 <disk+0x128>
  while(b->disk == 1) {
    8000566e:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80005670:	85ca                	mv	a1,s2
    80005672:	8556                	mv	a0,s5
    80005674:	851fc0ef          	jal	ra,80001ec4 <sleep>
  while(b->disk == 1) {
    80005678:	004aa783          	lw	a5,4(s5)
    8000567c:	fe978ae3          	beq	a5,s1,80005670 <virtio_disk_rw+0x1a4>
  }

  disk.info[idx[0]].b = 0;
    80005680:	f8042903          	lw	s2,-128(s0)
    80005684:	00290793          	addi	a5,s2,2
    80005688:	00479713          	slli	a4,a5,0x4
    8000568c:	0001b797          	auipc	a5,0x1b
    80005690:	71c78793          	addi	a5,a5,1820 # 80020da8 <disk>
    80005694:	97ba                	add	a5,a5,a4
    80005696:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    8000569a:	0001b997          	auipc	s3,0x1b
    8000569e:	70e98993          	addi	s3,s3,1806 # 80020da8 <disk>
    800056a2:	00491713          	slli	a4,s2,0x4
    800056a6:	0009b783          	ld	a5,0(s3)
    800056aa:	97ba                	add	a5,a5,a4
    800056ac:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800056b0:	854a                	mv	a0,s2
    800056b2:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800056b6:	be9ff0ef          	jal	ra,8000529e <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800056ba:	8885                	andi	s1,s1,1
    800056bc:	f0fd                	bnez	s1,800056a2 <virtio_disk_rw+0x1d6>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800056be:	0001c517          	auipc	a0,0x1c
    800056c2:	81250513          	addi	a0,a0,-2030 # 80020ed0 <disk+0x128>
    800056c6:	e18fb0ef          	jal	ra,80000cde <release>
}
    800056ca:	70e6                	ld	ra,120(sp)
    800056cc:	7446                	ld	s0,112(sp)
    800056ce:	74a6                	ld	s1,104(sp)
    800056d0:	7906                	ld	s2,96(sp)
    800056d2:	69e6                	ld	s3,88(sp)
    800056d4:	6a46                	ld	s4,80(sp)
    800056d6:	6aa6                	ld	s5,72(sp)
    800056d8:	6b06                	ld	s6,64(sp)
    800056da:	7be2                	ld	s7,56(sp)
    800056dc:	7c42                	ld	s8,48(sp)
    800056de:	7ca2                	ld	s9,40(sp)
    800056e0:	7d02                	ld	s10,32(sp)
    800056e2:	6de2                	ld	s11,24(sp)
    800056e4:	6109                	addi	sp,sp,128
    800056e6:	8082                	ret

00000000800056e8 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    800056e8:	1101                	addi	sp,sp,-32
    800056ea:	ec06                	sd	ra,24(sp)
    800056ec:	e822                	sd	s0,16(sp)
    800056ee:	e426                	sd	s1,8(sp)
    800056f0:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800056f2:	0001b497          	auipc	s1,0x1b
    800056f6:	6b648493          	addi	s1,s1,1718 # 80020da8 <disk>
    800056fa:	0001b517          	auipc	a0,0x1b
    800056fe:	7d650513          	addi	a0,a0,2006 # 80020ed0 <disk+0x128>
    80005702:	d44fb0ef          	jal	ra,80000c46 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005706:	10001737          	lui	a4,0x10001
    8000570a:	533c                	lw	a5,96(a4)
    8000570c:	8b8d                	andi	a5,a5,3
    8000570e:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80005710:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005714:	689c                	ld	a5,16(s1)
    80005716:	0204d703          	lhu	a4,32(s1)
    8000571a:	0027d783          	lhu	a5,2(a5)
    8000571e:	04f70663          	beq	a4,a5,8000576a <virtio_disk_intr+0x82>
    __sync_synchronize();
    80005722:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005726:	6898                	ld	a4,16(s1)
    80005728:	0204d783          	lhu	a5,32(s1)
    8000572c:	8b9d                	andi	a5,a5,7
    8000572e:	078e                	slli	a5,a5,0x3
    80005730:	97ba                	add	a5,a5,a4
    80005732:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005734:	00278713          	addi	a4,a5,2
    80005738:	0712                	slli	a4,a4,0x4
    8000573a:	9726                	add	a4,a4,s1
    8000573c:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80005740:	e321                	bnez	a4,80005780 <virtio_disk_intr+0x98>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005742:	0789                	addi	a5,a5,2
    80005744:	0792                	slli	a5,a5,0x4
    80005746:	97a6                	add	a5,a5,s1
    80005748:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    8000574a:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000574e:	fc2fc0ef          	jal	ra,80001f10 <wakeup>

    disk.used_idx += 1;
    80005752:	0204d783          	lhu	a5,32(s1)
    80005756:	2785                	addiw	a5,a5,1
    80005758:	17c2                	slli	a5,a5,0x30
    8000575a:	93c1                	srli	a5,a5,0x30
    8000575c:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005760:	6898                	ld	a4,16(s1)
    80005762:	00275703          	lhu	a4,2(a4)
    80005766:	faf71ee3          	bne	a4,a5,80005722 <virtio_disk_intr+0x3a>
  }

  release(&disk.vdisk_lock);
    8000576a:	0001b517          	auipc	a0,0x1b
    8000576e:	76650513          	addi	a0,a0,1894 # 80020ed0 <disk+0x128>
    80005772:	d6cfb0ef          	jal	ra,80000cde <release>
}
    80005776:	60e2                	ld	ra,24(sp)
    80005778:	6442                	ld	s0,16(sp)
    8000577a:	64a2                	ld	s1,8(sp)
    8000577c:	6105                	addi	sp,sp,32
    8000577e:	8082                	ret
      panic("virtio_disk_intr status");
    80005780:	00002517          	auipc	a0,0x2
    80005784:	1d050513          	addi	a0,a0,464 # 80007950 <syscall_names+0x3d8>
    80005788:	858fb0ef          	jal	ra,800007e0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
