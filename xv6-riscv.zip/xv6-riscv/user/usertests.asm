
user/_usertests:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <copyinstr1>:
}

// what if you pass ridiculous string pointers to system calls?
void
copyinstr1(char *s)
{
       0:	711d                	addi	sp,sp,-96
       2:	ec86                	sd	ra,88(sp)
       4:	e8a2                	sd	s0,80(sp)
       6:	e4a6                	sd	s1,72(sp)
       8:	e0ca                	sd	s2,64(sp)
       a:	fc4e                	sd	s3,56(sp)
       c:	1080                	addi	s0,sp,96
  uint64 addrs[] = { 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
       e:	00007797          	auipc	a5,0x7
      12:	71a78793          	addi	a5,a5,1818 # 7728 <malloc+0x2598>
      16:	638c                	ld	a1,0(a5)
      18:	6790                	ld	a2,8(a5)
      1a:	6b94                	ld	a3,16(a5)
      1c:	6f98                	ld	a4,24(a5)
      1e:	739c                	ld	a5,32(a5)
      20:	fab43423          	sd	a1,-88(s0)
      24:	fac43823          	sd	a2,-80(s0)
      28:	fad43c23          	sd	a3,-72(s0)
      2c:	fce43023          	sd	a4,-64(s0)
      30:	fcf43423          	sd	a5,-56(s0)
                     0xffffffffffffffff };

  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
      34:	fa840493          	addi	s1,s0,-88
      38:	fd040993          	addi	s3,s0,-48
    uint64 addr = addrs[ai];

    int fd = open((char *)addr, O_CREATE|O_WRONLY);
      3c:	0004b903          	ld	s2,0(s1)
      40:	20100593          	li	a1,513
      44:	854a                	mv	a0,s2
      46:	4a3040ef          	jal	ra,4ce8 <open>
    if(fd >= 0){
      4a:	00055c63          	bgez	a0,62 <copyinstr1+0x62>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
      4e:	04a1                	addi	s1,s1,8
      50:	ff3496e3          	bne	s1,s3,3c <copyinstr1+0x3c>
      printf("open(%p) returned %d, not -1\n", (void*)addr, fd);
      exit(1);
    }
  }
}
      54:	60e6                	ld	ra,88(sp)
      56:	6446                	ld	s0,80(sp)
      58:	64a6                	ld	s1,72(sp)
      5a:	6906                	ld	s2,64(sp)
      5c:	79e2                	ld	s3,56(sp)
      5e:	6125                	addi	sp,sp,96
      60:	8082                	ret
      printf("open(%p) returned %d, not -1\n", (void*)addr, fd);
      62:	862a                	mv	a2,a0
      64:	85ca                	mv	a1,s2
      66:	00005517          	auipc	a0,0x5
      6a:	22a50513          	addi	a0,a0,554 # 5290 <malloc+0x100>
      6e:	068050ef          	jal	ra,50d6 <printf>
      exit(1);
      72:	4505                	li	a0,1
      74:	435040ef          	jal	ra,4ca8 <exit>

0000000000000078 <bsstest>:
void
bsstest(char *s)
{
  int i;

  for(i = 0; i < sizeof(uninit); i++){
      78:	00009797          	auipc	a5,0x9
      7c:	52078793          	addi	a5,a5,1312 # 9598 <uninit>
      80:	0000c697          	auipc	a3,0xc
      84:	c2868693          	addi	a3,a3,-984 # bca8 <buf>
    if(uninit[i] != '\0'){
      88:	0007c703          	lbu	a4,0(a5)
      8c:	e709                	bnez	a4,96 <bsstest+0x1e>
  for(i = 0; i < sizeof(uninit); i++){
      8e:	0785                	addi	a5,a5,1
      90:	fed79ce3          	bne	a5,a3,88 <bsstest+0x10>
      94:	8082                	ret
{
      96:	1141                	addi	sp,sp,-16
      98:	e406                	sd	ra,8(sp)
      9a:	e022                	sd	s0,0(sp)
      9c:	0800                	addi	s0,sp,16
      printf("%s: bss test failed\n", s);
      9e:	85aa                	mv	a1,a0
      a0:	00005517          	auipc	a0,0x5
      a4:	21050513          	addi	a0,a0,528 # 52b0 <malloc+0x120>
      a8:	02e050ef          	jal	ra,50d6 <printf>
      exit(1);
      ac:	4505                	li	a0,1
      ae:	3fb040ef          	jal	ra,4ca8 <exit>

00000000000000b2 <opentest>:
{
      b2:	1101                	addi	sp,sp,-32
      b4:	ec06                	sd	ra,24(sp)
      b6:	e822                	sd	s0,16(sp)
      b8:	e426                	sd	s1,8(sp)
      ba:	1000                	addi	s0,sp,32
      bc:	84aa                	mv	s1,a0
  fd = open("echo", 0);
      be:	4581                	li	a1,0
      c0:	00005517          	auipc	a0,0x5
      c4:	20850513          	addi	a0,a0,520 # 52c8 <malloc+0x138>
      c8:	421040ef          	jal	ra,4ce8 <open>
  if(fd < 0){
      cc:	02054263          	bltz	a0,f0 <opentest+0x3e>
  close(fd);
      d0:	401040ef          	jal	ra,4cd0 <close>
  fd = open("doesnotexist", 0);
      d4:	4581                	li	a1,0
      d6:	00005517          	auipc	a0,0x5
      da:	21250513          	addi	a0,a0,530 # 52e8 <malloc+0x158>
      de:	40b040ef          	jal	ra,4ce8 <open>
  if(fd >= 0){
      e2:	02055163          	bgez	a0,104 <opentest+0x52>
}
      e6:	60e2                	ld	ra,24(sp)
      e8:	6442                	ld	s0,16(sp)
      ea:	64a2                	ld	s1,8(sp)
      ec:	6105                	addi	sp,sp,32
      ee:	8082                	ret
    printf("%s: open echo failed!\n", s);
      f0:	85a6                	mv	a1,s1
      f2:	00005517          	auipc	a0,0x5
      f6:	1de50513          	addi	a0,a0,478 # 52d0 <malloc+0x140>
      fa:	7dd040ef          	jal	ra,50d6 <printf>
    exit(1);
      fe:	4505                	li	a0,1
     100:	3a9040ef          	jal	ra,4ca8 <exit>
    printf("%s: open doesnotexist succeeded!\n", s);
     104:	85a6                	mv	a1,s1
     106:	00005517          	auipc	a0,0x5
     10a:	1f250513          	addi	a0,a0,498 # 52f8 <malloc+0x168>
     10e:	7c9040ef          	jal	ra,50d6 <printf>
    exit(1);
     112:	4505                	li	a0,1
     114:	395040ef          	jal	ra,4ca8 <exit>

0000000000000118 <truncate2>:
{
     118:	7179                	addi	sp,sp,-48
     11a:	f406                	sd	ra,40(sp)
     11c:	f022                	sd	s0,32(sp)
     11e:	ec26                	sd	s1,24(sp)
     120:	e84a                	sd	s2,16(sp)
     122:	e44e                	sd	s3,8(sp)
     124:	1800                	addi	s0,sp,48
     126:	89aa                	mv	s3,a0
  unlink("truncfile");
     128:	00005517          	auipc	a0,0x5
     12c:	1f850513          	addi	a0,a0,504 # 5320 <malloc+0x190>
     130:	3c9040ef          	jal	ra,4cf8 <unlink>
  int fd1 = open("truncfile", O_CREATE|O_TRUNC|O_WRONLY);
     134:	60100593          	li	a1,1537
     138:	00005517          	auipc	a0,0x5
     13c:	1e850513          	addi	a0,a0,488 # 5320 <malloc+0x190>
     140:	3a9040ef          	jal	ra,4ce8 <open>
     144:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     146:	4611                	li	a2,4
     148:	00005597          	auipc	a1,0x5
     14c:	1e858593          	addi	a1,a1,488 # 5330 <malloc+0x1a0>
     150:	379040ef          	jal	ra,4cc8 <write>
  int fd2 = open("truncfile", O_TRUNC|O_WRONLY);
     154:	40100593          	li	a1,1025
     158:	00005517          	auipc	a0,0x5
     15c:	1c850513          	addi	a0,a0,456 # 5320 <malloc+0x190>
     160:	389040ef          	jal	ra,4ce8 <open>
     164:	892a                	mv	s2,a0
  int n = write(fd1, "x", 1);
     166:	4605                	li	a2,1
     168:	00005597          	auipc	a1,0x5
     16c:	1d058593          	addi	a1,a1,464 # 5338 <malloc+0x1a8>
     170:	8526                	mv	a0,s1
     172:	357040ef          	jal	ra,4cc8 <write>
  if(n != -1){
     176:	57fd                	li	a5,-1
     178:	02f51563          	bne	a0,a5,1a2 <truncate2+0x8a>
  unlink("truncfile");
     17c:	00005517          	auipc	a0,0x5
     180:	1a450513          	addi	a0,a0,420 # 5320 <malloc+0x190>
     184:	375040ef          	jal	ra,4cf8 <unlink>
  close(fd1);
     188:	8526                	mv	a0,s1
     18a:	347040ef          	jal	ra,4cd0 <close>
  close(fd2);
     18e:	854a                	mv	a0,s2
     190:	341040ef          	jal	ra,4cd0 <close>
}
     194:	70a2                	ld	ra,40(sp)
     196:	7402                	ld	s0,32(sp)
     198:	64e2                	ld	s1,24(sp)
     19a:	6942                	ld	s2,16(sp)
     19c:	69a2                	ld	s3,8(sp)
     19e:	6145                	addi	sp,sp,48
     1a0:	8082                	ret
    printf("%s: write returned %d, expected -1\n", s, n);
     1a2:	862a                	mv	a2,a0
     1a4:	85ce                	mv	a1,s3
     1a6:	00005517          	auipc	a0,0x5
     1aa:	19a50513          	addi	a0,a0,410 # 5340 <malloc+0x1b0>
     1ae:	729040ef          	jal	ra,50d6 <printf>
    exit(1);
     1b2:	4505                	li	a0,1
     1b4:	2f5040ef          	jal	ra,4ca8 <exit>

00000000000001b8 <createtest>:
{
     1b8:	7179                	addi	sp,sp,-48
     1ba:	f406                	sd	ra,40(sp)
     1bc:	f022                	sd	s0,32(sp)
     1be:	ec26                	sd	s1,24(sp)
     1c0:	e84a                	sd	s2,16(sp)
     1c2:	1800                	addi	s0,sp,48
  name[0] = 'a';
     1c4:	06100793          	li	a5,97
     1c8:	fcf40c23          	sb	a5,-40(s0)
  name[2] = '\0';
     1cc:	fc040d23          	sb	zero,-38(s0)
     1d0:	03000493          	li	s1,48
  for(i = 0; i < N; i++){
     1d4:	06400913          	li	s2,100
    name[1] = '0' + i;
     1d8:	fc940ca3          	sb	s1,-39(s0)
    fd = open(name, O_CREATE|O_RDWR);
     1dc:	20200593          	li	a1,514
     1e0:	fd840513          	addi	a0,s0,-40
     1e4:	305040ef          	jal	ra,4ce8 <open>
    close(fd);
     1e8:	2e9040ef          	jal	ra,4cd0 <close>
  for(i = 0; i < N; i++){
     1ec:	2485                	addiw	s1,s1,1
     1ee:	0ff4f493          	zext.b	s1,s1
     1f2:	ff2493e3          	bne	s1,s2,1d8 <createtest+0x20>
  name[0] = 'a';
     1f6:	06100793          	li	a5,97
     1fa:	fcf40c23          	sb	a5,-40(s0)
  name[2] = '\0';
     1fe:	fc040d23          	sb	zero,-38(s0)
     202:	03000493          	li	s1,48
  for(i = 0; i < N; i++){
     206:	06400913          	li	s2,100
    name[1] = '0' + i;
     20a:	fc940ca3          	sb	s1,-39(s0)
    unlink(name);
     20e:	fd840513          	addi	a0,s0,-40
     212:	2e7040ef          	jal	ra,4cf8 <unlink>
  for(i = 0; i < N; i++){
     216:	2485                	addiw	s1,s1,1
     218:	0ff4f493          	zext.b	s1,s1
     21c:	ff2497e3          	bne	s1,s2,20a <createtest+0x52>
}
     220:	70a2                	ld	ra,40(sp)
     222:	7402                	ld	s0,32(sp)
     224:	64e2                	ld	s1,24(sp)
     226:	6942                	ld	s2,16(sp)
     228:	6145                	addi	sp,sp,48
     22a:	8082                	ret

000000000000022c <bigwrite>:
{
     22c:	715d                	addi	sp,sp,-80
     22e:	e486                	sd	ra,72(sp)
     230:	e0a2                	sd	s0,64(sp)
     232:	fc26                	sd	s1,56(sp)
     234:	f84a                	sd	s2,48(sp)
     236:	f44e                	sd	s3,40(sp)
     238:	f052                	sd	s4,32(sp)
     23a:	ec56                	sd	s5,24(sp)
     23c:	e85a                	sd	s6,16(sp)
     23e:	e45e                	sd	s7,8(sp)
     240:	0880                	addi	s0,sp,80
     242:	8baa                	mv	s7,a0
  unlink("bigwrite");
     244:	00005517          	auipc	a0,0x5
     248:	12450513          	addi	a0,a0,292 # 5368 <malloc+0x1d8>
     24c:	2ad040ef          	jal	ra,4cf8 <unlink>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     250:	1f300493          	li	s1,499
    fd = open("bigwrite", O_CREATE | O_RDWR);
     254:	00005a97          	auipc	s5,0x5
     258:	114a8a93          	addi	s5,s5,276 # 5368 <malloc+0x1d8>
      int cc = write(fd, buf, sz);
     25c:	0000ca17          	auipc	s4,0xc
     260:	a4ca0a13          	addi	s4,s4,-1460 # bca8 <buf>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     264:	6b0d                	lui	s6,0x3
     266:	1c9b0b13          	addi	s6,s6,457 # 31c9 <subdir+0x3f9>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     26a:	20200593          	li	a1,514
     26e:	8556                	mv	a0,s5
     270:	279040ef          	jal	ra,4ce8 <open>
     274:	892a                	mv	s2,a0
    if(fd < 0){
     276:	04054563          	bltz	a0,2c0 <bigwrite+0x94>
      int cc = write(fd, buf, sz);
     27a:	8626                	mv	a2,s1
     27c:	85d2                	mv	a1,s4
     27e:	24b040ef          	jal	ra,4cc8 <write>
     282:	89aa                	mv	s3,a0
      if(cc != sz){
     284:	04a49a63          	bne	s1,a0,2d8 <bigwrite+0xac>
      int cc = write(fd, buf, sz);
     288:	8626                	mv	a2,s1
     28a:	85d2                	mv	a1,s4
     28c:	854a                	mv	a0,s2
     28e:	23b040ef          	jal	ra,4cc8 <write>
      if(cc != sz){
     292:	04951163          	bne	a0,s1,2d4 <bigwrite+0xa8>
    close(fd);
     296:	854a                	mv	a0,s2
     298:	239040ef          	jal	ra,4cd0 <close>
    unlink("bigwrite");
     29c:	8556                	mv	a0,s5
     29e:	25b040ef          	jal	ra,4cf8 <unlink>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     2a2:	1d74849b          	addiw	s1,s1,471
     2a6:	fd6492e3          	bne	s1,s6,26a <bigwrite+0x3e>
}
     2aa:	60a6                	ld	ra,72(sp)
     2ac:	6406                	ld	s0,64(sp)
     2ae:	74e2                	ld	s1,56(sp)
     2b0:	7942                	ld	s2,48(sp)
     2b2:	79a2                	ld	s3,40(sp)
     2b4:	7a02                	ld	s4,32(sp)
     2b6:	6ae2                	ld	s5,24(sp)
     2b8:	6b42                	ld	s6,16(sp)
     2ba:	6ba2                	ld	s7,8(sp)
     2bc:	6161                	addi	sp,sp,80
     2be:	8082                	ret
      printf("%s: cannot create bigwrite\n", s);
     2c0:	85de                	mv	a1,s7
     2c2:	00005517          	auipc	a0,0x5
     2c6:	0b650513          	addi	a0,a0,182 # 5378 <malloc+0x1e8>
     2ca:	60d040ef          	jal	ra,50d6 <printf>
      exit(1);
     2ce:	4505                	li	a0,1
     2d0:	1d9040ef          	jal	ra,4ca8 <exit>
     2d4:	84ce                	mv	s1,s3
      int cc = write(fd, buf, sz);
     2d6:	89aa                	mv	s3,a0
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     2d8:	86ce                	mv	a3,s3
     2da:	8626                	mv	a2,s1
     2dc:	85de                	mv	a1,s7
     2de:	00005517          	auipc	a0,0x5
     2e2:	0ba50513          	addi	a0,a0,186 # 5398 <malloc+0x208>
     2e6:	5f1040ef          	jal	ra,50d6 <printf>
        exit(1);
     2ea:	4505                	li	a0,1
     2ec:	1bd040ef          	jal	ra,4ca8 <exit>

00000000000002f0 <badwrite>:
// file is deleted? if the kernel has this bug, it will panic: balloc:
// out of blocks. assumed_free may need to be raised to be more than
// the number of free blocks. this test takes a long time.
void
badwrite(char *s)
{
     2f0:	7179                	addi	sp,sp,-48
     2f2:	f406                	sd	ra,40(sp)
     2f4:	f022                	sd	s0,32(sp)
     2f6:	ec26                	sd	s1,24(sp)
     2f8:	e84a                	sd	s2,16(sp)
     2fa:	e44e                	sd	s3,8(sp)
     2fc:	e052                	sd	s4,0(sp)
     2fe:	1800                	addi	s0,sp,48
  int assumed_free = 600;
  
  unlink("junk");
     300:	00005517          	auipc	a0,0x5
     304:	0b050513          	addi	a0,a0,176 # 53b0 <malloc+0x220>
     308:	1f1040ef          	jal	ra,4cf8 <unlink>
     30c:	25800913          	li	s2,600
  for(int i = 0; i < assumed_free; i++){
    int fd = open("junk", O_CREATE|O_WRONLY);
     310:	00005997          	auipc	s3,0x5
     314:	0a098993          	addi	s3,s3,160 # 53b0 <malloc+0x220>
    if(fd < 0){
      printf("open junk failed\n");
      exit(1);
    }
    write(fd, (char*)0xffffffffffL, 1);
     318:	5a7d                	li	s4,-1
     31a:	018a5a13          	srli	s4,s4,0x18
    int fd = open("junk", O_CREATE|O_WRONLY);
     31e:	20100593          	li	a1,513
     322:	854e                	mv	a0,s3
     324:	1c5040ef          	jal	ra,4ce8 <open>
     328:	84aa                	mv	s1,a0
    if(fd < 0){
     32a:	04054d63          	bltz	a0,384 <badwrite+0x94>
    write(fd, (char*)0xffffffffffL, 1);
     32e:	4605                	li	a2,1
     330:	85d2                	mv	a1,s4
     332:	197040ef          	jal	ra,4cc8 <write>
    close(fd);
     336:	8526                	mv	a0,s1
     338:	199040ef          	jal	ra,4cd0 <close>
    unlink("junk");
     33c:	854e                	mv	a0,s3
     33e:	1bb040ef          	jal	ra,4cf8 <unlink>
  for(int i = 0; i < assumed_free; i++){
     342:	397d                	addiw	s2,s2,-1
     344:	fc091de3          	bnez	s2,31e <badwrite+0x2e>
  }

  int fd = open("junk", O_CREATE|O_WRONLY);
     348:	20100593          	li	a1,513
     34c:	00005517          	auipc	a0,0x5
     350:	06450513          	addi	a0,a0,100 # 53b0 <malloc+0x220>
     354:	195040ef          	jal	ra,4ce8 <open>
     358:	84aa                	mv	s1,a0
  if(fd < 0){
     35a:	02054e63          	bltz	a0,396 <badwrite+0xa6>
    printf("open junk failed\n");
    exit(1);
  }
  if(write(fd, "x", 1) != 1){
     35e:	4605                	li	a2,1
     360:	00005597          	auipc	a1,0x5
     364:	fd858593          	addi	a1,a1,-40 # 5338 <malloc+0x1a8>
     368:	161040ef          	jal	ra,4cc8 <write>
     36c:	4785                	li	a5,1
     36e:	02f50d63          	beq	a0,a5,3a8 <badwrite+0xb8>
    printf("write failed\n");
     372:	00005517          	auipc	a0,0x5
     376:	05e50513          	addi	a0,a0,94 # 53d0 <malloc+0x240>
     37a:	55d040ef          	jal	ra,50d6 <printf>
    exit(1);
     37e:	4505                	li	a0,1
     380:	129040ef          	jal	ra,4ca8 <exit>
      printf("open junk failed\n");
     384:	00005517          	auipc	a0,0x5
     388:	03450513          	addi	a0,a0,52 # 53b8 <malloc+0x228>
     38c:	54b040ef          	jal	ra,50d6 <printf>
      exit(1);
     390:	4505                	li	a0,1
     392:	117040ef          	jal	ra,4ca8 <exit>
    printf("open junk failed\n");
     396:	00005517          	auipc	a0,0x5
     39a:	02250513          	addi	a0,a0,34 # 53b8 <malloc+0x228>
     39e:	539040ef          	jal	ra,50d6 <printf>
    exit(1);
     3a2:	4505                	li	a0,1
     3a4:	105040ef          	jal	ra,4ca8 <exit>
  }
  close(fd);
     3a8:	8526                	mv	a0,s1
     3aa:	127040ef          	jal	ra,4cd0 <close>
  unlink("junk");
     3ae:	00005517          	auipc	a0,0x5
     3b2:	00250513          	addi	a0,a0,2 # 53b0 <malloc+0x220>
     3b6:	143040ef          	jal	ra,4cf8 <unlink>

  exit(0);
     3ba:	4501                	li	a0,0
     3bc:	0ed040ef          	jal	ra,4ca8 <exit>

00000000000003c0 <outofinodes>:
  }
}

void
outofinodes(char *s)
{
     3c0:	715d                	addi	sp,sp,-80
     3c2:	e486                	sd	ra,72(sp)
     3c4:	e0a2                	sd	s0,64(sp)
     3c6:	fc26                	sd	s1,56(sp)
     3c8:	f84a                	sd	s2,48(sp)
     3ca:	f44e                	sd	s3,40(sp)
     3cc:	0880                	addi	s0,sp,80
  int nzz = 32*32;
  for(int i = 0; i < nzz; i++){
     3ce:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     3d0:	07a00913          	li	s2,122
  for(int i = 0; i < nzz; i++){
     3d4:	40000993          	li	s3,1024
    name[0] = 'z';
     3d8:	fb240823          	sb	s2,-80(s0)
    name[1] = 'z';
     3dc:	fb2408a3          	sb	s2,-79(s0)
    name[2] = '0' + (i / 32);
     3e0:	41f4d79b          	sraiw	a5,s1,0x1f
     3e4:	01b7d71b          	srliw	a4,a5,0x1b
     3e8:	009707bb          	addw	a5,a4,s1
     3ec:	4057d69b          	sraiw	a3,a5,0x5
     3f0:	0306869b          	addiw	a3,a3,48
     3f4:	fad40923          	sb	a3,-78(s0)
    name[3] = '0' + (i % 32);
     3f8:	8bfd                	andi	a5,a5,31
     3fa:	9f99                	subw	a5,a5,a4
     3fc:	0307879b          	addiw	a5,a5,48
     400:	faf409a3          	sb	a5,-77(s0)
    name[4] = '\0';
     404:	fa040a23          	sb	zero,-76(s0)
    unlink(name);
     408:	fb040513          	addi	a0,s0,-80
     40c:	0ed040ef          	jal	ra,4cf8 <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
     410:	60200593          	li	a1,1538
     414:	fb040513          	addi	a0,s0,-80
     418:	0d1040ef          	jal	ra,4ce8 <open>
    if(fd < 0){
     41c:	00054763          	bltz	a0,42a <outofinodes+0x6a>
      // failure is eventually expected.
      break;
    }
    close(fd);
     420:	0b1040ef          	jal	ra,4cd0 <close>
  for(int i = 0; i < nzz; i++){
     424:	2485                	addiw	s1,s1,1
     426:	fb3499e3          	bne	s1,s3,3d8 <outofinodes+0x18>
     42a:	4481                	li	s1,0
  }

  for(int i = 0; i < nzz; i++){
    char name[32];
    name[0] = 'z';
     42c:	07a00913          	li	s2,122
  for(int i = 0; i < nzz; i++){
     430:	40000993          	li	s3,1024
    name[0] = 'z';
     434:	fb240823          	sb	s2,-80(s0)
    name[1] = 'z';
     438:	fb2408a3          	sb	s2,-79(s0)
    name[2] = '0' + (i / 32);
     43c:	41f4d79b          	sraiw	a5,s1,0x1f
     440:	01b7d71b          	srliw	a4,a5,0x1b
     444:	009707bb          	addw	a5,a4,s1
     448:	4057d69b          	sraiw	a3,a5,0x5
     44c:	0306869b          	addiw	a3,a3,48
     450:	fad40923          	sb	a3,-78(s0)
    name[3] = '0' + (i % 32);
     454:	8bfd                	andi	a5,a5,31
     456:	9f99                	subw	a5,a5,a4
     458:	0307879b          	addiw	a5,a5,48
     45c:	faf409a3          	sb	a5,-77(s0)
    name[4] = '\0';
     460:	fa040a23          	sb	zero,-76(s0)
    unlink(name);
     464:	fb040513          	addi	a0,s0,-80
     468:	091040ef          	jal	ra,4cf8 <unlink>
  for(int i = 0; i < nzz; i++){
     46c:	2485                	addiw	s1,s1,1
     46e:	fd3493e3          	bne	s1,s3,434 <outofinodes+0x74>
  }
}
     472:	60a6                	ld	ra,72(sp)
     474:	6406                	ld	s0,64(sp)
     476:	74e2                	ld	s1,56(sp)
     478:	7942                	ld	s2,48(sp)
     47a:	79a2                	ld	s3,40(sp)
     47c:	6161                	addi	sp,sp,80
     47e:	8082                	ret

0000000000000480 <copyin>:
{
     480:	7159                	addi	sp,sp,-112
     482:	f486                	sd	ra,104(sp)
     484:	f0a2                	sd	s0,96(sp)
     486:	eca6                	sd	s1,88(sp)
     488:	e8ca                	sd	s2,80(sp)
     48a:	e4ce                	sd	s3,72(sp)
     48c:	e0d2                	sd	s4,64(sp)
     48e:	fc56                	sd	s5,56(sp)
     490:	1880                	addi	s0,sp,112
  uint64 addrs[] = { 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     492:	00007797          	auipc	a5,0x7
     496:	29678793          	addi	a5,a5,662 # 7728 <malloc+0x2598>
     49a:	638c                	ld	a1,0(a5)
     49c:	6790                	ld	a2,8(a5)
     49e:	6b94                	ld	a3,16(a5)
     4a0:	6f98                	ld	a4,24(a5)
     4a2:	739c                	ld	a5,32(a5)
     4a4:	f8b43c23          	sd	a1,-104(s0)
     4a8:	fac43023          	sd	a2,-96(s0)
     4ac:	fad43423          	sd	a3,-88(s0)
     4b0:	fae43823          	sd	a4,-80(s0)
     4b4:	faf43c23          	sd	a5,-72(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     4b8:	f9840913          	addi	s2,s0,-104
     4bc:	fc040a93          	addi	s5,s0,-64
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     4c0:	00005a17          	auipc	s4,0x5
     4c4:	f20a0a13          	addi	s4,s4,-224 # 53e0 <malloc+0x250>
    uint64 addr = addrs[ai];
     4c8:	00093983          	ld	s3,0(s2)
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     4cc:	20100593          	li	a1,513
     4d0:	8552                	mv	a0,s4
     4d2:	017040ef          	jal	ra,4ce8 <open>
     4d6:	84aa                	mv	s1,a0
    if(fd < 0){
     4d8:	06054763          	bltz	a0,546 <copyin+0xc6>
    int n = write(fd, (void*)addr, 8192);
     4dc:	6609                	lui	a2,0x2
     4de:	85ce                	mv	a1,s3
     4e0:	7e8040ef          	jal	ra,4cc8 <write>
    if(n >= 0){
     4e4:	06055a63          	bgez	a0,558 <copyin+0xd8>
    close(fd);
     4e8:	8526                	mv	a0,s1
     4ea:	7e6040ef          	jal	ra,4cd0 <close>
    unlink("copyin1");
     4ee:	8552                	mv	a0,s4
     4f0:	009040ef          	jal	ra,4cf8 <unlink>
    n = write(1, (char*)addr, 8192);
     4f4:	6609                	lui	a2,0x2
     4f6:	85ce                	mv	a1,s3
     4f8:	4505                	li	a0,1
     4fa:	7ce040ef          	jal	ra,4cc8 <write>
    if(n > 0){
     4fe:	06a04863          	bgtz	a0,56e <copyin+0xee>
    if(pipe(fds) < 0){
     502:	f9040513          	addi	a0,s0,-112
     506:	7b2040ef          	jal	ra,4cb8 <pipe>
     50a:	06054d63          	bltz	a0,584 <copyin+0x104>
    n = write(fds[1], (char*)addr, 8192);
     50e:	6609                	lui	a2,0x2
     510:	85ce                	mv	a1,s3
     512:	f9442503          	lw	a0,-108(s0)
     516:	7b2040ef          	jal	ra,4cc8 <write>
    if(n > 0){
     51a:	06a04e63          	bgtz	a0,596 <copyin+0x116>
    close(fds[0]);
     51e:	f9042503          	lw	a0,-112(s0)
     522:	7ae040ef          	jal	ra,4cd0 <close>
    close(fds[1]);
     526:	f9442503          	lw	a0,-108(s0)
     52a:	7a6040ef          	jal	ra,4cd0 <close>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     52e:	0921                	addi	s2,s2,8
     530:	f9591ce3          	bne	s2,s5,4c8 <copyin+0x48>
}
     534:	70a6                	ld	ra,104(sp)
     536:	7406                	ld	s0,96(sp)
     538:	64e6                	ld	s1,88(sp)
     53a:	6946                	ld	s2,80(sp)
     53c:	69a6                	ld	s3,72(sp)
     53e:	6a06                	ld	s4,64(sp)
     540:	7ae2                	ld	s5,56(sp)
     542:	6165                	addi	sp,sp,112
     544:	8082                	ret
      printf("open(copyin1) failed\n");
     546:	00005517          	auipc	a0,0x5
     54a:	ea250513          	addi	a0,a0,-350 # 53e8 <malloc+0x258>
     54e:	389040ef          	jal	ra,50d6 <printf>
      exit(1);
     552:	4505                	li	a0,1
     554:	754040ef          	jal	ra,4ca8 <exit>
      printf("write(fd, %p, 8192) returned %d, not -1\n", (void*)addr, n);
     558:	862a                	mv	a2,a0
     55a:	85ce                	mv	a1,s3
     55c:	00005517          	auipc	a0,0x5
     560:	ea450513          	addi	a0,a0,-348 # 5400 <malloc+0x270>
     564:	373040ef          	jal	ra,50d6 <printf>
      exit(1);
     568:	4505                	li	a0,1
     56a:	73e040ef          	jal	ra,4ca8 <exit>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     56e:	862a                	mv	a2,a0
     570:	85ce                	mv	a1,s3
     572:	00005517          	auipc	a0,0x5
     576:	ebe50513          	addi	a0,a0,-322 # 5430 <malloc+0x2a0>
     57a:	35d040ef          	jal	ra,50d6 <printf>
      exit(1);
     57e:	4505                	li	a0,1
     580:	728040ef          	jal	ra,4ca8 <exit>
      printf("pipe() failed\n");
     584:	00005517          	auipc	a0,0x5
     588:	edc50513          	addi	a0,a0,-292 # 5460 <malloc+0x2d0>
     58c:	34b040ef          	jal	ra,50d6 <printf>
      exit(1);
     590:	4505                	li	a0,1
     592:	716040ef          	jal	ra,4ca8 <exit>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     596:	862a                	mv	a2,a0
     598:	85ce                	mv	a1,s3
     59a:	00005517          	auipc	a0,0x5
     59e:	ed650513          	addi	a0,a0,-298 # 5470 <malloc+0x2e0>
     5a2:	335040ef          	jal	ra,50d6 <printf>
      exit(1);
     5a6:	4505                	li	a0,1
     5a8:	700040ef          	jal	ra,4ca8 <exit>

00000000000005ac <copyout>:
{
     5ac:	7119                	addi	sp,sp,-128
     5ae:	fc86                	sd	ra,120(sp)
     5b0:	f8a2                	sd	s0,112(sp)
     5b2:	f4a6                	sd	s1,104(sp)
     5b4:	f0ca                	sd	s2,96(sp)
     5b6:	ecce                	sd	s3,88(sp)
     5b8:	e8d2                	sd	s4,80(sp)
     5ba:	e4d6                	sd	s5,72(sp)
     5bc:	e0da                	sd	s6,64(sp)
     5be:	0100                	addi	s0,sp,128
  uint64 addrs[] = { 0LL, 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     5c0:	00007797          	auipc	a5,0x7
     5c4:	16878793          	addi	a5,a5,360 # 7728 <malloc+0x2598>
     5c8:	7788                	ld	a0,40(a5)
     5ca:	7b8c                	ld	a1,48(a5)
     5cc:	7f90                	ld	a2,56(a5)
     5ce:	63b4                	ld	a3,64(a5)
     5d0:	67b8                	ld	a4,72(a5)
     5d2:	6bbc                	ld	a5,80(a5)
     5d4:	f8a43823          	sd	a0,-112(s0)
     5d8:	f8b43c23          	sd	a1,-104(s0)
     5dc:	fac43023          	sd	a2,-96(s0)
     5e0:	fad43423          	sd	a3,-88(s0)
     5e4:	fae43823          	sd	a4,-80(s0)
     5e8:	faf43c23          	sd	a5,-72(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     5ec:	f9040913          	addi	s2,s0,-112
     5f0:	fc040b13          	addi	s6,s0,-64
    int fd = open("README", 0);
     5f4:	00005a17          	auipc	s4,0x5
     5f8:	eaca0a13          	addi	s4,s4,-340 # 54a0 <malloc+0x310>
    n = write(fds[1], "x", 1);
     5fc:	00005a97          	auipc	s5,0x5
     600:	d3ca8a93          	addi	s5,s5,-708 # 5338 <malloc+0x1a8>
    uint64 addr = addrs[ai];
     604:	00093983          	ld	s3,0(s2)
    int fd = open("README", 0);
     608:	4581                	li	a1,0
     60a:	8552                	mv	a0,s4
     60c:	6dc040ef          	jal	ra,4ce8 <open>
     610:	84aa                	mv	s1,a0
    if(fd < 0){
     612:	06054763          	bltz	a0,680 <copyout+0xd4>
    int n = read(fd, (void*)addr, 8192);
     616:	6609                	lui	a2,0x2
     618:	85ce                	mv	a1,s3
     61a:	6a6040ef          	jal	ra,4cc0 <read>
    if(n > 0){
     61e:	06a04a63          	bgtz	a0,692 <copyout+0xe6>
    close(fd);
     622:	8526                	mv	a0,s1
     624:	6ac040ef          	jal	ra,4cd0 <close>
    if(pipe(fds) < 0){
     628:	f8840513          	addi	a0,s0,-120
     62c:	68c040ef          	jal	ra,4cb8 <pipe>
     630:	06054c63          	bltz	a0,6a8 <copyout+0xfc>
    n = write(fds[1], "x", 1);
     634:	4605                	li	a2,1
     636:	85d6                	mv	a1,s5
     638:	f8c42503          	lw	a0,-116(s0)
     63c:	68c040ef          	jal	ra,4cc8 <write>
    if(n != 1){
     640:	4785                	li	a5,1
     642:	06f51c63          	bne	a0,a5,6ba <copyout+0x10e>
    n = read(fds[0], (void*)addr, 8192);
     646:	6609                	lui	a2,0x2
     648:	85ce                	mv	a1,s3
     64a:	f8842503          	lw	a0,-120(s0)
     64e:	672040ef          	jal	ra,4cc0 <read>
    if(n > 0){
     652:	06a04d63          	bgtz	a0,6cc <copyout+0x120>
    close(fds[0]);
     656:	f8842503          	lw	a0,-120(s0)
     65a:	676040ef          	jal	ra,4cd0 <close>
    close(fds[1]);
     65e:	f8c42503          	lw	a0,-116(s0)
     662:	66e040ef          	jal	ra,4cd0 <close>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     666:	0921                	addi	s2,s2,8
     668:	f9691ee3          	bne	s2,s6,604 <copyout+0x58>
}
     66c:	70e6                	ld	ra,120(sp)
     66e:	7446                	ld	s0,112(sp)
     670:	74a6                	ld	s1,104(sp)
     672:	7906                	ld	s2,96(sp)
     674:	69e6                	ld	s3,88(sp)
     676:	6a46                	ld	s4,80(sp)
     678:	6aa6                	ld	s5,72(sp)
     67a:	6b06                	ld	s6,64(sp)
     67c:	6109                	addi	sp,sp,128
     67e:	8082                	ret
      printf("open(README) failed\n");
     680:	00005517          	auipc	a0,0x5
     684:	e2850513          	addi	a0,a0,-472 # 54a8 <malloc+0x318>
     688:	24f040ef          	jal	ra,50d6 <printf>
      exit(1);
     68c:	4505                	li	a0,1
     68e:	61a040ef          	jal	ra,4ca8 <exit>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     692:	862a                	mv	a2,a0
     694:	85ce                	mv	a1,s3
     696:	00005517          	auipc	a0,0x5
     69a:	e2a50513          	addi	a0,a0,-470 # 54c0 <malloc+0x330>
     69e:	239040ef          	jal	ra,50d6 <printf>
      exit(1);
     6a2:	4505                	li	a0,1
     6a4:	604040ef          	jal	ra,4ca8 <exit>
      printf("pipe() failed\n");
     6a8:	00005517          	auipc	a0,0x5
     6ac:	db850513          	addi	a0,a0,-584 # 5460 <malloc+0x2d0>
     6b0:	227040ef          	jal	ra,50d6 <printf>
      exit(1);
     6b4:	4505                	li	a0,1
     6b6:	5f2040ef          	jal	ra,4ca8 <exit>
      printf("pipe write failed\n");
     6ba:	00005517          	auipc	a0,0x5
     6be:	e3650513          	addi	a0,a0,-458 # 54f0 <malloc+0x360>
     6c2:	215040ef          	jal	ra,50d6 <printf>
      exit(1);
     6c6:	4505                	li	a0,1
     6c8:	5e0040ef          	jal	ra,4ca8 <exit>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     6cc:	862a                	mv	a2,a0
     6ce:	85ce                	mv	a1,s3
     6d0:	00005517          	auipc	a0,0x5
     6d4:	e3850513          	addi	a0,a0,-456 # 5508 <malloc+0x378>
     6d8:	1ff040ef          	jal	ra,50d6 <printf>
      exit(1);
     6dc:	4505                	li	a0,1
     6de:	5ca040ef          	jal	ra,4ca8 <exit>

00000000000006e2 <truncate1>:
{
     6e2:	711d                	addi	sp,sp,-96
     6e4:	ec86                	sd	ra,88(sp)
     6e6:	e8a2                	sd	s0,80(sp)
     6e8:	e4a6                	sd	s1,72(sp)
     6ea:	e0ca                	sd	s2,64(sp)
     6ec:	fc4e                	sd	s3,56(sp)
     6ee:	f852                	sd	s4,48(sp)
     6f0:	f456                	sd	s5,40(sp)
     6f2:	1080                	addi	s0,sp,96
     6f4:	8aaa                	mv	s5,a0
  unlink("truncfile");
     6f6:	00005517          	auipc	a0,0x5
     6fa:	c2a50513          	addi	a0,a0,-982 # 5320 <malloc+0x190>
     6fe:	5fa040ef          	jal	ra,4cf8 <unlink>
  int fd1 = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
     702:	60100593          	li	a1,1537
     706:	00005517          	auipc	a0,0x5
     70a:	c1a50513          	addi	a0,a0,-998 # 5320 <malloc+0x190>
     70e:	5da040ef          	jal	ra,4ce8 <open>
     712:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     714:	4611                	li	a2,4
     716:	00005597          	auipc	a1,0x5
     71a:	c1a58593          	addi	a1,a1,-998 # 5330 <malloc+0x1a0>
     71e:	5aa040ef          	jal	ra,4cc8 <write>
  close(fd1);
     722:	8526                	mv	a0,s1
     724:	5ac040ef          	jal	ra,4cd0 <close>
  int fd2 = open("truncfile", O_RDONLY);
     728:	4581                	li	a1,0
     72a:	00005517          	auipc	a0,0x5
     72e:	bf650513          	addi	a0,a0,-1034 # 5320 <malloc+0x190>
     732:	5b6040ef          	jal	ra,4ce8 <open>
     736:	84aa                	mv	s1,a0
  int n = read(fd2, buf, sizeof(buf));
     738:	02000613          	li	a2,32
     73c:	fa040593          	addi	a1,s0,-96
     740:	580040ef          	jal	ra,4cc0 <read>
  if(n != 4){
     744:	4791                	li	a5,4
     746:	0af51863          	bne	a0,a5,7f6 <truncate1+0x114>
  fd1 = open("truncfile", O_WRONLY|O_TRUNC);
     74a:	40100593          	li	a1,1025
     74e:	00005517          	auipc	a0,0x5
     752:	bd250513          	addi	a0,a0,-1070 # 5320 <malloc+0x190>
     756:	592040ef          	jal	ra,4ce8 <open>
     75a:	89aa                	mv	s3,a0
  int fd3 = open("truncfile", O_RDONLY);
     75c:	4581                	li	a1,0
     75e:	00005517          	auipc	a0,0x5
     762:	bc250513          	addi	a0,a0,-1086 # 5320 <malloc+0x190>
     766:	582040ef          	jal	ra,4ce8 <open>
     76a:	892a                	mv	s2,a0
  n = read(fd3, buf, sizeof(buf));
     76c:	02000613          	li	a2,32
     770:	fa040593          	addi	a1,s0,-96
     774:	54c040ef          	jal	ra,4cc0 <read>
     778:	8a2a                	mv	s4,a0
  if(n != 0){
     77a:	e949                	bnez	a0,80c <truncate1+0x12a>
  n = read(fd2, buf, sizeof(buf));
     77c:	02000613          	li	a2,32
     780:	fa040593          	addi	a1,s0,-96
     784:	8526                	mv	a0,s1
     786:	53a040ef          	jal	ra,4cc0 <read>
     78a:	8a2a                	mv	s4,a0
  if(n != 0){
     78c:	e155                	bnez	a0,830 <truncate1+0x14e>
  write(fd1, "abcdef", 6);
     78e:	4619                	li	a2,6
     790:	00005597          	auipc	a1,0x5
     794:	e0858593          	addi	a1,a1,-504 # 5598 <malloc+0x408>
     798:	854e                	mv	a0,s3
     79a:	52e040ef          	jal	ra,4cc8 <write>
  n = read(fd3, buf, sizeof(buf));
     79e:	02000613          	li	a2,32
     7a2:	fa040593          	addi	a1,s0,-96
     7a6:	854a                	mv	a0,s2
     7a8:	518040ef          	jal	ra,4cc0 <read>
  if(n != 6){
     7ac:	4799                	li	a5,6
     7ae:	0af51363          	bne	a0,a5,854 <truncate1+0x172>
  n = read(fd2, buf, sizeof(buf));
     7b2:	02000613          	li	a2,32
     7b6:	fa040593          	addi	a1,s0,-96
     7ba:	8526                	mv	a0,s1
     7bc:	504040ef          	jal	ra,4cc0 <read>
  if(n != 2){
     7c0:	4789                	li	a5,2
     7c2:	0af51463          	bne	a0,a5,86a <truncate1+0x188>
  unlink("truncfile");
     7c6:	00005517          	auipc	a0,0x5
     7ca:	b5a50513          	addi	a0,a0,-1190 # 5320 <malloc+0x190>
     7ce:	52a040ef          	jal	ra,4cf8 <unlink>
  close(fd1);
     7d2:	854e                	mv	a0,s3
     7d4:	4fc040ef          	jal	ra,4cd0 <close>
  close(fd2);
     7d8:	8526                	mv	a0,s1
     7da:	4f6040ef          	jal	ra,4cd0 <close>
  close(fd3);
     7de:	854a                	mv	a0,s2
     7e0:	4f0040ef          	jal	ra,4cd0 <close>
}
     7e4:	60e6                	ld	ra,88(sp)
     7e6:	6446                	ld	s0,80(sp)
     7e8:	64a6                	ld	s1,72(sp)
     7ea:	6906                	ld	s2,64(sp)
     7ec:	79e2                	ld	s3,56(sp)
     7ee:	7a42                	ld	s4,48(sp)
     7f0:	7aa2                	ld	s5,40(sp)
     7f2:	6125                	addi	sp,sp,96
     7f4:	8082                	ret
    printf("%s: read %d bytes, wanted 4\n", s, n);
     7f6:	862a                	mv	a2,a0
     7f8:	85d6                	mv	a1,s5
     7fa:	00005517          	auipc	a0,0x5
     7fe:	d3e50513          	addi	a0,a0,-706 # 5538 <malloc+0x3a8>
     802:	0d5040ef          	jal	ra,50d6 <printf>
    exit(1);
     806:	4505                	li	a0,1
     808:	4a0040ef          	jal	ra,4ca8 <exit>
    printf("aaa fd3=%d\n", fd3);
     80c:	85ca                	mv	a1,s2
     80e:	00005517          	auipc	a0,0x5
     812:	d4a50513          	addi	a0,a0,-694 # 5558 <malloc+0x3c8>
     816:	0c1040ef          	jal	ra,50d6 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     81a:	8652                	mv	a2,s4
     81c:	85d6                	mv	a1,s5
     81e:	00005517          	auipc	a0,0x5
     822:	d4a50513          	addi	a0,a0,-694 # 5568 <malloc+0x3d8>
     826:	0b1040ef          	jal	ra,50d6 <printf>
    exit(1);
     82a:	4505                	li	a0,1
     82c:	47c040ef          	jal	ra,4ca8 <exit>
    printf("bbb fd2=%d\n", fd2);
     830:	85a6                	mv	a1,s1
     832:	00005517          	auipc	a0,0x5
     836:	d5650513          	addi	a0,a0,-682 # 5588 <malloc+0x3f8>
     83a:	09d040ef          	jal	ra,50d6 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     83e:	8652                	mv	a2,s4
     840:	85d6                	mv	a1,s5
     842:	00005517          	auipc	a0,0x5
     846:	d2650513          	addi	a0,a0,-730 # 5568 <malloc+0x3d8>
     84a:	08d040ef          	jal	ra,50d6 <printf>
    exit(1);
     84e:	4505                	li	a0,1
     850:	458040ef          	jal	ra,4ca8 <exit>
    printf("%s: read %d bytes, wanted 6\n", s, n);
     854:	862a                	mv	a2,a0
     856:	85d6                	mv	a1,s5
     858:	00005517          	auipc	a0,0x5
     85c:	d4850513          	addi	a0,a0,-696 # 55a0 <malloc+0x410>
     860:	077040ef          	jal	ra,50d6 <printf>
    exit(1);
     864:	4505                	li	a0,1
     866:	442040ef          	jal	ra,4ca8 <exit>
    printf("%s: read %d bytes, wanted 2\n", s, n);
     86a:	862a                	mv	a2,a0
     86c:	85d6                	mv	a1,s5
     86e:	00005517          	auipc	a0,0x5
     872:	d5250513          	addi	a0,a0,-686 # 55c0 <malloc+0x430>
     876:	061040ef          	jal	ra,50d6 <printf>
    exit(1);
     87a:	4505                	li	a0,1
     87c:	42c040ef          	jal	ra,4ca8 <exit>

0000000000000880 <writetest>:
{
     880:	7139                	addi	sp,sp,-64
     882:	fc06                	sd	ra,56(sp)
     884:	f822                	sd	s0,48(sp)
     886:	f426                	sd	s1,40(sp)
     888:	f04a                	sd	s2,32(sp)
     88a:	ec4e                	sd	s3,24(sp)
     88c:	e852                	sd	s4,16(sp)
     88e:	e456                	sd	s5,8(sp)
     890:	e05a                	sd	s6,0(sp)
     892:	0080                	addi	s0,sp,64
     894:	8b2a                	mv	s6,a0
  fd = open("small", O_CREATE|O_RDWR);
     896:	20200593          	li	a1,514
     89a:	00005517          	auipc	a0,0x5
     89e:	d4650513          	addi	a0,a0,-698 # 55e0 <malloc+0x450>
     8a2:	446040ef          	jal	ra,4ce8 <open>
  if(fd < 0){
     8a6:	08054f63          	bltz	a0,944 <writetest+0xc4>
     8aa:	892a                	mv	s2,a0
     8ac:	4481                	li	s1,0
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     8ae:	00005997          	auipc	s3,0x5
     8b2:	d5a98993          	addi	s3,s3,-678 # 5608 <malloc+0x478>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     8b6:	00005a97          	auipc	s5,0x5
     8ba:	d8aa8a93          	addi	s5,s5,-630 # 5640 <malloc+0x4b0>
  for(i = 0; i < N; i++){
     8be:	06400a13          	li	s4,100
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     8c2:	4629                	li	a2,10
     8c4:	85ce                	mv	a1,s3
     8c6:	854a                	mv	a0,s2
     8c8:	400040ef          	jal	ra,4cc8 <write>
     8cc:	47a9                	li	a5,10
     8ce:	08f51563          	bne	a0,a5,958 <writetest+0xd8>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     8d2:	4629                	li	a2,10
     8d4:	85d6                	mv	a1,s5
     8d6:	854a                	mv	a0,s2
     8d8:	3f0040ef          	jal	ra,4cc8 <write>
     8dc:	47a9                	li	a5,10
     8de:	08f51863          	bne	a0,a5,96e <writetest+0xee>
  for(i = 0; i < N; i++){
     8e2:	2485                	addiw	s1,s1,1
     8e4:	fd449fe3          	bne	s1,s4,8c2 <writetest+0x42>
  close(fd);
     8e8:	854a                	mv	a0,s2
     8ea:	3e6040ef          	jal	ra,4cd0 <close>
  fd = open("small", O_RDONLY);
     8ee:	4581                	li	a1,0
     8f0:	00005517          	auipc	a0,0x5
     8f4:	cf050513          	addi	a0,a0,-784 # 55e0 <malloc+0x450>
     8f8:	3f0040ef          	jal	ra,4ce8 <open>
     8fc:	84aa                	mv	s1,a0
  if(fd < 0){
     8fe:	08054363          	bltz	a0,984 <writetest+0x104>
  i = read(fd, buf, N*SZ*2);
     902:	7d000613          	li	a2,2000
     906:	0000b597          	auipc	a1,0xb
     90a:	3a258593          	addi	a1,a1,930 # bca8 <buf>
     90e:	3b2040ef          	jal	ra,4cc0 <read>
  if(i != N*SZ*2){
     912:	7d000793          	li	a5,2000
     916:	08f51163          	bne	a0,a5,998 <writetest+0x118>
  close(fd);
     91a:	8526                	mv	a0,s1
     91c:	3b4040ef          	jal	ra,4cd0 <close>
  if(unlink("small") < 0){
     920:	00005517          	auipc	a0,0x5
     924:	cc050513          	addi	a0,a0,-832 # 55e0 <malloc+0x450>
     928:	3d0040ef          	jal	ra,4cf8 <unlink>
     92c:	08054063          	bltz	a0,9ac <writetest+0x12c>
}
     930:	70e2                	ld	ra,56(sp)
     932:	7442                	ld	s0,48(sp)
     934:	74a2                	ld	s1,40(sp)
     936:	7902                	ld	s2,32(sp)
     938:	69e2                	ld	s3,24(sp)
     93a:	6a42                	ld	s4,16(sp)
     93c:	6aa2                	ld	s5,8(sp)
     93e:	6b02                	ld	s6,0(sp)
     940:	6121                	addi	sp,sp,64
     942:	8082                	ret
    printf("%s: error: creat small failed!\n", s);
     944:	85da                	mv	a1,s6
     946:	00005517          	auipc	a0,0x5
     94a:	ca250513          	addi	a0,a0,-862 # 55e8 <malloc+0x458>
     94e:	788040ef          	jal	ra,50d6 <printf>
    exit(1);
     952:	4505                	li	a0,1
     954:	354040ef          	jal	ra,4ca8 <exit>
      printf("%s: error: write aa %d new file failed\n", s, i);
     958:	8626                	mv	a2,s1
     95a:	85da                	mv	a1,s6
     95c:	00005517          	auipc	a0,0x5
     960:	cbc50513          	addi	a0,a0,-836 # 5618 <malloc+0x488>
     964:	772040ef          	jal	ra,50d6 <printf>
      exit(1);
     968:	4505                	li	a0,1
     96a:	33e040ef          	jal	ra,4ca8 <exit>
      printf("%s: error: write bb %d new file failed\n", s, i);
     96e:	8626                	mv	a2,s1
     970:	85da                	mv	a1,s6
     972:	00005517          	auipc	a0,0x5
     976:	cde50513          	addi	a0,a0,-802 # 5650 <malloc+0x4c0>
     97a:	75c040ef          	jal	ra,50d6 <printf>
      exit(1);
     97e:	4505                	li	a0,1
     980:	328040ef          	jal	ra,4ca8 <exit>
    printf("%s: error: open small failed!\n", s);
     984:	85da                	mv	a1,s6
     986:	00005517          	auipc	a0,0x5
     98a:	cf250513          	addi	a0,a0,-782 # 5678 <malloc+0x4e8>
     98e:	748040ef          	jal	ra,50d6 <printf>
    exit(1);
     992:	4505                	li	a0,1
     994:	314040ef          	jal	ra,4ca8 <exit>
    printf("%s: read failed\n", s);
     998:	85da                	mv	a1,s6
     99a:	00005517          	auipc	a0,0x5
     99e:	cfe50513          	addi	a0,a0,-770 # 5698 <malloc+0x508>
     9a2:	734040ef          	jal	ra,50d6 <printf>
    exit(1);
     9a6:	4505                	li	a0,1
     9a8:	300040ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink small failed\n", s);
     9ac:	85da                	mv	a1,s6
     9ae:	00005517          	auipc	a0,0x5
     9b2:	d0250513          	addi	a0,a0,-766 # 56b0 <malloc+0x520>
     9b6:	720040ef          	jal	ra,50d6 <printf>
    exit(1);
     9ba:	4505                	li	a0,1
     9bc:	2ec040ef          	jal	ra,4ca8 <exit>

00000000000009c0 <writebig>:
{
     9c0:	7139                	addi	sp,sp,-64
     9c2:	fc06                	sd	ra,56(sp)
     9c4:	f822                	sd	s0,48(sp)
     9c6:	f426                	sd	s1,40(sp)
     9c8:	f04a                	sd	s2,32(sp)
     9ca:	ec4e                	sd	s3,24(sp)
     9cc:	e852                	sd	s4,16(sp)
     9ce:	e456                	sd	s5,8(sp)
     9d0:	0080                	addi	s0,sp,64
     9d2:	8aaa                	mv	s5,a0
  fd = open("big", O_CREATE|O_RDWR);
     9d4:	20200593          	li	a1,514
     9d8:	00005517          	auipc	a0,0x5
     9dc:	cf850513          	addi	a0,a0,-776 # 56d0 <malloc+0x540>
     9e0:	308040ef          	jal	ra,4ce8 <open>
     9e4:	89aa                	mv	s3,a0
  for(i = 0; i < MAXFILE; i++){
     9e6:	4481                	li	s1,0
    ((int*)buf)[0] = i;
     9e8:	0000b917          	auipc	s2,0xb
     9ec:	2c090913          	addi	s2,s2,704 # bca8 <buf>
  for(i = 0; i < MAXFILE; i++){
     9f0:	10c00a13          	li	s4,268
  if(fd < 0){
     9f4:	06054463          	bltz	a0,a5c <writebig+0x9c>
    ((int*)buf)[0] = i;
     9f8:	00992023          	sw	s1,0(s2)
    if(write(fd, buf, BSIZE) != BSIZE){
     9fc:	40000613          	li	a2,1024
     a00:	85ca                	mv	a1,s2
     a02:	854e                	mv	a0,s3
     a04:	2c4040ef          	jal	ra,4cc8 <write>
     a08:	40000793          	li	a5,1024
     a0c:	06f51263          	bne	a0,a5,a70 <writebig+0xb0>
  for(i = 0; i < MAXFILE; i++){
     a10:	2485                	addiw	s1,s1,1
     a12:	ff4493e3          	bne	s1,s4,9f8 <writebig+0x38>
  close(fd);
     a16:	854e                	mv	a0,s3
     a18:	2b8040ef          	jal	ra,4cd0 <close>
  fd = open("big", O_RDONLY);
     a1c:	4581                	li	a1,0
     a1e:	00005517          	auipc	a0,0x5
     a22:	cb250513          	addi	a0,a0,-846 # 56d0 <malloc+0x540>
     a26:	2c2040ef          	jal	ra,4ce8 <open>
     a2a:	89aa                	mv	s3,a0
  n = 0;
     a2c:	4481                	li	s1,0
    i = read(fd, buf, BSIZE);
     a2e:	0000b917          	auipc	s2,0xb
     a32:	27a90913          	addi	s2,s2,634 # bca8 <buf>
  if(fd < 0){
     a36:	04054863          	bltz	a0,a86 <writebig+0xc6>
    i = read(fd, buf, BSIZE);
     a3a:	40000613          	li	a2,1024
     a3e:	85ca                	mv	a1,s2
     a40:	854e                	mv	a0,s3
     a42:	27e040ef          	jal	ra,4cc0 <read>
    if(i == 0){
     a46:	c931                	beqz	a0,a9a <writebig+0xda>
    } else if(i != BSIZE){
     a48:	40000793          	li	a5,1024
     a4c:	08f51a63          	bne	a0,a5,ae0 <writebig+0x120>
    if(((int*)buf)[0] != n){
     a50:	00092683          	lw	a3,0(s2)
     a54:	0a969163          	bne	a3,s1,af6 <writebig+0x136>
    n++;
     a58:	2485                	addiw	s1,s1,1
    i = read(fd, buf, BSIZE);
     a5a:	b7c5                	j	a3a <writebig+0x7a>
    printf("%s: error: creat big failed!\n", s);
     a5c:	85d6                	mv	a1,s5
     a5e:	00005517          	auipc	a0,0x5
     a62:	c7a50513          	addi	a0,a0,-902 # 56d8 <malloc+0x548>
     a66:	670040ef          	jal	ra,50d6 <printf>
    exit(1);
     a6a:	4505                	li	a0,1
     a6c:	23c040ef          	jal	ra,4ca8 <exit>
      printf("%s: error: write big file failed i=%d\n", s, i);
     a70:	8626                	mv	a2,s1
     a72:	85d6                	mv	a1,s5
     a74:	00005517          	auipc	a0,0x5
     a78:	c8450513          	addi	a0,a0,-892 # 56f8 <malloc+0x568>
     a7c:	65a040ef          	jal	ra,50d6 <printf>
      exit(1);
     a80:	4505                	li	a0,1
     a82:	226040ef          	jal	ra,4ca8 <exit>
    printf("%s: error: open big failed!\n", s);
     a86:	85d6                	mv	a1,s5
     a88:	00005517          	auipc	a0,0x5
     a8c:	c9850513          	addi	a0,a0,-872 # 5720 <malloc+0x590>
     a90:	646040ef          	jal	ra,50d6 <printf>
    exit(1);
     a94:	4505                	li	a0,1
     a96:	212040ef          	jal	ra,4ca8 <exit>
      if(n != MAXFILE){
     a9a:	10c00793          	li	a5,268
     a9e:	02f49663          	bne	s1,a5,aca <writebig+0x10a>
  close(fd);
     aa2:	854e                	mv	a0,s3
     aa4:	22c040ef          	jal	ra,4cd0 <close>
  if(unlink("big") < 0){
     aa8:	00005517          	auipc	a0,0x5
     aac:	c2850513          	addi	a0,a0,-984 # 56d0 <malloc+0x540>
     ab0:	248040ef          	jal	ra,4cf8 <unlink>
     ab4:	04054c63          	bltz	a0,b0c <writebig+0x14c>
}
     ab8:	70e2                	ld	ra,56(sp)
     aba:	7442                	ld	s0,48(sp)
     abc:	74a2                	ld	s1,40(sp)
     abe:	7902                	ld	s2,32(sp)
     ac0:	69e2                	ld	s3,24(sp)
     ac2:	6a42                	ld	s4,16(sp)
     ac4:	6aa2                	ld	s5,8(sp)
     ac6:	6121                	addi	sp,sp,64
     ac8:	8082                	ret
        printf("%s: read only %d blocks from big", s, n);
     aca:	8626                	mv	a2,s1
     acc:	85d6                	mv	a1,s5
     ace:	00005517          	auipc	a0,0x5
     ad2:	c7250513          	addi	a0,a0,-910 # 5740 <malloc+0x5b0>
     ad6:	600040ef          	jal	ra,50d6 <printf>
        exit(1);
     ada:	4505                	li	a0,1
     adc:	1cc040ef          	jal	ra,4ca8 <exit>
      printf("%s: read failed %d\n", s, i);
     ae0:	862a                	mv	a2,a0
     ae2:	85d6                	mv	a1,s5
     ae4:	00005517          	auipc	a0,0x5
     ae8:	c8450513          	addi	a0,a0,-892 # 5768 <malloc+0x5d8>
     aec:	5ea040ef          	jal	ra,50d6 <printf>
      exit(1);
     af0:	4505                	li	a0,1
     af2:	1b6040ef          	jal	ra,4ca8 <exit>
      printf("%s: read content of block %d is %d\n", s,
     af6:	8626                	mv	a2,s1
     af8:	85d6                	mv	a1,s5
     afa:	00005517          	auipc	a0,0x5
     afe:	c8650513          	addi	a0,a0,-890 # 5780 <malloc+0x5f0>
     b02:	5d4040ef          	jal	ra,50d6 <printf>
      exit(1);
     b06:	4505                	li	a0,1
     b08:	1a0040ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink big failed\n", s);
     b0c:	85d6                	mv	a1,s5
     b0e:	00005517          	auipc	a0,0x5
     b12:	c9a50513          	addi	a0,a0,-870 # 57a8 <malloc+0x618>
     b16:	5c0040ef          	jal	ra,50d6 <printf>
    exit(1);
     b1a:	4505                	li	a0,1
     b1c:	18c040ef          	jal	ra,4ca8 <exit>

0000000000000b20 <unlinkread>:
{
     b20:	7179                	addi	sp,sp,-48
     b22:	f406                	sd	ra,40(sp)
     b24:	f022                	sd	s0,32(sp)
     b26:	ec26                	sd	s1,24(sp)
     b28:	e84a                	sd	s2,16(sp)
     b2a:	e44e                	sd	s3,8(sp)
     b2c:	1800                	addi	s0,sp,48
     b2e:	89aa                	mv	s3,a0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     b30:	20200593          	li	a1,514
     b34:	00005517          	auipc	a0,0x5
     b38:	c8c50513          	addi	a0,a0,-884 # 57c0 <malloc+0x630>
     b3c:	1ac040ef          	jal	ra,4ce8 <open>
  if(fd < 0){
     b40:	0a054f63          	bltz	a0,bfe <unlinkread+0xde>
     b44:	84aa                	mv	s1,a0
  write(fd, "hello", SZ);
     b46:	4615                	li	a2,5
     b48:	00005597          	auipc	a1,0x5
     b4c:	ca858593          	addi	a1,a1,-856 # 57f0 <malloc+0x660>
     b50:	178040ef          	jal	ra,4cc8 <write>
  close(fd);
     b54:	8526                	mv	a0,s1
     b56:	17a040ef          	jal	ra,4cd0 <close>
  fd = open("unlinkread", O_RDWR);
     b5a:	4589                	li	a1,2
     b5c:	00005517          	auipc	a0,0x5
     b60:	c6450513          	addi	a0,a0,-924 # 57c0 <malloc+0x630>
     b64:	184040ef          	jal	ra,4ce8 <open>
     b68:	84aa                	mv	s1,a0
  if(fd < 0){
     b6a:	0a054463          	bltz	a0,c12 <unlinkread+0xf2>
  if(unlink("unlinkread") != 0){
     b6e:	00005517          	auipc	a0,0x5
     b72:	c5250513          	addi	a0,a0,-942 # 57c0 <malloc+0x630>
     b76:	182040ef          	jal	ra,4cf8 <unlink>
     b7a:	e555                	bnez	a0,c26 <unlinkread+0x106>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     b7c:	20200593          	li	a1,514
     b80:	00005517          	auipc	a0,0x5
     b84:	c4050513          	addi	a0,a0,-960 # 57c0 <malloc+0x630>
     b88:	160040ef          	jal	ra,4ce8 <open>
     b8c:	892a                	mv	s2,a0
  write(fd1, "yyy", 3);
     b8e:	460d                	li	a2,3
     b90:	00005597          	auipc	a1,0x5
     b94:	ca858593          	addi	a1,a1,-856 # 5838 <malloc+0x6a8>
     b98:	130040ef          	jal	ra,4cc8 <write>
  close(fd1);
     b9c:	854a                	mv	a0,s2
     b9e:	132040ef          	jal	ra,4cd0 <close>
  if(read(fd, buf, sizeof(buf)) != SZ){
     ba2:	660d                	lui	a2,0x3
     ba4:	0000b597          	auipc	a1,0xb
     ba8:	10458593          	addi	a1,a1,260 # bca8 <buf>
     bac:	8526                	mv	a0,s1
     bae:	112040ef          	jal	ra,4cc0 <read>
     bb2:	4795                	li	a5,5
     bb4:	08f51363          	bne	a0,a5,c3a <unlinkread+0x11a>
  if(buf[0] != 'h'){
     bb8:	0000b717          	auipc	a4,0xb
     bbc:	0f074703          	lbu	a4,240(a4) # bca8 <buf>
     bc0:	06800793          	li	a5,104
     bc4:	08f71563          	bne	a4,a5,c4e <unlinkread+0x12e>
  if(write(fd, buf, 10) != 10){
     bc8:	4629                	li	a2,10
     bca:	0000b597          	auipc	a1,0xb
     bce:	0de58593          	addi	a1,a1,222 # bca8 <buf>
     bd2:	8526                	mv	a0,s1
     bd4:	0f4040ef          	jal	ra,4cc8 <write>
     bd8:	47a9                	li	a5,10
     bda:	08f51463          	bne	a0,a5,c62 <unlinkread+0x142>
  close(fd);
     bde:	8526                	mv	a0,s1
     be0:	0f0040ef          	jal	ra,4cd0 <close>
  unlink("unlinkread");
     be4:	00005517          	auipc	a0,0x5
     be8:	bdc50513          	addi	a0,a0,-1060 # 57c0 <malloc+0x630>
     bec:	10c040ef          	jal	ra,4cf8 <unlink>
}
     bf0:	70a2                	ld	ra,40(sp)
     bf2:	7402                	ld	s0,32(sp)
     bf4:	64e2                	ld	s1,24(sp)
     bf6:	6942                	ld	s2,16(sp)
     bf8:	69a2                	ld	s3,8(sp)
     bfa:	6145                	addi	sp,sp,48
     bfc:	8082                	ret
    printf("%s: create unlinkread failed\n", s);
     bfe:	85ce                	mv	a1,s3
     c00:	00005517          	auipc	a0,0x5
     c04:	bd050513          	addi	a0,a0,-1072 # 57d0 <malloc+0x640>
     c08:	4ce040ef          	jal	ra,50d6 <printf>
    exit(1);
     c0c:	4505                	li	a0,1
     c0e:	09a040ef          	jal	ra,4ca8 <exit>
    printf("%s: open unlinkread failed\n", s);
     c12:	85ce                	mv	a1,s3
     c14:	00005517          	auipc	a0,0x5
     c18:	be450513          	addi	a0,a0,-1052 # 57f8 <malloc+0x668>
     c1c:	4ba040ef          	jal	ra,50d6 <printf>
    exit(1);
     c20:	4505                	li	a0,1
     c22:	086040ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink unlinkread failed\n", s);
     c26:	85ce                	mv	a1,s3
     c28:	00005517          	auipc	a0,0x5
     c2c:	bf050513          	addi	a0,a0,-1040 # 5818 <malloc+0x688>
     c30:	4a6040ef          	jal	ra,50d6 <printf>
    exit(1);
     c34:	4505                	li	a0,1
     c36:	072040ef          	jal	ra,4ca8 <exit>
    printf("%s: unlinkread read failed", s);
     c3a:	85ce                	mv	a1,s3
     c3c:	00005517          	auipc	a0,0x5
     c40:	c0450513          	addi	a0,a0,-1020 # 5840 <malloc+0x6b0>
     c44:	492040ef          	jal	ra,50d6 <printf>
    exit(1);
     c48:	4505                	li	a0,1
     c4a:	05e040ef          	jal	ra,4ca8 <exit>
    printf("%s: unlinkread wrong data\n", s);
     c4e:	85ce                	mv	a1,s3
     c50:	00005517          	auipc	a0,0x5
     c54:	c1050513          	addi	a0,a0,-1008 # 5860 <malloc+0x6d0>
     c58:	47e040ef          	jal	ra,50d6 <printf>
    exit(1);
     c5c:	4505                	li	a0,1
     c5e:	04a040ef          	jal	ra,4ca8 <exit>
    printf("%s: unlinkread write failed\n", s);
     c62:	85ce                	mv	a1,s3
     c64:	00005517          	auipc	a0,0x5
     c68:	c1c50513          	addi	a0,a0,-996 # 5880 <malloc+0x6f0>
     c6c:	46a040ef          	jal	ra,50d6 <printf>
    exit(1);
     c70:	4505                	li	a0,1
     c72:	036040ef          	jal	ra,4ca8 <exit>

0000000000000c76 <linktest>:
{
     c76:	1101                	addi	sp,sp,-32
     c78:	ec06                	sd	ra,24(sp)
     c7a:	e822                	sd	s0,16(sp)
     c7c:	e426                	sd	s1,8(sp)
     c7e:	e04a                	sd	s2,0(sp)
     c80:	1000                	addi	s0,sp,32
     c82:	892a                	mv	s2,a0
  unlink("lf1");
     c84:	00005517          	auipc	a0,0x5
     c88:	c1c50513          	addi	a0,a0,-996 # 58a0 <malloc+0x710>
     c8c:	06c040ef          	jal	ra,4cf8 <unlink>
  unlink("lf2");
     c90:	00005517          	auipc	a0,0x5
     c94:	c1850513          	addi	a0,a0,-1000 # 58a8 <malloc+0x718>
     c98:	060040ef          	jal	ra,4cf8 <unlink>
  fd = open("lf1", O_CREATE|O_RDWR);
     c9c:	20200593          	li	a1,514
     ca0:	00005517          	auipc	a0,0x5
     ca4:	c0050513          	addi	a0,a0,-1024 # 58a0 <malloc+0x710>
     ca8:	040040ef          	jal	ra,4ce8 <open>
  if(fd < 0){
     cac:	0c054f63          	bltz	a0,d8a <linktest+0x114>
     cb0:	84aa                	mv	s1,a0
  if(write(fd, "hello", SZ) != SZ){
     cb2:	4615                	li	a2,5
     cb4:	00005597          	auipc	a1,0x5
     cb8:	b3c58593          	addi	a1,a1,-1220 # 57f0 <malloc+0x660>
     cbc:	00c040ef          	jal	ra,4cc8 <write>
     cc0:	4795                	li	a5,5
     cc2:	0cf51e63          	bne	a0,a5,d9e <linktest+0x128>
  close(fd);
     cc6:	8526                	mv	a0,s1
     cc8:	008040ef          	jal	ra,4cd0 <close>
  if(link("lf1", "lf2") < 0){
     ccc:	00005597          	auipc	a1,0x5
     cd0:	bdc58593          	addi	a1,a1,-1060 # 58a8 <malloc+0x718>
     cd4:	00005517          	auipc	a0,0x5
     cd8:	bcc50513          	addi	a0,a0,-1076 # 58a0 <malloc+0x710>
     cdc:	02c040ef          	jal	ra,4d08 <link>
     ce0:	0c054963          	bltz	a0,db2 <linktest+0x13c>
  unlink("lf1");
     ce4:	00005517          	auipc	a0,0x5
     ce8:	bbc50513          	addi	a0,a0,-1092 # 58a0 <malloc+0x710>
     cec:	00c040ef          	jal	ra,4cf8 <unlink>
  if(open("lf1", 0) >= 0){
     cf0:	4581                	li	a1,0
     cf2:	00005517          	auipc	a0,0x5
     cf6:	bae50513          	addi	a0,a0,-1106 # 58a0 <malloc+0x710>
     cfa:	7ef030ef          	jal	ra,4ce8 <open>
     cfe:	0c055463          	bgez	a0,dc6 <linktest+0x150>
  fd = open("lf2", 0);
     d02:	4581                	li	a1,0
     d04:	00005517          	auipc	a0,0x5
     d08:	ba450513          	addi	a0,a0,-1116 # 58a8 <malloc+0x718>
     d0c:	7dd030ef          	jal	ra,4ce8 <open>
     d10:	84aa                	mv	s1,a0
  if(fd < 0){
     d12:	0c054463          	bltz	a0,dda <linktest+0x164>
  if(read(fd, buf, sizeof(buf)) != SZ){
     d16:	660d                	lui	a2,0x3
     d18:	0000b597          	auipc	a1,0xb
     d1c:	f9058593          	addi	a1,a1,-112 # bca8 <buf>
     d20:	7a1030ef          	jal	ra,4cc0 <read>
     d24:	4795                	li	a5,5
     d26:	0cf51463          	bne	a0,a5,dee <linktest+0x178>
  close(fd);
     d2a:	8526                	mv	a0,s1
     d2c:	7a5030ef          	jal	ra,4cd0 <close>
  if(link("lf2", "lf2") >= 0){
     d30:	00005597          	auipc	a1,0x5
     d34:	b7858593          	addi	a1,a1,-1160 # 58a8 <malloc+0x718>
     d38:	852e                	mv	a0,a1
     d3a:	7cf030ef          	jal	ra,4d08 <link>
     d3e:	0c055263          	bgez	a0,e02 <linktest+0x18c>
  unlink("lf2");
     d42:	00005517          	auipc	a0,0x5
     d46:	b6650513          	addi	a0,a0,-1178 # 58a8 <malloc+0x718>
     d4a:	7af030ef          	jal	ra,4cf8 <unlink>
  if(link("lf2", "lf1") >= 0){
     d4e:	00005597          	auipc	a1,0x5
     d52:	b5258593          	addi	a1,a1,-1198 # 58a0 <malloc+0x710>
     d56:	00005517          	auipc	a0,0x5
     d5a:	b5250513          	addi	a0,a0,-1198 # 58a8 <malloc+0x718>
     d5e:	7ab030ef          	jal	ra,4d08 <link>
     d62:	0a055a63          	bgez	a0,e16 <linktest+0x1a0>
  if(link(".", "lf1") >= 0){
     d66:	00005597          	auipc	a1,0x5
     d6a:	b3a58593          	addi	a1,a1,-1222 # 58a0 <malloc+0x710>
     d6e:	00005517          	auipc	a0,0x5
     d72:	c4250513          	addi	a0,a0,-958 # 59b0 <malloc+0x820>
     d76:	793030ef          	jal	ra,4d08 <link>
     d7a:	0a055863          	bgez	a0,e2a <linktest+0x1b4>
}
     d7e:	60e2                	ld	ra,24(sp)
     d80:	6442                	ld	s0,16(sp)
     d82:	64a2                	ld	s1,8(sp)
     d84:	6902                	ld	s2,0(sp)
     d86:	6105                	addi	sp,sp,32
     d88:	8082                	ret
    printf("%s: create lf1 failed\n", s);
     d8a:	85ca                	mv	a1,s2
     d8c:	00005517          	auipc	a0,0x5
     d90:	b2450513          	addi	a0,a0,-1244 # 58b0 <malloc+0x720>
     d94:	342040ef          	jal	ra,50d6 <printf>
    exit(1);
     d98:	4505                	li	a0,1
     d9a:	70f030ef          	jal	ra,4ca8 <exit>
    printf("%s: write lf1 failed\n", s);
     d9e:	85ca                	mv	a1,s2
     da0:	00005517          	auipc	a0,0x5
     da4:	b2850513          	addi	a0,a0,-1240 # 58c8 <malloc+0x738>
     da8:	32e040ef          	jal	ra,50d6 <printf>
    exit(1);
     dac:	4505                	li	a0,1
     dae:	6fb030ef          	jal	ra,4ca8 <exit>
    printf("%s: link lf1 lf2 failed\n", s);
     db2:	85ca                	mv	a1,s2
     db4:	00005517          	auipc	a0,0x5
     db8:	b2c50513          	addi	a0,a0,-1236 # 58e0 <malloc+0x750>
     dbc:	31a040ef          	jal	ra,50d6 <printf>
    exit(1);
     dc0:	4505                	li	a0,1
     dc2:	6e7030ef          	jal	ra,4ca8 <exit>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     dc6:	85ca                	mv	a1,s2
     dc8:	00005517          	auipc	a0,0x5
     dcc:	b3850513          	addi	a0,a0,-1224 # 5900 <malloc+0x770>
     dd0:	306040ef          	jal	ra,50d6 <printf>
    exit(1);
     dd4:	4505                	li	a0,1
     dd6:	6d3030ef          	jal	ra,4ca8 <exit>
    printf("%s: open lf2 failed\n", s);
     dda:	85ca                	mv	a1,s2
     ddc:	00005517          	auipc	a0,0x5
     de0:	b5450513          	addi	a0,a0,-1196 # 5930 <malloc+0x7a0>
     de4:	2f2040ef          	jal	ra,50d6 <printf>
    exit(1);
     de8:	4505                	li	a0,1
     dea:	6bf030ef          	jal	ra,4ca8 <exit>
    printf("%s: read lf2 failed\n", s);
     dee:	85ca                	mv	a1,s2
     df0:	00005517          	auipc	a0,0x5
     df4:	b5850513          	addi	a0,a0,-1192 # 5948 <malloc+0x7b8>
     df8:	2de040ef          	jal	ra,50d6 <printf>
    exit(1);
     dfc:	4505                	li	a0,1
     dfe:	6ab030ef          	jal	ra,4ca8 <exit>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     e02:	85ca                	mv	a1,s2
     e04:	00005517          	auipc	a0,0x5
     e08:	b5c50513          	addi	a0,a0,-1188 # 5960 <malloc+0x7d0>
     e0c:	2ca040ef          	jal	ra,50d6 <printf>
    exit(1);
     e10:	4505                	li	a0,1
     e12:	697030ef          	jal	ra,4ca8 <exit>
    printf("%s: link non-existent succeeded! oops\n", s);
     e16:	85ca                	mv	a1,s2
     e18:	00005517          	auipc	a0,0x5
     e1c:	b7050513          	addi	a0,a0,-1168 # 5988 <malloc+0x7f8>
     e20:	2b6040ef          	jal	ra,50d6 <printf>
    exit(1);
     e24:	4505                	li	a0,1
     e26:	683030ef          	jal	ra,4ca8 <exit>
    printf("%s: link . lf1 succeeded! oops\n", s);
     e2a:	85ca                	mv	a1,s2
     e2c:	00005517          	auipc	a0,0x5
     e30:	b8c50513          	addi	a0,a0,-1140 # 59b8 <malloc+0x828>
     e34:	2a2040ef          	jal	ra,50d6 <printf>
    exit(1);
     e38:	4505                	li	a0,1
     e3a:	66f030ef          	jal	ra,4ca8 <exit>

0000000000000e3e <validatetest>:
{
     e3e:	7139                	addi	sp,sp,-64
     e40:	fc06                	sd	ra,56(sp)
     e42:	f822                	sd	s0,48(sp)
     e44:	f426                	sd	s1,40(sp)
     e46:	f04a                	sd	s2,32(sp)
     e48:	ec4e                	sd	s3,24(sp)
     e4a:	e852                	sd	s4,16(sp)
     e4c:	e456                	sd	s5,8(sp)
     e4e:	e05a                	sd	s6,0(sp)
     e50:	0080                	addi	s0,sp,64
     e52:	8b2a                	mv	s6,a0
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     e54:	4481                	li	s1,0
    if(link("nosuchfile", (char*)p) != -1){
     e56:	00005997          	auipc	s3,0x5
     e5a:	b8298993          	addi	s3,s3,-1150 # 59d8 <malloc+0x848>
     e5e:	597d                	li	s2,-1
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     e60:	6a85                	lui	s5,0x1
     e62:	00114a37          	lui	s4,0x114
    if(link("nosuchfile", (char*)p) != -1){
     e66:	85a6                	mv	a1,s1
     e68:	854e                	mv	a0,s3
     e6a:	69f030ef          	jal	ra,4d08 <link>
     e6e:	01251f63          	bne	a0,s2,e8c <validatetest+0x4e>
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     e72:	94d6                	add	s1,s1,s5
     e74:	ff4499e3          	bne	s1,s4,e66 <validatetest+0x28>
}
     e78:	70e2                	ld	ra,56(sp)
     e7a:	7442                	ld	s0,48(sp)
     e7c:	74a2                	ld	s1,40(sp)
     e7e:	7902                	ld	s2,32(sp)
     e80:	69e2                	ld	s3,24(sp)
     e82:	6a42                	ld	s4,16(sp)
     e84:	6aa2                	ld	s5,8(sp)
     e86:	6b02                	ld	s6,0(sp)
     e88:	6121                	addi	sp,sp,64
     e8a:	8082                	ret
      printf("%s: link should not succeed\n", s);
     e8c:	85da                	mv	a1,s6
     e8e:	00005517          	auipc	a0,0x5
     e92:	b5a50513          	addi	a0,a0,-1190 # 59e8 <malloc+0x858>
     e96:	240040ef          	jal	ra,50d6 <printf>
      exit(1);
     e9a:	4505                	li	a0,1
     e9c:	60d030ef          	jal	ra,4ca8 <exit>

0000000000000ea0 <bigdir>:
{
     ea0:	715d                	addi	sp,sp,-80
     ea2:	e486                	sd	ra,72(sp)
     ea4:	e0a2                	sd	s0,64(sp)
     ea6:	fc26                	sd	s1,56(sp)
     ea8:	f84a                	sd	s2,48(sp)
     eaa:	f44e                	sd	s3,40(sp)
     eac:	f052                	sd	s4,32(sp)
     eae:	ec56                	sd	s5,24(sp)
     eb0:	e85a                	sd	s6,16(sp)
     eb2:	0880                	addi	s0,sp,80
     eb4:	89aa                	mv	s3,a0
  unlink("bd");
     eb6:	00005517          	auipc	a0,0x5
     eba:	b5250513          	addi	a0,a0,-1198 # 5a08 <malloc+0x878>
     ebe:	63b030ef          	jal	ra,4cf8 <unlink>
  fd = open("bd", O_CREATE);
     ec2:	20000593          	li	a1,512
     ec6:	00005517          	auipc	a0,0x5
     eca:	b4250513          	addi	a0,a0,-1214 # 5a08 <malloc+0x878>
     ece:	61b030ef          	jal	ra,4ce8 <open>
  if(fd < 0){
     ed2:	0c054163          	bltz	a0,f94 <bigdir+0xf4>
  close(fd);
     ed6:	5fb030ef          	jal	ra,4cd0 <close>
  for(i = 0; i < N; i++){
     eda:	4901                	li	s2,0
    name[0] = 'x';
     edc:	07800a93          	li	s5,120
    if(link("bd", name) != 0){
     ee0:	00005a17          	auipc	s4,0x5
     ee4:	b28a0a13          	addi	s4,s4,-1240 # 5a08 <malloc+0x878>
  for(i = 0; i < N; i++){
     ee8:	1f400b13          	li	s6,500
    name[0] = 'x';
     eec:	fb540823          	sb	s5,-80(s0)
    name[1] = '0' + (i / 64);
     ef0:	41f9579b          	sraiw	a5,s2,0x1f
     ef4:	01a7d71b          	srliw	a4,a5,0x1a
     ef8:	012707bb          	addw	a5,a4,s2
     efc:	4067d69b          	sraiw	a3,a5,0x6
     f00:	0306869b          	addiw	a3,a3,48
     f04:	fad408a3          	sb	a3,-79(s0)
    name[2] = '0' + (i % 64);
     f08:	03f7f793          	andi	a5,a5,63
     f0c:	9f99                	subw	a5,a5,a4
     f0e:	0307879b          	addiw	a5,a5,48
     f12:	faf40923          	sb	a5,-78(s0)
    name[3] = '\0';
     f16:	fa0409a3          	sb	zero,-77(s0)
    if(link("bd", name) != 0){
     f1a:	fb040593          	addi	a1,s0,-80
     f1e:	8552                	mv	a0,s4
     f20:	5e9030ef          	jal	ra,4d08 <link>
     f24:	84aa                	mv	s1,a0
     f26:	e149                	bnez	a0,fa8 <bigdir+0x108>
  for(i = 0; i < N; i++){
     f28:	2905                	addiw	s2,s2,1
     f2a:	fd6911e3          	bne	s2,s6,eec <bigdir+0x4c>
  unlink("bd");
     f2e:	00005517          	auipc	a0,0x5
     f32:	ada50513          	addi	a0,a0,-1318 # 5a08 <malloc+0x878>
     f36:	5c3030ef          	jal	ra,4cf8 <unlink>
    name[0] = 'x';
     f3a:	07800913          	li	s2,120
  for(i = 0; i < N; i++){
     f3e:	1f400a13          	li	s4,500
    name[0] = 'x';
     f42:	fb240823          	sb	s2,-80(s0)
    name[1] = '0' + (i / 64);
     f46:	41f4d79b          	sraiw	a5,s1,0x1f
     f4a:	01a7d71b          	srliw	a4,a5,0x1a
     f4e:	009707bb          	addw	a5,a4,s1
     f52:	4067d69b          	sraiw	a3,a5,0x6
     f56:	0306869b          	addiw	a3,a3,48
     f5a:	fad408a3          	sb	a3,-79(s0)
    name[2] = '0' + (i % 64);
     f5e:	03f7f793          	andi	a5,a5,63
     f62:	9f99                	subw	a5,a5,a4
     f64:	0307879b          	addiw	a5,a5,48
     f68:	faf40923          	sb	a5,-78(s0)
    name[3] = '\0';
     f6c:	fa0409a3          	sb	zero,-77(s0)
    if(unlink(name) != 0){
     f70:	fb040513          	addi	a0,s0,-80
     f74:	585030ef          	jal	ra,4cf8 <unlink>
     f78:	e529                	bnez	a0,fc2 <bigdir+0x122>
  for(i = 0; i < N; i++){
     f7a:	2485                	addiw	s1,s1,1
     f7c:	fd4493e3          	bne	s1,s4,f42 <bigdir+0xa2>
}
     f80:	60a6                	ld	ra,72(sp)
     f82:	6406                	ld	s0,64(sp)
     f84:	74e2                	ld	s1,56(sp)
     f86:	7942                	ld	s2,48(sp)
     f88:	79a2                	ld	s3,40(sp)
     f8a:	7a02                	ld	s4,32(sp)
     f8c:	6ae2                	ld	s5,24(sp)
     f8e:	6b42                	ld	s6,16(sp)
     f90:	6161                	addi	sp,sp,80
     f92:	8082                	ret
    printf("%s: bigdir create failed\n", s);
     f94:	85ce                	mv	a1,s3
     f96:	00005517          	auipc	a0,0x5
     f9a:	a7a50513          	addi	a0,a0,-1414 # 5a10 <malloc+0x880>
     f9e:	138040ef          	jal	ra,50d6 <printf>
    exit(1);
     fa2:	4505                	li	a0,1
     fa4:	505030ef          	jal	ra,4ca8 <exit>
      printf("%s: bigdir i=%d link(bd, %s) failed\n", s, i, name);
     fa8:	fb040693          	addi	a3,s0,-80
     fac:	864a                	mv	a2,s2
     fae:	85ce                	mv	a1,s3
     fb0:	00005517          	auipc	a0,0x5
     fb4:	a8050513          	addi	a0,a0,-1408 # 5a30 <malloc+0x8a0>
     fb8:	11e040ef          	jal	ra,50d6 <printf>
      exit(1);
     fbc:	4505                	li	a0,1
     fbe:	4eb030ef          	jal	ra,4ca8 <exit>
      printf("%s: bigdir unlink failed", s);
     fc2:	85ce                	mv	a1,s3
     fc4:	00005517          	auipc	a0,0x5
     fc8:	a9450513          	addi	a0,a0,-1388 # 5a58 <malloc+0x8c8>
     fcc:	10a040ef          	jal	ra,50d6 <printf>
      exit(1);
     fd0:	4505                	li	a0,1
     fd2:	4d7030ef          	jal	ra,4ca8 <exit>

0000000000000fd6 <pgbug>:
{
     fd6:	7179                	addi	sp,sp,-48
     fd8:	f406                	sd	ra,40(sp)
     fda:	f022                	sd	s0,32(sp)
     fdc:	ec26                	sd	s1,24(sp)
     fde:	1800                	addi	s0,sp,48
  argv[0] = 0;
     fe0:	fc043c23          	sd	zero,-40(s0)
  exec(big, argv);
     fe4:	00007497          	auipc	s1,0x7
     fe8:	01c48493          	addi	s1,s1,28 # 8000 <big>
     fec:	fd840593          	addi	a1,s0,-40
     ff0:	6088                	ld	a0,0(s1)
     ff2:	4ef030ef          	jal	ra,4ce0 <exec>
  pipe(big);
     ff6:	6088                	ld	a0,0(s1)
     ff8:	4c1030ef          	jal	ra,4cb8 <pipe>
  exit(0);
     ffc:	4501                	li	a0,0
     ffe:	4ab030ef          	jal	ra,4ca8 <exit>

0000000000001002 <badarg>:
{
    1002:	7139                	addi	sp,sp,-64
    1004:	fc06                	sd	ra,56(sp)
    1006:	f822                	sd	s0,48(sp)
    1008:	f426                	sd	s1,40(sp)
    100a:	f04a                	sd	s2,32(sp)
    100c:	ec4e                	sd	s3,24(sp)
    100e:	0080                	addi	s0,sp,64
    1010:	64b1                	lui	s1,0xc
    1012:	35048493          	addi	s1,s1,848 # c350 <buf+0x6a8>
    argv[0] = (char*)0xffffffff;
    1016:	597d                	li	s2,-1
    1018:	02095913          	srli	s2,s2,0x20
    exec("echo", argv);
    101c:	00004997          	auipc	s3,0x4
    1020:	2ac98993          	addi	s3,s3,684 # 52c8 <malloc+0x138>
    argv[0] = (char*)0xffffffff;
    1024:	fd243023          	sd	s2,-64(s0)
    argv[1] = 0;
    1028:	fc043423          	sd	zero,-56(s0)
    exec("echo", argv);
    102c:	fc040593          	addi	a1,s0,-64
    1030:	854e                	mv	a0,s3
    1032:	4af030ef          	jal	ra,4ce0 <exec>
  for(int i = 0; i < 50000; i++){
    1036:	34fd                	addiw	s1,s1,-1
    1038:	f4f5                	bnez	s1,1024 <badarg+0x22>
  exit(0);
    103a:	4501                	li	a0,0
    103c:	46d030ef          	jal	ra,4ca8 <exit>

0000000000001040 <copyinstr2>:
{
    1040:	7155                	addi	sp,sp,-208
    1042:	e586                	sd	ra,200(sp)
    1044:	e1a2                	sd	s0,192(sp)
    1046:	0980                	addi	s0,sp,208
  for(int i = 0; i < MAXPATH; i++)
    1048:	f6840793          	addi	a5,s0,-152
    104c:	fe840693          	addi	a3,s0,-24
    b[i] = 'x';
    1050:	07800713          	li	a4,120
    1054:	00e78023          	sb	a4,0(a5)
  for(int i = 0; i < MAXPATH; i++)
    1058:	0785                	addi	a5,a5,1
    105a:	fed79de3          	bne	a5,a3,1054 <copyinstr2+0x14>
  b[MAXPATH] = '\0';
    105e:	fe040423          	sb	zero,-24(s0)
  int ret = unlink(b);
    1062:	f6840513          	addi	a0,s0,-152
    1066:	493030ef          	jal	ra,4cf8 <unlink>
  if(ret != -1){
    106a:	57fd                	li	a5,-1
    106c:	0cf51263          	bne	a0,a5,1130 <copyinstr2+0xf0>
  int fd = open(b, O_CREATE | O_WRONLY);
    1070:	20100593          	li	a1,513
    1074:	f6840513          	addi	a0,s0,-152
    1078:	471030ef          	jal	ra,4ce8 <open>
  if(fd != -1){
    107c:	57fd                	li	a5,-1
    107e:	0cf51563          	bne	a0,a5,1148 <copyinstr2+0x108>
  ret = link(b, b);
    1082:	f6840593          	addi	a1,s0,-152
    1086:	852e                	mv	a0,a1
    1088:	481030ef          	jal	ra,4d08 <link>
  if(ret != -1){
    108c:	57fd                	li	a5,-1
    108e:	0cf51963          	bne	a0,a5,1160 <copyinstr2+0x120>
  char *args[] = { "xx", 0 };
    1092:	00006797          	auipc	a5,0x6
    1096:	bf678793          	addi	a5,a5,-1034 # 6c88 <malloc+0x1af8>
    109a:	f4f43c23          	sd	a5,-168(s0)
    109e:	f6043023          	sd	zero,-160(s0)
  ret = exec(b, args);
    10a2:	f5840593          	addi	a1,s0,-168
    10a6:	f6840513          	addi	a0,s0,-152
    10aa:	437030ef          	jal	ra,4ce0 <exec>
  if(ret != -1){
    10ae:	57fd                	li	a5,-1
    10b0:	0cf51563          	bne	a0,a5,117a <copyinstr2+0x13a>
  int pid = fork();
    10b4:	3ed030ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    10b8:	0c054d63          	bltz	a0,1192 <copyinstr2+0x152>
  if(pid == 0){
    10bc:	0e051863          	bnez	a0,11ac <copyinstr2+0x16c>
    10c0:	00007797          	auipc	a5,0x7
    10c4:	4d078793          	addi	a5,a5,1232 # 8590 <big.0>
    10c8:	00008697          	auipc	a3,0x8
    10cc:	4c868693          	addi	a3,a3,1224 # 9590 <big.0+0x1000>
      big[i] = 'x';
    10d0:	07800713          	li	a4,120
    10d4:	00e78023          	sb	a4,0(a5)
    for(int i = 0; i < PGSIZE; i++)
    10d8:	0785                	addi	a5,a5,1
    10da:	fed79de3          	bne	a5,a3,10d4 <copyinstr2+0x94>
    big[PGSIZE] = '\0';
    10de:	00008797          	auipc	a5,0x8
    10e2:	4a078923          	sb	zero,1202(a5) # 9590 <big.0+0x1000>
    char *args2[] = { big, big, big, 0 };
    10e6:	00006797          	auipc	a5,0x6
    10ea:	64278793          	addi	a5,a5,1602 # 7728 <malloc+0x2598>
    10ee:	6fb0                	ld	a2,88(a5)
    10f0:	73b4                	ld	a3,96(a5)
    10f2:	77b8                	ld	a4,104(a5)
    10f4:	7bbc                	ld	a5,112(a5)
    10f6:	f2c43823          	sd	a2,-208(s0)
    10fa:	f2d43c23          	sd	a3,-200(s0)
    10fe:	f4e43023          	sd	a4,-192(s0)
    1102:	f4f43423          	sd	a5,-184(s0)
    ret = exec("echo", args2);
    1106:	f3040593          	addi	a1,s0,-208
    110a:	00004517          	auipc	a0,0x4
    110e:	1be50513          	addi	a0,a0,446 # 52c8 <malloc+0x138>
    1112:	3cf030ef          	jal	ra,4ce0 <exec>
    if(ret != -1){
    1116:	57fd                	li	a5,-1
    1118:	08f50663          	beq	a0,a5,11a4 <copyinstr2+0x164>
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    111c:	55fd                	li	a1,-1
    111e:	00005517          	auipc	a0,0x5
    1122:	9e250513          	addi	a0,a0,-1566 # 5b00 <malloc+0x970>
    1126:	7b1030ef          	jal	ra,50d6 <printf>
      exit(1);
    112a:	4505                	li	a0,1
    112c:	37d030ef          	jal	ra,4ca8 <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1130:	862a                	mv	a2,a0
    1132:	f6840593          	addi	a1,s0,-152
    1136:	00005517          	auipc	a0,0x5
    113a:	94250513          	addi	a0,a0,-1726 # 5a78 <malloc+0x8e8>
    113e:	799030ef          	jal	ra,50d6 <printf>
    exit(1);
    1142:	4505                	li	a0,1
    1144:	365030ef          	jal	ra,4ca8 <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1148:	862a                	mv	a2,a0
    114a:	f6840593          	addi	a1,s0,-152
    114e:	00005517          	auipc	a0,0x5
    1152:	94a50513          	addi	a0,a0,-1718 # 5a98 <malloc+0x908>
    1156:	781030ef          	jal	ra,50d6 <printf>
    exit(1);
    115a:	4505                	li	a0,1
    115c:	34d030ef          	jal	ra,4ca8 <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    1160:	86aa                	mv	a3,a0
    1162:	f6840613          	addi	a2,s0,-152
    1166:	85b2                	mv	a1,a2
    1168:	00005517          	auipc	a0,0x5
    116c:	95050513          	addi	a0,a0,-1712 # 5ab8 <malloc+0x928>
    1170:	767030ef          	jal	ra,50d6 <printf>
    exit(1);
    1174:	4505                	li	a0,1
    1176:	333030ef          	jal	ra,4ca8 <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    117a:	567d                	li	a2,-1
    117c:	f6840593          	addi	a1,s0,-152
    1180:	00005517          	auipc	a0,0x5
    1184:	96050513          	addi	a0,a0,-1696 # 5ae0 <malloc+0x950>
    1188:	74f030ef          	jal	ra,50d6 <printf>
    exit(1);
    118c:	4505                	li	a0,1
    118e:	31b030ef          	jal	ra,4ca8 <exit>
    printf("fork failed\n");
    1192:	00006517          	auipc	a0,0x6
    1196:	ff650513          	addi	a0,a0,-10 # 7188 <malloc+0x1ff8>
    119a:	73d030ef          	jal	ra,50d6 <printf>
    exit(1);
    119e:	4505                	li	a0,1
    11a0:	309030ef          	jal	ra,4ca8 <exit>
    exit(747); // OK
    11a4:	2eb00513          	li	a0,747
    11a8:	301030ef          	jal	ra,4ca8 <exit>
  int st = 0;
    11ac:	f4042a23          	sw	zero,-172(s0)
  wait(&st);
    11b0:	f5440513          	addi	a0,s0,-172
    11b4:	2fd030ef          	jal	ra,4cb0 <wait>
  if(st != 747){
    11b8:	f5442703          	lw	a4,-172(s0)
    11bc:	2eb00793          	li	a5,747
    11c0:	00f71663          	bne	a4,a5,11cc <copyinstr2+0x18c>
}
    11c4:	60ae                	ld	ra,200(sp)
    11c6:	640e                	ld	s0,192(sp)
    11c8:	6169                	addi	sp,sp,208
    11ca:	8082                	ret
    printf("exec(echo, BIG) succeeded, should have failed\n");
    11cc:	00005517          	auipc	a0,0x5
    11d0:	95c50513          	addi	a0,a0,-1700 # 5b28 <malloc+0x998>
    11d4:	703030ef          	jal	ra,50d6 <printf>
    exit(1);
    11d8:	4505                	li	a0,1
    11da:	2cf030ef          	jal	ra,4ca8 <exit>

00000000000011de <truncate3>:
{
    11de:	7159                	addi	sp,sp,-112
    11e0:	f486                	sd	ra,104(sp)
    11e2:	f0a2                	sd	s0,96(sp)
    11e4:	eca6                	sd	s1,88(sp)
    11e6:	e8ca                	sd	s2,80(sp)
    11e8:	e4ce                	sd	s3,72(sp)
    11ea:	e0d2                	sd	s4,64(sp)
    11ec:	fc56                	sd	s5,56(sp)
    11ee:	1880                	addi	s0,sp,112
    11f0:	892a                	mv	s2,a0
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
    11f2:	60100593          	li	a1,1537
    11f6:	00004517          	auipc	a0,0x4
    11fa:	12a50513          	addi	a0,a0,298 # 5320 <malloc+0x190>
    11fe:	2eb030ef          	jal	ra,4ce8 <open>
    1202:	2cf030ef          	jal	ra,4cd0 <close>
  pid = fork();
    1206:	29b030ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    120a:	06054263          	bltz	a0,126e <truncate3+0x90>
  if(pid == 0){
    120e:	ed59                	bnez	a0,12ac <truncate3+0xce>
    1210:	06400993          	li	s3,100
      int fd = open("truncfile", O_WRONLY);
    1214:	00004a17          	auipc	s4,0x4
    1218:	10ca0a13          	addi	s4,s4,268 # 5320 <malloc+0x190>
      int n = write(fd, "1234567890", 10);
    121c:	00005a97          	auipc	s5,0x5
    1220:	96ca8a93          	addi	s5,s5,-1684 # 5b88 <malloc+0x9f8>
      int fd = open("truncfile", O_WRONLY);
    1224:	4585                	li	a1,1
    1226:	8552                	mv	a0,s4
    1228:	2c1030ef          	jal	ra,4ce8 <open>
    122c:	84aa                	mv	s1,a0
      if(fd < 0){
    122e:	04054a63          	bltz	a0,1282 <truncate3+0xa4>
      int n = write(fd, "1234567890", 10);
    1232:	4629                	li	a2,10
    1234:	85d6                	mv	a1,s5
    1236:	293030ef          	jal	ra,4cc8 <write>
      if(n != 10){
    123a:	47a9                	li	a5,10
    123c:	04f51d63          	bne	a0,a5,1296 <truncate3+0xb8>
      close(fd);
    1240:	8526                	mv	a0,s1
    1242:	28f030ef          	jal	ra,4cd0 <close>
      fd = open("truncfile", O_RDONLY);
    1246:	4581                	li	a1,0
    1248:	8552                	mv	a0,s4
    124a:	29f030ef          	jal	ra,4ce8 <open>
    124e:	84aa                	mv	s1,a0
      read(fd, buf, sizeof(buf));
    1250:	02000613          	li	a2,32
    1254:	f9840593          	addi	a1,s0,-104
    1258:	269030ef          	jal	ra,4cc0 <read>
      close(fd);
    125c:	8526                	mv	a0,s1
    125e:	273030ef          	jal	ra,4cd0 <close>
    for(int i = 0; i < 100; i++){
    1262:	39fd                	addiw	s3,s3,-1
    1264:	fc0990e3          	bnez	s3,1224 <truncate3+0x46>
    exit(0);
    1268:	4501                	li	a0,0
    126a:	23f030ef          	jal	ra,4ca8 <exit>
    printf("%s: fork failed\n", s);
    126e:	85ca                	mv	a1,s2
    1270:	00005517          	auipc	a0,0x5
    1274:	8e850513          	addi	a0,a0,-1816 # 5b58 <malloc+0x9c8>
    1278:	65f030ef          	jal	ra,50d6 <printf>
    exit(1);
    127c:	4505                	li	a0,1
    127e:	22b030ef          	jal	ra,4ca8 <exit>
        printf("%s: open failed\n", s);
    1282:	85ca                	mv	a1,s2
    1284:	00005517          	auipc	a0,0x5
    1288:	8ec50513          	addi	a0,a0,-1812 # 5b70 <malloc+0x9e0>
    128c:	64b030ef          	jal	ra,50d6 <printf>
        exit(1);
    1290:	4505                	li	a0,1
    1292:	217030ef          	jal	ra,4ca8 <exit>
        printf("%s: write got %d, expected 10\n", s, n);
    1296:	862a                	mv	a2,a0
    1298:	85ca                	mv	a1,s2
    129a:	00005517          	auipc	a0,0x5
    129e:	8fe50513          	addi	a0,a0,-1794 # 5b98 <malloc+0xa08>
    12a2:	635030ef          	jal	ra,50d6 <printf>
        exit(1);
    12a6:	4505                	li	a0,1
    12a8:	201030ef          	jal	ra,4ca8 <exit>
    12ac:	09600993          	li	s3,150
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    12b0:	00004a17          	auipc	s4,0x4
    12b4:	070a0a13          	addi	s4,s4,112 # 5320 <malloc+0x190>
    int n = write(fd, "xxx", 3);
    12b8:	00005a97          	auipc	s5,0x5
    12bc:	900a8a93          	addi	s5,s5,-1792 # 5bb8 <malloc+0xa28>
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    12c0:	60100593          	li	a1,1537
    12c4:	8552                	mv	a0,s4
    12c6:	223030ef          	jal	ra,4ce8 <open>
    12ca:	84aa                	mv	s1,a0
    if(fd < 0){
    12cc:	02054d63          	bltz	a0,1306 <truncate3+0x128>
    int n = write(fd, "xxx", 3);
    12d0:	460d                	li	a2,3
    12d2:	85d6                	mv	a1,s5
    12d4:	1f5030ef          	jal	ra,4cc8 <write>
    if(n != 3){
    12d8:	478d                	li	a5,3
    12da:	04f51063          	bne	a0,a5,131a <truncate3+0x13c>
    close(fd);
    12de:	8526                	mv	a0,s1
    12e0:	1f1030ef          	jal	ra,4cd0 <close>
  for(int i = 0; i < 150; i++){
    12e4:	39fd                	addiw	s3,s3,-1
    12e6:	fc099de3          	bnez	s3,12c0 <truncate3+0xe2>
  wait(&xstatus);
    12ea:	fbc40513          	addi	a0,s0,-68
    12ee:	1c3030ef          	jal	ra,4cb0 <wait>
  unlink("truncfile");
    12f2:	00004517          	auipc	a0,0x4
    12f6:	02e50513          	addi	a0,a0,46 # 5320 <malloc+0x190>
    12fa:	1ff030ef          	jal	ra,4cf8 <unlink>
  exit(xstatus);
    12fe:	fbc42503          	lw	a0,-68(s0)
    1302:	1a7030ef          	jal	ra,4ca8 <exit>
      printf("%s: open failed\n", s);
    1306:	85ca                	mv	a1,s2
    1308:	00005517          	auipc	a0,0x5
    130c:	86850513          	addi	a0,a0,-1944 # 5b70 <malloc+0x9e0>
    1310:	5c7030ef          	jal	ra,50d6 <printf>
      exit(1);
    1314:	4505                	li	a0,1
    1316:	193030ef          	jal	ra,4ca8 <exit>
      printf("%s: write got %d, expected 3\n", s, n);
    131a:	862a                	mv	a2,a0
    131c:	85ca                	mv	a1,s2
    131e:	00005517          	auipc	a0,0x5
    1322:	8a250513          	addi	a0,a0,-1886 # 5bc0 <malloc+0xa30>
    1326:	5b1030ef          	jal	ra,50d6 <printf>
      exit(1);
    132a:	4505                	li	a0,1
    132c:	17d030ef          	jal	ra,4ca8 <exit>

0000000000001330 <exectest>:
{
    1330:	715d                	addi	sp,sp,-80
    1332:	e486                	sd	ra,72(sp)
    1334:	e0a2                	sd	s0,64(sp)
    1336:	fc26                	sd	s1,56(sp)
    1338:	f84a                	sd	s2,48(sp)
    133a:	0880                	addi	s0,sp,80
    133c:	892a                	mv	s2,a0
  char *echoargv[] = { "echo", "OK", 0 };
    133e:	00004797          	auipc	a5,0x4
    1342:	f8a78793          	addi	a5,a5,-118 # 52c8 <malloc+0x138>
    1346:	fcf43023          	sd	a5,-64(s0)
    134a:	00005797          	auipc	a5,0x5
    134e:	89678793          	addi	a5,a5,-1898 # 5be0 <malloc+0xa50>
    1352:	fcf43423          	sd	a5,-56(s0)
    1356:	fc043823          	sd	zero,-48(s0)
  unlink("echo-ok");
    135a:	00005517          	auipc	a0,0x5
    135e:	88e50513          	addi	a0,a0,-1906 # 5be8 <malloc+0xa58>
    1362:	197030ef          	jal	ra,4cf8 <unlink>
  pid = fork();
    1366:	13b030ef          	jal	ra,4ca0 <fork>
  if(pid < 0) {
    136a:	02054e63          	bltz	a0,13a6 <exectest+0x76>
    136e:	84aa                	mv	s1,a0
  if(pid == 0) {
    1370:	e92d                	bnez	a0,13e2 <exectest+0xb2>
    close(1);
    1372:	4505                	li	a0,1
    1374:	15d030ef          	jal	ra,4cd0 <close>
    fd = open("echo-ok", O_CREATE|O_WRONLY);
    1378:	20100593          	li	a1,513
    137c:	00005517          	auipc	a0,0x5
    1380:	86c50513          	addi	a0,a0,-1940 # 5be8 <malloc+0xa58>
    1384:	165030ef          	jal	ra,4ce8 <open>
    if(fd < 0) {
    1388:	02054963          	bltz	a0,13ba <exectest+0x8a>
    if(fd != 1) {
    138c:	4785                	li	a5,1
    138e:	04f50063          	beq	a0,a5,13ce <exectest+0x9e>
      printf("%s: wrong fd\n", s);
    1392:	85ca                	mv	a1,s2
    1394:	00005517          	auipc	a0,0x5
    1398:	87450513          	addi	a0,a0,-1932 # 5c08 <malloc+0xa78>
    139c:	53b030ef          	jal	ra,50d6 <printf>
      exit(1);
    13a0:	4505                	li	a0,1
    13a2:	107030ef          	jal	ra,4ca8 <exit>
     printf("%s: fork failed\n", s);
    13a6:	85ca                	mv	a1,s2
    13a8:	00004517          	auipc	a0,0x4
    13ac:	7b050513          	addi	a0,a0,1968 # 5b58 <malloc+0x9c8>
    13b0:	527030ef          	jal	ra,50d6 <printf>
     exit(1);
    13b4:	4505                	li	a0,1
    13b6:	0f3030ef          	jal	ra,4ca8 <exit>
      printf("%s: create failed\n", s);
    13ba:	85ca                	mv	a1,s2
    13bc:	00005517          	auipc	a0,0x5
    13c0:	83450513          	addi	a0,a0,-1996 # 5bf0 <malloc+0xa60>
    13c4:	513030ef          	jal	ra,50d6 <printf>
      exit(1);
    13c8:	4505                	li	a0,1
    13ca:	0df030ef          	jal	ra,4ca8 <exit>
    if(exec("echo", echoargv) < 0){
    13ce:	fc040593          	addi	a1,s0,-64
    13d2:	00004517          	auipc	a0,0x4
    13d6:	ef650513          	addi	a0,a0,-266 # 52c8 <malloc+0x138>
    13da:	107030ef          	jal	ra,4ce0 <exec>
    13de:	00054d63          	bltz	a0,13f8 <exectest+0xc8>
  if (wait(&xstatus) != pid) {
    13e2:	fdc40513          	addi	a0,s0,-36
    13e6:	0cb030ef          	jal	ra,4cb0 <wait>
    13ea:	02951163          	bne	a0,s1,140c <exectest+0xdc>
  if(xstatus != 0)
    13ee:	fdc42503          	lw	a0,-36(s0)
    13f2:	c50d                	beqz	a0,141c <exectest+0xec>
    exit(xstatus);
    13f4:	0b5030ef          	jal	ra,4ca8 <exit>
      printf("%s: exec echo failed\n", s);
    13f8:	85ca                	mv	a1,s2
    13fa:	00005517          	auipc	a0,0x5
    13fe:	81e50513          	addi	a0,a0,-2018 # 5c18 <malloc+0xa88>
    1402:	4d5030ef          	jal	ra,50d6 <printf>
      exit(1);
    1406:	4505                	li	a0,1
    1408:	0a1030ef          	jal	ra,4ca8 <exit>
    printf("%s: wait failed!\n", s);
    140c:	85ca                	mv	a1,s2
    140e:	00005517          	auipc	a0,0x5
    1412:	82250513          	addi	a0,a0,-2014 # 5c30 <malloc+0xaa0>
    1416:	4c1030ef          	jal	ra,50d6 <printf>
    141a:	bfd1                	j	13ee <exectest+0xbe>
  fd = open("echo-ok", O_RDONLY);
    141c:	4581                	li	a1,0
    141e:	00004517          	auipc	a0,0x4
    1422:	7ca50513          	addi	a0,a0,1994 # 5be8 <malloc+0xa58>
    1426:	0c3030ef          	jal	ra,4ce8 <open>
  if(fd < 0) {
    142a:	02054463          	bltz	a0,1452 <exectest+0x122>
  if (read(fd, buf, 2) != 2) {
    142e:	4609                	li	a2,2
    1430:	fb840593          	addi	a1,s0,-72
    1434:	08d030ef          	jal	ra,4cc0 <read>
    1438:	4789                	li	a5,2
    143a:	02f50663          	beq	a0,a5,1466 <exectest+0x136>
    printf("%s: read failed\n", s);
    143e:	85ca                	mv	a1,s2
    1440:	00004517          	auipc	a0,0x4
    1444:	25850513          	addi	a0,a0,600 # 5698 <malloc+0x508>
    1448:	48f030ef          	jal	ra,50d6 <printf>
    exit(1);
    144c:	4505                	li	a0,1
    144e:	05b030ef          	jal	ra,4ca8 <exit>
    printf("%s: open failed\n", s);
    1452:	85ca                	mv	a1,s2
    1454:	00004517          	auipc	a0,0x4
    1458:	71c50513          	addi	a0,a0,1820 # 5b70 <malloc+0x9e0>
    145c:	47b030ef          	jal	ra,50d6 <printf>
    exit(1);
    1460:	4505                	li	a0,1
    1462:	047030ef          	jal	ra,4ca8 <exit>
  unlink("echo-ok");
    1466:	00004517          	auipc	a0,0x4
    146a:	78250513          	addi	a0,a0,1922 # 5be8 <malloc+0xa58>
    146e:	08b030ef          	jal	ra,4cf8 <unlink>
  if(buf[0] == 'O' && buf[1] == 'K')
    1472:	fb844703          	lbu	a4,-72(s0)
    1476:	04f00793          	li	a5,79
    147a:	00f71863          	bne	a4,a5,148a <exectest+0x15a>
    147e:	fb944703          	lbu	a4,-71(s0)
    1482:	04b00793          	li	a5,75
    1486:	00f70c63          	beq	a4,a5,149e <exectest+0x16e>
    printf("%s: wrong output\n", s);
    148a:	85ca                	mv	a1,s2
    148c:	00004517          	auipc	a0,0x4
    1490:	7bc50513          	addi	a0,a0,1980 # 5c48 <malloc+0xab8>
    1494:	443030ef          	jal	ra,50d6 <printf>
    exit(1);
    1498:	4505                	li	a0,1
    149a:	00f030ef          	jal	ra,4ca8 <exit>
    exit(0);
    149e:	4501                	li	a0,0
    14a0:	009030ef          	jal	ra,4ca8 <exit>

00000000000014a4 <pipe1>:
{
    14a4:	711d                	addi	sp,sp,-96
    14a6:	ec86                	sd	ra,88(sp)
    14a8:	e8a2                	sd	s0,80(sp)
    14aa:	e4a6                	sd	s1,72(sp)
    14ac:	e0ca                	sd	s2,64(sp)
    14ae:	fc4e                	sd	s3,56(sp)
    14b0:	f852                	sd	s4,48(sp)
    14b2:	f456                	sd	s5,40(sp)
    14b4:	f05a                	sd	s6,32(sp)
    14b6:	ec5e                	sd	s7,24(sp)
    14b8:	1080                	addi	s0,sp,96
    14ba:	892a                	mv	s2,a0
  if(pipe(fds) != 0){
    14bc:	fa840513          	addi	a0,s0,-88
    14c0:	7f8030ef          	jal	ra,4cb8 <pipe>
    14c4:	e535                	bnez	a0,1530 <pipe1+0x8c>
    14c6:	84aa                	mv	s1,a0
  pid = fork();
    14c8:	7d8030ef          	jal	ra,4ca0 <fork>
    14cc:	8a2a                	mv	s4,a0
  if(pid == 0){
    14ce:	c93d                	beqz	a0,1544 <pipe1+0xa0>
  } else if(pid > 0){
    14d0:	14a05163          	blez	a0,1612 <pipe1+0x16e>
    close(fds[1]);
    14d4:	fac42503          	lw	a0,-84(s0)
    14d8:	7f8030ef          	jal	ra,4cd0 <close>
    total = 0;
    14dc:	8a26                	mv	s4,s1
    cc = 1;
    14de:	4985                	li	s3,1
    while((n = read(fds[0], buf, cc)) > 0){
    14e0:	0000aa97          	auipc	s5,0xa
    14e4:	7c8a8a93          	addi	s5,s5,1992 # bca8 <buf>
      if(cc > sizeof(buf))
    14e8:	6b0d                	lui	s6,0x3
    while((n = read(fds[0], buf, cc)) > 0){
    14ea:	864e                	mv	a2,s3
    14ec:	85d6                	mv	a1,s5
    14ee:	fa842503          	lw	a0,-88(s0)
    14f2:	7ce030ef          	jal	ra,4cc0 <read>
    14f6:	0ea05263          	blez	a0,15da <pipe1+0x136>
      for(i = 0; i < n; i++){
    14fa:	0000a717          	auipc	a4,0xa
    14fe:	7ae70713          	addi	a4,a4,1966 # bca8 <buf>
    1502:	00a4863b          	addw	a2,s1,a0
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    1506:	00074683          	lbu	a3,0(a4)
    150a:	0ff4f793          	zext.b	a5,s1
    150e:	2485                	addiw	s1,s1,1
    1510:	0af69363          	bne	a3,a5,15b6 <pipe1+0x112>
      for(i = 0; i < n; i++){
    1514:	0705                	addi	a4,a4,1
    1516:	fec498e3          	bne	s1,a2,1506 <pipe1+0x62>
      total += n;
    151a:	00aa0a3b          	addw	s4,s4,a0
      cc = cc * 2;
    151e:	0019979b          	slliw	a5,s3,0x1
    1522:	0007899b          	sext.w	s3,a5
      if(cc > sizeof(buf))
    1526:	013b7363          	bgeu	s6,s3,152c <pipe1+0x88>
        cc = sizeof(buf);
    152a:	89da                	mv	s3,s6
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    152c:	84b2                	mv	s1,a2
    152e:	bf75                	j	14ea <pipe1+0x46>
    printf("%s: pipe() failed\n", s);
    1530:	85ca                	mv	a1,s2
    1532:	00004517          	auipc	a0,0x4
    1536:	72e50513          	addi	a0,a0,1838 # 5c60 <malloc+0xad0>
    153a:	39d030ef          	jal	ra,50d6 <printf>
    exit(1);
    153e:	4505                	li	a0,1
    1540:	768030ef          	jal	ra,4ca8 <exit>
    close(fds[0]);
    1544:	fa842503          	lw	a0,-88(s0)
    1548:	788030ef          	jal	ra,4cd0 <close>
    for(n = 0; n < N; n++){
    154c:	0000ab17          	auipc	s6,0xa
    1550:	75cb0b13          	addi	s6,s6,1884 # bca8 <buf>
    1554:	416004bb          	negw	s1,s6
    1558:	0ff4f493          	zext.b	s1,s1
    155c:	409b0993          	addi	s3,s6,1033
      if(write(fds[1], buf, SZ) != SZ){
    1560:	8bda                	mv	s7,s6
    for(n = 0; n < N; n++){
    1562:	6a85                	lui	s5,0x1
    1564:	42da8a93          	addi	s5,s5,1069 # 142d <exectest+0xfd>
{
    1568:	87da                	mv	a5,s6
        buf[i] = seq++;
    156a:	0097873b          	addw	a4,a5,s1
    156e:	00e78023          	sb	a4,0(a5)
      for(i = 0; i < SZ; i++)
    1572:	0785                	addi	a5,a5,1
    1574:	fef99be3          	bne	s3,a5,156a <pipe1+0xc6>
        buf[i] = seq++;
    1578:	409a0a1b          	addiw	s4,s4,1033
      if(write(fds[1], buf, SZ) != SZ){
    157c:	40900613          	li	a2,1033
    1580:	85de                	mv	a1,s7
    1582:	fac42503          	lw	a0,-84(s0)
    1586:	742030ef          	jal	ra,4cc8 <write>
    158a:	40900793          	li	a5,1033
    158e:	00f51a63          	bne	a0,a5,15a2 <pipe1+0xfe>
    for(n = 0; n < N; n++){
    1592:	24a5                	addiw	s1,s1,9
    1594:	0ff4f493          	zext.b	s1,s1
    1598:	fd5a18e3          	bne	s4,s5,1568 <pipe1+0xc4>
    exit(0);
    159c:	4501                	li	a0,0
    159e:	70a030ef          	jal	ra,4ca8 <exit>
        printf("%s: pipe1 oops 1\n", s);
    15a2:	85ca                	mv	a1,s2
    15a4:	00004517          	auipc	a0,0x4
    15a8:	6d450513          	addi	a0,a0,1748 # 5c78 <malloc+0xae8>
    15ac:	32b030ef          	jal	ra,50d6 <printf>
        exit(1);
    15b0:	4505                	li	a0,1
    15b2:	6f6030ef          	jal	ra,4ca8 <exit>
          printf("%s: pipe1 oops 2\n", s);
    15b6:	85ca                	mv	a1,s2
    15b8:	00004517          	auipc	a0,0x4
    15bc:	6d850513          	addi	a0,a0,1752 # 5c90 <malloc+0xb00>
    15c0:	317030ef          	jal	ra,50d6 <printf>
}
    15c4:	60e6                	ld	ra,88(sp)
    15c6:	6446                	ld	s0,80(sp)
    15c8:	64a6                	ld	s1,72(sp)
    15ca:	6906                	ld	s2,64(sp)
    15cc:	79e2                	ld	s3,56(sp)
    15ce:	7a42                	ld	s4,48(sp)
    15d0:	7aa2                	ld	s5,40(sp)
    15d2:	7b02                	ld	s6,32(sp)
    15d4:	6be2                	ld	s7,24(sp)
    15d6:	6125                	addi	sp,sp,96
    15d8:	8082                	ret
    if(total != N * SZ){
    15da:	6785                	lui	a5,0x1
    15dc:	42d78793          	addi	a5,a5,1069 # 142d <exectest+0xfd>
    15e0:	00fa0d63          	beq	s4,a5,15fa <pipe1+0x156>
      printf("%s: pipe1 oops 3 total %d\n", s, total);
    15e4:	8652                	mv	a2,s4
    15e6:	85ca                	mv	a1,s2
    15e8:	00004517          	auipc	a0,0x4
    15ec:	6c050513          	addi	a0,a0,1728 # 5ca8 <malloc+0xb18>
    15f0:	2e7030ef          	jal	ra,50d6 <printf>
      exit(1);
    15f4:	4505                	li	a0,1
    15f6:	6b2030ef          	jal	ra,4ca8 <exit>
    close(fds[0]);
    15fa:	fa842503          	lw	a0,-88(s0)
    15fe:	6d2030ef          	jal	ra,4cd0 <close>
    wait(&xstatus);
    1602:	fa440513          	addi	a0,s0,-92
    1606:	6aa030ef          	jal	ra,4cb0 <wait>
    exit(xstatus);
    160a:	fa442503          	lw	a0,-92(s0)
    160e:	69a030ef          	jal	ra,4ca8 <exit>
    printf("%s: fork() failed\n", s);
    1612:	85ca                	mv	a1,s2
    1614:	00004517          	auipc	a0,0x4
    1618:	6b450513          	addi	a0,a0,1716 # 5cc8 <malloc+0xb38>
    161c:	2bb030ef          	jal	ra,50d6 <printf>
    exit(1);
    1620:	4505                	li	a0,1
    1622:	686030ef          	jal	ra,4ca8 <exit>

0000000000001626 <exitwait>:
{
    1626:	7139                	addi	sp,sp,-64
    1628:	fc06                	sd	ra,56(sp)
    162a:	f822                	sd	s0,48(sp)
    162c:	f426                	sd	s1,40(sp)
    162e:	f04a                	sd	s2,32(sp)
    1630:	ec4e                	sd	s3,24(sp)
    1632:	e852                	sd	s4,16(sp)
    1634:	0080                	addi	s0,sp,64
    1636:	8a2a                	mv	s4,a0
  for(i = 0; i < 100; i++){
    1638:	4901                	li	s2,0
    163a:	06400993          	li	s3,100
    pid = fork();
    163e:	662030ef          	jal	ra,4ca0 <fork>
    1642:	84aa                	mv	s1,a0
    if(pid < 0){
    1644:	02054863          	bltz	a0,1674 <exitwait+0x4e>
    if(pid){
    1648:	c525                	beqz	a0,16b0 <exitwait+0x8a>
      if(wait(&xstate) != pid){
    164a:	fcc40513          	addi	a0,s0,-52
    164e:	662030ef          	jal	ra,4cb0 <wait>
    1652:	02951b63          	bne	a0,s1,1688 <exitwait+0x62>
      if(i != xstate) {
    1656:	fcc42783          	lw	a5,-52(s0)
    165a:	05279163          	bne	a5,s2,169c <exitwait+0x76>
  for(i = 0; i < 100; i++){
    165e:	2905                	addiw	s2,s2,1
    1660:	fd391fe3          	bne	s2,s3,163e <exitwait+0x18>
}
    1664:	70e2                	ld	ra,56(sp)
    1666:	7442                	ld	s0,48(sp)
    1668:	74a2                	ld	s1,40(sp)
    166a:	7902                	ld	s2,32(sp)
    166c:	69e2                	ld	s3,24(sp)
    166e:	6a42                	ld	s4,16(sp)
    1670:	6121                	addi	sp,sp,64
    1672:	8082                	ret
      printf("%s: fork failed\n", s);
    1674:	85d2                	mv	a1,s4
    1676:	00004517          	auipc	a0,0x4
    167a:	4e250513          	addi	a0,a0,1250 # 5b58 <malloc+0x9c8>
    167e:	259030ef          	jal	ra,50d6 <printf>
      exit(1);
    1682:	4505                	li	a0,1
    1684:	624030ef          	jal	ra,4ca8 <exit>
        printf("%s: wait wrong pid\n", s);
    1688:	85d2                	mv	a1,s4
    168a:	00004517          	auipc	a0,0x4
    168e:	65650513          	addi	a0,a0,1622 # 5ce0 <malloc+0xb50>
    1692:	245030ef          	jal	ra,50d6 <printf>
        exit(1);
    1696:	4505                	li	a0,1
    1698:	610030ef          	jal	ra,4ca8 <exit>
        printf("%s: wait wrong exit status\n", s);
    169c:	85d2                	mv	a1,s4
    169e:	00004517          	auipc	a0,0x4
    16a2:	65a50513          	addi	a0,a0,1626 # 5cf8 <malloc+0xb68>
    16a6:	231030ef          	jal	ra,50d6 <printf>
        exit(1);
    16aa:	4505                	li	a0,1
    16ac:	5fc030ef          	jal	ra,4ca8 <exit>
      exit(i);
    16b0:	854a                	mv	a0,s2
    16b2:	5f6030ef          	jal	ra,4ca8 <exit>

00000000000016b6 <twochildren>:
{
    16b6:	1101                	addi	sp,sp,-32
    16b8:	ec06                	sd	ra,24(sp)
    16ba:	e822                	sd	s0,16(sp)
    16bc:	e426                	sd	s1,8(sp)
    16be:	e04a                	sd	s2,0(sp)
    16c0:	1000                	addi	s0,sp,32
    16c2:	892a                	mv	s2,a0
    16c4:	3e800493          	li	s1,1000
    int pid1 = fork();
    16c8:	5d8030ef          	jal	ra,4ca0 <fork>
    if(pid1 < 0){
    16cc:	02054663          	bltz	a0,16f8 <twochildren+0x42>
    if(pid1 == 0){
    16d0:	cd15                	beqz	a0,170c <twochildren+0x56>
      int pid2 = fork();
    16d2:	5ce030ef          	jal	ra,4ca0 <fork>
      if(pid2 < 0){
    16d6:	02054d63          	bltz	a0,1710 <twochildren+0x5a>
      if(pid2 == 0){
    16da:	c529                	beqz	a0,1724 <twochildren+0x6e>
        wait(0);
    16dc:	4501                	li	a0,0
    16de:	5d2030ef          	jal	ra,4cb0 <wait>
        wait(0);
    16e2:	4501                	li	a0,0
    16e4:	5cc030ef          	jal	ra,4cb0 <wait>
  for(int i = 0; i < 1000; i++){
    16e8:	34fd                	addiw	s1,s1,-1
    16ea:	fcf9                	bnez	s1,16c8 <twochildren+0x12>
}
    16ec:	60e2                	ld	ra,24(sp)
    16ee:	6442                	ld	s0,16(sp)
    16f0:	64a2                	ld	s1,8(sp)
    16f2:	6902                	ld	s2,0(sp)
    16f4:	6105                	addi	sp,sp,32
    16f6:	8082                	ret
      printf("%s: fork failed\n", s);
    16f8:	85ca                	mv	a1,s2
    16fa:	00004517          	auipc	a0,0x4
    16fe:	45e50513          	addi	a0,a0,1118 # 5b58 <malloc+0x9c8>
    1702:	1d5030ef          	jal	ra,50d6 <printf>
      exit(1);
    1706:	4505                	li	a0,1
    1708:	5a0030ef          	jal	ra,4ca8 <exit>
      exit(0);
    170c:	59c030ef          	jal	ra,4ca8 <exit>
        printf("%s: fork failed\n", s);
    1710:	85ca                	mv	a1,s2
    1712:	00004517          	auipc	a0,0x4
    1716:	44650513          	addi	a0,a0,1094 # 5b58 <malloc+0x9c8>
    171a:	1bd030ef          	jal	ra,50d6 <printf>
        exit(1);
    171e:	4505                	li	a0,1
    1720:	588030ef          	jal	ra,4ca8 <exit>
        exit(0);
    1724:	584030ef          	jal	ra,4ca8 <exit>

0000000000001728 <forkfork>:
{
    1728:	7179                	addi	sp,sp,-48
    172a:	f406                	sd	ra,40(sp)
    172c:	f022                	sd	s0,32(sp)
    172e:	ec26                	sd	s1,24(sp)
    1730:	1800                	addi	s0,sp,48
    1732:	84aa                	mv	s1,a0
    int pid = fork();
    1734:	56c030ef          	jal	ra,4ca0 <fork>
    if(pid < 0){
    1738:	02054b63          	bltz	a0,176e <forkfork+0x46>
    if(pid == 0){
    173c:	c139                	beqz	a0,1782 <forkfork+0x5a>
    int pid = fork();
    173e:	562030ef          	jal	ra,4ca0 <fork>
    if(pid < 0){
    1742:	02054663          	bltz	a0,176e <forkfork+0x46>
    if(pid == 0){
    1746:	cd15                	beqz	a0,1782 <forkfork+0x5a>
    wait(&xstatus);
    1748:	fdc40513          	addi	a0,s0,-36
    174c:	564030ef          	jal	ra,4cb0 <wait>
    if(xstatus != 0) {
    1750:	fdc42783          	lw	a5,-36(s0)
    1754:	ebb9                	bnez	a5,17aa <forkfork+0x82>
    wait(&xstatus);
    1756:	fdc40513          	addi	a0,s0,-36
    175a:	556030ef          	jal	ra,4cb0 <wait>
    if(xstatus != 0) {
    175e:	fdc42783          	lw	a5,-36(s0)
    1762:	e7a1                	bnez	a5,17aa <forkfork+0x82>
}
    1764:	70a2                	ld	ra,40(sp)
    1766:	7402                	ld	s0,32(sp)
    1768:	64e2                	ld	s1,24(sp)
    176a:	6145                	addi	sp,sp,48
    176c:	8082                	ret
      printf("%s: fork failed", s);
    176e:	85a6                	mv	a1,s1
    1770:	00004517          	auipc	a0,0x4
    1774:	5a850513          	addi	a0,a0,1448 # 5d18 <malloc+0xb88>
    1778:	15f030ef          	jal	ra,50d6 <printf>
      exit(1);
    177c:	4505                	li	a0,1
    177e:	52a030ef          	jal	ra,4ca8 <exit>
{
    1782:	0c800493          	li	s1,200
        int pid1 = fork();
    1786:	51a030ef          	jal	ra,4ca0 <fork>
        if(pid1 < 0){
    178a:	00054b63          	bltz	a0,17a0 <forkfork+0x78>
        if(pid1 == 0){
    178e:	cd01                	beqz	a0,17a6 <forkfork+0x7e>
        wait(0);
    1790:	4501                	li	a0,0
    1792:	51e030ef          	jal	ra,4cb0 <wait>
      for(int j = 0; j < 200; j++){
    1796:	34fd                	addiw	s1,s1,-1
    1798:	f4fd                	bnez	s1,1786 <forkfork+0x5e>
      exit(0);
    179a:	4501                	li	a0,0
    179c:	50c030ef          	jal	ra,4ca8 <exit>
          exit(1);
    17a0:	4505                	li	a0,1
    17a2:	506030ef          	jal	ra,4ca8 <exit>
          exit(0);
    17a6:	502030ef          	jal	ra,4ca8 <exit>
      printf("%s: fork in child failed", s);
    17aa:	85a6                	mv	a1,s1
    17ac:	00004517          	auipc	a0,0x4
    17b0:	57c50513          	addi	a0,a0,1404 # 5d28 <malloc+0xb98>
    17b4:	123030ef          	jal	ra,50d6 <printf>
      exit(1);
    17b8:	4505                	li	a0,1
    17ba:	4ee030ef          	jal	ra,4ca8 <exit>

00000000000017be <reparent2>:
{
    17be:	1101                	addi	sp,sp,-32
    17c0:	ec06                	sd	ra,24(sp)
    17c2:	e822                	sd	s0,16(sp)
    17c4:	e426                	sd	s1,8(sp)
    17c6:	1000                	addi	s0,sp,32
    17c8:	32000493          	li	s1,800
    int pid1 = fork();
    17cc:	4d4030ef          	jal	ra,4ca0 <fork>
    if(pid1 < 0){
    17d0:	00054b63          	bltz	a0,17e6 <reparent2+0x28>
    if(pid1 == 0){
    17d4:	c115                	beqz	a0,17f8 <reparent2+0x3a>
    wait(0);
    17d6:	4501                	li	a0,0
    17d8:	4d8030ef          	jal	ra,4cb0 <wait>
  for(int i = 0; i < 800; i++){
    17dc:	34fd                	addiw	s1,s1,-1
    17de:	f4fd                	bnez	s1,17cc <reparent2+0xe>
  exit(0);
    17e0:	4501                	li	a0,0
    17e2:	4c6030ef          	jal	ra,4ca8 <exit>
      printf("fork failed\n");
    17e6:	00006517          	auipc	a0,0x6
    17ea:	9a250513          	addi	a0,a0,-1630 # 7188 <malloc+0x1ff8>
    17ee:	0e9030ef          	jal	ra,50d6 <printf>
      exit(1);
    17f2:	4505                	li	a0,1
    17f4:	4b4030ef          	jal	ra,4ca8 <exit>
      fork();
    17f8:	4a8030ef          	jal	ra,4ca0 <fork>
      fork();
    17fc:	4a4030ef          	jal	ra,4ca0 <fork>
      exit(0);
    1800:	4501                	li	a0,0
    1802:	4a6030ef          	jal	ra,4ca8 <exit>

0000000000001806 <createdelete>:
{
    1806:	7175                	addi	sp,sp,-144
    1808:	e506                	sd	ra,136(sp)
    180a:	e122                	sd	s0,128(sp)
    180c:	fca6                	sd	s1,120(sp)
    180e:	f8ca                	sd	s2,112(sp)
    1810:	f4ce                	sd	s3,104(sp)
    1812:	f0d2                	sd	s4,96(sp)
    1814:	ecd6                	sd	s5,88(sp)
    1816:	e8da                	sd	s6,80(sp)
    1818:	e4de                	sd	s7,72(sp)
    181a:	e0e2                	sd	s8,64(sp)
    181c:	fc66                	sd	s9,56(sp)
    181e:	0900                	addi	s0,sp,144
    1820:	8caa                	mv	s9,a0
  for(pi = 0; pi < NCHILD; pi++){
    1822:	4901                	li	s2,0
    1824:	4991                	li	s3,4
    pid = fork();
    1826:	47a030ef          	jal	ra,4ca0 <fork>
    182a:	84aa                	mv	s1,a0
    if(pid < 0){
    182c:	02054d63          	bltz	a0,1866 <createdelete+0x60>
    if(pid == 0){
    1830:	c529                	beqz	a0,187a <createdelete+0x74>
  for(pi = 0; pi < NCHILD; pi++){
    1832:	2905                	addiw	s2,s2,1
    1834:	ff3919e3          	bne	s2,s3,1826 <createdelete+0x20>
    1838:	4491                	li	s1,4
    wait(&xstatus);
    183a:	f7c40513          	addi	a0,s0,-132
    183e:	472030ef          	jal	ra,4cb0 <wait>
    if(xstatus != 0)
    1842:	f7c42903          	lw	s2,-132(s0)
    1846:	0a091e63          	bnez	s2,1902 <createdelete+0xfc>
  for(pi = 0; pi < NCHILD; pi++){
    184a:	34fd                	addiw	s1,s1,-1
    184c:	f4fd                	bnez	s1,183a <createdelete+0x34>
  name[0] = name[1] = name[2] = 0;
    184e:	f8040123          	sb	zero,-126(s0)
    1852:	03000993          	li	s3,48
    1856:	5a7d                	li	s4,-1
    1858:	07000c13          	li	s8,112
      } else if((i >= 1 && i < N/2) && fd >= 0){
    185c:	4b21                	li	s6,8
      if((i == 0 || i >= N/2) && fd < 0){
    185e:	4ba5                	li	s7,9
    for(pi = 0; pi < NCHILD; pi++){
    1860:	07400a93          	li	s5,116
    1864:	a20d                	j	1986 <createdelete+0x180>
      printf("%s: fork failed\n", s);
    1866:	85e6                	mv	a1,s9
    1868:	00004517          	auipc	a0,0x4
    186c:	2f050513          	addi	a0,a0,752 # 5b58 <malloc+0x9c8>
    1870:	067030ef          	jal	ra,50d6 <printf>
      exit(1);
    1874:	4505                	li	a0,1
    1876:	432030ef          	jal	ra,4ca8 <exit>
      name[0] = 'p' + pi;
    187a:	0709091b          	addiw	s2,s2,112
    187e:	f9240023          	sb	s2,-128(s0)
      name[2] = '\0';
    1882:	f8040123          	sb	zero,-126(s0)
      for(i = 0; i < N; i++){
    1886:	4951                	li	s2,20
    1888:	a831                	j	18a4 <createdelete+0x9e>
          printf("%s: create failed\n", s);
    188a:	85e6                	mv	a1,s9
    188c:	00004517          	auipc	a0,0x4
    1890:	36450513          	addi	a0,a0,868 # 5bf0 <malloc+0xa60>
    1894:	043030ef          	jal	ra,50d6 <printf>
          exit(1);
    1898:	4505                	li	a0,1
    189a:	40e030ef          	jal	ra,4ca8 <exit>
      for(i = 0; i < N; i++){
    189e:	2485                	addiw	s1,s1,1
    18a0:	05248e63          	beq	s1,s2,18fc <createdelete+0xf6>
        name[1] = '0' + i;
    18a4:	0304879b          	addiw	a5,s1,48
    18a8:	f8f400a3          	sb	a5,-127(s0)
        fd = open(name, O_CREATE | O_RDWR);
    18ac:	20200593          	li	a1,514
    18b0:	f8040513          	addi	a0,s0,-128
    18b4:	434030ef          	jal	ra,4ce8 <open>
        if(fd < 0){
    18b8:	fc0549e3          	bltz	a0,188a <createdelete+0x84>
        close(fd);
    18bc:	414030ef          	jal	ra,4cd0 <close>
        if(i > 0 && (i % 2 ) == 0){
    18c0:	fc905fe3          	blez	s1,189e <createdelete+0x98>
    18c4:	0014f793          	andi	a5,s1,1
    18c8:	fbf9                	bnez	a5,189e <createdelete+0x98>
          name[1] = '0' + (i / 2);
    18ca:	01f4d79b          	srliw	a5,s1,0x1f
    18ce:	9fa5                	addw	a5,a5,s1
    18d0:	4017d79b          	sraiw	a5,a5,0x1
    18d4:	0307879b          	addiw	a5,a5,48
    18d8:	f8f400a3          	sb	a5,-127(s0)
          if(unlink(name) < 0){
    18dc:	f8040513          	addi	a0,s0,-128
    18e0:	418030ef          	jal	ra,4cf8 <unlink>
    18e4:	fa055de3          	bgez	a0,189e <createdelete+0x98>
            printf("%s: unlink failed\n", s);
    18e8:	85e6                	mv	a1,s9
    18ea:	00004517          	auipc	a0,0x4
    18ee:	45e50513          	addi	a0,a0,1118 # 5d48 <malloc+0xbb8>
    18f2:	7e4030ef          	jal	ra,50d6 <printf>
            exit(1);
    18f6:	4505                	li	a0,1
    18f8:	3b0030ef          	jal	ra,4ca8 <exit>
      exit(0);
    18fc:	4501                	li	a0,0
    18fe:	3aa030ef          	jal	ra,4ca8 <exit>
      exit(1);
    1902:	4505                	li	a0,1
    1904:	3a4030ef          	jal	ra,4ca8 <exit>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    1908:	f8040613          	addi	a2,s0,-128
    190c:	85e6                	mv	a1,s9
    190e:	00004517          	auipc	a0,0x4
    1912:	45250513          	addi	a0,a0,1106 # 5d60 <malloc+0xbd0>
    1916:	7c0030ef          	jal	ra,50d6 <printf>
        exit(1);
    191a:	4505                	li	a0,1
    191c:	38c030ef          	jal	ra,4ca8 <exit>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    1920:	034b7d63          	bgeu	s6,s4,195a <createdelete+0x154>
      if(fd >= 0)
    1924:	02055863          	bgez	a0,1954 <createdelete+0x14e>
    for(pi = 0; pi < NCHILD; pi++){
    1928:	2485                	addiw	s1,s1,1
    192a:	0ff4f493          	zext.b	s1,s1
    192e:	05548463          	beq	s1,s5,1976 <createdelete+0x170>
      name[0] = 'p' + pi;
    1932:	f8940023          	sb	s1,-128(s0)
      name[1] = '0' + i;
    1936:	f93400a3          	sb	s3,-127(s0)
      fd = open(name, 0);
    193a:	4581                	li	a1,0
    193c:	f8040513          	addi	a0,s0,-128
    1940:	3a8030ef          	jal	ra,4ce8 <open>
      if((i == 0 || i >= N/2) && fd < 0){
    1944:	00090463          	beqz	s2,194c <createdelete+0x146>
    1948:	fd2bdce3          	bge	s7,s2,1920 <createdelete+0x11a>
    194c:	fa054ee3          	bltz	a0,1908 <createdelete+0x102>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    1950:	014b7763          	bgeu	s6,s4,195e <createdelete+0x158>
        close(fd);
    1954:	37c030ef          	jal	ra,4cd0 <close>
    1958:	bfc1                	j	1928 <createdelete+0x122>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    195a:	fc0547e3          	bltz	a0,1928 <createdelete+0x122>
        printf("%s: oops createdelete %s did exist\n", s, name);
    195e:	f8040613          	addi	a2,s0,-128
    1962:	85e6                	mv	a1,s9
    1964:	00004517          	auipc	a0,0x4
    1968:	42450513          	addi	a0,a0,1060 # 5d88 <malloc+0xbf8>
    196c:	76a030ef          	jal	ra,50d6 <printf>
        exit(1);
    1970:	4505                	li	a0,1
    1972:	336030ef          	jal	ra,4ca8 <exit>
  for(i = 0; i < N; i++){
    1976:	2905                	addiw	s2,s2,1
    1978:	2a05                	addiw	s4,s4,1
    197a:	2985                	addiw	s3,s3,1
    197c:	0ff9f993          	zext.b	s3,s3
    1980:	47d1                	li	a5,20
    1982:	02f90863          	beq	s2,a5,19b2 <createdelete+0x1ac>
    for(pi = 0; pi < NCHILD; pi++){
    1986:	84e2                	mv	s1,s8
    1988:	b76d                	j	1932 <createdelete+0x12c>
  for(i = 0; i < N; i++){
    198a:	2905                	addiw	s2,s2,1
    198c:	0ff97913          	zext.b	s2,s2
    1990:	03490a63          	beq	s2,s4,19c4 <createdelete+0x1be>
  name[0] = name[1] = name[2] = 0;
    1994:	84d6                	mv	s1,s5
      name[0] = 'p' + pi;
    1996:	f8940023          	sb	s1,-128(s0)
      name[1] = '0' + i;
    199a:	f92400a3          	sb	s2,-127(s0)
      unlink(name);
    199e:	f8040513          	addi	a0,s0,-128
    19a2:	356030ef          	jal	ra,4cf8 <unlink>
    for(pi = 0; pi < NCHILD; pi++){
    19a6:	2485                	addiw	s1,s1,1
    19a8:	0ff4f493          	zext.b	s1,s1
    19ac:	ff3495e3          	bne	s1,s3,1996 <createdelete+0x190>
    19b0:	bfe9                	j	198a <createdelete+0x184>
    19b2:	03000913          	li	s2,48
  name[0] = name[1] = name[2] = 0;
    19b6:	07000a93          	li	s5,112
    for(pi = 0; pi < NCHILD; pi++){
    19ba:	07400993          	li	s3,116
  for(i = 0; i < N; i++){
    19be:	04400a13          	li	s4,68
    19c2:	bfc9                	j	1994 <createdelete+0x18e>
}
    19c4:	60aa                	ld	ra,136(sp)
    19c6:	640a                	ld	s0,128(sp)
    19c8:	74e6                	ld	s1,120(sp)
    19ca:	7946                	ld	s2,112(sp)
    19cc:	79a6                	ld	s3,104(sp)
    19ce:	7a06                	ld	s4,96(sp)
    19d0:	6ae6                	ld	s5,88(sp)
    19d2:	6b46                	ld	s6,80(sp)
    19d4:	6ba6                	ld	s7,72(sp)
    19d6:	6c06                	ld	s8,64(sp)
    19d8:	7ce2                	ld	s9,56(sp)
    19da:	6149                	addi	sp,sp,144
    19dc:	8082                	ret

00000000000019de <linkunlink>:
{
    19de:	711d                	addi	sp,sp,-96
    19e0:	ec86                	sd	ra,88(sp)
    19e2:	e8a2                	sd	s0,80(sp)
    19e4:	e4a6                	sd	s1,72(sp)
    19e6:	e0ca                	sd	s2,64(sp)
    19e8:	fc4e                	sd	s3,56(sp)
    19ea:	f852                	sd	s4,48(sp)
    19ec:	f456                	sd	s5,40(sp)
    19ee:	f05a                	sd	s6,32(sp)
    19f0:	ec5e                	sd	s7,24(sp)
    19f2:	e862                	sd	s8,16(sp)
    19f4:	e466                	sd	s9,8(sp)
    19f6:	1080                	addi	s0,sp,96
    19f8:	84aa                	mv	s1,a0
  unlink("x");
    19fa:	00004517          	auipc	a0,0x4
    19fe:	93e50513          	addi	a0,a0,-1730 # 5338 <malloc+0x1a8>
    1a02:	2f6030ef          	jal	ra,4cf8 <unlink>
  pid = fork();
    1a06:	29a030ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    1a0a:	02054b63          	bltz	a0,1a40 <linkunlink+0x62>
    1a0e:	8c2a                	mv	s8,a0
  unsigned int x = (pid ? 1 : 97);
    1a10:	4c85                	li	s9,1
    1a12:	e119                	bnez	a0,1a18 <linkunlink+0x3a>
    1a14:	06100c93          	li	s9,97
    1a18:	06400493          	li	s1,100
    x = x * 1103515245 + 12345;
    1a1c:	41c659b7          	lui	s3,0x41c65
    1a20:	e6d9899b          	addiw	s3,s3,-403
    1a24:	690d                	lui	s2,0x3
    1a26:	0399091b          	addiw	s2,s2,57
    if((x % 3) == 0){
    1a2a:	4a0d                	li	s4,3
    } else if((x % 3) == 1){
    1a2c:	4b05                	li	s6,1
      unlink("x");
    1a2e:	00004a97          	auipc	s5,0x4
    1a32:	90aa8a93          	addi	s5,s5,-1782 # 5338 <malloc+0x1a8>
      link("cat", "x");
    1a36:	00004b97          	auipc	s7,0x4
    1a3a:	37ab8b93          	addi	s7,s7,890 # 5db0 <malloc+0xc20>
    1a3e:	a025                	j	1a66 <linkunlink+0x88>
    printf("%s: fork failed\n", s);
    1a40:	85a6                	mv	a1,s1
    1a42:	00004517          	auipc	a0,0x4
    1a46:	11650513          	addi	a0,a0,278 # 5b58 <malloc+0x9c8>
    1a4a:	68c030ef          	jal	ra,50d6 <printf>
    exit(1);
    1a4e:	4505                	li	a0,1
    1a50:	258030ef          	jal	ra,4ca8 <exit>
      close(open("x", O_RDWR | O_CREATE));
    1a54:	20200593          	li	a1,514
    1a58:	8556                	mv	a0,s5
    1a5a:	28e030ef          	jal	ra,4ce8 <open>
    1a5e:	272030ef          	jal	ra,4cd0 <close>
  for(i = 0; i < 100; i++){
    1a62:	34fd                	addiw	s1,s1,-1
    1a64:	c48d                	beqz	s1,1a8e <linkunlink+0xb0>
    x = x * 1103515245 + 12345;
    1a66:	033c87bb          	mulw	a5,s9,s3
    1a6a:	012787bb          	addw	a5,a5,s2
    1a6e:	00078c9b          	sext.w	s9,a5
    if((x % 3) == 0){
    1a72:	0347f7bb          	remuw	a5,a5,s4
    1a76:	dff9                	beqz	a5,1a54 <linkunlink+0x76>
    } else if((x % 3) == 1){
    1a78:	01678663          	beq	a5,s6,1a84 <linkunlink+0xa6>
      unlink("x");
    1a7c:	8556                	mv	a0,s5
    1a7e:	27a030ef          	jal	ra,4cf8 <unlink>
    1a82:	b7c5                	j	1a62 <linkunlink+0x84>
      link("cat", "x");
    1a84:	85d6                	mv	a1,s5
    1a86:	855e                	mv	a0,s7
    1a88:	280030ef          	jal	ra,4d08 <link>
    1a8c:	bfd9                	j	1a62 <linkunlink+0x84>
  if(pid)
    1a8e:	020c0263          	beqz	s8,1ab2 <linkunlink+0xd4>
    wait(0);
    1a92:	4501                	li	a0,0
    1a94:	21c030ef          	jal	ra,4cb0 <wait>
}
    1a98:	60e6                	ld	ra,88(sp)
    1a9a:	6446                	ld	s0,80(sp)
    1a9c:	64a6                	ld	s1,72(sp)
    1a9e:	6906                	ld	s2,64(sp)
    1aa0:	79e2                	ld	s3,56(sp)
    1aa2:	7a42                	ld	s4,48(sp)
    1aa4:	7aa2                	ld	s5,40(sp)
    1aa6:	7b02                	ld	s6,32(sp)
    1aa8:	6be2                	ld	s7,24(sp)
    1aaa:	6c42                	ld	s8,16(sp)
    1aac:	6ca2                	ld	s9,8(sp)
    1aae:	6125                	addi	sp,sp,96
    1ab0:	8082                	ret
    exit(0);
    1ab2:	4501                	li	a0,0
    1ab4:	1f4030ef          	jal	ra,4ca8 <exit>

0000000000001ab8 <forktest>:
{
    1ab8:	7179                	addi	sp,sp,-48
    1aba:	f406                	sd	ra,40(sp)
    1abc:	f022                	sd	s0,32(sp)
    1abe:	ec26                	sd	s1,24(sp)
    1ac0:	e84a                	sd	s2,16(sp)
    1ac2:	e44e                	sd	s3,8(sp)
    1ac4:	1800                	addi	s0,sp,48
    1ac6:	89aa                	mv	s3,a0
  for(n=0; n<N; n++){
    1ac8:	4481                	li	s1,0
    1aca:	3e800913          	li	s2,1000
    pid = fork();
    1ace:	1d2030ef          	jal	ra,4ca0 <fork>
    if(pid < 0)
    1ad2:	02054263          	bltz	a0,1af6 <forktest+0x3e>
    if(pid == 0)
    1ad6:	cd11                	beqz	a0,1af2 <forktest+0x3a>
  for(n=0; n<N; n++){
    1ad8:	2485                	addiw	s1,s1,1
    1ada:	ff249ae3          	bne	s1,s2,1ace <forktest+0x16>
    printf("%s: fork claimed to work 1000 times!\n", s);
    1ade:	85ce                	mv	a1,s3
    1ae0:	00004517          	auipc	a0,0x4
    1ae4:	2f050513          	addi	a0,a0,752 # 5dd0 <malloc+0xc40>
    1ae8:	5ee030ef          	jal	ra,50d6 <printf>
    exit(1);
    1aec:	4505                	li	a0,1
    1aee:	1ba030ef          	jal	ra,4ca8 <exit>
      exit(0);
    1af2:	1b6030ef          	jal	ra,4ca8 <exit>
  if (n == 0) {
    1af6:	c89d                	beqz	s1,1b2c <forktest+0x74>
  if(n == N){
    1af8:	3e800793          	li	a5,1000
    1afc:	fef481e3          	beq	s1,a5,1ade <forktest+0x26>
  for(; n > 0; n--){
    1b00:	00905963          	blez	s1,1b12 <forktest+0x5a>
    if(wait(0) < 0){
    1b04:	4501                	li	a0,0
    1b06:	1aa030ef          	jal	ra,4cb0 <wait>
    1b0a:	02054b63          	bltz	a0,1b40 <forktest+0x88>
  for(; n > 0; n--){
    1b0e:	34fd                	addiw	s1,s1,-1
    1b10:	f8f5                	bnez	s1,1b04 <forktest+0x4c>
  if(wait(0) != -1){
    1b12:	4501                	li	a0,0
    1b14:	19c030ef          	jal	ra,4cb0 <wait>
    1b18:	57fd                	li	a5,-1
    1b1a:	02f51d63          	bne	a0,a5,1b54 <forktest+0x9c>
}
    1b1e:	70a2                	ld	ra,40(sp)
    1b20:	7402                	ld	s0,32(sp)
    1b22:	64e2                	ld	s1,24(sp)
    1b24:	6942                	ld	s2,16(sp)
    1b26:	69a2                	ld	s3,8(sp)
    1b28:	6145                	addi	sp,sp,48
    1b2a:	8082                	ret
    printf("%s: no fork at all!\n", s);
    1b2c:	85ce                	mv	a1,s3
    1b2e:	00004517          	auipc	a0,0x4
    1b32:	28a50513          	addi	a0,a0,650 # 5db8 <malloc+0xc28>
    1b36:	5a0030ef          	jal	ra,50d6 <printf>
    exit(1);
    1b3a:	4505                	li	a0,1
    1b3c:	16c030ef          	jal	ra,4ca8 <exit>
      printf("%s: wait stopped early\n", s);
    1b40:	85ce                	mv	a1,s3
    1b42:	00004517          	auipc	a0,0x4
    1b46:	2b650513          	addi	a0,a0,694 # 5df8 <malloc+0xc68>
    1b4a:	58c030ef          	jal	ra,50d6 <printf>
      exit(1);
    1b4e:	4505                	li	a0,1
    1b50:	158030ef          	jal	ra,4ca8 <exit>
    printf("%s: wait got too many\n", s);
    1b54:	85ce                	mv	a1,s3
    1b56:	00004517          	auipc	a0,0x4
    1b5a:	2ba50513          	addi	a0,a0,698 # 5e10 <malloc+0xc80>
    1b5e:	578030ef          	jal	ra,50d6 <printf>
    exit(1);
    1b62:	4505                	li	a0,1
    1b64:	144030ef          	jal	ra,4ca8 <exit>

0000000000001b68 <kernmem>:
{
    1b68:	715d                	addi	sp,sp,-80
    1b6a:	e486                	sd	ra,72(sp)
    1b6c:	e0a2                	sd	s0,64(sp)
    1b6e:	fc26                	sd	s1,56(sp)
    1b70:	f84a                	sd	s2,48(sp)
    1b72:	f44e                	sd	s3,40(sp)
    1b74:	f052                	sd	s4,32(sp)
    1b76:	ec56                	sd	s5,24(sp)
    1b78:	0880                	addi	s0,sp,80
    1b7a:	8a2a                	mv	s4,a0
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1b7c:	4485                	li	s1,1
    1b7e:	04fe                	slli	s1,s1,0x1f
    if(xstatus != -1)  // did kernel kill child?
    1b80:	5afd                	li	s5,-1
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1b82:	69b1                	lui	s3,0xc
    1b84:	35098993          	addi	s3,s3,848 # c350 <buf+0x6a8>
    1b88:	1003d937          	lui	s2,0x1003d
    1b8c:	090e                	slli	s2,s2,0x3
    1b8e:	48090913          	addi	s2,s2,1152 # 1003d480 <base+0x1002e7d8>
    pid = fork();
    1b92:	10e030ef          	jal	ra,4ca0 <fork>
    if(pid < 0){
    1b96:	02054763          	bltz	a0,1bc4 <kernmem+0x5c>
    if(pid == 0){
    1b9a:	cd1d                	beqz	a0,1bd8 <kernmem+0x70>
    wait(&xstatus);
    1b9c:	fbc40513          	addi	a0,s0,-68
    1ba0:	110030ef          	jal	ra,4cb0 <wait>
    if(xstatus != -1)  // did kernel kill child?
    1ba4:	fbc42783          	lw	a5,-68(s0)
    1ba8:	05579563          	bne	a5,s5,1bf2 <kernmem+0x8a>
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1bac:	94ce                	add	s1,s1,s3
    1bae:	ff2492e3          	bne	s1,s2,1b92 <kernmem+0x2a>
}
    1bb2:	60a6                	ld	ra,72(sp)
    1bb4:	6406                	ld	s0,64(sp)
    1bb6:	74e2                	ld	s1,56(sp)
    1bb8:	7942                	ld	s2,48(sp)
    1bba:	79a2                	ld	s3,40(sp)
    1bbc:	7a02                	ld	s4,32(sp)
    1bbe:	6ae2                	ld	s5,24(sp)
    1bc0:	6161                	addi	sp,sp,80
    1bc2:	8082                	ret
      printf("%s: fork failed\n", s);
    1bc4:	85d2                	mv	a1,s4
    1bc6:	00004517          	auipc	a0,0x4
    1bca:	f9250513          	addi	a0,a0,-110 # 5b58 <malloc+0x9c8>
    1bce:	508030ef          	jal	ra,50d6 <printf>
      exit(1);
    1bd2:	4505                	li	a0,1
    1bd4:	0d4030ef          	jal	ra,4ca8 <exit>
      printf("%s: oops could read %p = %x\n", s, a, *a);
    1bd8:	0004c683          	lbu	a3,0(s1)
    1bdc:	8626                	mv	a2,s1
    1bde:	85d2                	mv	a1,s4
    1be0:	00004517          	auipc	a0,0x4
    1be4:	24850513          	addi	a0,a0,584 # 5e28 <malloc+0xc98>
    1be8:	4ee030ef          	jal	ra,50d6 <printf>
      exit(1);
    1bec:	4505                	li	a0,1
    1bee:	0ba030ef          	jal	ra,4ca8 <exit>
      exit(1);
    1bf2:	4505                	li	a0,1
    1bf4:	0b4030ef          	jal	ra,4ca8 <exit>

0000000000001bf8 <MAXVAplus>:
{
    1bf8:	7179                	addi	sp,sp,-48
    1bfa:	f406                	sd	ra,40(sp)
    1bfc:	f022                	sd	s0,32(sp)
    1bfe:	ec26                	sd	s1,24(sp)
    1c00:	e84a                	sd	s2,16(sp)
    1c02:	1800                	addi	s0,sp,48
  volatile uint64 a = MAXVA;
    1c04:	4785                	li	a5,1
    1c06:	179a                	slli	a5,a5,0x26
    1c08:	fcf43c23          	sd	a5,-40(s0)
  for( ; a != 0; a <<= 1){
    1c0c:	fd843783          	ld	a5,-40(s0)
    1c10:	cb85                	beqz	a5,1c40 <MAXVAplus+0x48>
    1c12:	892a                	mv	s2,a0
    if(xstatus != -1)  // did kernel kill child?
    1c14:	54fd                	li	s1,-1
    pid = fork();
    1c16:	08a030ef          	jal	ra,4ca0 <fork>
    if(pid < 0){
    1c1a:	02054963          	bltz	a0,1c4c <MAXVAplus+0x54>
    if(pid == 0){
    1c1e:	c129                	beqz	a0,1c60 <MAXVAplus+0x68>
    wait(&xstatus);
    1c20:	fd440513          	addi	a0,s0,-44
    1c24:	08c030ef          	jal	ra,4cb0 <wait>
    if(xstatus != -1)  // did kernel kill child?
    1c28:	fd442783          	lw	a5,-44(s0)
    1c2c:	04979c63          	bne	a5,s1,1c84 <MAXVAplus+0x8c>
  for( ; a != 0; a <<= 1){
    1c30:	fd843783          	ld	a5,-40(s0)
    1c34:	0786                	slli	a5,a5,0x1
    1c36:	fcf43c23          	sd	a5,-40(s0)
    1c3a:	fd843783          	ld	a5,-40(s0)
    1c3e:	ffe1                	bnez	a5,1c16 <MAXVAplus+0x1e>
}
    1c40:	70a2                	ld	ra,40(sp)
    1c42:	7402                	ld	s0,32(sp)
    1c44:	64e2                	ld	s1,24(sp)
    1c46:	6942                	ld	s2,16(sp)
    1c48:	6145                	addi	sp,sp,48
    1c4a:	8082                	ret
      printf("%s: fork failed\n", s);
    1c4c:	85ca                	mv	a1,s2
    1c4e:	00004517          	auipc	a0,0x4
    1c52:	f0a50513          	addi	a0,a0,-246 # 5b58 <malloc+0x9c8>
    1c56:	480030ef          	jal	ra,50d6 <printf>
      exit(1);
    1c5a:	4505                	li	a0,1
    1c5c:	04c030ef          	jal	ra,4ca8 <exit>
      *(char*)a = 99;
    1c60:	fd843783          	ld	a5,-40(s0)
    1c64:	06300713          	li	a4,99
    1c68:	00e78023          	sb	a4,0(a5)
      printf("%s: oops wrote %p\n", s, (void*)a);
    1c6c:	fd843603          	ld	a2,-40(s0)
    1c70:	85ca                	mv	a1,s2
    1c72:	00004517          	auipc	a0,0x4
    1c76:	1d650513          	addi	a0,a0,470 # 5e48 <malloc+0xcb8>
    1c7a:	45c030ef          	jal	ra,50d6 <printf>
      exit(1);
    1c7e:	4505                	li	a0,1
    1c80:	028030ef          	jal	ra,4ca8 <exit>
      exit(1);
    1c84:	4505                	li	a0,1
    1c86:	022030ef          	jal	ra,4ca8 <exit>

0000000000001c8a <stacktest>:
{
    1c8a:	7179                	addi	sp,sp,-48
    1c8c:	f406                	sd	ra,40(sp)
    1c8e:	f022                	sd	s0,32(sp)
    1c90:	ec26                	sd	s1,24(sp)
    1c92:	1800                	addi	s0,sp,48
    1c94:	84aa                	mv	s1,a0
  pid = fork();
    1c96:	00a030ef          	jal	ra,4ca0 <fork>
  if(pid == 0) {
    1c9a:	cd11                	beqz	a0,1cb6 <stacktest+0x2c>
  } else if(pid < 0){
    1c9c:	02054c63          	bltz	a0,1cd4 <stacktest+0x4a>
  wait(&xstatus);
    1ca0:	fdc40513          	addi	a0,s0,-36
    1ca4:	00c030ef          	jal	ra,4cb0 <wait>
  if(xstatus == -1)  // kernel killed child?
    1ca8:	fdc42503          	lw	a0,-36(s0)
    1cac:	57fd                	li	a5,-1
    1cae:	02f50d63          	beq	a0,a5,1ce8 <stacktest+0x5e>
    exit(xstatus);
    1cb2:	7f7020ef          	jal	ra,4ca8 <exit>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mv %0, sp" : "=r" (x) );
    1cb6:	870a                	mv	a4,sp
    printf("%s: stacktest: read below stack %d\n", s, *sp);
    1cb8:	77fd                	lui	a5,0xfffff
    1cba:	97ba                	add	a5,a5,a4
    1cbc:	0007c603          	lbu	a2,0(a5) # fffffffffffff000 <base+0xffffffffffff0358>
    1cc0:	85a6                	mv	a1,s1
    1cc2:	00004517          	auipc	a0,0x4
    1cc6:	19e50513          	addi	a0,a0,414 # 5e60 <malloc+0xcd0>
    1cca:	40c030ef          	jal	ra,50d6 <printf>
    exit(1);
    1cce:	4505                	li	a0,1
    1cd0:	7d9020ef          	jal	ra,4ca8 <exit>
    printf("%s: fork failed\n", s);
    1cd4:	85a6                	mv	a1,s1
    1cd6:	00004517          	auipc	a0,0x4
    1cda:	e8250513          	addi	a0,a0,-382 # 5b58 <malloc+0x9c8>
    1cde:	3f8030ef          	jal	ra,50d6 <printf>
    exit(1);
    1ce2:	4505                	li	a0,1
    1ce4:	7c5020ef          	jal	ra,4ca8 <exit>
    exit(0);
    1ce8:	4501                	li	a0,0
    1cea:	7bf020ef          	jal	ra,4ca8 <exit>

0000000000001cee <nowrite>:
{
    1cee:	7159                	addi	sp,sp,-112
    1cf0:	f486                	sd	ra,104(sp)
    1cf2:	f0a2                	sd	s0,96(sp)
    1cf4:	eca6                	sd	s1,88(sp)
    1cf6:	e8ca                	sd	s2,80(sp)
    1cf8:	e4ce                	sd	s3,72(sp)
    1cfa:	1880                	addi	s0,sp,112
    1cfc:	89aa                	mv	s3,a0
  uint64 addrs[] = { 0, 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
    1cfe:	00006797          	auipc	a5,0x6
    1d02:	a2a78793          	addi	a5,a5,-1494 # 7728 <malloc+0x2598>
    1d06:	7788                	ld	a0,40(a5)
    1d08:	7b8c                	ld	a1,48(a5)
    1d0a:	7f90                	ld	a2,56(a5)
    1d0c:	63b4                	ld	a3,64(a5)
    1d0e:	67b8                	ld	a4,72(a5)
    1d10:	6bbc                	ld	a5,80(a5)
    1d12:	f8a43c23          	sd	a0,-104(s0)
    1d16:	fab43023          	sd	a1,-96(s0)
    1d1a:	fac43423          	sd	a2,-88(s0)
    1d1e:	fad43823          	sd	a3,-80(s0)
    1d22:	fae43c23          	sd	a4,-72(s0)
    1d26:	fcf43023          	sd	a5,-64(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1d2a:	4481                	li	s1,0
    1d2c:	4919                	li	s2,6
    pid = fork();
    1d2e:	773020ef          	jal	ra,4ca0 <fork>
    if(pid == 0) {
    1d32:	c105                	beqz	a0,1d52 <nowrite+0x64>
    } else if(pid < 0){
    1d34:	04054163          	bltz	a0,1d76 <nowrite+0x88>
    wait(&xstatus);
    1d38:	fcc40513          	addi	a0,s0,-52
    1d3c:	775020ef          	jal	ra,4cb0 <wait>
    if(xstatus == 0){
    1d40:	fcc42783          	lw	a5,-52(s0)
    1d44:	c3b9                	beqz	a5,1d8a <nowrite+0x9c>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1d46:	2485                	addiw	s1,s1,1
    1d48:	ff2493e3          	bne	s1,s2,1d2e <nowrite+0x40>
  exit(0);
    1d4c:	4501                	li	a0,0
    1d4e:	75b020ef          	jal	ra,4ca8 <exit>
      volatile int *addr = (int *) addrs[ai];
    1d52:	048e                	slli	s1,s1,0x3
    1d54:	fd040793          	addi	a5,s0,-48
    1d58:	94be                	add	s1,s1,a5
    1d5a:	fc84b603          	ld	a2,-56(s1)
      *addr = 10;
    1d5e:	47a9                	li	a5,10
    1d60:	c21c                	sw	a5,0(a2)
      printf("%s: write to %p did not fail!\n", s, addr);
    1d62:	85ce                	mv	a1,s3
    1d64:	00004517          	auipc	a0,0x4
    1d68:	12450513          	addi	a0,a0,292 # 5e88 <malloc+0xcf8>
    1d6c:	36a030ef          	jal	ra,50d6 <printf>
      exit(0);
    1d70:	4501                	li	a0,0
    1d72:	737020ef          	jal	ra,4ca8 <exit>
      printf("%s: fork failed\n", s);
    1d76:	85ce                	mv	a1,s3
    1d78:	00004517          	auipc	a0,0x4
    1d7c:	de050513          	addi	a0,a0,-544 # 5b58 <malloc+0x9c8>
    1d80:	356030ef          	jal	ra,50d6 <printf>
      exit(1);
    1d84:	4505                	li	a0,1
    1d86:	723020ef          	jal	ra,4ca8 <exit>
      exit(1);
    1d8a:	4505                	li	a0,1
    1d8c:	71d020ef          	jal	ra,4ca8 <exit>

0000000000001d90 <manywrites>:
{
    1d90:	711d                	addi	sp,sp,-96
    1d92:	ec86                	sd	ra,88(sp)
    1d94:	e8a2                	sd	s0,80(sp)
    1d96:	e4a6                	sd	s1,72(sp)
    1d98:	e0ca                	sd	s2,64(sp)
    1d9a:	fc4e                	sd	s3,56(sp)
    1d9c:	f852                	sd	s4,48(sp)
    1d9e:	f456                	sd	s5,40(sp)
    1da0:	f05a                	sd	s6,32(sp)
    1da2:	ec5e                	sd	s7,24(sp)
    1da4:	1080                	addi	s0,sp,96
    1da6:	8aaa                	mv	s5,a0
  for(int ci = 0; ci < nchildren; ci++){
    1da8:	4981                	li	s3,0
    1daa:	4911                	li	s2,4
    int pid = fork();
    1dac:	6f5020ef          	jal	ra,4ca0 <fork>
    1db0:	84aa                	mv	s1,a0
    if(pid < 0){
    1db2:	02054563          	bltz	a0,1ddc <manywrites+0x4c>
    if(pid == 0){
    1db6:	cd05                	beqz	a0,1dee <manywrites+0x5e>
  for(int ci = 0; ci < nchildren; ci++){
    1db8:	2985                	addiw	s3,s3,1
    1dba:	ff2999e3          	bne	s3,s2,1dac <manywrites+0x1c>
    1dbe:	4491                	li	s1,4
    int st = 0;
    1dc0:	fa042423          	sw	zero,-88(s0)
    wait(&st);
    1dc4:	fa840513          	addi	a0,s0,-88
    1dc8:	6e9020ef          	jal	ra,4cb0 <wait>
    if(st != 0)
    1dcc:	fa842503          	lw	a0,-88(s0)
    1dd0:	e169                	bnez	a0,1e92 <manywrites+0x102>
  for(int ci = 0; ci < nchildren; ci++){
    1dd2:	34fd                	addiw	s1,s1,-1
    1dd4:	f4f5                	bnez	s1,1dc0 <manywrites+0x30>
  exit(0);
    1dd6:	4501                	li	a0,0
    1dd8:	6d1020ef          	jal	ra,4ca8 <exit>
      printf("fork failed\n");
    1ddc:	00005517          	auipc	a0,0x5
    1de0:	3ac50513          	addi	a0,a0,940 # 7188 <malloc+0x1ff8>
    1de4:	2f2030ef          	jal	ra,50d6 <printf>
      exit(1);
    1de8:	4505                	li	a0,1
    1dea:	6bf020ef          	jal	ra,4ca8 <exit>
      name[0] = 'b';
    1dee:	06200793          	li	a5,98
    1df2:	faf40423          	sb	a5,-88(s0)
      name[1] = 'a' + ci;
    1df6:	0619879b          	addiw	a5,s3,97
    1dfa:	faf404a3          	sb	a5,-87(s0)
      name[2] = '\0';
    1dfe:	fa040523          	sb	zero,-86(s0)
      unlink(name);
    1e02:	fa840513          	addi	a0,s0,-88
    1e06:	6f3020ef          	jal	ra,4cf8 <unlink>
    1e0a:	4bf9                	li	s7,30
          int cc = write(fd, buf, sz);
    1e0c:	0000ab17          	auipc	s6,0xa
    1e10:	e9cb0b13          	addi	s6,s6,-356 # bca8 <buf>
        for(int i = 0; i < ci+1; i++){
    1e14:	8a26                	mv	s4,s1
    1e16:	0209c863          	bltz	s3,1e46 <manywrites+0xb6>
          int fd = open(name, O_CREATE | O_RDWR);
    1e1a:	20200593          	li	a1,514
    1e1e:	fa840513          	addi	a0,s0,-88
    1e22:	6c7020ef          	jal	ra,4ce8 <open>
    1e26:	892a                	mv	s2,a0
          if(fd < 0){
    1e28:	02054d63          	bltz	a0,1e62 <manywrites+0xd2>
          int cc = write(fd, buf, sz);
    1e2c:	660d                	lui	a2,0x3
    1e2e:	85da                	mv	a1,s6
    1e30:	699020ef          	jal	ra,4cc8 <write>
          if(cc != sz){
    1e34:	678d                	lui	a5,0x3
    1e36:	04f51263          	bne	a0,a5,1e7a <manywrites+0xea>
          close(fd);
    1e3a:	854a                	mv	a0,s2
    1e3c:	695020ef          	jal	ra,4cd0 <close>
        for(int i = 0; i < ci+1; i++){
    1e40:	2a05                	addiw	s4,s4,1
    1e42:	fd49dce3          	bge	s3,s4,1e1a <manywrites+0x8a>
        unlink(name);
    1e46:	fa840513          	addi	a0,s0,-88
    1e4a:	6af020ef          	jal	ra,4cf8 <unlink>
      for(int iters = 0; iters < howmany; iters++){
    1e4e:	3bfd                	addiw	s7,s7,-1
    1e50:	fc0b92e3          	bnez	s7,1e14 <manywrites+0x84>
      unlink(name);
    1e54:	fa840513          	addi	a0,s0,-88
    1e58:	6a1020ef          	jal	ra,4cf8 <unlink>
      exit(0);
    1e5c:	4501                	li	a0,0
    1e5e:	64b020ef          	jal	ra,4ca8 <exit>
            printf("%s: cannot create %s\n", s, name);
    1e62:	fa840613          	addi	a2,s0,-88
    1e66:	85d6                	mv	a1,s5
    1e68:	00004517          	auipc	a0,0x4
    1e6c:	04050513          	addi	a0,a0,64 # 5ea8 <malloc+0xd18>
    1e70:	266030ef          	jal	ra,50d6 <printf>
            exit(1);
    1e74:	4505                	li	a0,1
    1e76:	633020ef          	jal	ra,4ca8 <exit>
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    1e7a:	86aa                	mv	a3,a0
    1e7c:	660d                	lui	a2,0x3
    1e7e:	85d6                	mv	a1,s5
    1e80:	00003517          	auipc	a0,0x3
    1e84:	51850513          	addi	a0,a0,1304 # 5398 <malloc+0x208>
    1e88:	24e030ef          	jal	ra,50d6 <printf>
            exit(1);
    1e8c:	4505                	li	a0,1
    1e8e:	61b020ef          	jal	ra,4ca8 <exit>
      exit(st);
    1e92:	617020ef          	jal	ra,4ca8 <exit>

0000000000001e96 <copyinstr3>:
{
    1e96:	7179                	addi	sp,sp,-48
    1e98:	f406                	sd	ra,40(sp)
    1e9a:	f022                	sd	s0,32(sp)
    1e9c:	ec26                	sd	s1,24(sp)
    1e9e:	1800                	addi	s0,sp,48
  sbrk(8192);
    1ea0:	6509                	lui	a0,0x2
    1ea2:	68f020ef          	jal	ra,4d30 <sbrk>
  uint64 top = (uint64) sbrk(0);
    1ea6:	4501                	li	a0,0
    1ea8:	689020ef          	jal	ra,4d30 <sbrk>
  if((top % PGSIZE) != 0){
    1eac:	03451793          	slli	a5,a0,0x34
    1eb0:	e7bd                	bnez	a5,1f1e <copyinstr3+0x88>
  top = (uint64) sbrk(0);
    1eb2:	4501                	li	a0,0
    1eb4:	67d020ef          	jal	ra,4d30 <sbrk>
  if(top % PGSIZE){
    1eb8:	03451793          	slli	a5,a0,0x34
    1ebc:	ebad                	bnez	a5,1f2e <copyinstr3+0x98>
  char *b = (char *) (top - 1);
    1ebe:	fff50493          	addi	s1,a0,-1 # 1fff <rwsbrk+0x65>
  *b = 'x';
    1ec2:	07800793          	li	a5,120
    1ec6:	fef50fa3          	sb	a5,-1(a0)
  int ret = unlink(b);
    1eca:	8526                	mv	a0,s1
    1ecc:	62d020ef          	jal	ra,4cf8 <unlink>
  if(ret != -1){
    1ed0:	57fd                	li	a5,-1
    1ed2:	06f51763          	bne	a0,a5,1f40 <copyinstr3+0xaa>
  int fd = open(b, O_CREATE | O_WRONLY);
    1ed6:	20100593          	li	a1,513
    1eda:	8526                	mv	a0,s1
    1edc:	60d020ef          	jal	ra,4ce8 <open>
  if(fd != -1){
    1ee0:	57fd                	li	a5,-1
    1ee2:	06f51a63          	bne	a0,a5,1f56 <copyinstr3+0xc0>
  ret = link(b, b);
    1ee6:	85a6                	mv	a1,s1
    1ee8:	8526                	mv	a0,s1
    1eea:	61f020ef          	jal	ra,4d08 <link>
  if(ret != -1){
    1eee:	57fd                	li	a5,-1
    1ef0:	06f51e63          	bne	a0,a5,1f6c <copyinstr3+0xd6>
  char *args[] = { "xx", 0 };
    1ef4:	00005797          	auipc	a5,0x5
    1ef8:	d9478793          	addi	a5,a5,-620 # 6c88 <malloc+0x1af8>
    1efc:	fcf43823          	sd	a5,-48(s0)
    1f00:	fc043c23          	sd	zero,-40(s0)
  ret = exec(b, args);
    1f04:	fd040593          	addi	a1,s0,-48
    1f08:	8526                	mv	a0,s1
    1f0a:	5d7020ef          	jal	ra,4ce0 <exec>
  if(ret != -1){
    1f0e:	57fd                	li	a5,-1
    1f10:	06f51a63          	bne	a0,a5,1f84 <copyinstr3+0xee>
}
    1f14:	70a2                	ld	ra,40(sp)
    1f16:	7402                	ld	s0,32(sp)
    1f18:	64e2                	ld	s1,24(sp)
    1f1a:	6145                	addi	sp,sp,48
    1f1c:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    1f1e:	0347d513          	srli	a0,a5,0x34
    1f22:	6785                	lui	a5,0x1
    1f24:	40a7853b          	subw	a0,a5,a0
    1f28:	609020ef          	jal	ra,4d30 <sbrk>
    1f2c:	b759                	j	1eb2 <copyinstr3+0x1c>
    printf("oops\n");
    1f2e:	00004517          	auipc	a0,0x4
    1f32:	f9250513          	addi	a0,a0,-110 # 5ec0 <malloc+0xd30>
    1f36:	1a0030ef          	jal	ra,50d6 <printf>
    exit(1);
    1f3a:	4505                	li	a0,1
    1f3c:	56d020ef          	jal	ra,4ca8 <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1f40:	862a                	mv	a2,a0
    1f42:	85a6                	mv	a1,s1
    1f44:	00004517          	auipc	a0,0x4
    1f48:	b3450513          	addi	a0,a0,-1228 # 5a78 <malloc+0x8e8>
    1f4c:	18a030ef          	jal	ra,50d6 <printf>
    exit(1);
    1f50:	4505                	li	a0,1
    1f52:	557020ef          	jal	ra,4ca8 <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1f56:	862a                	mv	a2,a0
    1f58:	85a6                	mv	a1,s1
    1f5a:	00004517          	auipc	a0,0x4
    1f5e:	b3e50513          	addi	a0,a0,-1218 # 5a98 <malloc+0x908>
    1f62:	174030ef          	jal	ra,50d6 <printf>
    exit(1);
    1f66:	4505                	li	a0,1
    1f68:	541020ef          	jal	ra,4ca8 <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    1f6c:	86aa                	mv	a3,a0
    1f6e:	8626                	mv	a2,s1
    1f70:	85a6                	mv	a1,s1
    1f72:	00004517          	auipc	a0,0x4
    1f76:	b4650513          	addi	a0,a0,-1210 # 5ab8 <malloc+0x928>
    1f7a:	15c030ef          	jal	ra,50d6 <printf>
    exit(1);
    1f7e:	4505                	li	a0,1
    1f80:	529020ef          	jal	ra,4ca8 <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1f84:	567d                	li	a2,-1
    1f86:	85a6                	mv	a1,s1
    1f88:	00004517          	auipc	a0,0x4
    1f8c:	b5850513          	addi	a0,a0,-1192 # 5ae0 <malloc+0x950>
    1f90:	146030ef          	jal	ra,50d6 <printf>
    exit(1);
    1f94:	4505                	li	a0,1
    1f96:	513020ef          	jal	ra,4ca8 <exit>

0000000000001f9a <rwsbrk>:
{
    1f9a:	1101                	addi	sp,sp,-32
    1f9c:	ec06                	sd	ra,24(sp)
    1f9e:	e822                	sd	s0,16(sp)
    1fa0:	e426                	sd	s1,8(sp)
    1fa2:	e04a                	sd	s2,0(sp)
    1fa4:	1000                	addi	s0,sp,32
  uint64 a = (uint64) sbrk(8192);
    1fa6:	6509                	lui	a0,0x2
    1fa8:	589020ef          	jal	ra,4d30 <sbrk>
  if(a == 0xffffffffffffffffLL) {
    1fac:	57fd                	li	a5,-1
    1fae:	04f50963          	beq	a0,a5,2000 <rwsbrk+0x66>
    1fb2:	84aa                	mv	s1,a0
  if ((uint64) sbrk(-8192) ==  0xffffffffffffffffLL) {
    1fb4:	7579                	lui	a0,0xffffe
    1fb6:	57b020ef          	jal	ra,4d30 <sbrk>
    1fba:	57fd                	li	a5,-1
    1fbc:	04f50b63          	beq	a0,a5,2012 <rwsbrk+0x78>
  fd = open("rwsbrk", O_CREATE|O_WRONLY);
    1fc0:	20100593          	li	a1,513
    1fc4:	00004517          	auipc	a0,0x4
    1fc8:	f3c50513          	addi	a0,a0,-196 # 5f00 <malloc+0xd70>
    1fcc:	51d020ef          	jal	ra,4ce8 <open>
    1fd0:	892a                	mv	s2,a0
  if(fd < 0){
    1fd2:	04054963          	bltz	a0,2024 <rwsbrk+0x8a>
  n = write(fd, (void*)(a+4096), 1024);
    1fd6:	6505                	lui	a0,0x1
    1fd8:	94aa                	add	s1,s1,a0
    1fda:	40000613          	li	a2,1024
    1fde:	85a6                	mv	a1,s1
    1fe0:	854a                	mv	a0,s2
    1fe2:	4e7020ef          	jal	ra,4cc8 <write>
    1fe6:	862a                	mv	a2,a0
  if(n >= 0){
    1fe8:	04054763          	bltz	a0,2036 <rwsbrk+0x9c>
    printf("write(fd, %p, 1024) returned %d, not -1\n", (void*)a+4096, n);
    1fec:	85a6                	mv	a1,s1
    1fee:	00004517          	auipc	a0,0x4
    1ff2:	f3250513          	addi	a0,a0,-206 # 5f20 <malloc+0xd90>
    1ff6:	0e0030ef          	jal	ra,50d6 <printf>
    exit(1);
    1ffa:	4505                	li	a0,1
    1ffc:	4ad020ef          	jal	ra,4ca8 <exit>
    printf("sbrk(rwsbrk) failed\n");
    2000:	00004517          	auipc	a0,0x4
    2004:	ec850513          	addi	a0,a0,-312 # 5ec8 <malloc+0xd38>
    2008:	0ce030ef          	jal	ra,50d6 <printf>
    exit(1);
    200c:	4505                	li	a0,1
    200e:	49b020ef          	jal	ra,4ca8 <exit>
    printf("sbrk(rwsbrk) shrink failed\n");
    2012:	00004517          	auipc	a0,0x4
    2016:	ece50513          	addi	a0,a0,-306 # 5ee0 <malloc+0xd50>
    201a:	0bc030ef          	jal	ra,50d6 <printf>
    exit(1);
    201e:	4505                	li	a0,1
    2020:	489020ef          	jal	ra,4ca8 <exit>
    printf("open(rwsbrk) failed\n");
    2024:	00004517          	auipc	a0,0x4
    2028:	ee450513          	addi	a0,a0,-284 # 5f08 <malloc+0xd78>
    202c:	0aa030ef          	jal	ra,50d6 <printf>
    exit(1);
    2030:	4505                	li	a0,1
    2032:	477020ef          	jal	ra,4ca8 <exit>
  close(fd);
    2036:	854a                	mv	a0,s2
    2038:	499020ef          	jal	ra,4cd0 <close>
  unlink("rwsbrk");
    203c:	00004517          	auipc	a0,0x4
    2040:	ec450513          	addi	a0,a0,-316 # 5f00 <malloc+0xd70>
    2044:	4b5020ef          	jal	ra,4cf8 <unlink>
  fd = open("README", O_RDONLY);
    2048:	4581                	li	a1,0
    204a:	00003517          	auipc	a0,0x3
    204e:	45650513          	addi	a0,a0,1110 # 54a0 <malloc+0x310>
    2052:	497020ef          	jal	ra,4ce8 <open>
    2056:	892a                	mv	s2,a0
  if(fd < 0){
    2058:	02054363          	bltz	a0,207e <rwsbrk+0xe4>
  n = read(fd, (void*)(a+4096), 10);
    205c:	4629                	li	a2,10
    205e:	85a6                	mv	a1,s1
    2060:	461020ef          	jal	ra,4cc0 <read>
    2064:	862a                	mv	a2,a0
  if(n >= 0){
    2066:	02054563          	bltz	a0,2090 <rwsbrk+0xf6>
    printf("read(fd, %p, 10) returned %d, not -1\n", (void*)a+4096, n);
    206a:	85a6                	mv	a1,s1
    206c:	00004517          	auipc	a0,0x4
    2070:	ee450513          	addi	a0,a0,-284 # 5f50 <malloc+0xdc0>
    2074:	062030ef          	jal	ra,50d6 <printf>
    exit(1);
    2078:	4505                	li	a0,1
    207a:	42f020ef          	jal	ra,4ca8 <exit>
    printf("open(rwsbrk) failed\n");
    207e:	00004517          	auipc	a0,0x4
    2082:	e8a50513          	addi	a0,a0,-374 # 5f08 <malloc+0xd78>
    2086:	050030ef          	jal	ra,50d6 <printf>
    exit(1);
    208a:	4505                	li	a0,1
    208c:	41d020ef          	jal	ra,4ca8 <exit>
  close(fd);
    2090:	854a                	mv	a0,s2
    2092:	43f020ef          	jal	ra,4cd0 <close>
  exit(0);
    2096:	4501                	li	a0,0
    2098:	411020ef          	jal	ra,4ca8 <exit>

000000000000209c <sbrkbasic>:
{
    209c:	7139                	addi	sp,sp,-64
    209e:	fc06                	sd	ra,56(sp)
    20a0:	f822                	sd	s0,48(sp)
    20a2:	f426                	sd	s1,40(sp)
    20a4:	f04a                	sd	s2,32(sp)
    20a6:	ec4e                	sd	s3,24(sp)
    20a8:	e852                	sd	s4,16(sp)
    20aa:	0080                	addi	s0,sp,64
    20ac:	8a2a                	mv	s4,a0
  pid = fork();
    20ae:	3f3020ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    20b2:	02054863          	bltz	a0,20e2 <sbrkbasic+0x46>
  if(pid == 0){
    20b6:	e131                	bnez	a0,20fa <sbrkbasic+0x5e>
    a = sbrk(TOOMUCH);
    20b8:	40000537          	lui	a0,0x40000
    20bc:	475020ef          	jal	ra,4d30 <sbrk>
    if(a == (char*)0xffffffffffffffffL){
    20c0:	57fd                	li	a5,-1
    20c2:	02f50963          	beq	a0,a5,20f4 <sbrkbasic+0x58>
    for(b = a; b < a+TOOMUCH; b += 4096){
    20c6:	400007b7          	lui	a5,0x40000
    20ca:	97aa                	add	a5,a5,a0
      *b = 99;
    20cc:	06300693          	li	a3,99
    for(b = a; b < a+TOOMUCH; b += 4096){
    20d0:	6705                	lui	a4,0x1
      *b = 99;
    20d2:	00d50023          	sb	a3,0(a0) # 40000000 <base+0x3fff1358>
    for(b = a; b < a+TOOMUCH; b += 4096){
    20d6:	953a                	add	a0,a0,a4
    20d8:	fef51de3          	bne	a0,a5,20d2 <sbrkbasic+0x36>
    exit(1);
    20dc:	4505                	li	a0,1
    20de:	3cb020ef          	jal	ra,4ca8 <exit>
    printf("fork failed in sbrkbasic\n");
    20e2:	00004517          	auipc	a0,0x4
    20e6:	e9650513          	addi	a0,a0,-362 # 5f78 <malloc+0xde8>
    20ea:	7ed020ef          	jal	ra,50d6 <printf>
    exit(1);
    20ee:	4505                	li	a0,1
    20f0:	3b9020ef          	jal	ra,4ca8 <exit>
      exit(0);
    20f4:	4501                	li	a0,0
    20f6:	3b3020ef          	jal	ra,4ca8 <exit>
  wait(&xstatus);
    20fa:	fcc40513          	addi	a0,s0,-52
    20fe:	3b3020ef          	jal	ra,4cb0 <wait>
  if(xstatus == 1){
    2102:	fcc42703          	lw	a4,-52(s0)
    2106:	4785                	li	a5,1
    2108:	00f70b63          	beq	a4,a5,211e <sbrkbasic+0x82>
  a = sbrk(0);
    210c:	4501                	li	a0,0
    210e:	423020ef          	jal	ra,4d30 <sbrk>
    2112:	84aa                	mv	s1,a0
  for(i = 0; i < 5000; i++){
    2114:	4901                	li	s2,0
    2116:	6985                	lui	s3,0x1
    2118:	38898993          	addi	s3,s3,904 # 1388 <exectest+0x58>
    211c:	a821                	j	2134 <sbrkbasic+0x98>
    printf("%s: too much memory allocated!\n", s);
    211e:	85d2                	mv	a1,s4
    2120:	00004517          	auipc	a0,0x4
    2124:	e7850513          	addi	a0,a0,-392 # 5f98 <malloc+0xe08>
    2128:	7af020ef          	jal	ra,50d6 <printf>
    exit(1);
    212c:	4505                	li	a0,1
    212e:	37b020ef          	jal	ra,4ca8 <exit>
    a = b + 1;
    2132:	84be                	mv	s1,a5
    b = sbrk(1);
    2134:	4505                	li	a0,1
    2136:	3fb020ef          	jal	ra,4d30 <sbrk>
    if(b != a){
    213a:	04951263          	bne	a0,s1,217e <sbrkbasic+0xe2>
    *b = 1;
    213e:	4785                	li	a5,1
    2140:	00f48023          	sb	a5,0(s1)
    a = b + 1;
    2144:	00148793          	addi	a5,s1,1
  for(i = 0; i < 5000; i++){
    2148:	2905                	addiw	s2,s2,1
    214a:	ff3914e3          	bne	s2,s3,2132 <sbrkbasic+0x96>
  pid = fork();
    214e:	353020ef          	jal	ra,4ca0 <fork>
    2152:	892a                	mv	s2,a0
  if(pid < 0){
    2154:	04054263          	bltz	a0,2198 <sbrkbasic+0xfc>
  c = sbrk(1);
    2158:	4505                	li	a0,1
    215a:	3d7020ef          	jal	ra,4d30 <sbrk>
  c = sbrk(1);
    215e:	4505                	li	a0,1
    2160:	3d1020ef          	jal	ra,4d30 <sbrk>
  if(c != a + 1){
    2164:	0489                	addi	s1,s1,2
    2166:	04a48363          	beq	s1,a0,21ac <sbrkbasic+0x110>
    printf("%s: sbrk test failed post-fork\n", s);
    216a:	85d2                	mv	a1,s4
    216c:	00004517          	auipc	a0,0x4
    2170:	e8c50513          	addi	a0,a0,-372 # 5ff8 <malloc+0xe68>
    2174:	763020ef          	jal	ra,50d6 <printf>
    exit(1);
    2178:	4505                	li	a0,1
    217a:	32f020ef          	jal	ra,4ca8 <exit>
      printf("%s: sbrk test failed %d %p %p\n", s, i, a, b);
    217e:	872a                	mv	a4,a0
    2180:	86a6                	mv	a3,s1
    2182:	864a                	mv	a2,s2
    2184:	85d2                	mv	a1,s4
    2186:	00004517          	auipc	a0,0x4
    218a:	e3250513          	addi	a0,a0,-462 # 5fb8 <malloc+0xe28>
    218e:	749020ef          	jal	ra,50d6 <printf>
      exit(1);
    2192:	4505                	li	a0,1
    2194:	315020ef          	jal	ra,4ca8 <exit>
    printf("%s: sbrk test fork failed\n", s);
    2198:	85d2                	mv	a1,s4
    219a:	00004517          	auipc	a0,0x4
    219e:	e3e50513          	addi	a0,a0,-450 # 5fd8 <malloc+0xe48>
    21a2:	735020ef          	jal	ra,50d6 <printf>
    exit(1);
    21a6:	4505                	li	a0,1
    21a8:	301020ef          	jal	ra,4ca8 <exit>
  if(pid == 0)
    21ac:	00091563          	bnez	s2,21b6 <sbrkbasic+0x11a>
    exit(0);
    21b0:	4501                	li	a0,0
    21b2:	2f7020ef          	jal	ra,4ca8 <exit>
  wait(&xstatus);
    21b6:	fcc40513          	addi	a0,s0,-52
    21ba:	2f7020ef          	jal	ra,4cb0 <wait>
  exit(xstatus);
    21be:	fcc42503          	lw	a0,-52(s0)
    21c2:	2e7020ef          	jal	ra,4ca8 <exit>

00000000000021c6 <sbrkmuch>:
{
    21c6:	7179                	addi	sp,sp,-48
    21c8:	f406                	sd	ra,40(sp)
    21ca:	f022                	sd	s0,32(sp)
    21cc:	ec26                	sd	s1,24(sp)
    21ce:	e84a                	sd	s2,16(sp)
    21d0:	e44e                	sd	s3,8(sp)
    21d2:	e052                	sd	s4,0(sp)
    21d4:	1800                	addi	s0,sp,48
    21d6:	89aa                	mv	s3,a0
  oldbrk = sbrk(0);
    21d8:	4501                	li	a0,0
    21da:	357020ef          	jal	ra,4d30 <sbrk>
    21de:	892a                	mv	s2,a0
  a = sbrk(0);
    21e0:	4501                	li	a0,0
    21e2:	34f020ef          	jal	ra,4d30 <sbrk>
    21e6:	84aa                	mv	s1,a0
  p = sbrk(amt);
    21e8:	06400537          	lui	a0,0x6400
    21ec:	9d05                	subw	a0,a0,s1
    21ee:	343020ef          	jal	ra,4d30 <sbrk>
  if (p != a) {
    21f2:	0aa49463          	bne	s1,a0,229a <sbrkmuch+0xd4>
  char *eee = sbrk(0);
    21f6:	4501                	li	a0,0
    21f8:	339020ef          	jal	ra,4d30 <sbrk>
    21fc:	87aa                	mv	a5,a0
  for(char *pp = a; pp < eee; pp += 4096)
    21fe:	00a4f963          	bgeu	s1,a0,2210 <sbrkmuch+0x4a>
    *pp = 1;
    2202:	4685                	li	a3,1
  for(char *pp = a; pp < eee; pp += 4096)
    2204:	6705                	lui	a4,0x1
    *pp = 1;
    2206:	00d48023          	sb	a3,0(s1)
  for(char *pp = a; pp < eee; pp += 4096)
    220a:	94ba                	add	s1,s1,a4
    220c:	fef4ede3          	bltu	s1,a5,2206 <sbrkmuch+0x40>
  *lastaddr = 99;
    2210:	064007b7          	lui	a5,0x6400
    2214:	06300713          	li	a4,99
    2218:	fee78fa3          	sb	a4,-1(a5) # 63fffff <base+0x63f1357>
  a = sbrk(0);
    221c:	4501                	li	a0,0
    221e:	313020ef          	jal	ra,4d30 <sbrk>
    2222:	84aa                	mv	s1,a0
  c = sbrk(-PGSIZE);
    2224:	757d                	lui	a0,0xfffff
    2226:	30b020ef          	jal	ra,4d30 <sbrk>
  if(c == (char*)0xffffffffffffffffL){
    222a:	57fd                	li	a5,-1
    222c:	08f50163          	beq	a0,a5,22ae <sbrkmuch+0xe8>
  c = sbrk(0);
    2230:	4501                	li	a0,0
    2232:	2ff020ef          	jal	ra,4d30 <sbrk>
  if(c != a - PGSIZE){
    2236:	77fd                	lui	a5,0xfffff
    2238:	97a6                	add	a5,a5,s1
    223a:	08f51463          	bne	a0,a5,22c2 <sbrkmuch+0xfc>
  a = sbrk(0);
    223e:	4501                	li	a0,0
    2240:	2f1020ef          	jal	ra,4d30 <sbrk>
    2244:	84aa                	mv	s1,a0
  c = sbrk(PGSIZE);
    2246:	6505                	lui	a0,0x1
    2248:	2e9020ef          	jal	ra,4d30 <sbrk>
    224c:	8a2a                	mv	s4,a0
  if(c != a || sbrk(0) != a + PGSIZE){
    224e:	08a49663          	bne	s1,a0,22da <sbrkmuch+0x114>
    2252:	4501                	li	a0,0
    2254:	2dd020ef          	jal	ra,4d30 <sbrk>
    2258:	6785                	lui	a5,0x1
    225a:	97a6                	add	a5,a5,s1
    225c:	06f51f63          	bne	a0,a5,22da <sbrkmuch+0x114>
  if(*lastaddr == 99){
    2260:	064007b7          	lui	a5,0x6400
    2264:	fff7c703          	lbu	a4,-1(a5) # 63fffff <base+0x63f1357>
    2268:	06300793          	li	a5,99
    226c:	08f70363          	beq	a4,a5,22f2 <sbrkmuch+0x12c>
  a = sbrk(0);
    2270:	4501                	li	a0,0
    2272:	2bf020ef          	jal	ra,4d30 <sbrk>
    2276:	84aa                	mv	s1,a0
  c = sbrk(-(sbrk(0) - oldbrk));
    2278:	4501                	li	a0,0
    227a:	2b7020ef          	jal	ra,4d30 <sbrk>
    227e:	40a9053b          	subw	a0,s2,a0
    2282:	2af020ef          	jal	ra,4d30 <sbrk>
  if(c != a){
    2286:	08a49063          	bne	s1,a0,2306 <sbrkmuch+0x140>
}
    228a:	70a2                	ld	ra,40(sp)
    228c:	7402                	ld	s0,32(sp)
    228e:	64e2                	ld	s1,24(sp)
    2290:	6942                	ld	s2,16(sp)
    2292:	69a2                	ld	s3,8(sp)
    2294:	6a02                	ld	s4,0(sp)
    2296:	6145                	addi	sp,sp,48
    2298:	8082                	ret
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n", s);
    229a:	85ce                	mv	a1,s3
    229c:	00004517          	auipc	a0,0x4
    22a0:	d7c50513          	addi	a0,a0,-644 # 6018 <malloc+0xe88>
    22a4:	633020ef          	jal	ra,50d6 <printf>
    exit(1);
    22a8:	4505                	li	a0,1
    22aa:	1ff020ef          	jal	ra,4ca8 <exit>
    printf("%s: sbrk could not deallocate\n", s);
    22ae:	85ce                	mv	a1,s3
    22b0:	00004517          	auipc	a0,0x4
    22b4:	db050513          	addi	a0,a0,-592 # 6060 <malloc+0xed0>
    22b8:	61f020ef          	jal	ra,50d6 <printf>
    exit(1);
    22bc:	4505                	li	a0,1
    22be:	1eb020ef          	jal	ra,4ca8 <exit>
    printf("%s: sbrk deallocation produced wrong address, a %p c %p\n", s, a, c);
    22c2:	86aa                	mv	a3,a0
    22c4:	8626                	mv	a2,s1
    22c6:	85ce                	mv	a1,s3
    22c8:	00004517          	auipc	a0,0x4
    22cc:	db850513          	addi	a0,a0,-584 # 6080 <malloc+0xef0>
    22d0:	607020ef          	jal	ra,50d6 <printf>
    exit(1);
    22d4:	4505                	li	a0,1
    22d6:	1d3020ef          	jal	ra,4ca8 <exit>
    printf("%s: sbrk re-allocation failed, a %p c %p\n", s, a, c);
    22da:	86d2                	mv	a3,s4
    22dc:	8626                	mv	a2,s1
    22de:	85ce                	mv	a1,s3
    22e0:	00004517          	auipc	a0,0x4
    22e4:	de050513          	addi	a0,a0,-544 # 60c0 <malloc+0xf30>
    22e8:	5ef020ef          	jal	ra,50d6 <printf>
    exit(1);
    22ec:	4505                	li	a0,1
    22ee:	1bb020ef          	jal	ra,4ca8 <exit>
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    22f2:	85ce                	mv	a1,s3
    22f4:	00004517          	auipc	a0,0x4
    22f8:	dfc50513          	addi	a0,a0,-516 # 60f0 <malloc+0xf60>
    22fc:	5db020ef          	jal	ra,50d6 <printf>
    exit(1);
    2300:	4505                	li	a0,1
    2302:	1a7020ef          	jal	ra,4ca8 <exit>
    printf("%s: sbrk downsize failed, a %p c %p\n", s, a, c);
    2306:	86aa                	mv	a3,a0
    2308:	8626                	mv	a2,s1
    230a:	85ce                	mv	a1,s3
    230c:	00004517          	auipc	a0,0x4
    2310:	e1c50513          	addi	a0,a0,-484 # 6128 <malloc+0xf98>
    2314:	5c3020ef          	jal	ra,50d6 <printf>
    exit(1);
    2318:	4505                	li	a0,1
    231a:	18f020ef          	jal	ra,4ca8 <exit>

000000000000231e <sbrkarg>:
{
    231e:	7179                	addi	sp,sp,-48
    2320:	f406                	sd	ra,40(sp)
    2322:	f022                	sd	s0,32(sp)
    2324:	ec26                	sd	s1,24(sp)
    2326:	e84a                	sd	s2,16(sp)
    2328:	e44e                	sd	s3,8(sp)
    232a:	1800                	addi	s0,sp,48
    232c:	89aa                	mv	s3,a0
  a = sbrk(PGSIZE);
    232e:	6505                	lui	a0,0x1
    2330:	201020ef          	jal	ra,4d30 <sbrk>
    2334:	892a                	mv	s2,a0
  fd = open("sbrk", O_CREATE|O_WRONLY);
    2336:	20100593          	li	a1,513
    233a:	00004517          	auipc	a0,0x4
    233e:	e1650513          	addi	a0,a0,-490 # 6150 <malloc+0xfc0>
    2342:	1a7020ef          	jal	ra,4ce8 <open>
    2346:	84aa                	mv	s1,a0
  unlink("sbrk");
    2348:	00004517          	auipc	a0,0x4
    234c:	e0850513          	addi	a0,a0,-504 # 6150 <malloc+0xfc0>
    2350:	1a9020ef          	jal	ra,4cf8 <unlink>
  if(fd < 0)  {
    2354:	0204c963          	bltz	s1,2386 <sbrkarg+0x68>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    2358:	6605                	lui	a2,0x1
    235a:	85ca                	mv	a1,s2
    235c:	8526                	mv	a0,s1
    235e:	16b020ef          	jal	ra,4cc8 <write>
    2362:	02054c63          	bltz	a0,239a <sbrkarg+0x7c>
  close(fd);
    2366:	8526                	mv	a0,s1
    2368:	169020ef          	jal	ra,4cd0 <close>
  a = sbrk(PGSIZE);
    236c:	6505                	lui	a0,0x1
    236e:	1c3020ef          	jal	ra,4d30 <sbrk>
  if(pipe((int *) a) != 0){
    2372:	147020ef          	jal	ra,4cb8 <pipe>
    2376:	ed05                	bnez	a0,23ae <sbrkarg+0x90>
}
    2378:	70a2                	ld	ra,40(sp)
    237a:	7402                	ld	s0,32(sp)
    237c:	64e2                	ld	s1,24(sp)
    237e:	6942                	ld	s2,16(sp)
    2380:	69a2                	ld	s3,8(sp)
    2382:	6145                	addi	sp,sp,48
    2384:	8082                	ret
    printf("%s: open sbrk failed\n", s);
    2386:	85ce                	mv	a1,s3
    2388:	00004517          	auipc	a0,0x4
    238c:	dd050513          	addi	a0,a0,-560 # 6158 <malloc+0xfc8>
    2390:	547020ef          	jal	ra,50d6 <printf>
    exit(1);
    2394:	4505                	li	a0,1
    2396:	113020ef          	jal	ra,4ca8 <exit>
    printf("%s: write sbrk failed\n", s);
    239a:	85ce                	mv	a1,s3
    239c:	00004517          	auipc	a0,0x4
    23a0:	dd450513          	addi	a0,a0,-556 # 6170 <malloc+0xfe0>
    23a4:	533020ef          	jal	ra,50d6 <printf>
    exit(1);
    23a8:	4505                	li	a0,1
    23aa:	0ff020ef          	jal	ra,4ca8 <exit>
    printf("%s: pipe() failed\n", s);
    23ae:	85ce                	mv	a1,s3
    23b0:	00004517          	auipc	a0,0x4
    23b4:	8b050513          	addi	a0,a0,-1872 # 5c60 <malloc+0xad0>
    23b8:	51f020ef          	jal	ra,50d6 <printf>
    exit(1);
    23bc:	4505                	li	a0,1
    23be:	0eb020ef          	jal	ra,4ca8 <exit>

00000000000023c2 <argptest>:
{
    23c2:	1101                	addi	sp,sp,-32
    23c4:	ec06                	sd	ra,24(sp)
    23c6:	e822                	sd	s0,16(sp)
    23c8:	e426                	sd	s1,8(sp)
    23ca:	e04a                	sd	s2,0(sp)
    23cc:	1000                	addi	s0,sp,32
    23ce:	892a                	mv	s2,a0
  fd = open("init", O_RDONLY);
    23d0:	4581                	li	a1,0
    23d2:	00004517          	auipc	a0,0x4
    23d6:	db650513          	addi	a0,a0,-586 # 6188 <malloc+0xff8>
    23da:	10f020ef          	jal	ra,4ce8 <open>
  if (fd < 0) {
    23de:	02054563          	bltz	a0,2408 <argptest+0x46>
    23e2:	84aa                	mv	s1,a0
  read(fd, sbrk(0) - 1, -1);
    23e4:	4501                	li	a0,0
    23e6:	14b020ef          	jal	ra,4d30 <sbrk>
    23ea:	567d                	li	a2,-1
    23ec:	fff50593          	addi	a1,a0,-1
    23f0:	8526                	mv	a0,s1
    23f2:	0cf020ef          	jal	ra,4cc0 <read>
  close(fd);
    23f6:	8526                	mv	a0,s1
    23f8:	0d9020ef          	jal	ra,4cd0 <close>
}
    23fc:	60e2                	ld	ra,24(sp)
    23fe:	6442                	ld	s0,16(sp)
    2400:	64a2                	ld	s1,8(sp)
    2402:	6902                	ld	s2,0(sp)
    2404:	6105                	addi	sp,sp,32
    2406:	8082                	ret
    printf("%s: open failed\n", s);
    2408:	85ca                	mv	a1,s2
    240a:	00003517          	auipc	a0,0x3
    240e:	76650513          	addi	a0,a0,1894 # 5b70 <malloc+0x9e0>
    2412:	4c5020ef          	jal	ra,50d6 <printf>
    exit(1);
    2416:	4505                	li	a0,1
    2418:	091020ef          	jal	ra,4ca8 <exit>

000000000000241c <sbrkbugs>:
{
    241c:	1141                	addi	sp,sp,-16
    241e:	e406                	sd	ra,8(sp)
    2420:	e022                	sd	s0,0(sp)
    2422:	0800                	addi	s0,sp,16
  int pid = fork();
    2424:	07d020ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    2428:	00054c63          	bltz	a0,2440 <sbrkbugs+0x24>
  if(pid == 0){
    242c:	e11d                	bnez	a0,2452 <sbrkbugs+0x36>
    int sz = (uint64) sbrk(0);
    242e:	103020ef          	jal	ra,4d30 <sbrk>
    sbrk(-sz);
    2432:	40a0053b          	negw	a0,a0
    2436:	0fb020ef          	jal	ra,4d30 <sbrk>
    exit(0);
    243a:	4501                	li	a0,0
    243c:	06d020ef          	jal	ra,4ca8 <exit>
    printf("fork failed\n");
    2440:	00005517          	auipc	a0,0x5
    2444:	d4850513          	addi	a0,a0,-696 # 7188 <malloc+0x1ff8>
    2448:	48f020ef          	jal	ra,50d6 <printf>
    exit(1);
    244c:	4505                	li	a0,1
    244e:	05b020ef          	jal	ra,4ca8 <exit>
  wait(0);
    2452:	4501                	li	a0,0
    2454:	05d020ef          	jal	ra,4cb0 <wait>
  pid = fork();
    2458:	049020ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    245c:	00054f63          	bltz	a0,247a <sbrkbugs+0x5e>
  if(pid == 0){
    2460:	e515                	bnez	a0,248c <sbrkbugs+0x70>
    int sz = (uint64) sbrk(0);
    2462:	0cf020ef          	jal	ra,4d30 <sbrk>
    sbrk(-(sz - 3500));
    2466:	6785                	lui	a5,0x1
    2468:	dac7879b          	addiw	a5,a5,-596
    246c:	40a7853b          	subw	a0,a5,a0
    2470:	0c1020ef          	jal	ra,4d30 <sbrk>
    exit(0);
    2474:	4501                	li	a0,0
    2476:	033020ef          	jal	ra,4ca8 <exit>
    printf("fork failed\n");
    247a:	00005517          	auipc	a0,0x5
    247e:	d0e50513          	addi	a0,a0,-754 # 7188 <malloc+0x1ff8>
    2482:	455020ef          	jal	ra,50d6 <printf>
    exit(1);
    2486:	4505                	li	a0,1
    2488:	021020ef          	jal	ra,4ca8 <exit>
  wait(0);
    248c:	4501                	li	a0,0
    248e:	023020ef          	jal	ra,4cb0 <wait>
  pid = fork();
    2492:	00f020ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    2496:	02054263          	bltz	a0,24ba <sbrkbugs+0x9e>
  if(pid == 0){
    249a:	e90d                	bnez	a0,24cc <sbrkbugs+0xb0>
    sbrk((10*4096 + 2048) - (uint64)sbrk(0));
    249c:	095020ef          	jal	ra,4d30 <sbrk>
    24a0:	67ad                	lui	a5,0xb
    24a2:	8007879b          	addiw	a5,a5,-2048
    24a6:	40a7853b          	subw	a0,a5,a0
    24aa:	087020ef          	jal	ra,4d30 <sbrk>
    sbrk(-10);
    24ae:	5559                	li	a0,-10
    24b0:	081020ef          	jal	ra,4d30 <sbrk>
    exit(0);
    24b4:	4501                	li	a0,0
    24b6:	7f2020ef          	jal	ra,4ca8 <exit>
    printf("fork failed\n");
    24ba:	00005517          	auipc	a0,0x5
    24be:	cce50513          	addi	a0,a0,-818 # 7188 <malloc+0x1ff8>
    24c2:	415020ef          	jal	ra,50d6 <printf>
    exit(1);
    24c6:	4505                	li	a0,1
    24c8:	7e0020ef          	jal	ra,4ca8 <exit>
  wait(0);
    24cc:	4501                	li	a0,0
    24ce:	7e2020ef          	jal	ra,4cb0 <wait>
  exit(0);
    24d2:	4501                	li	a0,0
    24d4:	7d4020ef          	jal	ra,4ca8 <exit>

00000000000024d8 <sbrklast>:
{
    24d8:	7179                	addi	sp,sp,-48
    24da:	f406                	sd	ra,40(sp)
    24dc:	f022                	sd	s0,32(sp)
    24de:	ec26                	sd	s1,24(sp)
    24e0:	e84a                	sd	s2,16(sp)
    24e2:	e44e                	sd	s3,8(sp)
    24e4:	e052                	sd	s4,0(sp)
    24e6:	1800                	addi	s0,sp,48
  uint64 top = (uint64) sbrk(0);
    24e8:	4501                	li	a0,0
    24ea:	047020ef          	jal	ra,4d30 <sbrk>
  if((top % 4096) != 0)
    24ee:	03451793          	slli	a5,a0,0x34
    24f2:	ebad                	bnez	a5,2564 <sbrklast+0x8c>
  sbrk(4096);
    24f4:	6505                	lui	a0,0x1
    24f6:	03b020ef          	jal	ra,4d30 <sbrk>
  sbrk(10);
    24fa:	4529                	li	a0,10
    24fc:	035020ef          	jal	ra,4d30 <sbrk>
  sbrk(-20);
    2500:	5531                	li	a0,-20
    2502:	02f020ef          	jal	ra,4d30 <sbrk>
  top = (uint64) sbrk(0);
    2506:	4501                	li	a0,0
    2508:	029020ef          	jal	ra,4d30 <sbrk>
    250c:	84aa                	mv	s1,a0
  char *p = (char *) (top - 64);
    250e:	fc050913          	addi	s2,a0,-64 # fc0 <bigdir+0x120>
  p[0] = 'x';
    2512:	07800a13          	li	s4,120
    2516:	fd450023          	sb	s4,-64(a0)
  p[1] = '\0';
    251a:	fc0500a3          	sb	zero,-63(a0)
  int fd = open(p, O_RDWR|O_CREATE);
    251e:	20200593          	li	a1,514
    2522:	854a                	mv	a0,s2
    2524:	7c4020ef          	jal	ra,4ce8 <open>
    2528:	89aa                	mv	s3,a0
  write(fd, p, 1);
    252a:	4605                	li	a2,1
    252c:	85ca                	mv	a1,s2
    252e:	79a020ef          	jal	ra,4cc8 <write>
  close(fd);
    2532:	854e                	mv	a0,s3
    2534:	79c020ef          	jal	ra,4cd0 <close>
  fd = open(p, O_RDWR);
    2538:	4589                	li	a1,2
    253a:	854a                	mv	a0,s2
    253c:	7ac020ef          	jal	ra,4ce8 <open>
  p[0] = '\0';
    2540:	fc048023          	sb	zero,-64(s1)
  read(fd, p, 1);
    2544:	4605                	li	a2,1
    2546:	85ca                	mv	a1,s2
    2548:	778020ef          	jal	ra,4cc0 <read>
  if(p[0] != 'x')
    254c:	fc04c783          	lbu	a5,-64(s1)
    2550:	03479263          	bne	a5,s4,2574 <sbrklast+0x9c>
}
    2554:	70a2                	ld	ra,40(sp)
    2556:	7402                	ld	s0,32(sp)
    2558:	64e2                	ld	s1,24(sp)
    255a:	6942                	ld	s2,16(sp)
    255c:	69a2                	ld	s3,8(sp)
    255e:	6a02                	ld	s4,0(sp)
    2560:	6145                	addi	sp,sp,48
    2562:	8082                	ret
    sbrk(4096 - (top % 4096));
    2564:	0347d513          	srli	a0,a5,0x34
    2568:	6785                	lui	a5,0x1
    256a:	40a7853b          	subw	a0,a5,a0
    256e:	7c2020ef          	jal	ra,4d30 <sbrk>
    2572:	b749                	j	24f4 <sbrklast+0x1c>
    exit(1);
    2574:	4505                	li	a0,1
    2576:	732020ef          	jal	ra,4ca8 <exit>

000000000000257a <sbrk8000>:
{
    257a:	1141                	addi	sp,sp,-16
    257c:	e406                	sd	ra,8(sp)
    257e:	e022                	sd	s0,0(sp)
    2580:	0800                	addi	s0,sp,16
  sbrk(0x80000004);
    2582:	80000537          	lui	a0,0x80000
    2586:	0511                	addi	a0,a0,4
    2588:	7a8020ef          	jal	ra,4d30 <sbrk>
  volatile char *top = sbrk(0);
    258c:	4501                	li	a0,0
    258e:	7a2020ef          	jal	ra,4d30 <sbrk>
  *(top-1) = *(top-1) + 1;
    2592:	fff54783          	lbu	a5,-1(a0) # ffffffff7fffffff <base+0xffffffff7fff1357>
    2596:	0785                	addi	a5,a5,1
    2598:	0ff7f793          	zext.b	a5,a5
    259c:	fef50fa3          	sb	a5,-1(a0)
}
    25a0:	60a2                	ld	ra,8(sp)
    25a2:	6402                	ld	s0,0(sp)
    25a4:	0141                	addi	sp,sp,16
    25a6:	8082                	ret

00000000000025a8 <sparse_memory>:
{
    25a8:	1141                	addi	sp,sp,-16
    25aa:	e406                	sd	ra,8(sp)
    25ac:	e022                	sd	s0,0(sp)
    25ae:	0800                	addi	s0,sp,16
  prev_end = sbrk(REGION_SZ);
    25b0:	40000537          	lui	a0,0x40000
    25b4:	77c020ef          	jal	ra,4d30 <sbrk>
  if (prev_end == (char*)0xffffffffffffffffL) {
    25b8:	57fd                	li	a5,-1
    25ba:	02f50963          	beq	a0,a5,25ec <sparse_memory+0x44>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    25be:	6605                	lui	a2,0x1
    25c0:	962a                	add	a2,a2,a0
    25c2:	40001737          	lui	a4,0x40001
    25c6:	972a                	add	a4,a4,a0
    25c8:	87b2                	mv	a5,a2
    25ca:	000406b7          	lui	a3,0x40
    *(char **)i = i;
    25ce:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    25d0:	97b6                	add	a5,a5,a3
    25d2:	fee79ee3          	bne	a5,a4,25ce <sparse_memory+0x26>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    25d6:	000406b7          	lui	a3,0x40
    if (*(char **)i != i) {
    25da:	621c                	ld	a5,0(a2)
    25dc:	02c79163          	bne	a5,a2,25fe <sparse_memory+0x56>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    25e0:	9636                	add	a2,a2,a3
    25e2:	fee61ce3          	bne	a2,a4,25da <sparse_memory+0x32>
  exit(0);
    25e6:	4501                	li	a0,0
    25e8:	6c0020ef          	jal	ra,4ca8 <exit>
    printf("sbrk() failed\n");
    25ec:	00004517          	auipc	a0,0x4
    25f0:	ba450513          	addi	a0,a0,-1116 # 6190 <malloc+0x1000>
    25f4:	2e3020ef          	jal	ra,50d6 <printf>
    exit(1);
    25f8:	4505                	li	a0,1
    25fa:	6ae020ef          	jal	ra,4ca8 <exit>
      printf("failed to read value from memory\n");
    25fe:	00004517          	auipc	a0,0x4
    2602:	ba250513          	addi	a0,a0,-1118 # 61a0 <malloc+0x1010>
    2606:	2d1020ef          	jal	ra,50d6 <printf>
      exit(1);
    260a:	4505                	li	a0,1
    260c:	69c020ef          	jal	ra,4ca8 <exit>

0000000000002610 <sparse_memory_unmap>:
{
    2610:	7139                	addi	sp,sp,-64
    2612:	fc06                	sd	ra,56(sp)
    2614:	f822                	sd	s0,48(sp)
    2616:	f426                	sd	s1,40(sp)
    2618:	f04a                	sd	s2,32(sp)
    261a:	ec4e                	sd	s3,24(sp)
    261c:	0080                	addi	s0,sp,64
  prev_end = sbrk(REGION_SZ);
    261e:	40000537          	lui	a0,0x40000
    2622:	70e020ef          	jal	ra,4d30 <sbrk>
  if (prev_end == (char*)0xffffffffffffffffL) {
    2626:	57fd                	li	a5,-1
    2628:	04f50263          	beq	a0,a5,266c <sparse_memory_unmap+0x5c>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    262c:	6905                	lui	s2,0x1
    262e:	992a                	add	s2,s2,a0
    2630:	400014b7          	lui	s1,0x40001
    2634:	94aa                	add	s1,s1,a0
    2636:	87ca                	mv	a5,s2
    2638:	01000737          	lui	a4,0x1000
    *(char **)i = i;
    263c:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    263e:	97ba                	add	a5,a5,a4
    2640:	fef49ee3          	bne	s1,a5,263c <sparse_memory_unmap+0x2c>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    2644:	010009b7          	lui	s3,0x1000
    pid = fork();
    2648:	658020ef          	jal	ra,4ca0 <fork>
    if (pid < 0) {
    264c:	02054963          	bltz	a0,267e <sparse_memory_unmap+0x6e>
    } else if (pid == 0) {
    2650:	c121                	beqz	a0,2690 <sparse_memory_unmap+0x80>
      wait(&status);
    2652:	fcc40513          	addi	a0,s0,-52
    2656:	65a020ef          	jal	ra,4cb0 <wait>
      if (status == 0) {
    265a:	fcc42783          	lw	a5,-52(s0)
    265e:	c3b1                	beqz	a5,26a2 <sparse_memory_unmap+0x92>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    2660:	994e                	add	s2,s2,s3
    2662:	ff2493e3          	bne	s1,s2,2648 <sparse_memory_unmap+0x38>
  exit(0);
    2666:	4501                	li	a0,0
    2668:	640020ef          	jal	ra,4ca8 <exit>
    printf("sbrk() failed\n");
    266c:	00004517          	auipc	a0,0x4
    2670:	b2450513          	addi	a0,a0,-1244 # 6190 <malloc+0x1000>
    2674:	263020ef          	jal	ra,50d6 <printf>
    exit(1);
    2678:	4505                	li	a0,1
    267a:	62e020ef          	jal	ra,4ca8 <exit>
      printf("error forking\n");
    267e:	00004517          	auipc	a0,0x4
    2682:	b4a50513          	addi	a0,a0,-1206 # 61c8 <malloc+0x1038>
    2686:	251020ef          	jal	ra,50d6 <printf>
      exit(1);
    268a:	4505                	li	a0,1
    268c:	61c020ef          	jal	ra,4ca8 <exit>
      sbrk(-1L * REGION_SZ);
    2690:	c0000537          	lui	a0,0xc0000
    2694:	69c020ef          	jal	ra,4d30 <sbrk>
      *(char **)i = i;
    2698:	01293023          	sd	s2,0(s2) # 1000 <pgbug+0x2a>
      exit(0);
    269c:	4501                	li	a0,0
    269e:	60a020ef          	jal	ra,4ca8 <exit>
        printf("memory not unmapped\n");
    26a2:	00004517          	auipc	a0,0x4
    26a6:	b3650513          	addi	a0,a0,-1226 # 61d8 <malloc+0x1048>
    26aa:	22d020ef          	jal	ra,50d6 <printf>
        exit(1);
    26ae:	4505                	li	a0,1
    26b0:	5f8020ef          	jal	ra,4ca8 <exit>

00000000000026b4 <more_sparse>:
{
    26b4:	7159                	addi	sp,sp,-112
    26b6:	f486                	sd	ra,104(sp)
    26b8:	f0a2                	sd	s0,96(sp)
    26ba:	eca6                	sd	s1,88(sp)
    26bc:	e8ca                	sd	s2,80(sp)
    26be:	e4ce                	sd	s3,72(sp)
    26c0:	e0d2                	sd	s4,64(sp)
    26c2:	fc56                	sd	s5,56(sp)
    26c4:	f85a                	sd	s6,48(sp)
    26c6:	1880                	addi	s0,sp,112
    char *p = sbrk(0);
    26c8:	4501                	li	a0,0
    26ca:	666020ef          	jal	ra,4d30 <sbrk>
    26ce:	84aa                	mv	s1,a0
    sbrk(4*4096);
    26d0:	6511                	lui	a0,0x4
    26d2:	65e020ef          	jal	ra,4d30 <sbrk>
    open(p + 8192, 0);
    26d6:	4581                	li	a1,0
    26d8:	6509                	lui	a0,0x2
    26da:	9526                	add	a0,a0,s1
    26dc:	60c020ef          	jal	ra,4ce8 <open>
    int xx = (int) (long) sbrk(0);
    26e0:	4501                	li	a0,0
    26e2:	64e020ef          	jal	ra,4d30 <sbrk>
    void *ret = sbrk(-(xx+1));
    26e6:	fff54513          	not	a0,a0
    26ea:	2501                	sext.w	a0,a0
    26ec:	644020ef          	jal	ra,4d30 <sbrk>
    if(ret != (void*)0xffffffffffffffff){
    26f0:	57fd                	li	a5,-1
    26f2:	00f50c63          	beq	a0,a5,270a <more_sparse+0x56>
    26f6:	85aa                	mv	a1,a0
      printf("sbrk(sbrk(0)+1) returned %p, not -1\n", ret);
    26f8:	00004517          	auipc	a0,0x4
    26fc:	af850513          	addi	a0,a0,-1288 # 61f0 <malloc+0x1060>
    2700:	1d7020ef          	jal	ra,50d6 <printf>
      exit(1);
    2704:	4505                	li	a0,1
    2706:	5a2020ef          	jal	ra,4ca8 <exit>
  unsigned long bad[] = {
    270a:	00005797          	auipc	a5,0x5
    270e:	01e78793          	addi	a5,a5,30 # 7728 <malloc+0x2598>
    2712:	7fa8                	ld	a0,120(a5)
    2714:	63cc                	ld	a1,128(a5)
    2716:	67d0                	ld	a2,136(a5)
    2718:	6bd4                	ld	a3,144(a5)
    271a:	6fd8                	ld	a4,152(a5)
    271c:	73dc                	ld	a5,160(a5)
    271e:	f8a43823          	sd	a0,-112(s0)
    2722:	f8b43c23          	sd	a1,-104(s0)
    2726:	fac43023          	sd	a2,-96(s0)
    272a:	fad43423          	sd	a3,-88(s0)
    272e:	fae43823          	sd	a4,-80(s0)
    2732:	faf43c23          	sd	a5,-72(s0)
  for(int i = 0; i < sizeof(bad)/sizeof(bad[0]); i++){
    2736:	f9040913          	addi	s2,s0,-112
    273a:	fc040b13          	addi	s6,s0,-64
    int fd = open("README", 0);
    273e:	00003a17          	auipc	s4,0x3
    2742:	d62a0a13          	addi	s4,s4,-670 # 54a0 <malloc+0x310>
    fd = open("junk", O_CREATE|O_RDWR|O_TRUNC);
    2746:	00003a97          	auipc	s5,0x3
    274a:	c6aa8a93          	addi	s5,s5,-918 # 53b0 <malloc+0x220>
    int fd = open("README", 0);
    274e:	4581                	li	a1,0
    2750:	8552                	mv	a0,s4
    2752:	596020ef          	jal	ra,4ce8 <open>
    2756:	84aa                	mv	s1,a0
    if(fd < 0) { printf("cannot open README\n"); exit(1); }
    2758:	04054663          	bltz	a0,27a4 <more_sparse+0xf0>
    if(read(fd, (char*)bad[i], 512) >= 0) { printf("read succeeded\n");  exit(1); }
    275c:	00093983          	ld	s3,0(s2)
    2760:	20000613          	li	a2,512
    2764:	85ce                	mv	a1,s3
    2766:	55a020ef          	jal	ra,4cc0 <read>
    276a:	04055663          	bgez	a0,27b6 <more_sparse+0x102>
    close(fd);
    276e:	8526                	mv	a0,s1
    2770:	560020ef          	jal	ra,4cd0 <close>
    fd = open("junk", O_CREATE|O_RDWR|O_TRUNC);
    2774:	60200593          	li	a1,1538
    2778:	8556                	mv	a0,s5
    277a:	56e020ef          	jal	ra,4ce8 <open>
    277e:	84aa                	mv	s1,a0
    if(fd < 0) { printf("cannot open junk\n"); exit(1); }
    2780:	04054463          	bltz	a0,27c8 <more_sparse+0x114>
    if(write(fd, (char*)bad[i], 512) >= 0) { printf("write succeeded\n"); exit(1); }
    2784:	20000613          	li	a2,512
    2788:	85ce                	mv	a1,s3
    278a:	53e020ef          	jal	ra,4cc8 <write>
    278e:	04055663          	bgez	a0,27da <more_sparse+0x126>
    close(fd);
    2792:	8526                	mv	a0,s1
    2794:	53c020ef          	jal	ra,4cd0 <close>
  for(int i = 0; i < sizeof(bad)/sizeof(bad[0]); i++){
    2798:	0921                	addi	s2,s2,8
    279a:	fb691ae3          	bne	s2,s6,274e <more_sparse+0x9a>
  exit(0);
    279e:	4501                	li	a0,0
    27a0:	508020ef          	jal	ra,4ca8 <exit>
    if(fd < 0) { printf("cannot open README\n"); exit(1); }
    27a4:	00004517          	auipc	a0,0x4
    27a8:	a7450513          	addi	a0,a0,-1420 # 6218 <malloc+0x1088>
    27ac:	12b020ef          	jal	ra,50d6 <printf>
    27b0:	4505                	li	a0,1
    27b2:	4f6020ef          	jal	ra,4ca8 <exit>
    if(read(fd, (char*)bad[i], 512) >= 0) { printf("read succeeded\n");  exit(1); }
    27b6:	00004517          	auipc	a0,0x4
    27ba:	a7a50513          	addi	a0,a0,-1414 # 6230 <malloc+0x10a0>
    27be:	119020ef          	jal	ra,50d6 <printf>
    27c2:	4505                	li	a0,1
    27c4:	4e4020ef          	jal	ra,4ca8 <exit>
    if(fd < 0) { printf("cannot open junk\n"); exit(1); }
    27c8:	00004517          	auipc	a0,0x4
    27cc:	a7850513          	addi	a0,a0,-1416 # 6240 <malloc+0x10b0>
    27d0:	107020ef          	jal	ra,50d6 <printf>
    27d4:	4505                	li	a0,1
    27d6:	4d2020ef          	jal	ra,4ca8 <exit>
    if(write(fd, (char*)bad[i], 512) >= 0) { printf("write succeeded\n"); exit(1); }
    27da:	00004517          	auipc	a0,0x4
    27de:	a7e50513          	addi	a0,a0,-1410 # 6258 <malloc+0x10c8>
    27e2:	0f5020ef          	jal	ra,50d6 <printf>
    27e6:	4505                	li	a0,1
    27e8:	4c0020ef          	jal	ra,4ca8 <exit>

00000000000027ec <execout>:
{
    27ec:	715d                	addi	sp,sp,-80
    27ee:	e486                	sd	ra,72(sp)
    27f0:	e0a2                	sd	s0,64(sp)
    27f2:	fc26                	sd	s1,56(sp)
    27f4:	f84a                	sd	s2,48(sp)
    27f6:	f44e                	sd	s3,40(sp)
    27f8:	f052                	sd	s4,32(sp)
    27fa:	0880                	addi	s0,sp,80
  for(int avail = 0; avail < 15; avail++){
    27fc:	4901                	li	s2,0
    27fe:	49bd                	li	s3,15
    int pid = fork();
    2800:	4a0020ef          	jal	ra,4ca0 <fork>
    2804:	84aa                	mv	s1,a0
    if(pid < 0){
    2806:	00054c63          	bltz	a0,281e <execout+0x32>
    } else if(pid == 0){
    280a:	c11d                	beqz	a0,2830 <execout+0x44>
      wait((int*)0);
    280c:	4501                	li	a0,0
    280e:	4a2020ef          	jal	ra,4cb0 <wait>
  for(int avail = 0; avail < 15; avail++){
    2812:	2905                	addiw	s2,s2,1
    2814:	ff3916e3          	bne	s2,s3,2800 <execout+0x14>
  exit(0);
    2818:	4501                	li	a0,0
    281a:	48e020ef          	jal	ra,4ca8 <exit>
      printf("fork failed\n");
    281e:	00005517          	auipc	a0,0x5
    2822:	96a50513          	addi	a0,a0,-1686 # 7188 <malloc+0x1ff8>
    2826:	0b1020ef          	jal	ra,50d6 <printf>
      exit(1);
    282a:	4505                	li	a0,1
    282c:	47c020ef          	jal	ra,4ca8 <exit>
        if(a == 0xffffffffffffffffLL)
    2830:	59fd                	li	s3,-1
        *(char*)(a + 4096 - 1) = 1;
    2832:	4a05                	li	s4,1
        uint64 a = (uint64) sbrk(4096);
    2834:	6505                	lui	a0,0x1
    2836:	4fa020ef          	jal	ra,4d30 <sbrk>
        if(a == 0xffffffffffffffffLL)
    283a:	01350763          	beq	a0,s3,2848 <execout+0x5c>
        *(char*)(a + 4096 - 1) = 1;
    283e:	6785                	lui	a5,0x1
    2840:	953e                	add	a0,a0,a5
    2842:	ff450fa3          	sb	s4,-1(a0) # fff <pgbug+0x29>
      while(1){
    2846:	b7fd                	j	2834 <execout+0x48>
      for(int i = 0; i < avail; i++)
    2848:	01205863          	blez	s2,2858 <execout+0x6c>
        sbrk(-4096);
    284c:	757d                	lui	a0,0xfffff
    284e:	4e2020ef          	jal	ra,4d30 <sbrk>
      for(int i = 0; i < avail; i++)
    2852:	2485                	addiw	s1,s1,1
    2854:	ff249ce3          	bne	s1,s2,284c <execout+0x60>
      close(1);
    2858:	4505                	li	a0,1
    285a:	476020ef          	jal	ra,4cd0 <close>
      char *args[] = { "echo", "x", 0 };
    285e:	00003517          	auipc	a0,0x3
    2862:	a6a50513          	addi	a0,a0,-1430 # 52c8 <malloc+0x138>
    2866:	faa43c23          	sd	a0,-72(s0)
    286a:	00003797          	auipc	a5,0x3
    286e:	ace78793          	addi	a5,a5,-1330 # 5338 <malloc+0x1a8>
    2872:	fcf43023          	sd	a5,-64(s0)
    2876:	fc043423          	sd	zero,-56(s0)
      exec("echo", args);
    287a:	fb840593          	addi	a1,s0,-72
    287e:	462020ef          	jal	ra,4ce0 <exec>
      exit(0);
    2882:	4501                	li	a0,0
    2884:	424020ef          	jal	ra,4ca8 <exit>

0000000000002888 <fourteen>:
{
    2888:	1101                	addi	sp,sp,-32
    288a:	ec06                	sd	ra,24(sp)
    288c:	e822                	sd	s0,16(sp)
    288e:	e426                	sd	s1,8(sp)
    2890:	1000                	addi	s0,sp,32
    2892:	84aa                	mv	s1,a0
  if(mkdir("12345678901234") != 0){
    2894:	00004517          	auipc	a0,0x4
    2898:	bac50513          	addi	a0,a0,-1108 # 6440 <malloc+0x12b0>
    289c:	474020ef          	jal	ra,4d10 <mkdir>
    28a0:	e555                	bnez	a0,294c <fourteen+0xc4>
  if(mkdir("12345678901234/123456789012345") != 0){
    28a2:	00004517          	auipc	a0,0x4
    28a6:	9f650513          	addi	a0,a0,-1546 # 6298 <malloc+0x1108>
    28aa:	466020ef          	jal	ra,4d10 <mkdir>
    28ae:	e94d                	bnez	a0,2960 <fourteen+0xd8>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    28b0:	20000593          	li	a1,512
    28b4:	00004517          	auipc	a0,0x4
    28b8:	a3c50513          	addi	a0,a0,-1476 # 62f0 <malloc+0x1160>
    28bc:	42c020ef          	jal	ra,4ce8 <open>
  if(fd < 0){
    28c0:	0a054a63          	bltz	a0,2974 <fourteen+0xec>
  close(fd);
    28c4:	40c020ef          	jal	ra,4cd0 <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    28c8:	4581                	li	a1,0
    28ca:	00004517          	auipc	a0,0x4
    28ce:	a9e50513          	addi	a0,a0,-1378 # 6368 <malloc+0x11d8>
    28d2:	416020ef          	jal	ra,4ce8 <open>
  if(fd < 0){
    28d6:	0a054963          	bltz	a0,2988 <fourteen+0x100>
  close(fd);
    28da:	3f6020ef          	jal	ra,4cd0 <close>
  if(mkdir("12345678901234/12345678901234") == 0){
    28de:	00004517          	auipc	a0,0x4
    28e2:	afa50513          	addi	a0,a0,-1286 # 63d8 <malloc+0x1248>
    28e6:	42a020ef          	jal	ra,4d10 <mkdir>
    28ea:	c94d                	beqz	a0,299c <fourteen+0x114>
  if(mkdir("123456789012345/12345678901234") == 0){
    28ec:	00004517          	auipc	a0,0x4
    28f0:	b4450513          	addi	a0,a0,-1212 # 6430 <malloc+0x12a0>
    28f4:	41c020ef          	jal	ra,4d10 <mkdir>
    28f8:	cd45                	beqz	a0,29b0 <fourteen+0x128>
  unlink("123456789012345/12345678901234");
    28fa:	00004517          	auipc	a0,0x4
    28fe:	b3650513          	addi	a0,a0,-1226 # 6430 <malloc+0x12a0>
    2902:	3f6020ef          	jal	ra,4cf8 <unlink>
  unlink("12345678901234/12345678901234");
    2906:	00004517          	auipc	a0,0x4
    290a:	ad250513          	addi	a0,a0,-1326 # 63d8 <malloc+0x1248>
    290e:	3ea020ef          	jal	ra,4cf8 <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    2912:	00004517          	auipc	a0,0x4
    2916:	a5650513          	addi	a0,a0,-1450 # 6368 <malloc+0x11d8>
    291a:	3de020ef          	jal	ra,4cf8 <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    291e:	00004517          	auipc	a0,0x4
    2922:	9d250513          	addi	a0,a0,-1582 # 62f0 <malloc+0x1160>
    2926:	3d2020ef          	jal	ra,4cf8 <unlink>
  unlink("12345678901234/123456789012345");
    292a:	00004517          	auipc	a0,0x4
    292e:	96e50513          	addi	a0,a0,-1682 # 6298 <malloc+0x1108>
    2932:	3c6020ef          	jal	ra,4cf8 <unlink>
  unlink("12345678901234");
    2936:	00004517          	auipc	a0,0x4
    293a:	b0a50513          	addi	a0,a0,-1270 # 6440 <malloc+0x12b0>
    293e:	3ba020ef          	jal	ra,4cf8 <unlink>
}
    2942:	60e2                	ld	ra,24(sp)
    2944:	6442                	ld	s0,16(sp)
    2946:	64a2                	ld	s1,8(sp)
    2948:	6105                	addi	sp,sp,32
    294a:	8082                	ret
    printf("%s: mkdir 12345678901234 failed\n", s);
    294c:	85a6                	mv	a1,s1
    294e:	00004517          	auipc	a0,0x4
    2952:	92250513          	addi	a0,a0,-1758 # 6270 <malloc+0x10e0>
    2956:	780020ef          	jal	ra,50d6 <printf>
    exit(1);
    295a:	4505                	li	a0,1
    295c:	34c020ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    2960:	85a6                	mv	a1,s1
    2962:	00004517          	auipc	a0,0x4
    2966:	95650513          	addi	a0,a0,-1706 # 62b8 <malloc+0x1128>
    296a:	76c020ef          	jal	ra,50d6 <printf>
    exit(1);
    296e:	4505                	li	a0,1
    2970:	338020ef          	jal	ra,4ca8 <exit>
    printf("%s: create 123456789012345/123456789012345/123456789012345 failed\n", s);
    2974:	85a6                	mv	a1,s1
    2976:	00004517          	auipc	a0,0x4
    297a:	9aa50513          	addi	a0,a0,-1622 # 6320 <malloc+0x1190>
    297e:	758020ef          	jal	ra,50d6 <printf>
    exit(1);
    2982:	4505                	li	a0,1
    2984:	324020ef          	jal	ra,4ca8 <exit>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    2988:	85a6                	mv	a1,s1
    298a:	00004517          	auipc	a0,0x4
    298e:	a0e50513          	addi	a0,a0,-1522 # 6398 <malloc+0x1208>
    2992:	744020ef          	jal	ra,50d6 <printf>
    exit(1);
    2996:	4505                	li	a0,1
    2998:	310020ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    299c:	85a6                	mv	a1,s1
    299e:	00004517          	auipc	a0,0x4
    29a2:	a5a50513          	addi	a0,a0,-1446 # 63f8 <malloc+0x1268>
    29a6:	730020ef          	jal	ra,50d6 <printf>
    exit(1);
    29aa:	4505                	li	a0,1
    29ac:	2fc020ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    29b0:	85a6                	mv	a1,s1
    29b2:	00004517          	auipc	a0,0x4
    29b6:	a9e50513          	addi	a0,a0,-1378 # 6450 <malloc+0x12c0>
    29ba:	71c020ef          	jal	ra,50d6 <printf>
    exit(1);
    29be:	4505                	li	a0,1
    29c0:	2e8020ef          	jal	ra,4ca8 <exit>

00000000000029c4 <diskfull>:
{
    29c4:	b8010113          	addi	sp,sp,-1152
    29c8:	46113c23          	sd	ra,1144(sp)
    29cc:	46813823          	sd	s0,1136(sp)
    29d0:	46913423          	sd	s1,1128(sp)
    29d4:	47213023          	sd	s2,1120(sp)
    29d8:	45313c23          	sd	s3,1112(sp)
    29dc:	45413823          	sd	s4,1104(sp)
    29e0:	45513423          	sd	s5,1096(sp)
    29e4:	45613023          	sd	s6,1088(sp)
    29e8:	43713c23          	sd	s7,1080(sp)
    29ec:	43813823          	sd	s8,1072(sp)
    29f0:	43913423          	sd	s9,1064(sp)
    29f4:	48010413          	addi	s0,sp,1152
    29f8:	8caa                	mv	s9,a0
  unlink("diskfulldir");
    29fa:	00004517          	auipc	a0,0x4
    29fe:	a8e50513          	addi	a0,a0,-1394 # 6488 <malloc+0x12f8>
    2a02:	2f6020ef          	jal	ra,4cf8 <unlink>
    2a06:	03000993          	li	s3,48
    name[0] = 'b';
    2a0a:	06200b13          	li	s6,98
    name[1] = 'i';
    2a0e:	06900a93          	li	s5,105
    name[2] = 'g';
    2a12:	06700a13          	li	s4,103
    2a16:	10c00b93          	li	s7,268
  for(fi = 0; done == 0 && '0' + fi < 0177; fi++){
    2a1a:	07f00c13          	li	s8,127
    2a1e:	aab9                	j	2b7c <diskfull+0x1b8>
      printf("%s: could not create file %s\n", s, name);
    2a20:	b8040613          	addi	a2,s0,-1152
    2a24:	85e6                	mv	a1,s9
    2a26:	00004517          	auipc	a0,0x4
    2a2a:	a7250513          	addi	a0,a0,-1422 # 6498 <malloc+0x1308>
    2a2e:	6a8020ef          	jal	ra,50d6 <printf>
      break;
    2a32:	a039                	j	2a40 <diskfull+0x7c>
        close(fd);
    2a34:	854a                	mv	a0,s2
    2a36:	29a020ef          	jal	ra,4cd0 <close>
    close(fd);
    2a3a:	854a                	mv	a0,s2
    2a3c:	294020ef          	jal	ra,4cd0 <close>
  for(int i = 0; i < nzz; i++){
    2a40:	4481                	li	s1,0
    name[0] = 'z';
    2a42:	07a00913          	li	s2,122
  for(int i = 0; i < nzz; i++){
    2a46:	08000993          	li	s3,128
    name[0] = 'z';
    2a4a:	bb240023          	sb	s2,-1120(s0)
    name[1] = 'z';
    2a4e:	bb2400a3          	sb	s2,-1119(s0)
    name[2] = '0' + (i / 32);
    2a52:	41f4d79b          	sraiw	a5,s1,0x1f
    2a56:	01b7d71b          	srliw	a4,a5,0x1b
    2a5a:	009707bb          	addw	a5,a4,s1
    2a5e:	4057d69b          	sraiw	a3,a5,0x5
    2a62:	0306869b          	addiw	a3,a3,48
    2a66:	bad40123          	sb	a3,-1118(s0)
    name[3] = '0' + (i % 32);
    2a6a:	8bfd                	andi	a5,a5,31
    2a6c:	9f99                	subw	a5,a5,a4
    2a6e:	0307879b          	addiw	a5,a5,48
    2a72:	baf401a3          	sb	a5,-1117(s0)
    name[4] = '\0';
    2a76:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    2a7a:	ba040513          	addi	a0,s0,-1120
    2a7e:	27a020ef          	jal	ra,4cf8 <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    2a82:	60200593          	li	a1,1538
    2a86:	ba040513          	addi	a0,s0,-1120
    2a8a:	25e020ef          	jal	ra,4ce8 <open>
    if(fd < 0)
    2a8e:	00054763          	bltz	a0,2a9c <diskfull+0xd8>
    close(fd);
    2a92:	23e020ef          	jal	ra,4cd0 <close>
  for(int i = 0; i < nzz; i++){
    2a96:	2485                	addiw	s1,s1,1
    2a98:	fb3499e3          	bne	s1,s3,2a4a <diskfull+0x86>
  if(mkdir("diskfulldir") == 0)
    2a9c:	00004517          	auipc	a0,0x4
    2aa0:	9ec50513          	addi	a0,a0,-1556 # 6488 <malloc+0x12f8>
    2aa4:	26c020ef          	jal	ra,4d10 <mkdir>
    2aa8:	12050063          	beqz	a0,2bc8 <diskfull+0x204>
  unlink("diskfulldir");
    2aac:	00004517          	auipc	a0,0x4
    2ab0:	9dc50513          	addi	a0,a0,-1572 # 6488 <malloc+0x12f8>
    2ab4:	244020ef          	jal	ra,4cf8 <unlink>
  for(int i = 0; i < nzz; i++){
    2ab8:	4481                	li	s1,0
    name[0] = 'z';
    2aba:	07a00913          	li	s2,122
  for(int i = 0; i < nzz; i++){
    2abe:	08000993          	li	s3,128
    name[0] = 'z';
    2ac2:	bb240023          	sb	s2,-1120(s0)
    name[1] = 'z';
    2ac6:	bb2400a3          	sb	s2,-1119(s0)
    name[2] = '0' + (i / 32);
    2aca:	41f4d79b          	sraiw	a5,s1,0x1f
    2ace:	01b7d71b          	srliw	a4,a5,0x1b
    2ad2:	009707bb          	addw	a5,a4,s1
    2ad6:	4057d69b          	sraiw	a3,a5,0x5
    2ada:	0306869b          	addiw	a3,a3,48
    2ade:	bad40123          	sb	a3,-1118(s0)
    name[3] = '0' + (i % 32);
    2ae2:	8bfd                	andi	a5,a5,31
    2ae4:	9f99                	subw	a5,a5,a4
    2ae6:	0307879b          	addiw	a5,a5,48
    2aea:	baf401a3          	sb	a5,-1117(s0)
    name[4] = '\0';
    2aee:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    2af2:	ba040513          	addi	a0,s0,-1120
    2af6:	202020ef          	jal	ra,4cf8 <unlink>
  for(int i = 0; i < nzz; i++){
    2afa:	2485                	addiw	s1,s1,1
    2afc:	fd3493e3          	bne	s1,s3,2ac2 <diskfull+0xfe>
    2b00:	03000493          	li	s1,48
    name[0] = 'b';
    2b04:	06200a93          	li	s5,98
    name[1] = 'i';
    2b08:	06900a13          	li	s4,105
    name[2] = 'g';
    2b0c:	06700993          	li	s3,103
  for(int i = 0; '0' + i < 0177; i++){
    2b10:	07f00913          	li	s2,127
    name[0] = 'b';
    2b14:	bb540023          	sb	s5,-1120(s0)
    name[1] = 'i';
    2b18:	bb4400a3          	sb	s4,-1119(s0)
    name[2] = 'g';
    2b1c:	bb340123          	sb	s3,-1118(s0)
    name[3] = '0' + i;
    2b20:	ba9401a3          	sb	s1,-1117(s0)
    name[4] = '\0';
    2b24:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    2b28:	ba040513          	addi	a0,s0,-1120
    2b2c:	1cc020ef          	jal	ra,4cf8 <unlink>
  for(int i = 0; '0' + i < 0177; i++){
    2b30:	2485                	addiw	s1,s1,1
    2b32:	0ff4f493          	zext.b	s1,s1
    2b36:	fd249fe3          	bne	s1,s2,2b14 <diskfull+0x150>
}
    2b3a:	47813083          	ld	ra,1144(sp)
    2b3e:	47013403          	ld	s0,1136(sp)
    2b42:	46813483          	ld	s1,1128(sp)
    2b46:	46013903          	ld	s2,1120(sp)
    2b4a:	45813983          	ld	s3,1112(sp)
    2b4e:	45013a03          	ld	s4,1104(sp)
    2b52:	44813a83          	ld	s5,1096(sp)
    2b56:	44013b03          	ld	s6,1088(sp)
    2b5a:	43813b83          	ld	s7,1080(sp)
    2b5e:	43013c03          	ld	s8,1072(sp)
    2b62:	42813c83          	ld	s9,1064(sp)
    2b66:	48010113          	addi	sp,sp,1152
    2b6a:	8082                	ret
    close(fd);
    2b6c:	854a                	mv	a0,s2
    2b6e:	162020ef          	jal	ra,4cd0 <close>
  for(fi = 0; done == 0 && '0' + fi < 0177; fi++){
    2b72:	2985                	addiw	s3,s3,1
    2b74:	0ff9f993          	zext.b	s3,s3
    2b78:	ed8984e3          	beq	s3,s8,2a40 <diskfull+0x7c>
    name[0] = 'b';
    2b7c:	b9640023          	sb	s6,-1152(s0)
    name[1] = 'i';
    2b80:	b95400a3          	sb	s5,-1151(s0)
    name[2] = 'g';
    2b84:	b9440123          	sb	s4,-1150(s0)
    name[3] = '0' + fi;
    2b88:	b93401a3          	sb	s3,-1149(s0)
    name[4] = '\0';
    2b8c:	b8040223          	sb	zero,-1148(s0)
    unlink(name);
    2b90:	b8040513          	addi	a0,s0,-1152
    2b94:	164020ef          	jal	ra,4cf8 <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    2b98:	60200593          	li	a1,1538
    2b9c:	b8040513          	addi	a0,s0,-1152
    2ba0:	148020ef          	jal	ra,4ce8 <open>
    2ba4:	892a                	mv	s2,a0
    if(fd < 0){
    2ba6:	e6054de3          	bltz	a0,2a20 <diskfull+0x5c>
    2baa:	84de                	mv	s1,s7
      if(write(fd, buf, BSIZE) != BSIZE){
    2bac:	40000613          	li	a2,1024
    2bb0:	ba040593          	addi	a1,s0,-1120
    2bb4:	854a                	mv	a0,s2
    2bb6:	112020ef          	jal	ra,4cc8 <write>
    2bba:	40000793          	li	a5,1024
    2bbe:	e6f51be3          	bne	a0,a5,2a34 <diskfull+0x70>
    for(int i = 0; i < MAXFILE; i++){
    2bc2:	34fd                	addiw	s1,s1,-1
    2bc4:	f4e5                	bnez	s1,2bac <diskfull+0x1e8>
    2bc6:	b75d                	j	2b6c <diskfull+0x1a8>
    printf("%s: mkdir(diskfulldir) unexpectedly succeeded!\n", s);
    2bc8:	85e6                	mv	a1,s9
    2bca:	00004517          	auipc	a0,0x4
    2bce:	8ee50513          	addi	a0,a0,-1810 # 64b8 <malloc+0x1328>
    2bd2:	504020ef          	jal	ra,50d6 <printf>
    2bd6:	bdd9                	j	2aac <diskfull+0xe8>

0000000000002bd8 <iputtest>:
{
    2bd8:	1101                	addi	sp,sp,-32
    2bda:	ec06                	sd	ra,24(sp)
    2bdc:	e822                	sd	s0,16(sp)
    2bde:	e426                	sd	s1,8(sp)
    2be0:	1000                	addi	s0,sp,32
    2be2:	84aa                	mv	s1,a0
  if(mkdir("iputdir") < 0){
    2be4:	00004517          	auipc	a0,0x4
    2be8:	90450513          	addi	a0,a0,-1788 # 64e8 <malloc+0x1358>
    2bec:	124020ef          	jal	ra,4d10 <mkdir>
    2bf0:	02054f63          	bltz	a0,2c2e <iputtest+0x56>
  if(chdir("iputdir") < 0){
    2bf4:	00004517          	auipc	a0,0x4
    2bf8:	8f450513          	addi	a0,a0,-1804 # 64e8 <malloc+0x1358>
    2bfc:	11c020ef          	jal	ra,4d18 <chdir>
    2c00:	04054163          	bltz	a0,2c42 <iputtest+0x6a>
  if(unlink("../iputdir") < 0){
    2c04:	00004517          	auipc	a0,0x4
    2c08:	92450513          	addi	a0,a0,-1756 # 6528 <malloc+0x1398>
    2c0c:	0ec020ef          	jal	ra,4cf8 <unlink>
    2c10:	04054363          	bltz	a0,2c56 <iputtest+0x7e>
  if(chdir("/") < 0){
    2c14:	00004517          	auipc	a0,0x4
    2c18:	94450513          	addi	a0,a0,-1724 # 6558 <malloc+0x13c8>
    2c1c:	0fc020ef          	jal	ra,4d18 <chdir>
    2c20:	04054563          	bltz	a0,2c6a <iputtest+0x92>
}
    2c24:	60e2                	ld	ra,24(sp)
    2c26:	6442                	ld	s0,16(sp)
    2c28:	64a2                	ld	s1,8(sp)
    2c2a:	6105                	addi	sp,sp,32
    2c2c:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2c2e:	85a6                	mv	a1,s1
    2c30:	00004517          	auipc	a0,0x4
    2c34:	8c050513          	addi	a0,a0,-1856 # 64f0 <malloc+0x1360>
    2c38:	49e020ef          	jal	ra,50d6 <printf>
    exit(1);
    2c3c:	4505                	li	a0,1
    2c3e:	06a020ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir iputdir failed\n", s);
    2c42:	85a6                	mv	a1,s1
    2c44:	00004517          	auipc	a0,0x4
    2c48:	8c450513          	addi	a0,a0,-1852 # 6508 <malloc+0x1378>
    2c4c:	48a020ef          	jal	ra,50d6 <printf>
    exit(1);
    2c50:	4505                	li	a0,1
    2c52:	056020ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink ../iputdir failed\n", s);
    2c56:	85a6                	mv	a1,s1
    2c58:	00004517          	auipc	a0,0x4
    2c5c:	8e050513          	addi	a0,a0,-1824 # 6538 <malloc+0x13a8>
    2c60:	476020ef          	jal	ra,50d6 <printf>
    exit(1);
    2c64:	4505                	li	a0,1
    2c66:	042020ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir / failed\n", s);
    2c6a:	85a6                	mv	a1,s1
    2c6c:	00004517          	auipc	a0,0x4
    2c70:	8f450513          	addi	a0,a0,-1804 # 6560 <malloc+0x13d0>
    2c74:	462020ef          	jal	ra,50d6 <printf>
    exit(1);
    2c78:	4505                	li	a0,1
    2c7a:	02e020ef          	jal	ra,4ca8 <exit>

0000000000002c7e <exitiputtest>:
{
    2c7e:	7179                	addi	sp,sp,-48
    2c80:	f406                	sd	ra,40(sp)
    2c82:	f022                	sd	s0,32(sp)
    2c84:	ec26                	sd	s1,24(sp)
    2c86:	1800                	addi	s0,sp,48
    2c88:	84aa                	mv	s1,a0
  pid = fork();
    2c8a:	016020ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    2c8e:	02054e63          	bltz	a0,2cca <exitiputtest+0x4c>
  if(pid == 0){
    2c92:	e541                	bnez	a0,2d1a <exitiputtest+0x9c>
    if(mkdir("iputdir") < 0){
    2c94:	00004517          	auipc	a0,0x4
    2c98:	85450513          	addi	a0,a0,-1964 # 64e8 <malloc+0x1358>
    2c9c:	074020ef          	jal	ra,4d10 <mkdir>
    2ca0:	02054f63          	bltz	a0,2cde <exitiputtest+0x60>
    if(chdir("iputdir") < 0){
    2ca4:	00004517          	auipc	a0,0x4
    2ca8:	84450513          	addi	a0,a0,-1980 # 64e8 <malloc+0x1358>
    2cac:	06c020ef          	jal	ra,4d18 <chdir>
    2cb0:	04054163          	bltz	a0,2cf2 <exitiputtest+0x74>
    if(unlink("../iputdir") < 0){
    2cb4:	00004517          	auipc	a0,0x4
    2cb8:	87450513          	addi	a0,a0,-1932 # 6528 <malloc+0x1398>
    2cbc:	03c020ef          	jal	ra,4cf8 <unlink>
    2cc0:	04054363          	bltz	a0,2d06 <exitiputtest+0x88>
    exit(0);
    2cc4:	4501                	li	a0,0
    2cc6:	7e3010ef          	jal	ra,4ca8 <exit>
    printf("%s: fork failed\n", s);
    2cca:	85a6                	mv	a1,s1
    2ccc:	00003517          	auipc	a0,0x3
    2cd0:	e8c50513          	addi	a0,a0,-372 # 5b58 <malloc+0x9c8>
    2cd4:	402020ef          	jal	ra,50d6 <printf>
    exit(1);
    2cd8:	4505                	li	a0,1
    2cda:	7cf010ef          	jal	ra,4ca8 <exit>
      printf("%s: mkdir failed\n", s);
    2cde:	85a6                	mv	a1,s1
    2ce0:	00004517          	auipc	a0,0x4
    2ce4:	81050513          	addi	a0,a0,-2032 # 64f0 <malloc+0x1360>
    2ce8:	3ee020ef          	jal	ra,50d6 <printf>
      exit(1);
    2cec:	4505                	li	a0,1
    2cee:	7bb010ef          	jal	ra,4ca8 <exit>
      printf("%s: child chdir failed\n", s);
    2cf2:	85a6                	mv	a1,s1
    2cf4:	00004517          	auipc	a0,0x4
    2cf8:	88450513          	addi	a0,a0,-1916 # 6578 <malloc+0x13e8>
    2cfc:	3da020ef          	jal	ra,50d6 <printf>
      exit(1);
    2d00:	4505                	li	a0,1
    2d02:	7a7010ef          	jal	ra,4ca8 <exit>
      printf("%s: unlink ../iputdir failed\n", s);
    2d06:	85a6                	mv	a1,s1
    2d08:	00004517          	auipc	a0,0x4
    2d0c:	83050513          	addi	a0,a0,-2000 # 6538 <malloc+0x13a8>
    2d10:	3c6020ef          	jal	ra,50d6 <printf>
      exit(1);
    2d14:	4505                	li	a0,1
    2d16:	793010ef          	jal	ra,4ca8 <exit>
  wait(&xstatus);
    2d1a:	fdc40513          	addi	a0,s0,-36
    2d1e:	793010ef          	jal	ra,4cb0 <wait>
  exit(xstatus);
    2d22:	fdc42503          	lw	a0,-36(s0)
    2d26:	783010ef          	jal	ra,4ca8 <exit>

0000000000002d2a <dirtest>:
{
    2d2a:	1101                	addi	sp,sp,-32
    2d2c:	ec06                	sd	ra,24(sp)
    2d2e:	e822                	sd	s0,16(sp)
    2d30:	e426                	sd	s1,8(sp)
    2d32:	1000                	addi	s0,sp,32
    2d34:	84aa                	mv	s1,a0
  if(mkdir("dir0") < 0){
    2d36:	00004517          	auipc	a0,0x4
    2d3a:	85a50513          	addi	a0,a0,-1958 # 6590 <malloc+0x1400>
    2d3e:	7d3010ef          	jal	ra,4d10 <mkdir>
    2d42:	02054f63          	bltz	a0,2d80 <dirtest+0x56>
  if(chdir("dir0") < 0){
    2d46:	00004517          	auipc	a0,0x4
    2d4a:	84a50513          	addi	a0,a0,-1974 # 6590 <malloc+0x1400>
    2d4e:	7cb010ef          	jal	ra,4d18 <chdir>
    2d52:	04054163          	bltz	a0,2d94 <dirtest+0x6a>
  if(chdir("..") < 0){
    2d56:	00004517          	auipc	a0,0x4
    2d5a:	85a50513          	addi	a0,a0,-1958 # 65b0 <malloc+0x1420>
    2d5e:	7bb010ef          	jal	ra,4d18 <chdir>
    2d62:	04054363          	bltz	a0,2da8 <dirtest+0x7e>
  if(unlink("dir0") < 0){
    2d66:	00004517          	auipc	a0,0x4
    2d6a:	82a50513          	addi	a0,a0,-2006 # 6590 <malloc+0x1400>
    2d6e:	78b010ef          	jal	ra,4cf8 <unlink>
    2d72:	04054563          	bltz	a0,2dbc <dirtest+0x92>
}
    2d76:	60e2                	ld	ra,24(sp)
    2d78:	6442                	ld	s0,16(sp)
    2d7a:	64a2                	ld	s1,8(sp)
    2d7c:	6105                	addi	sp,sp,32
    2d7e:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2d80:	85a6                	mv	a1,s1
    2d82:	00003517          	auipc	a0,0x3
    2d86:	76e50513          	addi	a0,a0,1902 # 64f0 <malloc+0x1360>
    2d8a:	34c020ef          	jal	ra,50d6 <printf>
    exit(1);
    2d8e:	4505                	li	a0,1
    2d90:	719010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dir0 failed\n", s);
    2d94:	85a6                	mv	a1,s1
    2d96:	00004517          	auipc	a0,0x4
    2d9a:	80250513          	addi	a0,a0,-2046 # 6598 <malloc+0x1408>
    2d9e:	338020ef          	jal	ra,50d6 <printf>
    exit(1);
    2da2:	4505                	li	a0,1
    2da4:	705010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir .. failed\n", s);
    2da8:	85a6                	mv	a1,s1
    2daa:	00004517          	auipc	a0,0x4
    2dae:	80e50513          	addi	a0,a0,-2034 # 65b8 <malloc+0x1428>
    2db2:	324020ef          	jal	ra,50d6 <printf>
    exit(1);
    2db6:	4505                	li	a0,1
    2db8:	6f1010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dir0 failed\n", s);
    2dbc:	85a6                	mv	a1,s1
    2dbe:	00004517          	auipc	a0,0x4
    2dc2:	81250513          	addi	a0,a0,-2030 # 65d0 <malloc+0x1440>
    2dc6:	310020ef          	jal	ra,50d6 <printf>
    exit(1);
    2dca:	4505                	li	a0,1
    2dcc:	6dd010ef          	jal	ra,4ca8 <exit>

0000000000002dd0 <subdir>:
{
    2dd0:	1101                	addi	sp,sp,-32
    2dd2:	ec06                	sd	ra,24(sp)
    2dd4:	e822                	sd	s0,16(sp)
    2dd6:	e426                	sd	s1,8(sp)
    2dd8:	e04a                	sd	s2,0(sp)
    2dda:	1000                	addi	s0,sp,32
    2ddc:	892a                	mv	s2,a0
  unlink("ff");
    2dde:	00004517          	auipc	a0,0x4
    2de2:	93a50513          	addi	a0,a0,-1734 # 6718 <malloc+0x1588>
    2de6:	713010ef          	jal	ra,4cf8 <unlink>
  if(mkdir("dd") != 0){
    2dea:	00003517          	auipc	a0,0x3
    2dee:	7fe50513          	addi	a0,a0,2046 # 65e8 <malloc+0x1458>
    2df2:	71f010ef          	jal	ra,4d10 <mkdir>
    2df6:	2e051263          	bnez	a0,30da <subdir+0x30a>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2dfa:	20200593          	li	a1,514
    2dfe:	00004517          	auipc	a0,0x4
    2e02:	80a50513          	addi	a0,a0,-2038 # 6608 <malloc+0x1478>
    2e06:	6e3010ef          	jal	ra,4ce8 <open>
    2e0a:	84aa                	mv	s1,a0
  if(fd < 0){
    2e0c:	2e054163          	bltz	a0,30ee <subdir+0x31e>
  write(fd, "ff", 2);
    2e10:	4609                	li	a2,2
    2e12:	00004597          	auipc	a1,0x4
    2e16:	90658593          	addi	a1,a1,-1786 # 6718 <malloc+0x1588>
    2e1a:	6af010ef          	jal	ra,4cc8 <write>
  close(fd);
    2e1e:	8526                	mv	a0,s1
    2e20:	6b1010ef          	jal	ra,4cd0 <close>
  if(unlink("dd") >= 0){
    2e24:	00003517          	auipc	a0,0x3
    2e28:	7c450513          	addi	a0,a0,1988 # 65e8 <malloc+0x1458>
    2e2c:	6cd010ef          	jal	ra,4cf8 <unlink>
    2e30:	2c055963          	bgez	a0,3102 <subdir+0x332>
  if(mkdir("/dd/dd") != 0){
    2e34:	00004517          	auipc	a0,0x4
    2e38:	82c50513          	addi	a0,a0,-2004 # 6660 <malloc+0x14d0>
    2e3c:	6d5010ef          	jal	ra,4d10 <mkdir>
    2e40:	2c051b63          	bnez	a0,3116 <subdir+0x346>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2e44:	20200593          	li	a1,514
    2e48:	00004517          	auipc	a0,0x4
    2e4c:	84050513          	addi	a0,a0,-1984 # 6688 <malloc+0x14f8>
    2e50:	699010ef          	jal	ra,4ce8 <open>
    2e54:	84aa                	mv	s1,a0
  if(fd < 0){
    2e56:	2c054a63          	bltz	a0,312a <subdir+0x35a>
  write(fd, "FF", 2);
    2e5a:	4609                	li	a2,2
    2e5c:	00004597          	auipc	a1,0x4
    2e60:	85c58593          	addi	a1,a1,-1956 # 66b8 <malloc+0x1528>
    2e64:	665010ef          	jal	ra,4cc8 <write>
  close(fd);
    2e68:	8526                	mv	a0,s1
    2e6a:	667010ef          	jal	ra,4cd0 <close>
  fd = open("dd/dd/../ff", 0);
    2e6e:	4581                	li	a1,0
    2e70:	00004517          	auipc	a0,0x4
    2e74:	85050513          	addi	a0,a0,-1968 # 66c0 <malloc+0x1530>
    2e78:	671010ef          	jal	ra,4ce8 <open>
    2e7c:	84aa                	mv	s1,a0
  if(fd < 0){
    2e7e:	2c054063          	bltz	a0,313e <subdir+0x36e>
  cc = read(fd, buf, sizeof(buf));
    2e82:	660d                	lui	a2,0x3
    2e84:	00009597          	auipc	a1,0x9
    2e88:	e2458593          	addi	a1,a1,-476 # bca8 <buf>
    2e8c:	635010ef          	jal	ra,4cc0 <read>
  if(cc != 2 || buf[0] != 'f'){
    2e90:	4789                	li	a5,2
    2e92:	2cf51063          	bne	a0,a5,3152 <subdir+0x382>
    2e96:	00009717          	auipc	a4,0x9
    2e9a:	e1274703          	lbu	a4,-494(a4) # bca8 <buf>
    2e9e:	06600793          	li	a5,102
    2ea2:	2af71863          	bne	a4,a5,3152 <subdir+0x382>
  close(fd);
    2ea6:	8526                	mv	a0,s1
    2ea8:	629010ef          	jal	ra,4cd0 <close>
  if(link("dd/dd/ff", "dd/dd/ffff") != 0){
    2eac:	00004597          	auipc	a1,0x4
    2eb0:	86458593          	addi	a1,a1,-1948 # 6710 <malloc+0x1580>
    2eb4:	00003517          	auipc	a0,0x3
    2eb8:	7d450513          	addi	a0,a0,2004 # 6688 <malloc+0x14f8>
    2ebc:	64d010ef          	jal	ra,4d08 <link>
    2ec0:	2a051363          	bnez	a0,3166 <subdir+0x396>
  if(unlink("dd/dd/ff") != 0){
    2ec4:	00003517          	auipc	a0,0x3
    2ec8:	7c450513          	addi	a0,a0,1988 # 6688 <malloc+0x14f8>
    2ecc:	62d010ef          	jal	ra,4cf8 <unlink>
    2ed0:	2a051563          	bnez	a0,317a <subdir+0x3aa>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2ed4:	4581                	li	a1,0
    2ed6:	00003517          	auipc	a0,0x3
    2eda:	7b250513          	addi	a0,a0,1970 # 6688 <malloc+0x14f8>
    2ede:	60b010ef          	jal	ra,4ce8 <open>
    2ee2:	2a055663          	bgez	a0,318e <subdir+0x3be>
  if(chdir("dd") != 0){
    2ee6:	00003517          	auipc	a0,0x3
    2eea:	70250513          	addi	a0,a0,1794 # 65e8 <malloc+0x1458>
    2eee:	62b010ef          	jal	ra,4d18 <chdir>
    2ef2:	2a051863          	bnez	a0,31a2 <subdir+0x3d2>
  if(chdir("dd/../../dd") != 0){
    2ef6:	00004517          	auipc	a0,0x4
    2efa:	8b250513          	addi	a0,a0,-1870 # 67a8 <malloc+0x1618>
    2efe:	61b010ef          	jal	ra,4d18 <chdir>
    2f02:	2a051a63          	bnez	a0,31b6 <subdir+0x3e6>
  if(chdir("dd/../../../dd") != 0){
    2f06:	00004517          	auipc	a0,0x4
    2f0a:	8d250513          	addi	a0,a0,-1838 # 67d8 <malloc+0x1648>
    2f0e:	60b010ef          	jal	ra,4d18 <chdir>
    2f12:	2a051c63          	bnez	a0,31ca <subdir+0x3fa>
  if(chdir("./..") != 0){
    2f16:	00004517          	auipc	a0,0x4
    2f1a:	8fa50513          	addi	a0,a0,-1798 # 6810 <malloc+0x1680>
    2f1e:	5fb010ef          	jal	ra,4d18 <chdir>
    2f22:	2a051e63          	bnez	a0,31de <subdir+0x40e>
  fd = open("dd/dd/ffff", 0);
    2f26:	4581                	li	a1,0
    2f28:	00003517          	auipc	a0,0x3
    2f2c:	7e850513          	addi	a0,a0,2024 # 6710 <malloc+0x1580>
    2f30:	5b9010ef          	jal	ra,4ce8 <open>
    2f34:	84aa                	mv	s1,a0
  if(fd < 0){
    2f36:	2a054e63          	bltz	a0,31f2 <subdir+0x422>
  if(read(fd, buf, sizeof(buf)) != 2){
    2f3a:	660d                	lui	a2,0x3
    2f3c:	00009597          	auipc	a1,0x9
    2f40:	d6c58593          	addi	a1,a1,-660 # bca8 <buf>
    2f44:	57d010ef          	jal	ra,4cc0 <read>
    2f48:	4789                	li	a5,2
    2f4a:	2af51e63          	bne	a0,a5,3206 <subdir+0x436>
  close(fd);
    2f4e:	8526                	mv	a0,s1
    2f50:	581010ef          	jal	ra,4cd0 <close>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2f54:	4581                	li	a1,0
    2f56:	00003517          	auipc	a0,0x3
    2f5a:	73250513          	addi	a0,a0,1842 # 6688 <malloc+0x14f8>
    2f5e:	58b010ef          	jal	ra,4ce8 <open>
    2f62:	2a055c63          	bgez	a0,321a <subdir+0x44a>
  if(open("dd/ff/ff", O_CREATE|O_RDWR) >= 0){
    2f66:	20200593          	li	a1,514
    2f6a:	00004517          	auipc	a0,0x4
    2f6e:	93650513          	addi	a0,a0,-1738 # 68a0 <malloc+0x1710>
    2f72:	577010ef          	jal	ra,4ce8 <open>
    2f76:	2a055c63          	bgez	a0,322e <subdir+0x45e>
  if(open("dd/xx/ff", O_CREATE|O_RDWR) >= 0){
    2f7a:	20200593          	li	a1,514
    2f7e:	00004517          	auipc	a0,0x4
    2f82:	95250513          	addi	a0,a0,-1710 # 68d0 <malloc+0x1740>
    2f86:	563010ef          	jal	ra,4ce8 <open>
    2f8a:	2a055c63          	bgez	a0,3242 <subdir+0x472>
  if(open("dd", O_CREATE) >= 0){
    2f8e:	20000593          	li	a1,512
    2f92:	00003517          	auipc	a0,0x3
    2f96:	65650513          	addi	a0,a0,1622 # 65e8 <malloc+0x1458>
    2f9a:	54f010ef          	jal	ra,4ce8 <open>
    2f9e:	2a055c63          	bgez	a0,3256 <subdir+0x486>
  if(open("dd", O_RDWR) >= 0){
    2fa2:	4589                	li	a1,2
    2fa4:	00003517          	auipc	a0,0x3
    2fa8:	64450513          	addi	a0,a0,1604 # 65e8 <malloc+0x1458>
    2fac:	53d010ef          	jal	ra,4ce8 <open>
    2fb0:	2a055d63          	bgez	a0,326a <subdir+0x49a>
  if(open("dd", O_WRONLY) >= 0){
    2fb4:	4585                	li	a1,1
    2fb6:	00003517          	auipc	a0,0x3
    2fba:	63250513          	addi	a0,a0,1586 # 65e8 <malloc+0x1458>
    2fbe:	52b010ef          	jal	ra,4ce8 <open>
    2fc2:	2a055e63          	bgez	a0,327e <subdir+0x4ae>
  if(link("dd/ff/ff", "dd/dd/xx") == 0){
    2fc6:	00004597          	auipc	a1,0x4
    2fca:	99a58593          	addi	a1,a1,-1638 # 6960 <malloc+0x17d0>
    2fce:	00004517          	auipc	a0,0x4
    2fd2:	8d250513          	addi	a0,a0,-1838 # 68a0 <malloc+0x1710>
    2fd6:	533010ef          	jal	ra,4d08 <link>
    2fda:	2a050c63          	beqz	a0,3292 <subdir+0x4c2>
  if(link("dd/xx/ff", "dd/dd/xx") == 0){
    2fde:	00004597          	auipc	a1,0x4
    2fe2:	98258593          	addi	a1,a1,-1662 # 6960 <malloc+0x17d0>
    2fe6:	00004517          	auipc	a0,0x4
    2fea:	8ea50513          	addi	a0,a0,-1814 # 68d0 <malloc+0x1740>
    2fee:	51b010ef          	jal	ra,4d08 <link>
    2ff2:	2a050a63          	beqz	a0,32a6 <subdir+0x4d6>
  if(link("dd/ff", "dd/dd/ffff") == 0){
    2ff6:	00003597          	auipc	a1,0x3
    2ffa:	71a58593          	addi	a1,a1,1818 # 6710 <malloc+0x1580>
    2ffe:	00003517          	auipc	a0,0x3
    3002:	60a50513          	addi	a0,a0,1546 # 6608 <malloc+0x1478>
    3006:	503010ef          	jal	ra,4d08 <link>
    300a:	2a050863          	beqz	a0,32ba <subdir+0x4ea>
  if(mkdir("dd/ff/ff") == 0){
    300e:	00004517          	auipc	a0,0x4
    3012:	89250513          	addi	a0,a0,-1902 # 68a0 <malloc+0x1710>
    3016:	4fb010ef          	jal	ra,4d10 <mkdir>
    301a:	2a050a63          	beqz	a0,32ce <subdir+0x4fe>
  if(mkdir("dd/xx/ff") == 0){
    301e:	00004517          	auipc	a0,0x4
    3022:	8b250513          	addi	a0,a0,-1870 # 68d0 <malloc+0x1740>
    3026:	4eb010ef          	jal	ra,4d10 <mkdir>
    302a:	2a050c63          	beqz	a0,32e2 <subdir+0x512>
  if(mkdir("dd/dd/ffff") == 0){
    302e:	00003517          	auipc	a0,0x3
    3032:	6e250513          	addi	a0,a0,1762 # 6710 <malloc+0x1580>
    3036:	4db010ef          	jal	ra,4d10 <mkdir>
    303a:	2a050e63          	beqz	a0,32f6 <subdir+0x526>
  if(unlink("dd/xx/ff") == 0){
    303e:	00004517          	auipc	a0,0x4
    3042:	89250513          	addi	a0,a0,-1902 # 68d0 <malloc+0x1740>
    3046:	4b3010ef          	jal	ra,4cf8 <unlink>
    304a:	2c050063          	beqz	a0,330a <subdir+0x53a>
  if(unlink("dd/ff/ff") == 0){
    304e:	00004517          	auipc	a0,0x4
    3052:	85250513          	addi	a0,a0,-1966 # 68a0 <malloc+0x1710>
    3056:	4a3010ef          	jal	ra,4cf8 <unlink>
    305a:	2c050263          	beqz	a0,331e <subdir+0x54e>
  if(chdir("dd/ff") == 0){
    305e:	00003517          	auipc	a0,0x3
    3062:	5aa50513          	addi	a0,a0,1450 # 6608 <malloc+0x1478>
    3066:	4b3010ef          	jal	ra,4d18 <chdir>
    306a:	2c050463          	beqz	a0,3332 <subdir+0x562>
  if(chdir("dd/xx") == 0){
    306e:	00004517          	auipc	a0,0x4
    3072:	a4250513          	addi	a0,a0,-1470 # 6ab0 <malloc+0x1920>
    3076:	4a3010ef          	jal	ra,4d18 <chdir>
    307a:	2c050663          	beqz	a0,3346 <subdir+0x576>
  if(unlink("dd/dd/ffff") != 0){
    307e:	00003517          	auipc	a0,0x3
    3082:	69250513          	addi	a0,a0,1682 # 6710 <malloc+0x1580>
    3086:	473010ef          	jal	ra,4cf8 <unlink>
    308a:	2c051863          	bnez	a0,335a <subdir+0x58a>
  if(unlink("dd/ff") != 0){
    308e:	00003517          	auipc	a0,0x3
    3092:	57a50513          	addi	a0,a0,1402 # 6608 <malloc+0x1478>
    3096:	463010ef          	jal	ra,4cf8 <unlink>
    309a:	2c051a63          	bnez	a0,336e <subdir+0x59e>
  if(unlink("dd") == 0){
    309e:	00003517          	auipc	a0,0x3
    30a2:	54a50513          	addi	a0,a0,1354 # 65e8 <malloc+0x1458>
    30a6:	453010ef          	jal	ra,4cf8 <unlink>
    30aa:	2c050c63          	beqz	a0,3382 <subdir+0x5b2>
  if(unlink("dd/dd") < 0){
    30ae:	00004517          	auipc	a0,0x4
    30b2:	a7250513          	addi	a0,a0,-1422 # 6b20 <malloc+0x1990>
    30b6:	443010ef          	jal	ra,4cf8 <unlink>
    30ba:	2c054e63          	bltz	a0,3396 <subdir+0x5c6>
  if(unlink("dd") < 0){
    30be:	00003517          	auipc	a0,0x3
    30c2:	52a50513          	addi	a0,a0,1322 # 65e8 <malloc+0x1458>
    30c6:	433010ef          	jal	ra,4cf8 <unlink>
    30ca:	2e054063          	bltz	a0,33aa <subdir+0x5da>
}
    30ce:	60e2                	ld	ra,24(sp)
    30d0:	6442                	ld	s0,16(sp)
    30d2:	64a2                	ld	s1,8(sp)
    30d4:	6902                	ld	s2,0(sp)
    30d6:	6105                	addi	sp,sp,32
    30d8:	8082                	ret
    printf("%s: mkdir dd failed\n", s);
    30da:	85ca                	mv	a1,s2
    30dc:	00003517          	auipc	a0,0x3
    30e0:	51450513          	addi	a0,a0,1300 # 65f0 <malloc+0x1460>
    30e4:	7f3010ef          	jal	ra,50d6 <printf>
    exit(1);
    30e8:	4505                	li	a0,1
    30ea:	3bf010ef          	jal	ra,4ca8 <exit>
    printf("%s: create dd/ff failed\n", s);
    30ee:	85ca                	mv	a1,s2
    30f0:	00003517          	auipc	a0,0x3
    30f4:	52050513          	addi	a0,a0,1312 # 6610 <malloc+0x1480>
    30f8:	7df010ef          	jal	ra,50d6 <printf>
    exit(1);
    30fc:	4505                	li	a0,1
    30fe:	3ab010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    3102:	85ca                	mv	a1,s2
    3104:	00003517          	auipc	a0,0x3
    3108:	52c50513          	addi	a0,a0,1324 # 6630 <malloc+0x14a0>
    310c:	7cb010ef          	jal	ra,50d6 <printf>
    exit(1);
    3110:	4505                	li	a0,1
    3112:	397010ef          	jal	ra,4ca8 <exit>
    printf("%s: subdir mkdir dd/dd failed\n", s);
    3116:	85ca                	mv	a1,s2
    3118:	00003517          	auipc	a0,0x3
    311c:	55050513          	addi	a0,a0,1360 # 6668 <malloc+0x14d8>
    3120:	7b7010ef          	jal	ra,50d6 <printf>
    exit(1);
    3124:	4505                	li	a0,1
    3126:	383010ef          	jal	ra,4ca8 <exit>
    printf("%s: create dd/dd/ff failed\n", s);
    312a:	85ca                	mv	a1,s2
    312c:	00003517          	auipc	a0,0x3
    3130:	56c50513          	addi	a0,a0,1388 # 6698 <malloc+0x1508>
    3134:	7a3010ef          	jal	ra,50d6 <printf>
    exit(1);
    3138:	4505                	li	a0,1
    313a:	36f010ef          	jal	ra,4ca8 <exit>
    printf("%s: open dd/dd/../ff failed\n", s);
    313e:	85ca                	mv	a1,s2
    3140:	00003517          	auipc	a0,0x3
    3144:	59050513          	addi	a0,a0,1424 # 66d0 <malloc+0x1540>
    3148:	78f010ef          	jal	ra,50d6 <printf>
    exit(1);
    314c:	4505                	li	a0,1
    314e:	35b010ef          	jal	ra,4ca8 <exit>
    printf("%s: dd/dd/../ff wrong content\n", s);
    3152:	85ca                	mv	a1,s2
    3154:	00003517          	auipc	a0,0x3
    3158:	59c50513          	addi	a0,a0,1436 # 66f0 <malloc+0x1560>
    315c:	77b010ef          	jal	ra,50d6 <printf>
    exit(1);
    3160:	4505                	li	a0,1
    3162:	347010ef          	jal	ra,4ca8 <exit>
    printf("%s: link dd/dd/ff dd/dd/ffff failed\n", s);
    3166:	85ca                	mv	a1,s2
    3168:	00003517          	auipc	a0,0x3
    316c:	5b850513          	addi	a0,a0,1464 # 6720 <malloc+0x1590>
    3170:	767010ef          	jal	ra,50d6 <printf>
    exit(1);
    3174:	4505                	li	a0,1
    3176:	333010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    317a:	85ca                	mv	a1,s2
    317c:	00003517          	auipc	a0,0x3
    3180:	5cc50513          	addi	a0,a0,1484 # 6748 <malloc+0x15b8>
    3184:	753010ef          	jal	ra,50d6 <printf>
    exit(1);
    3188:	4505                	li	a0,1
    318a:	31f010ef          	jal	ra,4ca8 <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    318e:	85ca                	mv	a1,s2
    3190:	00003517          	auipc	a0,0x3
    3194:	5d850513          	addi	a0,a0,1496 # 6768 <malloc+0x15d8>
    3198:	73f010ef          	jal	ra,50d6 <printf>
    exit(1);
    319c:	4505                	li	a0,1
    319e:	30b010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dd failed\n", s);
    31a2:	85ca                	mv	a1,s2
    31a4:	00003517          	auipc	a0,0x3
    31a8:	5ec50513          	addi	a0,a0,1516 # 6790 <malloc+0x1600>
    31ac:	72b010ef          	jal	ra,50d6 <printf>
    exit(1);
    31b0:	4505                	li	a0,1
    31b2:	2f7010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dd/../../dd failed\n", s);
    31b6:	85ca                	mv	a1,s2
    31b8:	00003517          	auipc	a0,0x3
    31bc:	60050513          	addi	a0,a0,1536 # 67b8 <malloc+0x1628>
    31c0:	717010ef          	jal	ra,50d6 <printf>
    exit(1);
    31c4:	4505                	li	a0,1
    31c6:	2e3010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dd/../../../dd failed\n", s);
    31ca:	85ca                	mv	a1,s2
    31cc:	00003517          	auipc	a0,0x3
    31d0:	61c50513          	addi	a0,a0,1564 # 67e8 <malloc+0x1658>
    31d4:	703010ef          	jal	ra,50d6 <printf>
    exit(1);
    31d8:	4505                	li	a0,1
    31da:	2cf010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir ./.. failed\n", s);
    31de:	85ca                	mv	a1,s2
    31e0:	00003517          	auipc	a0,0x3
    31e4:	63850513          	addi	a0,a0,1592 # 6818 <malloc+0x1688>
    31e8:	6ef010ef          	jal	ra,50d6 <printf>
    exit(1);
    31ec:	4505                	li	a0,1
    31ee:	2bb010ef          	jal	ra,4ca8 <exit>
    printf("%s: open dd/dd/ffff failed\n", s);
    31f2:	85ca                	mv	a1,s2
    31f4:	00003517          	auipc	a0,0x3
    31f8:	63c50513          	addi	a0,a0,1596 # 6830 <malloc+0x16a0>
    31fc:	6db010ef          	jal	ra,50d6 <printf>
    exit(1);
    3200:	4505                	li	a0,1
    3202:	2a7010ef          	jal	ra,4ca8 <exit>
    printf("%s: read dd/dd/ffff wrong len\n", s);
    3206:	85ca                	mv	a1,s2
    3208:	00003517          	auipc	a0,0x3
    320c:	64850513          	addi	a0,a0,1608 # 6850 <malloc+0x16c0>
    3210:	6c7010ef          	jal	ra,50d6 <printf>
    exit(1);
    3214:	4505                	li	a0,1
    3216:	293010ef          	jal	ra,4ca8 <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    321a:	85ca                	mv	a1,s2
    321c:	00003517          	auipc	a0,0x3
    3220:	65450513          	addi	a0,a0,1620 # 6870 <malloc+0x16e0>
    3224:	6b3010ef          	jal	ra,50d6 <printf>
    exit(1);
    3228:	4505                	li	a0,1
    322a:	27f010ef          	jal	ra,4ca8 <exit>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    322e:	85ca                	mv	a1,s2
    3230:	00003517          	auipc	a0,0x3
    3234:	68050513          	addi	a0,a0,1664 # 68b0 <malloc+0x1720>
    3238:	69f010ef          	jal	ra,50d6 <printf>
    exit(1);
    323c:	4505                	li	a0,1
    323e:	26b010ef          	jal	ra,4ca8 <exit>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    3242:	85ca                	mv	a1,s2
    3244:	00003517          	auipc	a0,0x3
    3248:	69c50513          	addi	a0,a0,1692 # 68e0 <malloc+0x1750>
    324c:	68b010ef          	jal	ra,50d6 <printf>
    exit(1);
    3250:	4505                	li	a0,1
    3252:	257010ef          	jal	ra,4ca8 <exit>
    printf("%s: create dd succeeded!\n", s);
    3256:	85ca                	mv	a1,s2
    3258:	00003517          	auipc	a0,0x3
    325c:	6a850513          	addi	a0,a0,1704 # 6900 <malloc+0x1770>
    3260:	677010ef          	jal	ra,50d6 <printf>
    exit(1);
    3264:	4505                	li	a0,1
    3266:	243010ef          	jal	ra,4ca8 <exit>
    printf("%s: open dd rdwr succeeded!\n", s);
    326a:	85ca                	mv	a1,s2
    326c:	00003517          	auipc	a0,0x3
    3270:	6b450513          	addi	a0,a0,1716 # 6920 <malloc+0x1790>
    3274:	663010ef          	jal	ra,50d6 <printf>
    exit(1);
    3278:	4505                	li	a0,1
    327a:	22f010ef          	jal	ra,4ca8 <exit>
    printf("%s: open dd wronly succeeded!\n", s);
    327e:	85ca                	mv	a1,s2
    3280:	00003517          	auipc	a0,0x3
    3284:	6c050513          	addi	a0,a0,1728 # 6940 <malloc+0x17b0>
    3288:	64f010ef          	jal	ra,50d6 <printf>
    exit(1);
    328c:	4505                	li	a0,1
    328e:	21b010ef          	jal	ra,4ca8 <exit>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    3292:	85ca                	mv	a1,s2
    3294:	00003517          	auipc	a0,0x3
    3298:	6dc50513          	addi	a0,a0,1756 # 6970 <malloc+0x17e0>
    329c:	63b010ef          	jal	ra,50d6 <printf>
    exit(1);
    32a0:	4505                	li	a0,1
    32a2:	207010ef          	jal	ra,4ca8 <exit>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    32a6:	85ca                	mv	a1,s2
    32a8:	00003517          	auipc	a0,0x3
    32ac:	6f050513          	addi	a0,a0,1776 # 6998 <malloc+0x1808>
    32b0:	627010ef          	jal	ra,50d6 <printf>
    exit(1);
    32b4:	4505                	li	a0,1
    32b6:	1f3010ef          	jal	ra,4ca8 <exit>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    32ba:	85ca                	mv	a1,s2
    32bc:	00003517          	auipc	a0,0x3
    32c0:	70450513          	addi	a0,a0,1796 # 69c0 <malloc+0x1830>
    32c4:	613010ef          	jal	ra,50d6 <printf>
    exit(1);
    32c8:	4505                	li	a0,1
    32ca:	1df010ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    32ce:	85ca                	mv	a1,s2
    32d0:	00003517          	auipc	a0,0x3
    32d4:	71850513          	addi	a0,a0,1816 # 69e8 <malloc+0x1858>
    32d8:	5ff010ef          	jal	ra,50d6 <printf>
    exit(1);
    32dc:	4505                	li	a0,1
    32de:	1cb010ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    32e2:	85ca                	mv	a1,s2
    32e4:	00003517          	auipc	a0,0x3
    32e8:	72450513          	addi	a0,a0,1828 # 6a08 <malloc+0x1878>
    32ec:	5eb010ef          	jal	ra,50d6 <printf>
    exit(1);
    32f0:	4505                	li	a0,1
    32f2:	1b7010ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    32f6:	85ca                	mv	a1,s2
    32f8:	00003517          	auipc	a0,0x3
    32fc:	73050513          	addi	a0,a0,1840 # 6a28 <malloc+0x1898>
    3300:	5d7010ef          	jal	ra,50d6 <printf>
    exit(1);
    3304:	4505                	li	a0,1
    3306:	1a3010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    330a:	85ca                	mv	a1,s2
    330c:	00003517          	auipc	a0,0x3
    3310:	74450513          	addi	a0,a0,1860 # 6a50 <malloc+0x18c0>
    3314:	5c3010ef          	jal	ra,50d6 <printf>
    exit(1);
    3318:	4505                	li	a0,1
    331a:	18f010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    331e:	85ca                	mv	a1,s2
    3320:	00003517          	auipc	a0,0x3
    3324:	75050513          	addi	a0,a0,1872 # 6a70 <malloc+0x18e0>
    3328:	5af010ef          	jal	ra,50d6 <printf>
    exit(1);
    332c:	4505                	li	a0,1
    332e:	17b010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dd/ff succeeded!\n", s);
    3332:	85ca                	mv	a1,s2
    3334:	00003517          	auipc	a0,0x3
    3338:	75c50513          	addi	a0,a0,1884 # 6a90 <malloc+0x1900>
    333c:	59b010ef          	jal	ra,50d6 <printf>
    exit(1);
    3340:	4505                	li	a0,1
    3342:	167010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dd/xx succeeded!\n", s);
    3346:	85ca                	mv	a1,s2
    3348:	00003517          	auipc	a0,0x3
    334c:	77050513          	addi	a0,a0,1904 # 6ab8 <malloc+0x1928>
    3350:	587010ef          	jal	ra,50d6 <printf>
    exit(1);
    3354:	4505                	li	a0,1
    3356:	153010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    335a:	85ca                	mv	a1,s2
    335c:	00003517          	auipc	a0,0x3
    3360:	3ec50513          	addi	a0,a0,1004 # 6748 <malloc+0x15b8>
    3364:	573010ef          	jal	ra,50d6 <printf>
    exit(1);
    3368:	4505                	li	a0,1
    336a:	13f010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd/ff failed\n", s);
    336e:	85ca                	mv	a1,s2
    3370:	00003517          	auipc	a0,0x3
    3374:	76850513          	addi	a0,a0,1896 # 6ad8 <malloc+0x1948>
    3378:	55f010ef          	jal	ra,50d6 <printf>
    exit(1);
    337c:	4505                	li	a0,1
    337e:	12b010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    3382:	85ca                	mv	a1,s2
    3384:	00003517          	auipc	a0,0x3
    3388:	77450513          	addi	a0,a0,1908 # 6af8 <malloc+0x1968>
    338c:	54b010ef          	jal	ra,50d6 <printf>
    exit(1);
    3390:	4505                	li	a0,1
    3392:	117010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd/dd failed\n", s);
    3396:	85ca                	mv	a1,s2
    3398:	00003517          	auipc	a0,0x3
    339c:	79050513          	addi	a0,a0,1936 # 6b28 <malloc+0x1998>
    33a0:	537010ef          	jal	ra,50d6 <printf>
    exit(1);
    33a4:	4505                	li	a0,1
    33a6:	103010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dd failed\n", s);
    33aa:	85ca                	mv	a1,s2
    33ac:	00003517          	auipc	a0,0x3
    33b0:	79c50513          	addi	a0,a0,1948 # 6b48 <malloc+0x19b8>
    33b4:	523010ef          	jal	ra,50d6 <printf>
    exit(1);
    33b8:	4505                	li	a0,1
    33ba:	0ef010ef          	jal	ra,4ca8 <exit>

00000000000033be <rmdot>:
{
    33be:	1101                	addi	sp,sp,-32
    33c0:	ec06                	sd	ra,24(sp)
    33c2:	e822                	sd	s0,16(sp)
    33c4:	e426                	sd	s1,8(sp)
    33c6:	1000                	addi	s0,sp,32
    33c8:	84aa                	mv	s1,a0
  if(mkdir("dots") != 0){
    33ca:	00003517          	auipc	a0,0x3
    33ce:	79650513          	addi	a0,a0,1942 # 6b60 <malloc+0x19d0>
    33d2:	13f010ef          	jal	ra,4d10 <mkdir>
    33d6:	e53d                	bnez	a0,3444 <rmdot+0x86>
  if(chdir("dots") != 0){
    33d8:	00003517          	auipc	a0,0x3
    33dc:	78850513          	addi	a0,a0,1928 # 6b60 <malloc+0x19d0>
    33e0:	139010ef          	jal	ra,4d18 <chdir>
    33e4:	e935                	bnez	a0,3458 <rmdot+0x9a>
  if(unlink(".") == 0){
    33e6:	00002517          	auipc	a0,0x2
    33ea:	5ca50513          	addi	a0,a0,1482 # 59b0 <malloc+0x820>
    33ee:	10b010ef          	jal	ra,4cf8 <unlink>
    33f2:	cd2d                	beqz	a0,346c <rmdot+0xae>
  if(unlink("..") == 0){
    33f4:	00003517          	auipc	a0,0x3
    33f8:	1bc50513          	addi	a0,a0,444 # 65b0 <malloc+0x1420>
    33fc:	0fd010ef          	jal	ra,4cf8 <unlink>
    3400:	c141                	beqz	a0,3480 <rmdot+0xc2>
  if(chdir("/") != 0){
    3402:	00003517          	auipc	a0,0x3
    3406:	15650513          	addi	a0,a0,342 # 6558 <malloc+0x13c8>
    340a:	10f010ef          	jal	ra,4d18 <chdir>
    340e:	e159                	bnez	a0,3494 <rmdot+0xd6>
  if(unlink("dots/.") == 0){
    3410:	00003517          	auipc	a0,0x3
    3414:	7b850513          	addi	a0,a0,1976 # 6bc8 <malloc+0x1a38>
    3418:	0e1010ef          	jal	ra,4cf8 <unlink>
    341c:	c551                	beqz	a0,34a8 <rmdot+0xea>
  if(unlink("dots/..") == 0){
    341e:	00003517          	auipc	a0,0x3
    3422:	7d250513          	addi	a0,a0,2002 # 6bf0 <malloc+0x1a60>
    3426:	0d3010ef          	jal	ra,4cf8 <unlink>
    342a:	c949                	beqz	a0,34bc <rmdot+0xfe>
  if(unlink("dots") != 0){
    342c:	00003517          	auipc	a0,0x3
    3430:	73450513          	addi	a0,a0,1844 # 6b60 <malloc+0x19d0>
    3434:	0c5010ef          	jal	ra,4cf8 <unlink>
    3438:	ed41                	bnez	a0,34d0 <rmdot+0x112>
}
    343a:	60e2                	ld	ra,24(sp)
    343c:	6442                	ld	s0,16(sp)
    343e:	64a2                	ld	s1,8(sp)
    3440:	6105                	addi	sp,sp,32
    3442:	8082                	ret
    printf("%s: mkdir dots failed\n", s);
    3444:	85a6                	mv	a1,s1
    3446:	00003517          	auipc	a0,0x3
    344a:	72250513          	addi	a0,a0,1826 # 6b68 <malloc+0x19d8>
    344e:	489010ef          	jal	ra,50d6 <printf>
    exit(1);
    3452:	4505                	li	a0,1
    3454:	055010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dots failed\n", s);
    3458:	85a6                	mv	a1,s1
    345a:	00003517          	auipc	a0,0x3
    345e:	72650513          	addi	a0,a0,1830 # 6b80 <malloc+0x19f0>
    3462:	475010ef          	jal	ra,50d6 <printf>
    exit(1);
    3466:	4505                	li	a0,1
    3468:	041010ef          	jal	ra,4ca8 <exit>
    printf("%s: rm . worked!\n", s);
    346c:	85a6                	mv	a1,s1
    346e:	00003517          	auipc	a0,0x3
    3472:	72a50513          	addi	a0,a0,1834 # 6b98 <malloc+0x1a08>
    3476:	461010ef          	jal	ra,50d6 <printf>
    exit(1);
    347a:	4505                	li	a0,1
    347c:	02d010ef          	jal	ra,4ca8 <exit>
    printf("%s: rm .. worked!\n", s);
    3480:	85a6                	mv	a1,s1
    3482:	00003517          	auipc	a0,0x3
    3486:	72e50513          	addi	a0,a0,1838 # 6bb0 <malloc+0x1a20>
    348a:	44d010ef          	jal	ra,50d6 <printf>
    exit(1);
    348e:	4505                	li	a0,1
    3490:	019010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir / failed\n", s);
    3494:	85a6                	mv	a1,s1
    3496:	00003517          	auipc	a0,0x3
    349a:	0ca50513          	addi	a0,a0,202 # 6560 <malloc+0x13d0>
    349e:	439010ef          	jal	ra,50d6 <printf>
    exit(1);
    34a2:	4505                	li	a0,1
    34a4:	005010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dots/. worked!\n", s);
    34a8:	85a6                	mv	a1,s1
    34aa:	00003517          	auipc	a0,0x3
    34ae:	72650513          	addi	a0,a0,1830 # 6bd0 <malloc+0x1a40>
    34b2:	425010ef          	jal	ra,50d6 <printf>
    exit(1);
    34b6:	4505                	li	a0,1
    34b8:	7f0010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dots/.. worked!\n", s);
    34bc:	85a6                	mv	a1,s1
    34be:	00003517          	auipc	a0,0x3
    34c2:	73a50513          	addi	a0,a0,1850 # 6bf8 <malloc+0x1a68>
    34c6:	411010ef          	jal	ra,50d6 <printf>
    exit(1);
    34ca:	4505                	li	a0,1
    34cc:	7dc010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dots failed!\n", s);
    34d0:	85a6                	mv	a1,s1
    34d2:	00003517          	auipc	a0,0x3
    34d6:	74650513          	addi	a0,a0,1862 # 6c18 <malloc+0x1a88>
    34da:	3fd010ef          	jal	ra,50d6 <printf>
    exit(1);
    34de:	4505                	li	a0,1
    34e0:	7c8010ef          	jal	ra,4ca8 <exit>

00000000000034e4 <dirfile>:
{
    34e4:	1101                	addi	sp,sp,-32
    34e6:	ec06                	sd	ra,24(sp)
    34e8:	e822                	sd	s0,16(sp)
    34ea:	e426                	sd	s1,8(sp)
    34ec:	e04a                	sd	s2,0(sp)
    34ee:	1000                	addi	s0,sp,32
    34f0:	892a                	mv	s2,a0
  fd = open("dirfile", O_CREATE);
    34f2:	20000593          	li	a1,512
    34f6:	00003517          	auipc	a0,0x3
    34fa:	74250513          	addi	a0,a0,1858 # 6c38 <malloc+0x1aa8>
    34fe:	7ea010ef          	jal	ra,4ce8 <open>
  if(fd < 0){
    3502:	0c054563          	bltz	a0,35cc <dirfile+0xe8>
  close(fd);
    3506:	7ca010ef          	jal	ra,4cd0 <close>
  if(chdir("dirfile") == 0){
    350a:	00003517          	auipc	a0,0x3
    350e:	72e50513          	addi	a0,a0,1838 # 6c38 <malloc+0x1aa8>
    3512:	007010ef          	jal	ra,4d18 <chdir>
    3516:	c569                	beqz	a0,35e0 <dirfile+0xfc>
  fd = open("dirfile/xx", 0);
    3518:	4581                	li	a1,0
    351a:	00003517          	auipc	a0,0x3
    351e:	76650513          	addi	a0,a0,1894 # 6c80 <malloc+0x1af0>
    3522:	7c6010ef          	jal	ra,4ce8 <open>
  if(fd >= 0){
    3526:	0c055763          	bgez	a0,35f4 <dirfile+0x110>
  fd = open("dirfile/xx", O_CREATE);
    352a:	20000593          	li	a1,512
    352e:	00003517          	auipc	a0,0x3
    3532:	75250513          	addi	a0,a0,1874 # 6c80 <malloc+0x1af0>
    3536:	7b2010ef          	jal	ra,4ce8 <open>
  if(fd >= 0){
    353a:	0c055763          	bgez	a0,3608 <dirfile+0x124>
  if(mkdir("dirfile/xx") == 0){
    353e:	00003517          	auipc	a0,0x3
    3542:	74250513          	addi	a0,a0,1858 # 6c80 <malloc+0x1af0>
    3546:	7ca010ef          	jal	ra,4d10 <mkdir>
    354a:	0c050963          	beqz	a0,361c <dirfile+0x138>
  if(unlink("dirfile/xx") == 0){
    354e:	00003517          	auipc	a0,0x3
    3552:	73250513          	addi	a0,a0,1842 # 6c80 <malloc+0x1af0>
    3556:	7a2010ef          	jal	ra,4cf8 <unlink>
    355a:	0c050b63          	beqz	a0,3630 <dirfile+0x14c>
  if(link("README", "dirfile/xx") == 0){
    355e:	00003597          	auipc	a1,0x3
    3562:	72258593          	addi	a1,a1,1826 # 6c80 <malloc+0x1af0>
    3566:	00002517          	auipc	a0,0x2
    356a:	f3a50513          	addi	a0,a0,-198 # 54a0 <malloc+0x310>
    356e:	79a010ef          	jal	ra,4d08 <link>
    3572:	0c050963          	beqz	a0,3644 <dirfile+0x160>
  if(unlink("dirfile") != 0){
    3576:	00003517          	auipc	a0,0x3
    357a:	6c250513          	addi	a0,a0,1730 # 6c38 <malloc+0x1aa8>
    357e:	77a010ef          	jal	ra,4cf8 <unlink>
    3582:	0c051b63          	bnez	a0,3658 <dirfile+0x174>
  fd = open(".", O_RDWR);
    3586:	4589                	li	a1,2
    3588:	00002517          	auipc	a0,0x2
    358c:	42850513          	addi	a0,a0,1064 # 59b0 <malloc+0x820>
    3590:	758010ef          	jal	ra,4ce8 <open>
  if(fd >= 0){
    3594:	0c055c63          	bgez	a0,366c <dirfile+0x188>
  fd = open(".", 0);
    3598:	4581                	li	a1,0
    359a:	00002517          	auipc	a0,0x2
    359e:	41650513          	addi	a0,a0,1046 # 59b0 <malloc+0x820>
    35a2:	746010ef          	jal	ra,4ce8 <open>
    35a6:	84aa                	mv	s1,a0
  if(write(fd, "x", 1) > 0){
    35a8:	4605                	li	a2,1
    35aa:	00002597          	auipc	a1,0x2
    35ae:	d8e58593          	addi	a1,a1,-626 # 5338 <malloc+0x1a8>
    35b2:	716010ef          	jal	ra,4cc8 <write>
    35b6:	0ca04563          	bgtz	a0,3680 <dirfile+0x19c>
  close(fd);
    35ba:	8526                	mv	a0,s1
    35bc:	714010ef          	jal	ra,4cd0 <close>
}
    35c0:	60e2                	ld	ra,24(sp)
    35c2:	6442                	ld	s0,16(sp)
    35c4:	64a2                	ld	s1,8(sp)
    35c6:	6902                	ld	s2,0(sp)
    35c8:	6105                	addi	sp,sp,32
    35ca:	8082                	ret
    printf("%s: create dirfile failed\n", s);
    35cc:	85ca                	mv	a1,s2
    35ce:	00003517          	auipc	a0,0x3
    35d2:	67250513          	addi	a0,a0,1650 # 6c40 <malloc+0x1ab0>
    35d6:	301010ef          	jal	ra,50d6 <printf>
    exit(1);
    35da:	4505                	li	a0,1
    35dc:	6cc010ef          	jal	ra,4ca8 <exit>
    printf("%s: chdir dirfile succeeded!\n", s);
    35e0:	85ca                	mv	a1,s2
    35e2:	00003517          	auipc	a0,0x3
    35e6:	67e50513          	addi	a0,a0,1662 # 6c60 <malloc+0x1ad0>
    35ea:	2ed010ef          	jal	ra,50d6 <printf>
    exit(1);
    35ee:	4505                	li	a0,1
    35f0:	6b8010ef          	jal	ra,4ca8 <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    35f4:	85ca                	mv	a1,s2
    35f6:	00003517          	auipc	a0,0x3
    35fa:	69a50513          	addi	a0,a0,1690 # 6c90 <malloc+0x1b00>
    35fe:	2d9010ef          	jal	ra,50d6 <printf>
    exit(1);
    3602:	4505                	li	a0,1
    3604:	6a4010ef          	jal	ra,4ca8 <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    3608:	85ca                	mv	a1,s2
    360a:	00003517          	auipc	a0,0x3
    360e:	68650513          	addi	a0,a0,1670 # 6c90 <malloc+0x1b00>
    3612:	2c5010ef          	jal	ra,50d6 <printf>
    exit(1);
    3616:	4505                	li	a0,1
    3618:	690010ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    361c:	85ca                	mv	a1,s2
    361e:	00003517          	auipc	a0,0x3
    3622:	69a50513          	addi	a0,a0,1690 # 6cb8 <malloc+0x1b28>
    3626:	2b1010ef          	jal	ra,50d6 <printf>
    exit(1);
    362a:	4505                	li	a0,1
    362c:	67c010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    3630:	85ca                	mv	a1,s2
    3632:	00003517          	auipc	a0,0x3
    3636:	6ae50513          	addi	a0,a0,1710 # 6ce0 <malloc+0x1b50>
    363a:	29d010ef          	jal	ra,50d6 <printf>
    exit(1);
    363e:	4505                	li	a0,1
    3640:	668010ef          	jal	ra,4ca8 <exit>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    3644:	85ca                	mv	a1,s2
    3646:	00003517          	auipc	a0,0x3
    364a:	6c250513          	addi	a0,a0,1730 # 6d08 <malloc+0x1b78>
    364e:	289010ef          	jal	ra,50d6 <printf>
    exit(1);
    3652:	4505                	li	a0,1
    3654:	654010ef          	jal	ra,4ca8 <exit>
    printf("%s: unlink dirfile failed!\n", s);
    3658:	85ca                	mv	a1,s2
    365a:	00003517          	auipc	a0,0x3
    365e:	6d650513          	addi	a0,a0,1750 # 6d30 <malloc+0x1ba0>
    3662:	275010ef          	jal	ra,50d6 <printf>
    exit(1);
    3666:	4505                	li	a0,1
    3668:	640010ef          	jal	ra,4ca8 <exit>
    printf("%s: open . for writing succeeded!\n", s);
    366c:	85ca                	mv	a1,s2
    366e:	00003517          	auipc	a0,0x3
    3672:	6e250513          	addi	a0,a0,1762 # 6d50 <malloc+0x1bc0>
    3676:	261010ef          	jal	ra,50d6 <printf>
    exit(1);
    367a:	4505                	li	a0,1
    367c:	62c010ef          	jal	ra,4ca8 <exit>
    printf("%s: write . succeeded!\n", s);
    3680:	85ca                	mv	a1,s2
    3682:	00003517          	auipc	a0,0x3
    3686:	6f650513          	addi	a0,a0,1782 # 6d78 <malloc+0x1be8>
    368a:	24d010ef          	jal	ra,50d6 <printf>
    exit(1);
    368e:	4505                	li	a0,1
    3690:	618010ef          	jal	ra,4ca8 <exit>

0000000000003694 <iref>:
{
    3694:	7139                	addi	sp,sp,-64
    3696:	fc06                	sd	ra,56(sp)
    3698:	f822                	sd	s0,48(sp)
    369a:	f426                	sd	s1,40(sp)
    369c:	f04a                	sd	s2,32(sp)
    369e:	ec4e                	sd	s3,24(sp)
    36a0:	e852                	sd	s4,16(sp)
    36a2:	e456                	sd	s5,8(sp)
    36a4:	e05a                	sd	s6,0(sp)
    36a6:	0080                	addi	s0,sp,64
    36a8:	8b2a                	mv	s6,a0
    36aa:	03300913          	li	s2,51
    if(mkdir("irefd") != 0){
    36ae:	00003a17          	auipc	s4,0x3
    36b2:	6e2a0a13          	addi	s4,s4,1762 # 6d90 <malloc+0x1c00>
    mkdir("");
    36b6:	00003497          	auipc	s1,0x3
    36ba:	1e248493          	addi	s1,s1,482 # 6898 <malloc+0x1708>
    link("README", "");
    36be:	00002a97          	auipc	s5,0x2
    36c2:	de2a8a93          	addi	s5,s5,-542 # 54a0 <malloc+0x310>
    fd = open("xx", O_CREATE);
    36c6:	00003997          	auipc	s3,0x3
    36ca:	5c298993          	addi	s3,s3,1474 # 6c88 <malloc+0x1af8>
    36ce:	a835                	j	370a <iref+0x76>
      printf("%s: mkdir irefd failed\n", s);
    36d0:	85da                	mv	a1,s6
    36d2:	00003517          	auipc	a0,0x3
    36d6:	6c650513          	addi	a0,a0,1734 # 6d98 <malloc+0x1c08>
    36da:	1fd010ef          	jal	ra,50d6 <printf>
      exit(1);
    36de:	4505                	li	a0,1
    36e0:	5c8010ef          	jal	ra,4ca8 <exit>
      printf("%s: chdir irefd failed\n", s);
    36e4:	85da                	mv	a1,s6
    36e6:	00003517          	auipc	a0,0x3
    36ea:	6ca50513          	addi	a0,a0,1738 # 6db0 <malloc+0x1c20>
    36ee:	1e9010ef          	jal	ra,50d6 <printf>
      exit(1);
    36f2:	4505                	li	a0,1
    36f4:	5b4010ef          	jal	ra,4ca8 <exit>
      close(fd);
    36f8:	5d8010ef          	jal	ra,4cd0 <close>
    36fc:	a82d                	j	3736 <iref+0xa2>
    unlink("xx");
    36fe:	854e                	mv	a0,s3
    3700:	5f8010ef          	jal	ra,4cf8 <unlink>
  for(i = 0; i < NINODE + 1; i++){
    3704:	397d                	addiw	s2,s2,-1
    3706:	04090263          	beqz	s2,374a <iref+0xb6>
    if(mkdir("irefd") != 0){
    370a:	8552                	mv	a0,s4
    370c:	604010ef          	jal	ra,4d10 <mkdir>
    3710:	f161                	bnez	a0,36d0 <iref+0x3c>
    if(chdir("irefd") != 0){
    3712:	8552                	mv	a0,s4
    3714:	604010ef          	jal	ra,4d18 <chdir>
    3718:	f571                	bnez	a0,36e4 <iref+0x50>
    mkdir("");
    371a:	8526                	mv	a0,s1
    371c:	5f4010ef          	jal	ra,4d10 <mkdir>
    link("README", "");
    3720:	85a6                	mv	a1,s1
    3722:	8556                	mv	a0,s5
    3724:	5e4010ef          	jal	ra,4d08 <link>
    fd = open("", O_CREATE);
    3728:	20000593          	li	a1,512
    372c:	8526                	mv	a0,s1
    372e:	5ba010ef          	jal	ra,4ce8 <open>
    if(fd >= 0)
    3732:	fc0553e3          	bgez	a0,36f8 <iref+0x64>
    fd = open("xx", O_CREATE);
    3736:	20000593          	li	a1,512
    373a:	854e                	mv	a0,s3
    373c:	5ac010ef          	jal	ra,4ce8 <open>
    if(fd >= 0)
    3740:	fa054fe3          	bltz	a0,36fe <iref+0x6a>
      close(fd);
    3744:	58c010ef          	jal	ra,4cd0 <close>
    3748:	bf5d                	j	36fe <iref+0x6a>
    374a:	03300493          	li	s1,51
    chdir("..");
    374e:	00003997          	auipc	s3,0x3
    3752:	e6298993          	addi	s3,s3,-414 # 65b0 <malloc+0x1420>
    unlink("irefd");
    3756:	00003917          	auipc	s2,0x3
    375a:	63a90913          	addi	s2,s2,1594 # 6d90 <malloc+0x1c00>
    chdir("..");
    375e:	854e                	mv	a0,s3
    3760:	5b8010ef          	jal	ra,4d18 <chdir>
    unlink("irefd");
    3764:	854a                	mv	a0,s2
    3766:	592010ef          	jal	ra,4cf8 <unlink>
  for(i = 0; i < NINODE + 1; i++){
    376a:	34fd                	addiw	s1,s1,-1
    376c:	f8ed                	bnez	s1,375e <iref+0xca>
  chdir("/");
    376e:	00003517          	auipc	a0,0x3
    3772:	dea50513          	addi	a0,a0,-534 # 6558 <malloc+0x13c8>
    3776:	5a2010ef          	jal	ra,4d18 <chdir>
}
    377a:	70e2                	ld	ra,56(sp)
    377c:	7442                	ld	s0,48(sp)
    377e:	74a2                	ld	s1,40(sp)
    3780:	7902                	ld	s2,32(sp)
    3782:	69e2                	ld	s3,24(sp)
    3784:	6a42                	ld	s4,16(sp)
    3786:	6aa2                	ld	s5,8(sp)
    3788:	6b02                	ld	s6,0(sp)
    378a:	6121                	addi	sp,sp,64
    378c:	8082                	ret

000000000000378e <openiputtest>:
{
    378e:	7179                	addi	sp,sp,-48
    3790:	f406                	sd	ra,40(sp)
    3792:	f022                	sd	s0,32(sp)
    3794:	ec26                	sd	s1,24(sp)
    3796:	1800                	addi	s0,sp,48
    3798:	84aa                	mv	s1,a0
  if(mkdir("oidir") < 0){
    379a:	00003517          	auipc	a0,0x3
    379e:	62e50513          	addi	a0,a0,1582 # 6dc8 <malloc+0x1c38>
    37a2:	56e010ef          	jal	ra,4d10 <mkdir>
    37a6:	02054a63          	bltz	a0,37da <openiputtest+0x4c>
  pid = fork();
    37aa:	4f6010ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    37ae:	04054063          	bltz	a0,37ee <openiputtest+0x60>
  if(pid == 0){
    37b2:	e939                	bnez	a0,3808 <openiputtest+0x7a>
    int fd = open("oidir", O_RDWR);
    37b4:	4589                	li	a1,2
    37b6:	00003517          	auipc	a0,0x3
    37ba:	61250513          	addi	a0,a0,1554 # 6dc8 <malloc+0x1c38>
    37be:	52a010ef          	jal	ra,4ce8 <open>
    if(fd >= 0){
    37c2:	04054063          	bltz	a0,3802 <openiputtest+0x74>
      printf("%s: open directory for write succeeded\n", s);
    37c6:	85a6                	mv	a1,s1
    37c8:	00003517          	auipc	a0,0x3
    37cc:	62050513          	addi	a0,a0,1568 # 6de8 <malloc+0x1c58>
    37d0:	107010ef          	jal	ra,50d6 <printf>
      exit(1);
    37d4:	4505                	li	a0,1
    37d6:	4d2010ef          	jal	ra,4ca8 <exit>
    printf("%s: mkdir oidir failed\n", s);
    37da:	85a6                	mv	a1,s1
    37dc:	00003517          	auipc	a0,0x3
    37e0:	5f450513          	addi	a0,a0,1524 # 6dd0 <malloc+0x1c40>
    37e4:	0f3010ef          	jal	ra,50d6 <printf>
    exit(1);
    37e8:	4505                	li	a0,1
    37ea:	4be010ef          	jal	ra,4ca8 <exit>
    printf("%s: fork failed\n", s);
    37ee:	85a6                	mv	a1,s1
    37f0:	00002517          	auipc	a0,0x2
    37f4:	36850513          	addi	a0,a0,872 # 5b58 <malloc+0x9c8>
    37f8:	0df010ef          	jal	ra,50d6 <printf>
    exit(1);
    37fc:	4505                	li	a0,1
    37fe:	4aa010ef          	jal	ra,4ca8 <exit>
    exit(0);
    3802:	4501                	li	a0,0
    3804:	4a4010ef          	jal	ra,4ca8 <exit>
  sleep(1);
    3808:	4505                	li	a0,1
    380a:	52e010ef          	jal	ra,4d38 <sleep>
  if(unlink("oidir") != 0){
    380e:	00003517          	auipc	a0,0x3
    3812:	5ba50513          	addi	a0,a0,1466 # 6dc8 <malloc+0x1c38>
    3816:	4e2010ef          	jal	ra,4cf8 <unlink>
    381a:	c919                	beqz	a0,3830 <openiputtest+0xa2>
    printf("%s: unlink failed\n", s);
    381c:	85a6                	mv	a1,s1
    381e:	00002517          	auipc	a0,0x2
    3822:	52a50513          	addi	a0,a0,1322 # 5d48 <malloc+0xbb8>
    3826:	0b1010ef          	jal	ra,50d6 <printf>
    exit(1);
    382a:	4505                	li	a0,1
    382c:	47c010ef          	jal	ra,4ca8 <exit>
  wait(&xstatus);
    3830:	fdc40513          	addi	a0,s0,-36
    3834:	47c010ef          	jal	ra,4cb0 <wait>
  exit(xstatus);
    3838:	fdc42503          	lw	a0,-36(s0)
    383c:	46c010ef          	jal	ra,4ca8 <exit>

0000000000003840 <forkforkfork>:
{
    3840:	1101                	addi	sp,sp,-32
    3842:	ec06                	sd	ra,24(sp)
    3844:	e822                	sd	s0,16(sp)
    3846:	e426                	sd	s1,8(sp)
    3848:	1000                	addi	s0,sp,32
    384a:	84aa                	mv	s1,a0
  unlink("stopforking");
    384c:	00003517          	auipc	a0,0x3
    3850:	5c450513          	addi	a0,a0,1476 # 6e10 <malloc+0x1c80>
    3854:	4a4010ef          	jal	ra,4cf8 <unlink>
  int pid = fork();
    3858:	448010ef          	jal	ra,4ca0 <fork>
  if(pid < 0){
    385c:	02054b63          	bltz	a0,3892 <forkforkfork+0x52>
  if(pid == 0){
    3860:	c139                	beqz	a0,38a6 <forkforkfork+0x66>
  sleep(20); // two seconds
    3862:	4551                	li	a0,20
    3864:	4d4010ef          	jal	ra,4d38 <sleep>
  close(open("stopforking", O_CREATE|O_RDWR));
    3868:	20200593          	li	a1,514
    386c:	00003517          	auipc	a0,0x3
    3870:	5a450513          	addi	a0,a0,1444 # 6e10 <malloc+0x1c80>
    3874:	474010ef          	jal	ra,4ce8 <open>
    3878:	458010ef          	jal	ra,4cd0 <close>
  wait(0);
    387c:	4501                	li	a0,0
    387e:	432010ef          	jal	ra,4cb0 <wait>
  sleep(10); // one second
    3882:	4529                	li	a0,10
    3884:	4b4010ef          	jal	ra,4d38 <sleep>
}
    3888:	60e2                	ld	ra,24(sp)
    388a:	6442                	ld	s0,16(sp)
    388c:	64a2                	ld	s1,8(sp)
    388e:	6105                	addi	sp,sp,32
    3890:	8082                	ret
    printf("%s: fork failed", s);
    3892:	85a6                	mv	a1,s1
    3894:	00002517          	auipc	a0,0x2
    3898:	48450513          	addi	a0,a0,1156 # 5d18 <malloc+0xb88>
    389c:	03b010ef          	jal	ra,50d6 <printf>
    exit(1);
    38a0:	4505                	li	a0,1
    38a2:	406010ef          	jal	ra,4ca8 <exit>
      int fd = open("stopforking", 0);
    38a6:	00003497          	auipc	s1,0x3
    38aa:	56a48493          	addi	s1,s1,1386 # 6e10 <malloc+0x1c80>
    38ae:	4581                	li	a1,0
    38b0:	8526                	mv	a0,s1
    38b2:	436010ef          	jal	ra,4ce8 <open>
      if(fd >= 0){
    38b6:	00055e63          	bgez	a0,38d2 <forkforkfork+0x92>
      if(fork() < 0){
    38ba:	3e6010ef          	jal	ra,4ca0 <fork>
    38be:	fe0558e3          	bgez	a0,38ae <forkforkfork+0x6e>
        close(open("stopforking", O_CREATE|O_RDWR));
    38c2:	20200593          	li	a1,514
    38c6:	8526                	mv	a0,s1
    38c8:	420010ef          	jal	ra,4ce8 <open>
    38cc:	404010ef          	jal	ra,4cd0 <close>
    38d0:	bff9                	j	38ae <forkforkfork+0x6e>
        exit(0);
    38d2:	4501                	li	a0,0
    38d4:	3d4010ef          	jal	ra,4ca8 <exit>

00000000000038d8 <killstatus>:
{
    38d8:	7139                	addi	sp,sp,-64
    38da:	fc06                	sd	ra,56(sp)
    38dc:	f822                	sd	s0,48(sp)
    38de:	f426                	sd	s1,40(sp)
    38e0:	f04a                	sd	s2,32(sp)
    38e2:	ec4e                	sd	s3,24(sp)
    38e4:	e852                	sd	s4,16(sp)
    38e6:	0080                	addi	s0,sp,64
    38e8:	8a2a                	mv	s4,a0
    38ea:	06400913          	li	s2,100
    if(xst != -1) {
    38ee:	59fd                	li	s3,-1
    int pid1 = fork();
    38f0:	3b0010ef          	jal	ra,4ca0 <fork>
    38f4:	84aa                	mv	s1,a0
    if(pid1 < 0){
    38f6:	02054763          	bltz	a0,3924 <killstatus+0x4c>
    if(pid1 == 0){
    38fa:	cd1d                	beqz	a0,3938 <killstatus+0x60>
    sleep(1);
    38fc:	4505                	li	a0,1
    38fe:	43a010ef          	jal	ra,4d38 <sleep>
    kill(pid1);
    3902:	8526                	mv	a0,s1
    3904:	3d4010ef          	jal	ra,4cd8 <kill>
    wait(&xst);
    3908:	fcc40513          	addi	a0,s0,-52
    390c:	3a4010ef          	jal	ra,4cb0 <wait>
    if(xst != -1) {
    3910:	fcc42783          	lw	a5,-52(s0)
    3914:	03379563          	bne	a5,s3,393e <killstatus+0x66>
  for(int i = 0; i < 100; i++){
    3918:	397d                	addiw	s2,s2,-1
    391a:	fc091be3          	bnez	s2,38f0 <killstatus+0x18>
  exit(0);
    391e:	4501                	li	a0,0
    3920:	388010ef          	jal	ra,4ca8 <exit>
      printf("%s: fork failed\n", s);
    3924:	85d2                	mv	a1,s4
    3926:	00002517          	auipc	a0,0x2
    392a:	23250513          	addi	a0,a0,562 # 5b58 <malloc+0x9c8>
    392e:	7a8010ef          	jal	ra,50d6 <printf>
      exit(1);
    3932:	4505                	li	a0,1
    3934:	374010ef          	jal	ra,4ca8 <exit>
        getpid();
    3938:	3f0010ef          	jal	ra,4d28 <getpid>
      while(1) {
    393c:	bff5                	j	3938 <killstatus+0x60>
       printf("%s: status should be -1\n", s);
    393e:	85d2                	mv	a1,s4
    3940:	00003517          	auipc	a0,0x3
    3944:	4e050513          	addi	a0,a0,1248 # 6e20 <malloc+0x1c90>
    3948:	78e010ef          	jal	ra,50d6 <printf>
       exit(1);
    394c:	4505                	li	a0,1
    394e:	35a010ef          	jal	ra,4ca8 <exit>

0000000000003952 <preempt>:
{
    3952:	7139                	addi	sp,sp,-64
    3954:	fc06                	sd	ra,56(sp)
    3956:	f822                	sd	s0,48(sp)
    3958:	f426                	sd	s1,40(sp)
    395a:	f04a                	sd	s2,32(sp)
    395c:	ec4e                	sd	s3,24(sp)
    395e:	e852                	sd	s4,16(sp)
    3960:	0080                	addi	s0,sp,64
    3962:	892a                	mv	s2,a0
  pid1 = fork();
    3964:	33c010ef          	jal	ra,4ca0 <fork>
  if(pid1 < 0) {
    3968:	00054563          	bltz	a0,3972 <preempt+0x20>
    396c:	84aa                	mv	s1,a0
  if(pid1 == 0)
    396e:	ed01                	bnez	a0,3986 <preempt+0x34>
    for(;;)
    3970:	a001                	j	3970 <preempt+0x1e>
    printf("%s: fork failed", s);
    3972:	85ca                	mv	a1,s2
    3974:	00002517          	auipc	a0,0x2
    3978:	3a450513          	addi	a0,a0,932 # 5d18 <malloc+0xb88>
    397c:	75a010ef          	jal	ra,50d6 <printf>
    exit(1);
    3980:	4505                	li	a0,1
    3982:	326010ef          	jal	ra,4ca8 <exit>
  pid2 = fork();
    3986:	31a010ef          	jal	ra,4ca0 <fork>
    398a:	89aa                	mv	s3,a0
  if(pid2 < 0) {
    398c:	00054463          	bltz	a0,3994 <preempt+0x42>
  if(pid2 == 0)
    3990:	ed01                	bnez	a0,39a8 <preempt+0x56>
    for(;;)
    3992:	a001                	j	3992 <preempt+0x40>
    printf("%s: fork failed\n", s);
    3994:	85ca                	mv	a1,s2
    3996:	00002517          	auipc	a0,0x2
    399a:	1c250513          	addi	a0,a0,450 # 5b58 <malloc+0x9c8>
    399e:	738010ef          	jal	ra,50d6 <printf>
    exit(1);
    39a2:	4505                	li	a0,1
    39a4:	304010ef          	jal	ra,4ca8 <exit>
  pipe(pfds);
    39a8:	fc840513          	addi	a0,s0,-56
    39ac:	30c010ef          	jal	ra,4cb8 <pipe>
  pid3 = fork();
    39b0:	2f0010ef          	jal	ra,4ca0 <fork>
    39b4:	8a2a                	mv	s4,a0
  if(pid3 < 0) {
    39b6:	02054863          	bltz	a0,39e6 <preempt+0x94>
  if(pid3 == 0){
    39ba:	e921                	bnez	a0,3a0a <preempt+0xb8>
    close(pfds[0]);
    39bc:	fc842503          	lw	a0,-56(s0)
    39c0:	310010ef          	jal	ra,4cd0 <close>
    if(write(pfds[1], "x", 1) != 1)
    39c4:	4605                	li	a2,1
    39c6:	00002597          	auipc	a1,0x2
    39ca:	97258593          	addi	a1,a1,-1678 # 5338 <malloc+0x1a8>
    39ce:	fcc42503          	lw	a0,-52(s0)
    39d2:	2f6010ef          	jal	ra,4cc8 <write>
    39d6:	4785                	li	a5,1
    39d8:	02f51163          	bne	a0,a5,39fa <preempt+0xa8>
    close(pfds[1]);
    39dc:	fcc42503          	lw	a0,-52(s0)
    39e0:	2f0010ef          	jal	ra,4cd0 <close>
    for(;;)
    39e4:	a001                	j	39e4 <preempt+0x92>
     printf("%s: fork failed\n", s);
    39e6:	85ca                	mv	a1,s2
    39e8:	00002517          	auipc	a0,0x2
    39ec:	17050513          	addi	a0,a0,368 # 5b58 <malloc+0x9c8>
    39f0:	6e6010ef          	jal	ra,50d6 <printf>
     exit(1);
    39f4:	4505                	li	a0,1
    39f6:	2b2010ef          	jal	ra,4ca8 <exit>
      printf("%s: preempt write error", s);
    39fa:	85ca                	mv	a1,s2
    39fc:	00003517          	auipc	a0,0x3
    3a00:	44450513          	addi	a0,a0,1092 # 6e40 <malloc+0x1cb0>
    3a04:	6d2010ef          	jal	ra,50d6 <printf>
    3a08:	bfd1                	j	39dc <preempt+0x8a>
  close(pfds[1]);
    3a0a:	fcc42503          	lw	a0,-52(s0)
    3a0e:	2c2010ef          	jal	ra,4cd0 <close>
  if(read(pfds[0], buf, sizeof(buf)) != 1){
    3a12:	660d                	lui	a2,0x3
    3a14:	00008597          	auipc	a1,0x8
    3a18:	29458593          	addi	a1,a1,660 # bca8 <buf>
    3a1c:	fc842503          	lw	a0,-56(s0)
    3a20:	2a0010ef          	jal	ra,4cc0 <read>
    3a24:	4785                	li	a5,1
    3a26:	02f50163          	beq	a0,a5,3a48 <preempt+0xf6>
    printf("%s: preempt read error", s);
    3a2a:	85ca                	mv	a1,s2
    3a2c:	00003517          	auipc	a0,0x3
    3a30:	42c50513          	addi	a0,a0,1068 # 6e58 <malloc+0x1cc8>
    3a34:	6a2010ef          	jal	ra,50d6 <printf>
}
    3a38:	70e2                	ld	ra,56(sp)
    3a3a:	7442                	ld	s0,48(sp)
    3a3c:	74a2                	ld	s1,40(sp)
    3a3e:	7902                	ld	s2,32(sp)
    3a40:	69e2                	ld	s3,24(sp)
    3a42:	6a42                	ld	s4,16(sp)
    3a44:	6121                	addi	sp,sp,64
    3a46:	8082                	ret
  close(pfds[0]);
    3a48:	fc842503          	lw	a0,-56(s0)
    3a4c:	284010ef          	jal	ra,4cd0 <close>
  printf("kill... ");
    3a50:	00003517          	auipc	a0,0x3
    3a54:	42050513          	addi	a0,a0,1056 # 6e70 <malloc+0x1ce0>
    3a58:	67e010ef          	jal	ra,50d6 <printf>
  kill(pid1);
    3a5c:	8526                	mv	a0,s1
    3a5e:	27a010ef          	jal	ra,4cd8 <kill>
  kill(pid2);
    3a62:	854e                	mv	a0,s3
    3a64:	274010ef          	jal	ra,4cd8 <kill>
  kill(pid3);
    3a68:	8552                	mv	a0,s4
    3a6a:	26e010ef          	jal	ra,4cd8 <kill>
  printf("wait... ");
    3a6e:	00003517          	auipc	a0,0x3
    3a72:	41250513          	addi	a0,a0,1042 # 6e80 <malloc+0x1cf0>
    3a76:	660010ef          	jal	ra,50d6 <printf>
  wait(0);
    3a7a:	4501                	li	a0,0
    3a7c:	234010ef          	jal	ra,4cb0 <wait>
  wait(0);
    3a80:	4501                	li	a0,0
    3a82:	22e010ef          	jal	ra,4cb0 <wait>
  wait(0);
    3a86:	4501                	li	a0,0
    3a88:	228010ef          	jal	ra,4cb0 <wait>
    3a8c:	b775                	j	3a38 <preempt+0xe6>

0000000000003a8e <reparent>:
{
    3a8e:	7179                	addi	sp,sp,-48
    3a90:	f406                	sd	ra,40(sp)
    3a92:	f022                	sd	s0,32(sp)
    3a94:	ec26                	sd	s1,24(sp)
    3a96:	e84a                	sd	s2,16(sp)
    3a98:	e44e                	sd	s3,8(sp)
    3a9a:	e052                	sd	s4,0(sp)
    3a9c:	1800                	addi	s0,sp,48
    3a9e:	89aa                	mv	s3,a0
  int master_pid = getpid();
    3aa0:	288010ef          	jal	ra,4d28 <getpid>
    3aa4:	8a2a                	mv	s4,a0
    3aa6:	0c800913          	li	s2,200
    int pid = fork();
    3aaa:	1f6010ef          	jal	ra,4ca0 <fork>
    3aae:	84aa                	mv	s1,a0
    if(pid < 0){
    3ab0:	00054e63          	bltz	a0,3acc <reparent+0x3e>
    if(pid){
    3ab4:	c121                	beqz	a0,3af4 <reparent+0x66>
      if(wait(0) != pid){
    3ab6:	4501                	li	a0,0
    3ab8:	1f8010ef          	jal	ra,4cb0 <wait>
    3abc:	02951263          	bne	a0,s1,3ae0 <reparent+0x52>
  for(int i = 0; i < 200; i++){
    3ac0:	397d                	addiw	s2,s2,-1
    3ac2:	fe0914e3          	bnez	s2,3aaa <reparent+0x1c>
  exit(0);
    3ac6:	4501                	li	a0,0
    3ac8:	1e0010ef          	jal	ra,4ca8 <exit>
      printf("%s: fork failed\n", s);
    3acc:	85ce                	mv	a1,s3
    3ace:	00002517          	auipc	a0,0x2
    3ad2:	08a50513          	addi	a0,a0,138 # 5b58 <malloc+0x9c8>
    3ad6:	600010ef          	jal	ra,50d6 <printf>
      exit(1);
    3ada:	4505                	li	a0,1
    3adc:	1cc010ef          	jal	ra,4ca8 <exit>
        printf("%s: wait wrong pid\n", s);
    3ae0:	85ce                	mv	a1,s3
    3ae2:	00002517          	auipc	a0,0x2
    3ae6:	1fe50513          	addi	a0,a0,510 # 5ce0 <malloc+0xb50>
    3aea:	5ec010ef          	jal	ra,50d6 <printf>
        exit(1);
    3aee:	4505                	li	a0,1
    3af0:	1b8010ef          	jal	ra,4ca8 <exit>
      int pid2 = fork();
    3af4:	1ac010ef          	jal	ra,4ca0 <fork>
      if(pid2 < 0){
    3af8:	00054563          	bltz	a0,3b02 <reparent+0x74>
      exit(0);
    3afc:	4501                	li	a0,0
    3afe:	1aa010ef          	jal	ra,4ca8 <exit>
        kill(master_pid);
    3b02:	8552                	mv	a0,s4
    3b04:	1d4010ef          	jal	ra,4cd8 <kill>
        exit(1);
    3b08:	4505                	li	a0,1
    3b0a:	19e010ef          	jal	ra,4ca8 <exit>

0000000000003b0e <sbrkfail>:
{
    3b0e:	7119                	addi	sp,sp,-128
    3b10:	fc86                	sd	ra,120(sp)
    3b12:	f8a2                	sd	s0,112(sp)
    3b14:	f4a6                	sd	s1,104(sp)
    3b16:	f0ca                	sd	s2,96(sp)
    3b18:	ecce                	sd	s3,88(sp)
    3b1a:	e8d2                	sd	s4,80(sp)
    3b1c:	e4d6                	sd	s5,72(sp)
    3b1e:	0100                	addi	s0,sp,128
    3b20:	8aaa                	mv	s5,a0
  if(pipe(fds) != 0){
    3b22:	fb040513          	addi	a0,s0,-80
    3b26:	192010ef          	jal	ra,4cb8 <pipe>
    3b2a:	e901                	bnez	a0,3b3a <sbrkfail+0x2c>
    3b2c:	f8040493          	addi	s1,s0,-128
    3b30:	fa840993          	addi	s3,s0,-88
    3b34:	8926                	mv	s2,s1
    if(pids[i] != -1)
    3b36:	5a7d                	li	s4,-1
    3b38:	a0a1                	j	3b80 <sbrkfail+0x72>
    printf("%s: pipe() failed\n", s);
    3b3a:	85d6                	mv	a1,s5
    3b3c:	00002517          	auipc	a0,0x2
    3b40:	12450513          	addi	a0,a0,292 # 5c60 <malloc+0xad0>
    3b44:	592010ef          	jal	ra,50d6 <printf>
    exit(1);
    3b48:	4505                	li	a0,1
    3b4a:	15e010ef          	jal	ra,4ca8 <exit>
      sbrk(BIG - (uint64)sbrk(0));
    3b4e:	1e2010ef          	jal	ra,4d30 <sbrk>
    3b52:	064007b7          	lui	a5,0x6400
    3b56:	40a7853b          	subw	a0,a5,a0
    3b5a:	1d6010ef          	jal	ra,4d30 <sbrk>
      write(fds[1], "x", 1);
    3b5e:	4605                	li	a2,1
    3b60:	00001597          	auipc	a1,0x1
    3b64:	7d858593          	addi	a1,a1,2008 # 5338 <malloc+0x1a8>
    3b68:	fb442503          	lw	a0,-76(s0)
    3b6c:	15c010ef          	jal	ra,4cc8 <write>
      for(;;) sleep(1000);
    3b70:	3e800513          	li	a0,1000
    3b74:	1c4010ef          	jal	ra,4d38 <sleep>
    3b78:	bfe5                	j	3b70 <sbrkfail+0x62>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3b7a:	0911                	addi	s2,s2,4
    3b7c:	03390163          	beq	s2,s3,3b9e <sbrkfail+0x90>
    if((pids[i] = fork()) == 0){
    3b80:	120010ef          	jal	ra,4ca0 <fork>
    3b84:	00a92023          	sw	a0,0(s2)
    3b88:	d179                	beqz	a0,3b4e <sbrkfail+0x40>
    if(pids[i] != -1)
    3b8a:	ff4508e3          	beq	a0,s4,3b7a <sbrkfail+0x6c>
      read(fds[0], &scratch, 1);
    3b8e:	4605                	li	a2,1
    3b90:	faf40593          	addi	a1,s0,-81
    3b94:	fb042503          	lw	a0,-80(s0)
    3b98:	128010ef          	jal	ra,4cc0 <read>
    3b9c:	bff9                	j	3b7a <sbrkfail+0x6c>
  c = sbrk(PGSIZE);
    3b9e:	6505                	lui	a0,0x1
    3ba0:	190010ef          	jal	ra,4d30 <sbrk>
    3ba4:	8a2a                	mv	s4,a0
    if(pids[i] == -1)
    3ba6:	597d                	li	s2,-1
    3ba8:	a021                	j	3bb0 <sbrkfail+0xa2>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3baa:	0491                	addi	s1,s1,4
    3bac:	01348b63          	beq	s1,s3,3bc2 <sbrkfail+0xb4>
    if(pids[i] == -1)
    3bb0:	4088                	lw	a0,0(s1)
    3bb2:	ff250ce3          	beq	a0,s2,3baa <sbrkfail+0x9c>
    kill(pids[i]);
    3bb6:	122010ef          	jal	ra,4cd8 <kill>
    wait(0);
    3bba:	4501                	li	a0,0
    3bbc:	0f4010ef          	jal	ra,4cb0 <wait>
    3bc0:	b7ed                	j	3baa <sbrkfail+0x9c>
  if(c == (char*)0xffffffffffffffffL){
    3bc2:	57fd                	li	a5,-1
    3bc4:	02fa0d63          	beq	s4,a5,3bfe <sbrkfail+0xf0>
  pid = fork();
    3bc8:	0d8010ef          	jal	ra,4ca0 <fork>
    3bcc:	84aa                	mv	s1,a0
  if(pid < 0){
    3bce:	04054263          	bltz	a0,3c12 <sbrkfail+0x104>
  if(pid == 0){
    3bd2:	c931                	beqz	a0,3c26 <sbrkfail+0x118>
  wait(&xstatus);
    3bd4:	fbc40513          	addi	a0,s0,-68
    3bd8:	0d8010ef          	jal	ra,4cb0 <wait>
  if(xstatus != -1 && xstatus != 2)
    3bdc:	fbc42783          	lw	a5,-68(s0)
    3be0:	577d                	li	a4,-1
    3be2:	00e78563          	beq	a5,a4,3bec <sbrkfail+0xde>
    3be6:	4709                	li	a4,2
    3be8:	06e79d63          	bne	a5,a4,3c62 <sbrkfail+0x154>
}
    3bec:	70e6                	ld	ra,120(sp)
    3bee:	7446                	ld	s0,112(sp)
    3bf0:	74a6                	ld	s1,104(sp)
    3bf2:	7906                	ld	s2,96(sp)
    3bf4:	69e6                	ld	s3,88(sp)
    3bf6:	6a46                	ld	s4,80(sp)
    3bf8:	6aa6                	ld	s5,72(sp)
    3bfa:	6109                	addi	sp,sp,128
    3bfc:	8082                	ret
    printf("%s: failed sbrk leaked memory\n", s);
    3bfe:	85d6                	mv	a1,s5
    3c00:	00003517          	auipc	a0,0x3
    3c04:	29050513          	addi	a0,a0,656 # 6e90 <malloc+0x1d00>
    3c08:	4ce010ef          	jal	ra,50d6 <printf>
    exit(1);
    3c0c:	4505                	li	a0,1
    3c0e:	09a010ef          	jal	ra,4ca8 <exit>
    printf("%s: fork failed\n", s);
    3c12:	85d6                	mv	a1,s5
    3c14:	00002517          	auipc	a0,0x2
    3c18:	f4450513          	addi	a0,a0,-188 # 5b58 <malloc+0x9c8>
    3c1c:	4ba010ef          	jal	ra,50d6 <printf>
    exit(1);
    3c20:	4505                	li	a0,1
    3c22:	086010ef          	jal	ra,4ca8 <exit>
    a = sbrk(0);
    3c26:	4501                	li	a0,0
    3c28:	108010ef          	jal	ra,4d30 <sbrk>
    3c2c:	892a                	mv	s2,a0
    sbrk(10*BIG);
    3c2e:	3e800537          	lui	a0,0x3e800
    3c32:	0fe010ef          	jal	ra,4d30 <sbrk>
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    3c36:	87ca                	mv	a5,s2
    3c38:	3e800737          	lui	a4,0x3e800
    3c3c:	993a                	add	s2,s2,a4
    3c3e:	6705                	lui	a4,0x1
      n += *(a+i);
    3c40:	0007c683          	lbu	a3,0(a5) # 6400000 <base+0x63f1358>
    3c44:	9cb5                	addw	s1,s1,a3
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    3c46:	97ba                	add	a5,a5,a4
    3c48:	ff279ce3          	bne	a5,s2,3c40 <sbrkfail+0x132>
    printf("%s: allocate a lot of memory succeeded %d\n", s, n);
    3c4c:	8626                	mv	a2,s1
    3c4e:	85d6                	mv	a1,s5
    3c50:	00003517          	auipc	a0,0x3
    3c54:	26050513          	addi	a0,a0,608 # 6eb0 <malloc+0x1d20>
    3c58:	47e010ef          	jal	ra,50d6 <printf>
    exit(1);
    3c5c:	4505                	li	a0,1
    3c5e:	04a010ef          	jal	ra,4ca8 <exit>
    exit(1);
    3c62:	4505                	li	a0,1
    3c64:	044010ef          	jal	ra,4ca8 <exit>

0000000000003c68 <mem>:
{
    3c68:	7139                	addi	sp,sp,-64
    3c6a:	fc06                	sd	ra,56(sp)
    3c6c:	f822                	sd	s0,48(sp)
    3c6e:	f426                	sd	s1,40(sp)
    3c70:	f04a                	sd	s2,32(sp)
    3c72:	ec4e                	sd	s3,24(sp)
    3c74:	0080                	addi	s0,sp,64
    3c76:	89aa                	mv	s3,a0
  if((pid = fork()) == 0){
    3c78:	028010ef          	jal	ra,4ca0 <fork>
    m1 = 0;
    3c7c:	4481                	li	s1,0
    while((m2 = malloc(10001)) != 0){
    3c7e:	6909                	lui	s2,0x2
    3c80:	71190913          	addi	s2,s2,1809 # 2711 <more_sparse+0x5d>
  if((pid = fork()) == 0){
    3c84:	cd11                	beqz	a0,3ca0 <mem+0x38>
    wait(&xstatus);
    3c86:	fcc40513          	addi	a0,s0,-52
    3c8a:	026010ef          	jal	ra,4cb0 <wait>
    if(xstatus == -1){
    3c8e:	fcc42503          	lw	a0,-52(s0)
    3c92:	57fd                	li	a5,-1
    3c94:	04f50363          	beq	a0,a5,3cda <mem+0x72>
    exit(xstatus);
    3c98:	010010ef          	jal	ra,4ca8 <exit>
      *(char**)m2 = m1;
    3c9c:	e104                	sd	s1,0(a0)
      m1 = m2;
    3c9e:	84aa                	mv	s1,a0
    while((m2 = malloc(10001)) != 0){
    3ca0:	854a                	mv	a0,s2
    3ca2:	4ee010ef          	jal	ra,5190 <malloc>
    3ca6:	f97d                	bnez	a0,3c9c <mem+0x34>
    while(m1){
    3ca8:	c491                	beqz	s1,3cb4 <mem+0x4c>
      m2 = *(char**)m1;
    3caa:	8526                	mv	a0,s1
    3cac:	6084                	ld	s1,0(s1)
      free(m1);
    3cae:	45a010ef          	jal	ra,5108 <free>
    while(m1){
    3cb2:	fce5                	bnez	s1,3caa <mem+0x42>
    m1 = malloc(1024*20);
    3cb4:	6515                	lui	a0,0x5
    3cb6:	4da010ef          	jal	ra,5190 <malloc>
    if(m1 == 0){
    3cba:	c511                	beqz	a0,3cc6 <mem+0x5e>
    free(m1);
    3cbc:	44c010ef          	jal	ra,5108 <free>
    exit(0);
    3cc0:	4501                	li	a0,0
    3cc2:	7e7000ef          	jal	ra,4ca8 <exit>
      printf("%s: couldn't allocate mem?!!\n", s);
    3cc6:	85ce                	mv	a1,s3
    3cc8:	00003517          	auipc	a0,0x3
    3ccc:	21850513          	addi	a0,a0,536 # 6ee0 <malloc+0x1d50>
    3cd0:	406010ef          	jal	ra,50d6 <printf>
      exit(1);
    3cd4:	4505                	li	a0,1
    3cd6:	7d3000ef          	jal	ra,4ca8 <exit>
      exit(0);
    3cda:	4501                	li	a0,0
    3cdc:	7cd000ef          	jal	ra,4ca8 <exit>

0000000000003ce0 <sharedfd>:
{
    3ce0:	7159                	addi	sp,sp,-112
    3ce2:	f486                	sd	ra,104(sp)
    3ce4:	f0a2                	sd	s0,96(sp)
    3ce6:	eca6                	sd	s1,88(sp)
    3ce8:	e8ca                	sd	s2,80(sp)
    3cea:	e4ce                	sd	s3,72(sp)
    3cec:	e0d2                	sd	s4,64(sp)
    3cee:	fc56                	sd	s5,56(sp)
    3cf0:	f85a                	sd	s6,48(sp)
    3cf2:	f45e                	sd	s7,40(sp)
    3cf4:	1880                	addi	s0,sp,112
    3cf6:	8a2a                	mv	s4,a0
  unlink("sharedfd");
    3cf8:	00003517          	auipc	a0,0x3
    3cfc:	20850513          	addi	a0,a0,520 # 6f00 <malloc+0x1d70>
    3d00:	7f9000ef          	jal	ra,4cf8 <unlink>
  fd = open("sharedfd", O_CREATE|O_RDWR);
    3d04:	20200593          	li	a1,514
    3d08:	00003517          	auipc	a0,0x3
    3d0c:	1f850513          	addi	a0,a0,504 # 6f00 <malloc+0x1d70>
    3d10:	7d9000ef          	jal	ra,4ce8 <open>
  if(fd < 0){
    3d14:	04054263          	bltz	a0,3d58 <sharedfd+0x78>
    3d18:	892a                	mv	s2,a0
  pid = fork();
    3d1a:	787000ef          	jal	ra,4ca0 <fork>
    3d1e:	89aa                	mv	s3,a0
  memset(buf, pid==0?'c':'p', sizeof(buf));
    3d20:	06300593          	li	a1,99
    3d24:	c119                	beqz	a0,3d2a <sharedfd+0x4a>
    3d26:	07000593          	li	a1,112
    3d2a:	4629                	li	a2,10
    3d2c:	fa040513          	addi	a0,s0,-96
    3d30:	591000ef          	jal	ra,4ac0 <memset>
    3d34:	3e800493          	li	s1,1000
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)){
    3d38:	4629                	li	a2,10
    3d3a:	fa040593          	addi	a1,s0,-96
    3d3e:	854a                	mv	a0,s2
    3d40:	789000ef          	jal	ra,4cc8 <write>
    3d44:	47a9                	li	a5,10
    3d46:	02f51363          	bne	a0,a5,3d6c <sharedfd+0x8c>
  for(i = 0; i < N; i++){
    3d4a:	34fd                	addiw	s1,s1,-1
    3d4c:	f4f5                	bnez	s1,3d38 <sharedfd+0x58>
  if(pid == 0) {
    3d4e:	02099963          	bnez	s3,3d80 <sharedfd+0xa0>
    exit(0);
    3d52:	4501                	li	a0,0
    3d54:	755000ef          	jal	ra,4ca8 <exit>
    printf("%s: cannot open sharedfd for writing", s);
    3d58:	85d2                	mv	a1,s4
    3d5a:	00003517          	auipc	a0,0x3
    3d5e:	1b650513          	addi	a0,a0,438 # 6f10 <malloc+0x1d80>
    3d62:	374010ef          	jal	ra,50d6 <printf>
    exit(1);
    3d66:	4505                	li	a0,1
    3d68:	741000ef          	jal	ra,4ca8 <exit>
      printf("%s: write sharedfd failed\n", s);
    3d6c:	85d2                	mv	a1,s4
    3d6e:	00003517          	auipc	a0,0x3
    3d72:	1ca50513          	addi	a0,a0,458 # 6f38 <malloc+0x1da8>
    3d76:	360010ef          	jal	ra,50d6 <printf>
      exit(1);
    3d7a:	4505                	li	a0,1
    3d7c:	72d000ef          	jal	ra,4ca8 <exit>
    wait(&xstatus);
    3d80:	f9c40513          	addi	a0,s0,-100
    3d84:	72d000ef          	jal	ra,4cb0 <wait>
    if(xstatus != 0)
    3d88:	f9c42983          	lw	s3,-100(s0)
    3d8c:	00098563          	beqz	s3,3d96 <sharedfd+0xb6>
      exit(xstatus);
    3d90:	854e                	mv	a0,s3
    3d92:	717000ef          	jal	ra,4ca8 <exit>
  close(fd);
    3d96:	854a                	mv	a0,s2
    3d98:	739000ef          	jal	ra,4cd0 <close>
  fd = open("sharedfd", 0);
    3d9c:	4581                	li	a1,0
    3d9e:	00003517          	auipc	a0,0x3
    3da2:	16250513          	addi	a0,a0,354 # 6f00 <malloc+0x1d70>
    3da6:	743000ef          	jal	ra,4ce8 <open>
    3daa:	8baa                	mv	s7,a0
  nc = np = 0;
    3dac:	8ace                	mv	s5,s3
  if(fd < 0){
    3dae:	02054363          	bltz	a0,3dd4 <sharedfd+0xf4>
    3db2:	faa40913          	addi	s2,s0,-86
      if(buf[i] == 'c')
    3db6:	06300493          	li	s1,99
      if(buf[i] == 'p')
    3dba:	07000b13          	li	s6,112
  while((n = read(fd, buf, sizeof(buf))) > 0){
    3dbe:	4629                	li	a2,10
    3dc0:	fa040593          	addi	a1,s0,-96
    3dc4:	855e                	mv	a0,s7
    3dc6:	6fb000ef          	jal	ra,4cc0 <read>
    3dca:	02a05b63          	blez	a0,3e00 <sharedfd+0x120>
    3dce:	fa040793          	addi	a5,s0,-96
    3dd2:	a839                	j	3df0 <sharedfd+0x110>
    printf("%s: cannot open sharedfd for reading\n", s);
    3dd4:	85d2                	mv	a1,s4
    3dd6:	00003517          	auipc	a0,0x3
    3dda:	18250513          	addi	a0,a0,386 # 6f58 <malloc+0x1dc8>
    3dde:	2f8010ef          	jal	ra,50d6 <printf>
    exit(1);
    3de2:	4505                	li	a0,1
    3de4:	6c5000ef          	jal	ra,4ca8 <exit>
        nc++;
    3de8:	2985                	addiw	s3,s3,1
    for(i = 0; i < sizeof(buf); i++){
    3dea:	0785                	addi	a5,a5,1
    3dec:	fd2789e3          	beq	a5,s2,3dbe <sharedfd+0xde>
      if(buf[i] == 'c')
    3df0:	0007c703          	lbu	a4,0(a5)
    3df4:	fe970ae3          	beq	a4,s1,3de8 <sharedfd+0x108>
      if(buf[i] == 'p')
    3df8:	ff6719e3          	bne	a4,s6,3dea <sharedfd+0x10a>
        np++;
    3dfc:	2a85                	addiw	s5,s5,1
    3dfe:	b7f5                	j	3dea <sharedfd+0x10a>
  close(fd);
    3e00:	855e                	mv	a0,s7
    3e02:	6cf000ef          	jal	ra,4cd0 <close>
  unlink("sharedfd");
    3e06:	00003517          	auipc	a0,0x3
    3e0a:	0fa50513          	addi	a0,a0,250 # 6f00 <malloc+0x1d70>
    3e0e:	6eb000ef          	jal	ra,4cf8 <unlink>
  if(nc == N*SZ && np == N*SZ){
    3e12:	6789                	lui	a5,0x2
    3e14:	71078793          	addi	a5,a5,1808 # 2710 <more_sparse+0x5c>
    3e18:	00f99763          	bne	s3,a5,3e26 <sharedfd+0x146>
    3e1c:	6789                	lui	a5,0x2
    3e1e:	71078793          	addi	a5,a5,1808 # 2710 <more_sparse+0x5c>
    3e22:	00fa8c63          	beq	s5,a5,3e3a <sharedfd+0x15a>
    printf("%s: nc/np test fails\n", s);
    3e26:	85d2                	mv	a1,s4
    3e28:	00003517          	auipc	a0,0x3
    3e2c:	15850513          	addi	a0,a0,344 # 6f80 <malloc+0x1df0>
    3e30:	2a6010ef          	jal	ra,50d6 <printf>
    exit(1);
    3e34:	4505                	li	a0,1
    3e36:	673000ef          	jal	ra,4ca8 <exit>
    exit(0);
    3e3a:	4501                	li	a0,0
    3e3c:	66d000ef          	jal	ra,4ca8 <exit>

0000000000003e40 <fourfiles>:
{
    3e40:	7171                	addi	sp,sp,-176
    3e42:	f506                	sd	ra,168(sp)
    3e44:	f122                	sd	s0,160(sp)
    3e46:	ed26                	sd	s1,152(sp)
    3e48:	e94a                	sd	s2,144(sp)
    3e4a:	e54e                	sd	s3,136(sp)
    3e4c:	e152                	sd	s4,128(sp)
    3e4e:	fcd6                	sd	s5,120(sp)
    3e50:	f8da                	sd	s6,112(sp)
    3e52:	f4de                	sd	s7,104(sp)
    3e54:	f0e2                	sd	s8,96(sp)
    3e56:	ece6                	sd	s9,88(sp)
    3e58:	e8ea                	sd	s10,80(sp)
    3e5a:	e4ee                	sd	s11,72(sp)
    3e5c:	1900                	addi	s0,sp,176
    3e5e:	f4a43c23          	sd	a0,-168(s0)
  char *names[] = { "f0", "f1", "f2", "f3" };
    3e62:	00001797          	auipc	a5,0x1
    3e66:	40e78793          	addi	a5,a5,1038 # 5270 <malloc+0xe0>
    3e6a:	f6f43823          	sd	a5,-144(s0)
    3e6e:	00001797          	auipc	a5,0x1
    3e72:	40a78793          	addi	a5,a5,1034 # 5278 <malloc+0xe8>
    3e76:	f6f43c23          	sd	a5,-136(s0)
    3e7a:	00001797          	auipc	a5,0x1
    3e7e:	40678793          	addi	a5,a5,1030 # 5280 <malloc+0xf0>
    3e82:	f8f43023          	sd	a5,-128(s0)
    3e86:	00001797          	auipc	a5,0x1
    3e8a:	40278793          	addi	a5,a5,1026 # 5288 <malloc+0xf8>
    3e8e:	f8f43423          	sd	a5,-120(s0)
  for(pi = 0; pi < NCHILD; pi++){
    3e92:	f7040c13          	addi	s8,s0,-144
  char *names[] = { "f0", "f1", "f2", "f3" };
    3e96:	8962                	mv	s2,s8
  for(pi = 0; pi < NCHILD; pi++){
    3e98:	4481                	li	s1,0
    3e9a:	4a11                	li	s4,4
    fname = names[pi];
    3e9c:	00093983          	ld	s3,0(s2)
    unlink(fname);
    3ea0:	854e                	mv	a0,s3
    3ea2:	657000ef          	jal	ra,4cf8 <unlink>
    pid = fork();
    3ea6:	5fb000ef          	jal	ra,4ca0 <fork>
    if(pid < 0){
    3eaa:	04054263          	bltz	a0,3eee <fourfiles+0xae>
    if(pid == 0){
    3eae:	c939                	beqz	a0,3f04 <fourfiles+0xc4>
  for(pi = 0; pi < NCHILD; pi++){
    3eb0:	2485                	addiw	s1,s1,1
    3eb2:	0921                	addi	s2,s2,8
    3eb4:	ff4494e3          	bne	s1,s4,3e9c <fourfiles+0x5c>
    3eb8:	4491                	li	s1,4
    wait(&xstatus);
    3eba:	f6c40513          	addi	a0,s0,-148
    3ebe:	5f3000ef          	jal	ra,4cb0 <wait>
    if(xstatus != 0)
    3ec2:	f6c42b03          	lw	s6,-148(s0)
    3ec6:	0a0b1a63          	bnez	s6,3f7a <fourfiles+0x13a>
  for(pi = 0; pi < NCHILD; pi++){
    3eca:	34fd                	addiw	s1,s1,-1
    3ecc:	f4fd                	bnez	s1,3eba <fourfiles+0x7a>
    3ece:	03000b93          	li	s7,48
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3ed2:	00008a17          	auipc	s4,0x8
    3ed6:	dd6a0a13          	addi	s4,s4,-554 # bca8 <buf>
    3eda:	00008a97          	auipc	s5,0x8
    3ede:	dcfa8a93          	addi	s5,s5,-561 # bca9 <buf+0x1>
    if(total != N*SZ){
    3ee2:	6d85                	lui	s11,0x1
    3ee4:	770d8d93          	addi	s11,s11,1904 # 1770 <forkfork+0x48>
  for(i = 0; i < NCHILD; i++){
    3ee8:	03400d13          	li	s10,52
    3eec:	a8dd                	j	3fe2 <fourfiles+0x1a2>
      printf("%s: fork failed\n", s);
    3eee:	f5843583          	ld	a1,-168(s0)
    3ef2:	00002517          	auipc	a0,0x2
    3ef6:	c6650513          	addi	a0,a0,-922 # 5b58 <malloc+0x9c8>
    3efa:	1dc010ef          	jal	ra,50d6 <printf>
      exit(1);
    3efe:	4505                	li	a0,1
    3f00:	5a9000ef          	jal	ra,4ca8 <exit>
      fd = open(fname, O_CREATE | O_RDWR);
    3f04:	20200593          	li	a1,514
    3f08:	854e                	mv	a0,s3
    3f0a:	5df000ef          	jal	ra,4ce8 <open>
    3f0e:	892a                	mv	s2,a0
      if(fd < 0){
    3f10:	04054163          	bltz	a0,3f52 <fourfiles+0x112>
      memset(buf, '0'+pi, SZ);
    3f14:	1f400613          	li	a2,500
    3f18:	0304859b          	addiw	a1,s1,48
    3f1c:	00008517          	auipc	a0,0x8
    3f20:	d8c50513          	addi	a0,a0,-628 # bca8 <buf>
    3f24:	39d000ef          	jal	ra,4ac0 <memset>
    3f28:	44b1                	li	s1,12
        if((n = write(fd, buf, SZ)) != SZ){
    3f2a:	00008997          	auipc	s3,0x8
    3f2e:	d7e98993          	addi	s3,s3,-642 # bca8 <buf>
    3f32:	1f400613          	li	a2,500
    3f36:	85ce                	mv	a1,s3
    3f38:	854a                	mv	a0,s2
    3f3a:	58f000ef          	jal	ra,4cc8 <write>
    3f3e:	85aa                	mv	a1,a0
    3f40:	1f400793          	li	a5,500
    3f44:	02f51263          	bne	a0,a5,3f68 <fourfiles+0x128>
      for(i = 0; i < N; i++){
    3f48:	34fd                	addiw	s1,s1,-1
    3f4a:	f4e5                	bnez	s1,3f32 <fourfiles+0xf2>
      exit(0);
    3f4c:	4501                	li	a0,0
    3f4e:	55b000ef          	jal	ra,4ca8 <exit>
        printf("%s: create failed\n", s);
    3f52:	f5843583          	ld	a1,-168(s0)
    3f56:	00002517          	auipc	a0,0x2
    3f5a:	c9a50513          	addi	a0,a0,-870 # 5bf0 <malloc+0xa60>
    3f5e:	178010ef          	jal	ra,50d6 <printf>
        exit(1);
    3f62:	4505                	li	a0,1
    3f64:	545000ef          	jal	ra,4ca8 <exit>
          printf("write failed %d\n", n);
    3f68:	00003517          	auipc	a0,0x3
    3f6c:	03050513          	addi	a0,a0,48 # 6f98 <malloc+0x1e08>
    3f70:	166010ef          	jal	ra,50d6 <printf>
          exit(1);
    3f74:	4505                	li	a0,1
    3f76:	533000ef          	jal	ra,4ca8 <exit>
      exit(xstatus);
    3f7a:	855a                	mv	a0,s6
    3f7c:	52d000ef          	jal	ra,4ca8 <exit>
          printf("%s: wrong char\n", s);
    3f80:	f5843583          	ld	a1,-168(s0)
    3f84:	00003517          	auipc	a0,0x3
    3f88:	02c50513          	addi	a0,a0,44 # 6fb0 <malloc+0x1e20>
    3f8c:	14a010ef          	jal	ra,50d6 <printf>
          exit(1);
    3f90:	4505                	li	a0,1
    3f92:	517000ef          	jal	ra,4ca8 <exit>
      total += n;
    3f96:	00a9093b          	addw	s2,s2,a0
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3f9a:	660d                	lui	a2,0x3
    3f9c:	85d2                	mv	a1,s4
    3f9e:	854e                	mv	a0,s3
    3fa0:	521000ef          	jal	ra,4cc0 <read>
    3fa4:	02a05363          	blez	a0,3fca <fourfiles+0x18a>
    3fa8:	00008797          	auipc	a5,0x8
    3fac:	d0078793          	addi	a5,a5,-768 # bca8 <buf>
    3fb0:	fff5069b          	addiw	a3,a0,-1
    3fb4:	1682                	slli	a3,a3,0x20
    3fb6:	9281                	srli	a3,a3,0x20
    3fb8:	96d6                	add	a3,a3,s5
        if(buf[j] != '0'+i){
    3fba:	0007c703          	lbu	a4,0(a5)
    3fbe:	fc9711e3          	bne	a4,s1,3f80 <fourfiles+0x140>
      for(j = 0; j < n; j++){
    3fc2:	0785                	addi	a5,a5,1
    3fc4:	fed79be3          	bne	a5,a3,3fba <fourfiles+0x17a>
    3fc8:	b7f9                	j	3f96 <fourfiles+0x156>
    close(fd);
    3fca:	854e                	mv	a0,s3
    3fcc:	505000ef          	jal	ra,4cd0 <close>
    if(total != N*SZ){
    3fd0:	03b91463          	bne	s2,s11,3ff8 <fourfiles+0x1b8>
    unlink(fname);
    3fd4:	8566                	mv	a0,s9
    3fd6:	523000ef          	jal	ra,4cf8 <unlink>
  for(i = 0; i < NCHILD; i++){
    3fda:	0c21                	addi	s8,s8,8
    3fdc:	2b85                	addiw	s7,s7,1
    3fde:	03ab8763          	beq	s7,s10,400c <fourfiles+0x1cc>
    fname = names[i];
    3fe2:	000c3c83          	ld	s9,0(s8)
    fd = open(fname, 0);
    3fe6:	4581                	li	a1,0
    3fe8:	8566                	mv	a0,s9
    3fea:	4ff000ef          	jal	ra,4ce8 <open>
    3fee:	89aa                	mv	s3,a0
    total = 0;
    3ff0:	895a                	mv	s2,s6
        if(buf[j] != '0'+i){
    3ff2:	000b849b          	sext.w	s1,s7
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3ff6:	b755                	j	3f9a <fourfiles+0x15a>
      printf("wrong length %d\n", total);
    3ff8:	85ca                	mv	a1,s2
    3ffa:	00003517          	auipc	a0,0x3
    3ffe:	fc650513          	addi	a0,a0,-58 # 6fc0 <malloc+0x1e30>
    4002:	0d4010ef          	jal	ra,50d6 <printf>
      exit(1);
    4006:	4505                	li	a0,1
    4008:	4a1000ef          	jal	ra,4ca8 <exit>
}
    400c:	70aa                	ld	ra,168(sp)
    400e:	740a                	ld	s0,160(sp)
    4010:	64ea                	ld	s1,152(sp)
    4012:	694a                	ld	s2,144(sp)
    4014:	69aa                	ld	s3,136(sp)
    4016:	6a0a                	ld	s4,128(sp)
    4018:	7ae6                	ld	s5,120(sp)
    401a:	7b46                	ld	s6,112(sp)
    401c:	7ba6                	ld	s7,104(sp)
    401e:	7c06                	ld	s8,96(sp)
    4020:	6ce6                	ld	s9,88(sp)
    4022:	6d46                	ld	s10,80(sp)
    4024:	6da6                	ld	s11,72(sp)
    4026:	614d                	addi	sp,sp,176
    4028:	8082                	ret

000000000000402a <concreate>:
{
    402a:	7135                	addi	sp,sp,-160
    402c:	ed06                	sd	ra,152(sp)
    402e:	e922                	sd	s0,144(sp)
    4030:	e526                	sd	s1,136(sp)
    4032:	e14a                	sd	s2,128(sp)
    4034:	fcce                	sd	s3,120(sp)
    4036:	f8d2                	sd	s4,112(sp)
    4038:	f4d6                	sd	s5,104(sp)
    403a:	f0da                	sd	s6,96(sp)
    403c:	ecde                	sd	s7,88(sp)
    403e:	1100                	addi	s0,sp,160
    4040:	89aa                	mv	s3,a0
  file[0] = 'C';
    4042:	04300793          	li	a5,67
    4046:	faf40423          	sb	a5,-88(s0)
  file[2] = '\0';
    404a:	fa040523          	sb	zero,-86(s0)
  for(i = 0; i < N; i++){
    404e:	4901                	li	s2,0
    if(pid && (i % 3) == 1){
    4050:	4b0d                	li	s6,3
    4052:	4a85                	li	s5,1
      link("C0", file);
    4054:	00003b97          	auipc	s7,0x3
    4058:	f84b8b93          	addi	s7,s7,-124 # 6fd8 <malloc+0x1e48>
  for(i = 0; i < N; i++){
    405c:	02800a13          	li	s4,40
    4060:	a415                	j	4284 <concreate+0x25a>
      link("C0", file);
    4062:	fa840593          	addi	a1,s0,-88
    4066:	855e                	mv	a0,s7
    4068:	4a1000ef          	jal	ra,4d08 <link>
    if(pid == 0) {
    406c:	a409                	j	426e <concreate+0x244>
    } else if(pid == 0 && (i % 5) == 1){
    406e:	4795                	li	a5,5
    4070:	02f9693b          	remw	s2,s2,a5
    4074:	4785                	li	a5,1
    4076:	02f90563          	beq	s2,a5,40a0 <concreate+0x76>
      fd = open(file, O_CREATE | O_RDWR);
    407a:	20200593          	li	a1,514
    407e:	fa840513          	addi	a0,s0,-88
    4082:	467000ef          	jal	ra,4ce8 <open>
      if(fd < 0){
    4086:	1c055f63          	bgez	a0,4264 <concreate+0x23a>
        printf("concreate create %s failed\n", file);
    408a:	fa840593          	addi	a1,s0,-88
    408e:	00003517          	auipc	a0,0x3
    4092:	f5250513          	addi	a0,a0,-174 # 6fe0 <malloc+0x1e50>
    4096:	040010ef          	jal	ra,50d6 <printf>
        exit(1);
    409a:	4505                	li	a0,1
    409c:	40d000ef          	jal	ra,4ca8 <exit>
      link("C0", file);
    40a0:	fa840593          	addi	a1,s0,-88
    40a4:	00003517          	auipc	a0,0x3
    40a8:	f3450513          	addi	a0,a0,-204 # 6fd8 <malloc+0x1e48>
    40ac:	45d000ef          	jal	ra,4d08 <link>
      exit(0);
    40b0:	4501                	li	a0,0
    40b2:	3f7000ef          	jal	ra,4ca8 <exit>
        exit(1);
    40b6:	4505                	li	a0,1
    40b8:	3f1000ef          	jal	ra,4ca8 <exit>
  memset(fa, 0, sizeof(fa));
    40bc:	02800613          	li	a2,40
    40c0:	4581                	li	a1,0
    40c2:	f8040513          	addi	a0,s0,-128
    40c6:	1fb000ef          	jal	ra,4ac0 <memset>
  fd = open(".", 0);
    40ca:	4581                	li	a1,0
    40cc:	00002517          	auipc	a0,0x2
    40d0:	8e450513          	addi	a0,a0,-1820 # 59b0 <malloc+0x820>
    40d4:	415000ef          	jal	ra,4ce8 <open>
    40d8:	892a                	mv	s2,a0
  n = 0;
    40da:	8aa6                	mv	s5,s1
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    40dc:	04300a13          	li	s4,67
      if(i < 0 || i >= sizeof(fa)){
    40e0:	02700b13          	li	s6,39
      fa[i] = 1;
    40e4:	4b85                	li	s7,1
  while(read(fd, &de, sizeof(de)) > 0){
    40e6:	4641                	li	a2,16
    40e8:	f7040593          	addi	a1,s0,-144
    40ec:	854a                	mv	a0,s2
    40ee:	3d3000ef          	jal	ra,4cc0 <read>
    40f2:	06a05963          	blez	a0,4164 <concreate+0x13a>
    if(de.inum == 0)
    40f6:	f7045783          	lhu	a5,-144(s0)
    40fa:	d7f5                	beqz	a5,40e6 <concreate+0xbc>
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    40fc:	f7244783          	lbu	a5,-142(s0)
    4100:	ff4793e3          	bne	a5,s4,40e6 <concreate+0xbc>
    4104:	f7444783          	lbu	a5,-140(s0)
    4108:	fff9                	bnez	a5,40e6 <concreate+0xbc>
      i = de.name[1] - '0';
    410a:	f7344783          	lbu	a5,-141(s0)
    410e:	fd07879b          	addiw	a5,a5,-48
    4112:	0007871b          	sext.w	a4,a5
      if(i < 0 || i >= sizeof(fa)){
    4116:	00eb6f63          	bltu	s6,a4,4134 <concreate+0x10a>
      if(fa[i]){
    411a:	fb040793          	addi	a5,s0,-80
    411e:	97ba                	add	a5,a5,a4
    4120:	fd07c783          	lbu	a5,-48(a5)
    4124:	e785                	bnez	a5,414c <concreate+0x122>
      fa[i] = 1;
    4126:	fb040793          	addi	a5,s0,-80
    412a:	973e                	add	a4,a4,a5
    412c:	fd770823          	sb	s7,-48(a4) # fd0 <bigdir+0x130>
      n++;
    4130:	2a85                	addiw	s5,s5,1
    4132:	bf55                	j	40e6 <concreate+0xbc>
        printf("%s: concreate weird file %s\n", s, de.name);
    4134:	f7240613          	addi	a2,s0,-142
    4138:	85ce                	mv	a1,s3
    413a:	00003517          	auipc	a0,0x3
    413e:	ec650513          	addi	a0,a0,-314 # 7000 <malloc+0x1e70>
    4142:	795000ef          	jal	ra,50d6 <printf>
        exit(1);
    4146:	4505                	li	a0,1
    4148:	361000ef          	jal	ra,4ca8 <exit>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    414c:	f7240613          	addi	a2,s0,-142
    4150:	85ce                	mv	a1,s3
    4152:	00003517          	auipc	a0,0x3
    4156:	ece50513          	addi	a0,a0,-306 # 7020 <malloc+0x1e90>
    415a:	77d000ef          	jal	ra,50d6 <printf>
        exit(1);
    415e:	4505                	li	a0,1
    4160:	349000ef          	jal	ra,4ca8 <exit>
  close(fd);
    4164:	854a                	mv	a0,s2
    4166:	36b000ef          	jal	ra,4cd0 <close>
  if(n != N){
    416a:	02800793          	li	a5,40
    416e:	00fa9763          	bne	s5,a5,417c <concreate+0x152>
    if(((i % 3) == 0 && pid == 0) ||
    4172:	4a8d                	li	s5,3
    4174:	4b05                	li	s6,1
  for(i = 0; i < N; i++){
    4176:	02800a13          	li	s4,40
    417a:	a079                	j	4208 <concreate+0x1de>
    printf("%s: concreate not enough files in directory listing\n", s);
    417c:	85ce                	mv	a1,s3
    417e:	00003517          	auipc	a0,0x3
    4182:	eca50513          	addi	a0,a0,-310 # 7048 <malloc+0x1eb8>
    4186:	751000ef          	jal	ra,50d6 <printf>
    exit(1);
    418a:	4505                	li	a0,1
    418c:	31d000ef          	jal	ra,4ca8 <exit>
      printf("%s: fork failed\n", s);
    4190:	85ce                	mv	a1,s3
    4192:	00002517          	auipc	a0,0x2
    4196:	9c650513          	addi	a0,a0,-1594 # 5b58 <malloc+0x9c8>
    419a:	73d000ef          	jal	ra,50d6 <printf>
      exit(1);
    419e:	4505                	li	a0,1
    41a0:	309000ef          	jal	ra,4ca8 <exit>
      close(open(file, 0));
    41a4:	4581                	li	a1,0
    41a6:	fa840513          	addi	a0,s0,-88
    41aa:	33f000ef          	jal	ra,4ce8 <open>
    41ae:	323000ef          	jal	ra,4cd0 <close>
      close(open(file, 0));
    41b2:	4581                	li	a1,0
    41b4:	fa840513          	addi	a0,s0,-88
    41b8:	331000ef          	jal	ra,4ce8 <open>
    41bc:	315000ef          	jal	ra,4cd0 <close>
      close(open(file, 0));
    41c0:	4581                	li	a1,0
    41c2:	fa840513          	addi	a0,s0,-88
    41c6:	323000ef          	jal	ra,4ce8 <open>
    41ca:	307000ef          	jal	ra,4cd0 <close>
      close(open(file, 0));
    41ce:	4581                	li	a1,0
    41d0:	fa840513          	addi	a0,s0,-88
    41d4:	315000ef          	jal	ra,4ce8 <open>
    41d8:	2f9000ef          	jal	ra,4cd0 <close>
      close(open(file, 0));
    41dc:	4581                	li	a1,0
    41de:	fa840513          	addi	a0,s0,-88
    41e2:	307000ef          	jal	ra,4ce8 <open>
    41e6:	2eb000ef          	jal	ra,4cd0 <close>
      close(open(file, 0));
    41ea:	4581                	li	a1,0
    41ec:	fa840513          	addi	a0,s0,-88
    41f0:	2f9000ef          	jal	ra,4ce8 <open>
    41f4:	2dd000ef          	jal	ra,4cd0 <close>
    if(pid == 0)
    41f8:	06090363          	beqz	s2,425e <concreate+0x234>
      wait(0);
    41fc:	4501                	li	a0,0
    41fe:	2b3000ef          	jal	ra,4cb0 <wait>
  for(i = 0; i < N; i++){
    4202:	2485                	addiw	s1,s1,1
    4204:	0b448963          	beq	s1,s4,42b6 <concreate+0x28c>
    file[1] = '0' + i;
    4208:	0304879b          	addiw	a5,s1,48
    420c:	faf404a3          	sb	a5,-87(s0)
    pid = fork();
    4210:	291000ef          	jal	ra,4ca0 <fork>
    4214:	892a                	mv	s2,a0
    if(pid < 0){
    4216:	f6054de3          	bltz	a0,4190 <concreate+0x166>
    if(((i % 3) == 0 && pid == 0) ||
    421a:	0354e73b          	remw	a4,s1,s5
    421e:	00a767b3          	or	a5,a4,a0
    4222:	2781                	sext.w	a5,a5
    4224:	d3c1                	beqz	a5,41a4 <concreate+0x17a>
    4226:	01671363          	bne	a4,s6,422c <concreate+0x202>
       ((i % 3) == 1 && pid != 0)){
    422a:	fd2d                	bnez	a0,41a4 <concreate+0x17a>
      unlink(file);
    422c:	fa840513          	addi	a0,s0,-88
    4230:	2c9000ef          	jal	ra,4cf8 <unlink>
      unlink(file);
    4234:	fa840513          	addi	a0,s0,-88
    4238:	2c1000ef          	jal	ra,4cf8 <unlink>
      unlink(file);
    423c:	fa840513          	addi	a0,s0,-88
    4240:	2b9000ef          	jal	ra,4cf8 <unlink>
      unlink(file);
    4244:	fa840513          	addi	a0,s0,-88
    4248:	2b1000ef          	jal	ra,4cf8 <unlink>
      unlink(file);
    424c:	fa840513          	addi	a0,s0,-88
    4250:	2a9000ef          	jal	ra,4cf8 <unlink>
      unlink(file);
    4254:	fa840513          	addi	a0,s0,-88
    4258:	2a1000ef          	jal	ra,4cf8 <unlink>
    425c:	bf71                	j	41f8 <concreate+0x1ce>
      exit(0);
    425e:	4501                	li	a0,0
    4260:	249000ef          	jal	ra,4ca8 <exit>
      close(fd);
    4264:	26d000ef          	jal	ra,4cd0 <close>
    if(pid == 0) {
    4268:	b5a1                	j	40b0 <concreate+0x86>
      close(fd);
    426a:	267000ef          	jal	ra,4cd0 <close>
      wait(&xstatus);
    426e:	f6c40513          	addi	a0,s0,-148
    4272:	23f000ef          	jal	ra,4cb0 <wait>
      if(xstatus != 0)
    4276:	f6c42483          	lw	s1,-148(s0)
    427a:	e2049ee3          	bnez	s1,40b6 <concreate+0x8c>
  for(i = 0; i < N; i++){
    427e:	2905                	addiw	s2,s2,1
    4280:	e3490ee3          	beq	s2,s4,40bc <concreate+0x92>
    file[1] = '0' + i;
    4284:	0309079b          	addiw	a5,s2,48
    4288:	faf404a3          	sb	a5,-87(s0)
    unlink(file);
    428c:	fa840513          	addi	a0,s0,-88
    4290:	269000ef          	jal	ra,4cf8 <unlink>
    pid = fork();
    4294:	20d000ef          	jal	ra,4ca0 <fork>
    if(pid && (i % 3) == 1){
    4298:	dc050be3          	beqz	a0,406e <concreate+0x44>
    429c:	036967bb          	remw	a5,s2,s6
    42a0:	dd5781e3          	beq	a5,s5,4062 <concreate+0x38>
      fd = open(file, O_CREATE | O_RDWR);
    42a4:	20200593          	li	a1,514
    42a8:	fa840513          	addi	a0,s0,-88
    42ac:	23d000ef          	jal	ra,4ce8 <open>
      if(fd < 0){
    42b0:	fa055de3          	bgez	a0,426a <concreate+0x240>
    42b4:	bbd9                	j	408a <concreate+0x60>
}
    42b6:	60ea                	ld	ra,152(sp)
    42b8:	644a                	ld	s0,144(sp)
    42ba:	64aa                	ld	s1,136(sp)
    42bc:	690a                	ld	s2,128(sp)
    42be:	79e6                	ld	s3,120(sp)
    42c0:	7a46                	ld	s4,112(sp)
    42c2:	7aa6                	ld	s5,104(sp)
    42c4:	7b06                	ld	s6,96(sp)
    42c6:	6be6                	ld	s7,88(sp)
    42c8:	610d                	addi	sp,sp,160
    42ca:	8082                	ret

00000000000042cc <bigfile>:
{
    42cc:	7139                	addi	sp,sp,-64
    42ce:	fc06                	sd	ra,56(sp)
    42d0:	f822                	sd	s0,48(sp)
    42d2:	f426                	sd	s1,40(sp)
    42d4:	f04a                	sd	s2,32(sp)
    42d6:	ec4e                	sd	s3,24(sp)
    42d8:	e852                	sd	s4,16(sp)
    42da:	e456                	sd	s5,8(sp)
    42dc:	0080                	addi	s0,sp,64
    42de:	8aaa                	mv	s5,a0
  unlink("bigfile.dat");
    42e0:	00003517          	auipc	a0,0x3
    42e4:	da050513          	addi	a0,a0,-608 # 7080 <malloc+0x1ef0>
    42e8:	211000ef          	jal	ra,4cf8 <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    42ec:	20200593          	li	a1,514
    42f0:	00003517          	auipc	a0,0x3
    42f4:	d9050513          	addi	a0,a0,-624 # 7080 <malloc+0x1ef0>
    42f8:	1f1000ef          	jal	ra,4ce8 <open>
    42fc:	89aa                	mv	s3,a0
  for(i = 0; i < N; i++){
    42fe:	4481                	li	s1,0
    memset(buf, i, SZ);
    4300:	00008917          	auipc	s2,0x8
    4304:	9a890913          	addi	s2,s2,-1624 # bca8 <buf>
  for(i = 0; i < N; i++){
    4308:	4a51                	li	s4,20
  if(fd < 0){
    430a:	08054663          	bltz	a0,4396 <bigfile+0xca>
    memset(buf, i, SZ);
    430e:	25800613          	li	a2,600
    4312:	85a6                	mv	a1,s1
    4314:	854a                	mv	a0,s2
    4316:	7aa000ef          	jal	ra,4ac0 <memset>
    if(write(fd, buf, SZ) != SZ){
    431a:	25800613          	li	a2,600
    431e:	85ca                	mv	a1,s2
    4320:	854e                	mv	a0,s3
    4322:	1a7000ef          	jal	ra,4cc8 <write>
    4326:	25800793          	li	a5,600
    432a:	08f51063          	bne	a0,a5,43aa <bigfile+0xde>
  for(i = 0; i < N; i++){
    432e:	2485                	addiw	s1,s1,1
    4330:	fd449fe3          	bne	s1,s4,430e <bigfile+0x42>
  close(fd);
    4334:	854e                	mv	a0,s3
    4336:	19b000ef          	jal	ra,4cd0 <close>
  fd = open("bigfile.dat", 0);
    433a:	4581                	li	a1,0
    433c:	00003517          	auipc	a0,0x3
    4340:	d4450513          	addi	a0,a0,-700 # 7080 <malloc+0x1ef0>
    4344:	1a5000ef          	jal	ra,4ce8 <open>
    4348:	8a2a                	mv	s4,a0
  total = 0;
    434a:	4981                	li	s3,0
  for(i = 0; ; i++){
    434c:	4481                	li	s1,0
    cc = read(fd, buf, SZ/2);
    434e:	00008917          	auipc	s2,0x8
    4352:	95a90913          	addi	s2,s2,-1702 # bca8 <buf>
  if(fd < 0){
    4356:	06054463          	bltz	a0,43be <bigfile+0xf2>
    cc = read(fd, buf, SZ/2);
    435a:	12c00613          	li	a2,300
    435e:	85ca                	mv	a1,s2
    4360:	8552                	mv	a0,s4
    4362:	15f000ef          	jal	ra,4cc0 <read>
    if(cc < 0){
    4366:	06054663          	bltz	a0,43d2 <bigfile+0x106>
    if(cc == 0)
    436a:	c155                	beqz	a0,440e <bigfile+0x142>
    if(cc != SZ/2){
    436c:	12c00793          	li	a5,300
    4370:	06f51b63          	bne	a0,a5,43e6 <bigfile+0x11a>
    if(buf[0] != i/2 || buf[SZ/2-1] != i/2){
    4374:	01f4d79b          	srliw	a5,s1,0x1f
    4378:	9fa5                	addw	a5,a5,s1
    437a:	4017d79b          	sraiw	a5,a5,0x1
    437e:	00094703          	lbu	a4,0(s2)
    4382:	06f71c63          	bne	a4,a5,43fa <bigfile+0x12e>
    4386:	12b94703          	lbu	a4,299(s2)
    438a:	06f71863          	bne	a4,a5,43fa <bigfile+0x12e>
    total += cc;
    438e:	12c9899b          	addiw	s3,s3,300
  for(i = 0; ; i++){
    4392:	2485                	addiw	s1,s1,1
    cc = read(fd, buf, SZ/2);
    4394:	b7d9                	j	435a <bigfile+0x8e>
    printf("%s: cannot create bigfile", s);
    4396:	85d6                	mv	a1,s5
    4398:	00003517          	auipc	a0,0x3
    439c:	cf850513          	addi	a0,a0,-776 # 7090 <malloc+0x1f00>
    43a0:	537000ef          	jal	ra,50d6 <printf>
    exit(1);
    43a4:	4505                	li	a0,1
    43a6:	103000ef          	jal	ra,4ca8 <exit>
      printf("%s: write bigfile failed\n", s);
    43aa:	85d6                	mv	a1,s5
    43ac:	00003517          	auipc	a0,0x3
    43b0:	d0450513          	addi	a0,a0,-764 # 70b0 <malloc+0x1f20>
    43b4:	523000ef          	jal	ra,50d6 <printf>
      exit(1);
    43b8:	4505                	li	a0,1
    43ba:	0ef000ef          	jal	ra,4ca8 <exit>
    printf("%s: cannot open bigfile\n", s);
    43be:	85d6                	mv	a1,s5
    43c0:	00003517          	auipc	a0,0x3
    43c4:	d1050513          	addi	a0,a0,-752 # 70d0 <malloc+0x1f40>
    43c8:	50f000ef          	jal	ra,50d6 <printf>
    exit(1);
    43cc:	4505                	li	a0,1
    43ce:	0db000ef          	jal	ra,4ca8 <exit>
      printf("%s: read bigfile failed\n", s);
    43d2:	85d6                	mv	a1,s5
    43d4:	00003517          	auipc	a0,0x3
    43d8:	d1c50513          	addi	a0,a0,-740 # 70f0 <malloc+0x1f60>
    43dc:	4fb000ef          	jal	ra,50d6 <printf>
      exit(1);
    43e0:	4505                	li	a0,1
    43e2:	0c7000ef          	jal	ra,4ca8 <exit>
      printf("%s: short read bigfile\n", s);
    43e6:	85d6                	mv	a1,s5
    43e8:	00003517          	auipc	a0,0x3
    43ec:	d2850513          	addi	a0,a0,-728 # 7110 <malloc+0x1f80>
    43f0:	4e7000ef          	jal	ra,50d6 <printf>
      exit(1);
    43f4:	4505                	li	a0,1
    43f6:	0b3000ef          	jal	ra,4ca8 <exit>
      printf("%s: read bigfile wrong data\n", s);
    43fa:	85d6                	mv	a1,s5
    43fc:	00003517          	auipc	a0,0x3
    4400:	d2c50513          	addi	a0,a0,-724 # 7128 <malloc+0x1f98>
    4404:	4d3000ef          	jal	ra,50d6 <printf>
      exit(1);
    4408:	4505                	li	a0,1
    440a:	09f000ef          	jal	ra,4ca8 <exit>
  close(fd);
    440e:	8552                	mv	a0,s4
    4410:	0c1000ef          	jal	ra,4cd0 <close>
  if(total != N*SZ){
    4414:	678d                	lui	a5,0x3
    4416:	ee078793          	addi	a5,a5,-288 # 2ee0 <subdir+0x110>
    441a:	02f99163          	bne	s3,a5,443c <bigfile+0x170>
  unlink("bigfile.dat");
    441e:	00003517          	auipc	a0,0x3
    4422:	c6250513          	addi	a0,a0,-926 # 7080 <malloc+0x1ef0>
    4426:	0d3000ef          	jal	ra,4cf8 <unlink>
}
    442a:	70e2                	ld	ra,56(sp)
    442c:	7442                	ld	s0,48(sp)
    442e:	74a2                	ld	s1,40(sp)
    4430:	7902                	ld	s2,32(sp)
    4432:	69e2                	ld	s3,24(sp)
    4434:	6a42                	ld	s4,16(sp)
    4436:	6aa2                	ld	s5,8(sp)
    4438:	6121                	addi	sp,sp,64
    443a:	8082                	ret
    printf("%s: read bigfile wrong total\n", s);
    443c:	85d6                	mv	a1,s5
    443e:	00003517          	auipc	a0,0x3
    4442:	d0a50513          	addi	a0,a0,-758 # 7148 <malloc+0x1fb8>
    4446:	491000ef          	jal	ra,50d6 <printf>
    exit(1);
    444a:	4505                	li	a0,1
    444c:	05d000ef          	jal	ra,4ca8 <exit>

0000000000004450 <bigargtest>:
{
    4450:	7121                	addi	sp,sp,-448
    4452:	ff06                	sd	ra,440(sp)
    4454:	fb22                	sd	s0,432(sp)
    4456:	f726                	sd	s1,424(sp)
    4458:	0380                	addi	s0,sp,448
    445a:	84aa                	mv	s1,a0
  unlink("bigarg-ok");
    445c:	00003517          	auipc	a0,0x3
    4460:	d0c50513          	addi	a0,a0,-756 # 7168 <malloc+0x1fd8>
    4464:	095000ef          	jal	ra,4cf8 <unlink>
  pid = fork();
    4468:	039000ef          	jal	ra,4ca0 <fork>
  if(pid == 0){
    446c:	c915                	beqz	a0,44a0 <bigargtest+0x50>
  } else if(pid < 0){
    446e:	08054a63          	bltz	a0,4502 <bigargtest+0xb2>
  wait(&xstatus);
    4472:	fdc40513          	addi	a0,s0,-36
    4476:	03b000ef          	jal	ra,4cb0 <wait>
  if(xstatus != 0)
    447a:	fdc42503          	lw	a0,-36(s0)
    447e:	ed41                	bnez	a0,4516 <bigargtest+0xc6>
  fd = open("bigarg-ok", 0);
    4480:	4581                	li	a1,0
    4482:	00003517          	auipc	a0,0x3
    4486:	ce650513          	addi	a0,a0,-794 # 7168 <malloc+0x1fd8>
    448a:	05f000ef          	jal	ra,4ce8 <open>
  if(fd < 0){
    448e:	08054663          	bltz	a0,451a <bigargtest+0xca>
  close(fd);
    4492:	03f000ef          	jal	ra,4cd0 <close>
}
    4496:	70fa                	ld	ra,440(sp)
    4498:	745a                	ld	s0,432(sp)
    449a:	74ba                	ld	s1,424(sp)
    449c:	6139                	addi	sp,sp,448
    449e:	8082                	ret
    memset(big, ' ', sizeof(big));
    44a0:	19000613          	li	a2,400
    44a4:	02000593          	li	a1,32
    44a8:	e4840513          	addi	a0,s0,-440
    44ac:	614000ef          	jal	ra,4ac0 <memset>
    big[sizeof(big)-1] = '\0';
    44b0:	fc040ba3          	sb	zero,-41(s0)
    for(i = 0; i < MAXARG-1; i++)
    44b4:	00004797          	auipc	a5,0x4
    44b8:	fdc78793          	addi	a5,a5,-36 # 8490 <args.1>
    44bc:	00004697          	auipc	a3,0x4
    44c0:	0cc68693          	addi	a3,a3,204 # 8588 <args.1+0xf8>
      args[i] = big;
    44c4:	e4840713          	addi	a4,s0,-440
    44c8:	e398                	sd	a4,0(a5)
    for(i = 0; i < MAXARG-1; i++)
    44ca:	07a1                	addi	a5,a5,8
    44cc:	fed79ee3          	bne	a5,a3,44c8 <bigargtest+0x78>
    args[MAXARG-1] = 0;
    44d0:	00004597          	auipc	a1,0x4
    44d4:	fc058593          	addi	a1,a1,-64 # 8490 <args.1>
    44d8:	0e05bc23          	sd	zero,248(a1)
    exec("echo", args);
    44dc:	00001517          	auipc	a0,0x1
    44e0:	dec50513          	addi	a0,a0,-532 # 52c8 <malloc+0x138>
    44e4:	7fc000ef          	jal	ra,4ce0 <exec>
    fd = open("bigarg-ok", O_CREATE);
    44e8:	20000593          	li	a1,512
    44ec:	00003517          	auipc	a0,0x3
    44f0:	c7c50513          	addi	a0,a0,-900 # 7168 <malloc+0x1fd8>
    44f4:	7f4000ef          	jal	ra,4ce8 <open>
    close(fd);
    44f8:	7d8000ef          	jal	ra,4cd0 <close>
    exit(0);
    44fc:	4501                	li	a0,0
    44fe:	7aa000ef          	jal	ra,4ca8 <exit>
    printf("%s: bigargtest: fork failed\n", s);
    4502:	85a6                	mv	a1,s1
    4504:	00003517          	auipc	a0,0x3
    4508:	c7450513          	addi	a0,a0,-908 # 7178 <malloc+0x1fe8>
    450c:	3cb000ef          	jal	ra,50d6 <printf>
    exit(1);
    4510:	4505                	li	a0,1
    4512:	796000ef          	jal	ra,4ca8 <exit>
    exit(xstatus);
    4516:	792000ef          	jal	ra,4ca8 <exit>
    printf("%s: bigarg test failed!\n", s);
    451a:	85a6                	mv	a1,s1
    451c:	00003517          	auipc	a0,0x3
    4520:	c7c50513          	addi	a0,a0,-900 # 7198 <malloc+0x2008>
    4524:	3b3000ef          	jal	ra,50d6 <printf>
    exit(1);
    4528:	4505                	li	a0,1
    452a:	77e000ef          	jal	ra,4ca8 <exit>

000000000000452e <fsfull>:
{
    452e:	7171                	addi	sp,sp,-176
    4530:	f506                	sd	ra,168(sp)
    4532:	f122                	sd	s0,160(sp)
    4534:	ed26                	sd	s1,152(sp)
    4536:	e94a                	sd	s2,144(sp)
    4538:	e54e                	sd	s3,136(sp)
    453a:	e152                	sd	s4,128(sp)
    453c:	fcd6                	sd	s5,120(sp)
    453e:	f8da                	sd	s6,112(sp)
    4540:	f4de                	sd	s7,104(sp)
    4542:	f0e2                	sd	s8,96(sp)
    4544:	ece6                	sd	s9,88(sp)
    4546:	e8ea                	sd	s10,80(sp)
    4548:	e4ee                	sd	s11,72(sp)
    454a:	1900                	addi	s0,sp,176
  printf("fsfull test\n");
    454c:	00003517          	auipc	a0,0x3
    4550:	c6c50513          	addi	a0,a0,-916 # 71b8 <malloc+0x2028>
    4554:	383000ef          	jal	ra,50d6 <printf>
  for(nfiles = 0; ; nfiles++){
    4558:	4481                	li	s1,0
    name[0] = 'f';
    455a:	06600d13          	li	s10,102
    name[1] = '0' + nfiles / 1000;
    455e:	3e800c13          	li	s8,1000
    name[2] = '0' + (nfiles % 1000) / 100;
    4562:	06400b93          	li	s7,100
    name[3] = '0' + (nfiles % 100) / 10;
    4566:	4b29                	li	s6,10
    printf("writing %s\n", name);
    4568:	00003c97          	auipc	s9,0x3
    456c:	c60c8c93          	addi	s9,s9,-928 # 71c8 <malloc+0x2038>
    int total = 0;
    4570:	4d81                	li	s11,0
      int cc = write(fd, buf, BSIZE);
    4572:	00007a17          	auipc	s4,0x7
    4576:	736a0a13          	addi	s4,s4,1846 # bca8 <buf>
    name[0] = 'f';
    457a:	f5a40823          	sb	s10,-176(s0)
    name[1] = '0' + nfiles / 1000;
    457e:	0384c7bb          	divw	a5,s1,s8
    4582:	0307879b          	addiw	a5,a5,48
    4586:	f4f408a3          	sb	a5,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    458a:	0384e7bb          	remw	a5,s1,s8
    458e:	0377c7bb          	divw	a5,a5,s7
    4592:	0307879b          	addiw	a5,a5,48
    4596:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    459a:	0374e7bb          	remw	a5,s1,s7
    459e:	0367c7bb          	divw	a5,a5,s6
    45a2:	0307879b          	addiw	a5,a5,48
    45a6:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    45aa:	0364e7bb          	remw	a5,s1,s6
    45ae:	0307879b          	addiw	a5,a5,48
    45b2:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    45b6:	f4040aa3          	sb	zero,-171(s0)
    printf("writing %s\n", name);
    45ba:	f5040593          	addi	a1,s0,-176
    45be:	8566                	mv	a0,s9
    45c0:	317000ef          	jal	ra,50d6 <printf>
    int fd = open(name, O_CREATE|O_RDWR);
    45c4:	20200593          	li	a1,514
    45c8:	f5040513          	addi	a0,s0,-176
    45cc:	71c000ef          	jal	ra,4ce8 <open>
    45d0:	892a                	mv	s2,a0
    if(fd < 0){
    45d2:	0a055063          	bgez	a0,4672 <fsfull+0x144>
      printf("open %s failed\n", name);
    45d6:	f5040593          	addi	a1,s0,-176
    45da:	00003517          	auipc	a0,0x3
    45de:	bfe50513          	addi	a0,a0,-1026 # 71d8 <malloc+0x2048>
    45e2:	2f5000ef          	jal	ra,50d6 <printf>
  while(nfiles >= 0){
    45e6:	0604c163          	bltz	s1,4648 <fsfull+0x11a>
    name[0] = 'f';
    45ea:	06600b13          	li	s6,102
    name[1] = '0' + nfiles / 1000;
    45ee:	3e800a13          	li	s4,1000
    name[2] = '0' + (nfiles % 1000) / 100;
    45f2:	06400993          	li	s3,100
    name[3] = '0' + (nfiles % 100) / 10;
    45f6:	4929                	li	s2,10
  while(nfiles >= 0){
    45f8:	5afd                	li	s5,-1
    name[0] = 'f';
    45fa:	f5640823          	sb	s6,-176(s0)
    name[1] = '0' + nfiles / 1000;
    45fe:	0344c7bb          	divw	a5,s1,s4
    4602:	0307879b          	addiw	a5,a5,48
    4606:	f4f408a3          	sb	a5,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    460a:	0344e7bb          	remw	a5,s1,s4
    460e:	0337c7bb          	divw	a5,a5,s3
    4612:	0307879b          	addiw	a5,a5,48
    4616:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    461a:	0334e7bb          	remw	a5,s1,s3
    461e:	0327c7bb          	divw	a5,a5,s2
    4622:	0307879b          	addiw	a5,a5,48
    4626:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    462a:	0324e7bb          	remw	a5,s1,s2
    462e:	0307879b          	addiw	a5,a5,48
    4632:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4636:	f4040aa3          	sb	zero,-171(s0)
    unlink(name);
    463a:	f5040513          	addi	a0,s0,-176
    463e:	6ba000ef          	jal	ra,4cf8 <unlink>
    nfiles--;
    4642:	34fd                	addiw	s1,s1,-1
  while(nfiles >= 0){
    4644:	fb549be3          	bne	s1,s5,45fa <fsfull+0xcc>
  printf("fsfull test finished\n");
    4648:	00003517          	auipc	a0,0x3
    464c:	bb050513          	addi	a0,a0,-1104 # 71f8 <malloc+0x2068>
    4650:	287000ef          	jal	ra,50d6 <printf>
}
    4654:	70aa                	ld	ra,168(sp)
    4656:	740a                	ld	s0,160(sp)
    4658:	64ea                	ld	s1,152(sp)
    465a:	694a                	ld	s2,144(sp)
    465c:	69aa                	ld	s3,136(sp)
    465e:	6a0a                	ld	s4,128(sp)
    4660:	7ae6                	ld	s5,120(sp)
    4662:	7b46                	ld	s6,112(sp)
    4664:	7ba6                	ld	s7,104(sp)
    4666:	7c06                	ld	s8,96(sp)
    4668:	6ce6                	ld	s9,88(sp)
    466a:	6d46                	ld	s10,80(sp)
    466c:	6da6                	ld	s11,72(sp)
    466e:	614d                	addi	sp,sp,176
    4670:	8082                	ret
    int total = 0;
    4672:	89ee                	mv	s3,s11
      if(cc < BSIZE)
    4674:	3ff00a93          	li	s5,1023
      int cc = write(fd, buf, BSIZE);
    4678:	40000613          	li	a2,1024
    467c:	85d2                	mv	a1,s4
    467e:	854a                	mv	a0,s2
    4680:	648000ef          	jal	ra,4cc8 <write>
      if(cc < BSIZE)
    4684:	00aad563          	bge	s5,a0,468e <fsfull+0x160>
      total += cc;
    4688:	00a989bb          	addw	s3,s3,a0
    while(1){
    468c:	b7f5                	j	4678 <fsfull+0x14a>
    printf("wrote %d bytes\n", total);
    468e:	85ce                	mv	a1,s3
    4690:	00003517          	auipc	a0,0x3
    4694:	b5850513          	addi	a0,a0,-1192 # 71e8 <malloc+0x2058>
    4698:	23f000ef          	jal	ra,50d6 <printf>
    close(fd);
    469c:	854a                	mv	a0,s2
    469e:	632000ef          	jal	ra,4cd0 <close>
    if(total == 0)
    46a2:	f40982e3          	beqz	s3,45e6 <fsfull+0xb8>
  for(nfiles = 0; ; nfiles++){
    46a6:	2485                	addiw	s1,s1,1
    46a8:	bdc9                	j	457a <fsfull+0x4c>

00000000000046aa <run>:
//

// run each test in its own process. run returns 1 if child's exit()
// indicates success.
int
run(void f(char *), char *s) {
    46aa:	7179                	addi	sp,sp,-48
    46ac:	f406                	sd	ra,40(sp)
    46ae:	f022                	sd	s0,32(sp)
    46b0:	ec26                	sd	s1,24(sp)
    46b2:	e84a                	sd	s2,16(sp)
    46b4:	1800                	addi	s0,sp,48
    46b6:	84aa                	mv	s1,a0
    46b8:	892e                	mv	s2,a1
  int pid;
  int xstatus;

  printf("test %s: ", s);
    46ba:	00003517          	auipc	a0,0x3
    46be:	b5650513          	addi	a0,a0,-1194 # 7210 <malloc+0x2080>
    46c2:	215000ef          	jal	ra,50d6 <printf>
  if((pid = fork()) < 0) {
    46c6:	5da000ef          	jal	ra,4ca0 <fork>
    46ca:	02054a63          	bltz	a0,46fe <run+0x54>
    printf("runtest: fork error\n");
    exit(1);
  }
  if(pid == 0) {
    46ce:	c129                	beqz	a0,4710 <run+0x66>
    f(s);
    exit(0);
  } else {
    wait(&xstatus);
    46d0:	fdc40513          	addi	a0,s0,-36
    46d4:	5dc000ef          	jal	ra,4cb0 <wait>
    if(xstatus != 0) 
    46d8:	fdc42783          	lw	a5,-36(s0)
    46dc:	cf9d                	beqz	a5,471a <run+0x70>
      printf("FAILED\n");
    46de:	00003517          	auipc	a0,0x3
    46e2:	b5a50513          	addi	a0,a0,-1190 # 7238 <malloc+0x20a8>
    46e6:	1f1000ef          	jal	ra,50d6 <printf>
    else
      printf("OK\n");
    return xstatus == 0;
    46ea:	fdc42503          	lw	a0,-36(s0)
  }
}
    46ee:	00153513          	seqz	a0,a0
    46f2:	70a2                	ld	ra,40(sp)
    46f4:	7402                	ld	s0,32(sp)
    46f6:	64e2                	ld	s1,24(sp)
    46f8:	6942                	ld	s2,16(sp)
    46fa:	6145                	addi	sp,sp,48
    46fc:	8082                	ret
    printf("runtest: fork error\n");
    46fe:	00003517          	auipc	a0,0x3
    4702:	b2250513          	addi	a0,a0,-1246 # 7220 <malloc+0x2090>
    4706:	1d1000ef          	jal	ra,50d6 <printf>
    exit(1);
    470a:	4505                	li	a0,1
    470c:	59c000ef          	jal	ra,4ca8 <exit>
    f(s);
    4710:	854a                	mv	a0,s2
    4712:	9482                	jalr	s1
    exit(0);
    4714:	4501                	li	a0,0
    4716:	592000ef          	jal	ra,4ca8 <exit>
      printf("OK\n");
    471a:	00003517          	auipc	a0,0x3
    471e:	b2650513          	addi	a0,a0,-1242 # 7240 <malloc+0x20b0>
    4722:	1b5000ef          	jal	ra,50d6 <printf>
    4726:	b7d1                	j	46ea <run+0x40>

0000000000004728 <runtests>:

int
runtests(struct test *tests, char *justone, int continuous) {
    4728:	7139                	addi	sp,sp,-64
    472a:	fc06                	sd	ra,56(sp)
    472c:	f822                	sd	s0,48(sp)
    472e:	f426                	sd	s1,40(sp)
    4730:	f04a                	sd	s2,32(sp)
    4732:	ec4e                	sd	s3,24(sp)
    4734:	e852                	sd	s4,16(sp)
    4736:	e456                	sd	s5,8(sp)
    4738:	0080                	addi	s0,sp,64
    473a:	84aa                	mv	s1,a0
  int ntests = 0;
  for (struct test *t = tests; t->s != 0; t++) {
    473c:	6508                	ld	a0,8(a0)
    473e:	c921                	beqz	a0,478e <runtests+0x66>
    4740:	892e                	mv	s2,a1
    4742:	8a32                	mv	s4,a2
  int ntests = 0;
    4744:	4981                	li	s3,0
    if((justone == 0) || strcmp(t->s, justone) == 0) {
      ntests++;
      if(!run(t->f, t->s)){
        if(continuous != 2){
    4746:	4a89                	li	s5,2
    4748:	a021                	j	4750 <runtests+0x28>
  for (struct test *t = tests; t->s != 0; t++) {
    474a:	04c1                	addi	s1,s1,16
    474c:	6488                	ld	a0,8(s1)
    474e:	c515                	beqz	a0,477a <runtests+0x52>
    if((justone == 0) || strcmp(t->s, justone) == 0) {
    4750:	00090663          	beqz	s2,475c <runtests+0x34>
    4754:	85ca                	mv	a1,s2
    4756:	314000ef          	jal	ra,4a6a <strcmp>
    475a:	f965                	bnez	a0,474a <runtests+0x22>
      ntests++;
    475c:	2985                	addiw	s3,s3,1
      if(!run(t->f, t->s)){
    475e:	648c                	ld	a1,8(s1)
    4760:	6088                	ld	a0,0(s1)
    4762:	f49ff0ef          	jal	ra,46aa <run>
    4766:	f175                	bnez	a0,474a <runtests+0x22>
        if(continuous != 2){
    4768:	ff5a01e3          	beq	s4,s5,474a <runtests+0x22>
          printf("SOME TESTS FAILED\n");
    476c:	00003517          	auipc	a0,0x3
    4770:	adc50513          	addi	a0,a0,-1316 # 7248 <malloc+0x20b8>
    4774:	163000ef          	jal	ra,50d6 <printf>
          return -1;
    4778:	59fd                	li	s3,-1
        }
      }
    }
  }
  return ntests;
}
    477a:	854e                	mv	a0,s3
    477c:	70e2                	ld	ra,56(sp)
    477e:	7442                	ld	s0,48(sp)
    4780:	74a2                	ld	s1,40(sp)
    4782:	7902                	ld	s2,32(sp)
    4784:	69e2                	ld	s3,24(sp)
    4786:	6a42                	ld	s4,16(sp)
    4788:	6aa2                	ld	s5,8(sp)
    478a:	6121                	addi	sp,sp,64
    478c:	8082                	ret
  int ntests = 0;
    478e:	4981                	li	s3,0
    4790:	b7ed                	j	477a <runtests+0x52>

0000000000004792 <countfree>:
// because out of memory with lazy allocation results in the process
// taking a fault and being killed, fork and report back.
//
int
countfree()
{
    4792:	7139                	addi	sp,sp,-64
    4794:	fc06                	sd	ra,56(sp)
    4796:	f822                	sd	s0,48(sp)
    4798:	f426                	sd	s1,40(sp)
    479a:	f04a                	sd	s2,32(sp)
    479c:	ec4e                	sd	s3,24(sp)
    479e:	0080                	addi	s0,sp,64
  int fds[2];

  if(pipe(fds) < 0){
    47a0:	fc840513          	addi	a0,s0,-56
    47a4:	514000ef          	jal	ra,4cb8 <pipe>
    47a8:	04054b63          	bltz	a0,47fe <countfree+0x6c>
    printf("pipe() failed in countfree()\n");
    exit(1);
  }
  
  int pid = fork();
    47ac:	4f4000ef          	jal	ra,4ca0 <fork>

  if(pid < 0){
    47b0:	06054063          	bltz	a0,4810 <countfree+0x7e>
    printf("fork failed in countfree()\n");
    exit(1);
  }

  if(pid == 0){
    47b4:	e935                	bnez	a0,4828 <countfree+0x96>
    close(fds[0]);
    47b6:	fc842503          	lw	a0,-56(s0)
    47ba:	516000ef          	jal	ra,4cd0 <close>
    
    while(1){
      uint64 a = (uint64) sbrk(4096);
      if(a == 0xffffffffffffffff){
    47be:	597d                	li	s2,-1
        break;
      }

      // modify the memory to make sure it's really allocated.
      *(char *)(a + 4096 - 1) = 1;
    47c0:	4485                	li	s1,1

      // report back one more page.
      if(write(fds[1], "x", 1) != 1){
    47c2:	00001997          	auipc	s3,0x1
    47c6:	b7698993          	addi	s3,s3,-1162 # 5338 <malloc+0x1a8>
      uint64 a = (uint64) sbrk(4096);
    47ca:	6505                	lui	a0,0x1
    47cc:	564000ef          	jal	ra,4d30 <sbrk>
      if(a == 0xffffffffffffffff){
    47d0:	05250963          	beq	a0,s2,4822 <countfree+0x90>
      *(char *)(a + 4096 - 1) = 1;
    47d4:	6785                	lui	a5,0x1
    47d6:	953e                	add	a0,a0,a5
    47d8:	fe950fa3          	sb	s1,-1(a0) # fff <pgbug+0x29>
      if(write(fds[1], "x", 1) != 1){
    47dc:	8626                	mv	a2,s1
    47de:	85ce                	mv	a1,s3
    47e0:	fcc42503          	lw	a0,-52(s0)
    47e4:	4e4000ef          	jal	ra,4cc8 <write>
    47e8:	fe9501e3          	beq	a0,s1,47ca <countfree+0x38>
        printf("write() failed in countfree()\n");
    47ec:	00003517          	auipc	a0,0x3
    47f0:	ab450513          	addi	a0,a0,-1356 # 72a0 <malloc+0x2110>
    47f4:	0e3000ef          	jal	ra,50d6 <printf>
        exit(1);
    47f8:	4505                	li	a0,1
    47fa:	4ae000ef          	jal	ra,4ca8 <exit>
    printf("pipe() failed in countfree()\n");
    47fe:	00003517          	auipc	a0,0x3
    4802:	a6250513          	addi	a0,a0,-1438 # 7260 <malloc+0x20d0>
    4806:	0d1000ef          	jal	ra,50d6 <printf>
    exit(1);
    480a:	4505                	li	a0,1
    480c:	49c000ef          	jal	ra,4ca8 <exit>
    printf("fork failed in countfree()\n");
    4810:	00003517          	auipc	a0,0x3
    4814:	a7050513          	addi	a0,a0,-1424 # 7280 <malloc+0x20f0>
    4818:	0bf000ef          	jal	ra,50d6 <printf>
    exit(1);
    481c:	4505                	li	a0,1
    481e:	48a000ef          	jal	ra,4ca8 <exit>
      }
    }

    exit(0);
    4822:	4501                	li	a0,0
    4824:	484000ef          	jal	ra,4ca8 <exit>
  }

  close(fds[1]);
    4828:	fcc42503          	lw	a0,-52(s0)
    482c:	4a4000ef          	jal	ra,4cd0 <close>

  int n = 0;
    4830:	4481                	li	s1,0
  while(1){
    char c;
    int cc = read(fds[0], &c, 1);
    4832:	4605                	li	a2,1
    4834:	fc740593          	addi	a1,s0,-57
    4838:	fc842503          	lw	a0,-56(s0)
    483c:	484000ef          	jal	ra,4cc0 <read>
    if(cc < 0){
    4840:	00054563          	bltz	a0,484a <countfree+0xb8>
      printf("read() failed in countfree()\n");
      exit(1);
    }
    if(cc == 0)
    4844:	cd01                	beqz	a0,485c <countfree+0xca>
      break;
    n += 1;
    4846:	2485                	addiw	s1,s1,1
  while(1){
    4848:	b7ed                	j	4832 <countfree+0xa0>
      printf("read() failed in countfree()\n");
    484a:	00003517          	auipc	a0,0x3
    484e:	a7650513          	addi	a0,a0,-1418 # 72c0 <malloc+0x2130>
    4852:	085000ef          	jal	ra,50d6 <printf>
      exit(1);
    4856:	4505                	li	a0,1
    4858:	450000ef          	jal	ra,4ca8 <exit>
  }

  close(fds[0]);
    485c:	fc842503          	lw	a0,-56(s0)
    4860:	470000ef          	jal	ra,4cd0 <close>
  wait((int*)0);
    4864:	4501                	li	a0,0
    4866:	44a000ef          	jal	ra,4cb0 <wait>
  
  return n;
}
    486a:	8526                	mv	a0,s1
    486c:	70e2                	ld	ra,56(sp)
    486e:	7442                	ld	s0,48(sp)
    4870:	74a2                	ld	s1,40(sp)
    4872:	7902                	ld	s2,32(sp)
    4874:	69e2                	ld	s3,24(sp)
    4876:	6121                	addi	sp,sp,64
    4878:	8082                	ret

000000000000487a <drivetests>:

int
drivetests(int quick, int continuous, char *justone) {
    487a:	7159                	addi	sp,sp,-112
    487c:	f486                	sd	ra,104(sp)
    487e:	f0a2                	sd	s0,96(sp)
    4880:	eca6                	sd	s1,88(sp)
    4882:	e8ca                	sd	s2,80(sp)
    4884:	e4ce                	sd	s3,72(sp)
    4886:	e0d2                	sd	s4,64(sp)
    4888:	fc56                	sd	s5,56(sp)
    488a:	f85a                	sd	s6,48(sp)
    488c:	f45e                	sd	s7,40(sp)
    488e:	f062                	sd	s8,32(sp)
    4890:	ec66                	sd	s9,24(sp)
    4892:	e86a                	sd	s10,16(sp)
    4894:	e46e                	sd	s11,8(sp)
    4896:	1880                	addi	s0,sp,112
    4898:	8aaa                	mv	s5,a0
    489a:	89ae                	mv	s3,a1
    489c:	8a32                	mv	s4,a2
  do {
    printf("usertests starting\n");
    489e:	00003b97          	auipc	s7,0x3
    48a2:	a42b8b93          	addi	s7,s7,-1470 # 72e0 <malloc+0x2150>
    int free0 = countfree();
    int free1 = 0;
    int ntests = 0;
    int n;
    n = runtests(quicktests, justone, continuous);
    48a6:	00003b17          	auipc	s6,0x3
    48aa:	76ab0b13          	addi	s6,s6,1898 # 8010 <quicktests>
    if (n < 0) {
      if(continuous != 2) {
    48ae:	4c09                	li	s8,2
      } else {
        ntests += n;
      }
    }
    if((free1 = countfree()) < free0) {
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    48b0:	00003d17          	auipc	s10,0x3
    48b4:	a68d0d13          	addi	s10,s10,-1432 # 7318 <malloc+0x2188>
      n = runtests(slowtests, justone, continuous);
    48b8:	00004c97          	auipc	s9,0x4
    48bc:	b58c8c93          	addi	s9,s9,-1192 # 8410 <slowtests>
        printf("usertests slow tests starting\n");
    48c0:	00003d97          	auipc	s11,0x3
    48c4:	a38d8d93          	addi	s11,s11,-1480 # 72f8 <malloc+0x2168>
    48c8:	a835                	j	4904 <drivetests+0x8a>
      if(continuous != 2) {
    48ca:	09899a63          	bne	s3,s8,495e <drivetests+0xe4>
    int ntests = 0;
    48ce:	4481                	li	s1,0
    48d0:	a881                	j	4920 <drivetests+0xa6>
        printf("usertests slow tests starting\n");
    48d2:	856e                	mv	a0,s11
    48d4:	003000ef          	jal	ra,50d6 <printf>
    48d8:	a881                	j	4928 <drivetests+0xae>
        if(continuous != 2) {
    48da:	09899463          	bne	s3,s8,4962 <drivetests+0xe8>
    if((free1 = countfree()) < free0) {
    48de:	eb5ff0ef          	jal	ra,4792 <countfree>
    48e2:	01255c63          	bge	a0,s2,48fa <drivetests+0x80>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    48e6:	864a                	mv	a2,s2
    48e8:	85aa                	mv	a1,a0
    48ea:	856a                	mv	a0,s10
    48ec:	7ea000ef          	jal	ra,50d6 <printf>
      if(continuous != 2) {
    48f0:	a8a1                	j	4948 <drivetests+0xce>
    if((free1 = countfree()) < free0) {
    48f2:	ea1ff0ef          	jal	ra,4792 <countfree>
    48f6:	05254263          	blt	a0,s2,493a <drivetests+0xc0>
        return 1;
      }
    }
    if (justone != 0 && ntests == 0) {
    48fa:	000a0363          	beqz	s4,4900 <drivetests+0x86>
    48fe:	c8a1                	beqz	s1,494e <drivetests+0xd4>
      printf("NO TESTS EXECUTED\n");
      return 1;
    }
  } while(continuous);
    4900:	06098563          	beqz	s3,496a <drivetests+0xf0>
    printf("usertests starting\n");
    4904:	855e                	mv	a0,s7
    4906:	7d0000ef          	jal	ra,50d6 <printf>
    int free0 = countfree();
    490a:	e89ff0ef          	jal	ra,4792 <countfree>
    490e:	892a                	mv	s2,a0
    n = runtests(quicktests, justone, continuous);
    4910:	864e                	mv	a2,s3
    4912:	85d2                	mv	a1,s4
    4914:	855a                	mv	a0,s6
    4916:	e13ff0ef          	jal	ra,4728 <runtests>
    491a:	84aa                	mv	s1,a0
    if (n < 0) {
    491c:	fa0547e3          	bltz	a0,48ca <drivetests+0x50>
    if(!quick) {
    4920:	fc0a99e3          	bnez	s5,48f2 <drivetests+0x78>
      if (justone == 0)
    4924:	fa0a07e3          	beqz	s4,48d2 <drivetests+0x58>
      n = runtests(slowtests, justone, continuous);
    4928:	864e                	mv	a2,s3
    492a:	85d2                	mv	a1,s4
    492c:	8566                	mv	a0,s9
    492e:	dfbff0ef          	jal	ra,4728 <runtests>
      if (n < 0) {
    4932:	fa0544e3          	bltz	a0,48da <drivetests+0x60>
        ntests += n;
    4936:	9ca9                	addw	s1,s1,a0
    4938:	bf6d                	j	48f2 <drivetests+0x78>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    493a:	864a                	mv	a2,s2
    493c:	85aa                	mv	a1,a0
    493e:	856a                	mv	a0,s10
    4940:	796000ef          	jal	ra,50d6 <printf>
      if(continuous != 2) {
    4944:	03899163          	bne	s3,s8,4966 <drivetests+0xec>
    if (justone != 0 && ntests == 0) {
    4948:	fa0a0ee3          	beqz	s4,4904 <drivetests+0x8a>
    494c:	fcc5                	bnez	s1,4904 <drivetests+0x8a>
      printf("NO TESTS EXECUTED\n");
    494e:	00003517          	auipc	a0,0x3
    4952:	9fa50513          	addi	a0,a0,-1542 # 7348 <malloc+0x21b8>
    4956:	780000ef          	jal	ra,50d6 <printf>
      return 1;
    495a:	4505                	li	a0,1
    495c:	a801                	j	496c <drivetests+0xf2>
        return 1;
    495e:	4505                	li	a0,1
    4960:	a031                	j	496c <drivetests+0xf2>
          return 1;
    4962:	4505                	li	a0,1
    4964:	a021                	j	496c <drivetests+0xf2>
        return 1;
    4966:	4505                	li	a0,1
    4968:	a011                	j	496c <drivetests+0xf2>
  return 0;
    496a:	854e                	mv	a0,s3
}
    496c:	70a6                	ld	ra,104(sp)
    496e:	7406                	ld	s0,96(sp)
    4970:	64e6                	ld	s1,88(sp)
    4972:	6946                	ld	s2,80(sp)
    4974:	69a6                	ld	s3,72(sp)
    4976:	6a06                	ld	s4,64(sp)
    4978:	7ae2                	ld	s5,56(sp)
    497a:	7b42                	ld	s6,48(sp)
    497c:	7ba2                	ld	s7,40(sp)
    497e:	7c02                	ld	s8,32(sp)
    4980:	6ce2                	ld	s9,24(sp)
    4982:	6d42                	ld	s10,16(sp)
    4984:	6da2                	ld	s11,8(sp)
    4986:	6165                	addi	sp,sp,112
    4988:	8082                	ret

000000000000498a <main>:

int
main(int argc, char *argv[])
{
    498a:	1101                	addi	sp,sp,-32
    498c:	ec06                	sd	ra,24(sp)
    498e:	e822                	sd	s0,16(sp)
    4990:	e426                	sd	s1,8(sp)
    4992:	e04a                	sd	s2,0(sp)
    4994:	1000                	addi	s0,sp,32
    4996:	84aa                	mv	s1,a0
  int continuous = 0;
  int quick = 0;
  char *justone = 0;

  if(argc == 2 && strcmp(argv[1], "-q") == 0){
    4998:	4789                	li	a5,2
    499a:	00f50f63          	beq	a0,a5,49b8 <main+0x2e>
    continuous = 1;
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    continuous = 2;
  } else if(argc == 2 && argv[1][0] != '-'){
    justone = argv[1];
  } else if(argc > 1){
    499e:	4785                	li	a5,1
    49a0:	06a7c363          	blt	a5,a0,4a06 <main+0x7c>
  char *justone = 0;
    49a4:	4601                	li	a2,0
  int quick = 0;
    49a6:	4501                	li	a0,0
  int continuous = 0;
    49a8:	4481                	li	s1,0
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    exit(1);
  }
  if (drivetests(quick, continuous, justone)) {
    49aa:	85a6                	mv	a1,s1
    49ac:	ecfff0ef          	jal	ra,487a <drivetests>
    49b0:	cd2d                	beqz	a0,4a2a <main+0xa0>
    exit(1);
    49b2:	4505                	li	a0,1
    49b4:	2f4000ef          	jal	ra,4ca8 <exit>
    49b8:	892e                	mv	s2,a1
  if(argc == 2 && strcmp(argv[1], "-q") == 0){
    49ba:	00003597          	auipc	a1,0x3
    49be:	9a658593          	addi	a1,a1,-1626 # 7360 <malloc+0x21d0>
    49c2:	00893503          	ld	a0,8(s2)
    49c6:	0a4000ef          	jal	ra,4a6a <strcmp>
    49ca:	c539                	beqz	a0,4a18 <main+0x8e>
  } else if(argc == 2 && strcmp(argv[1], "-c") == 0){
    49cc:	00003597          	auipc	a1,0x3
    49d0:	9ec58593          	addi	a1,a1,-1556 # 73b8 <malloc+0x2228>
    49d4:	00893503          	ld	a0,8(s2)
    49d8:	092000ef          	jal	ra,4a6a <strcmp>
    49dc:	c521                	beqz	a0,4a24 <main+0x9a>
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    49de:	00003597          	auipc	a1,0x3
    49e2:	9d258593          	addi	a1,a1,-1582 # 73b0 <malloc+0x2220>
    49e6:	00893503          	ld	a0,8(s2)
    49ea:	080000ef          	jal	ra,4a6a <strcmp>
    49ee:	c90d                	beqz	a0,4a20 <main+0x96>
  } else if(argc == 2 && argv[1][0] != '-'){
    49f0:	00893603          	ld	a2,8(s2)
    49f4:	00064703          	lbu	a4,0(a2) # 3000 <subdir+0x230>
    49f8:	02d00793          	li	a5,45
    49fc:	00f70563          	beq	a4,a5,4a06 <main+0x7c>
  int quick = 0;
    4a00:	4501                	li	a0,0
  int continuous = 0;
    4a02:	4481                	li	s1,0
    4a04:	b75d                	j	49aa <main+0x20>
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    4a06:	00003517          	auipc	a0,0x3
    4a0a:	96250513          	addi	a0,a0,-1694 # 7368 <malloc+0x21d8>
    4a0e:	6c8000ef          	jal	ra,50d6 <printf>
    exit(1);
    4a12:	4505                	li	a0,1
    4a14:	294000ef          	jal	ra,4ca8 <exit>
  int continuous = 0;
    4a18:	84aa                	mv	s1,a0
  char *justone = 0;
    4a1a:	4601                	li	a2,0
    quick = 1;
    4a1c:	4505                	li	a0,1
    4a1e:	b771                	j	49aa <main+0x20>
  char *justone = 0;
    4a20:	4601                	li	a2,0
    4a22:	b761                	j	49aa <main+0x20>
    4a24:	4601                	li	a2,0
    continuous = 1;
    4a26:	4485                	li	s1,1
    4a28:	b749                	j	49aa <main+0x20>
  }
  printf("ALL TESTS PASSED\n");
    4a2a:	00003517          	auipc	a0,0x3
    4a2e:	96e50513          	addi	a0,a0,-1682 # 7398 <malloc+0x2208>
    4a32:	6a4000ef          	jal	ra,50d6 <printf>
  exit(0);
    4a36:	4501                	li	a0,0
    4a38:	270000ef          	jal	ra,4ca8 <exit>

0000000000004a3c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
    4a3c:	1141                	addi	sp,sp,-16
    4a3e:	e406                	sd	ra,8(sp)
    4a40:	e022                	sd	s0,0(sp)
    4a42:	0800                	addi	s0,sp,16
  extern int main();
  main();
    4a44:	f47ff0ef          	jal	ra,498a <main>
  exit(0);
    4a48:	4501                	li	a0,0
    4a4a:	25e000ef          	jal	ra,4ca8 <exit>

0000000000004a4e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
    4a4e:	1141                	addi	sp,sp,-16
    4a50:	e422                	sd	s0,8(sp)
    4a52:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    4a54:	87aa                	mv	a5,a0
    4a56:	0585                	addi	a1,a1,1
    4a58:	0785                	addi	a5,a5,1
    4a5a:	fff5c703          	lbu	a4,-1(a1)
    4a5e:	fee78fa3          	sb	a4,-1(a5) # fff <pgbug+0x29>
    4a62:	fb75                	bnez	a4,4a56 <strcpy+0x8>
    ;
  return os;
}
    4a64:	6422                	ld	s0,8(sp)
    4a66:	0141                	addi	sp,sp,16
    4a68:	8082                	ret

0000000000004a6a <strcmp>:

int
strcmp(const char *p, const char *q)
{
    4a6a:	1141                	addi	sp,sp,-16
    4a6c:	e422                	sd	s0,8(sp)
    4a6e:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
    4a70:	00054783          	lbu	a5,0(a0)
    4a74:	cb91                	beqz	a5,4a88 <strcmp+0x1e>
    4a76:	0005c703          	lbu	a4,0(a1)
    4a7a:	00f71763          	bne	a4,a5,4a88 <strcmp+0x1e>
    p++, q++;
    4a7e:	0505                	addi	a0,a0,1
    4a80:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
    4a82:	00054783          	lbu	a5,0(a0)
    4a86:	fbe5                	bnez	a5,4a76 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
    4a88:	0005c503          	lbu	a0,0(a1)
}
    4a8c:	40a7853b          	subw	a0,a5,a0
    4a90:	6422                	ld	s0,8(sp)
    4a92:	0141                	addi	sp,sp,16
    4a94:	8082                	ret

0000000000004a96 <strlen>:

uint
strlen(const char *s)
{
    4a96:	1141                	addi	sp,sp,-16
    4a98:	e422                	sd	s0,8(sp)
    4a9a:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    4a9c:	00054783          	lbu	a5,0(a0)
    4aa0:	cf91                	beqz	a5,4abc <strlen+0x26>
    4aa2:	0505                	addi	a0,a0,1
    4aa4:	87aa                	mv	a5,a0
    4aa6:	4685                	li	a3,1
    4aa8:	9e89                	subw	a3,a3,a0
    4aaa:	00f6853b          	addw	a0,a3,a5
    4aae:	0785                	addi	a5,a5,1
    4ab0:	fff7c703          	lbu	a4,-1(a5)
    4ab4:	fb7d                	bnez	a4,4aaa <strlen+0x14>
    ;
  return n;
}
    4ab6:	6422                	ld	s0,8(sp)
    4ab8:	0141                	addi	sp,sp,16
    4aba:	8082                	ret
  for(n = 0; s[n]; n++)
    4abc:	4501                	li	a0,0
    4abe:	bfe5                	j	4ab6 <strlen+0x20>

0000000000004ac0 <memset>:

void*
memset(void *dst, int c, uint n)
{
    4ac0:	1141                	addi	sp,sp,-16
    4ac2:	e422                	sd	s0,8(sp)
    4ac4:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    4ac6:	ca19                	beqz	a2,4adc <memset+0x1c>
    4ac8:	87aa                	mv	a5,a0
    4aca:	1602                	slli	a2,a2,0x20
    4acc:	9201                	srli	a2,a2,0x20
    4ace:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    4ad2:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    4ad6:	0785                	addi	a5,a5,1
    4ad8:	fee79de3          	bne	a5,a4,4ad2 <memset+0x12>
  }
  return dst;
}
    4adc:	6422                	ld	s0,8(sp)
    4ade:	0141                	addi	sp,sp,16
    4ae0:	8082                	ret

0000000000004ae2 <strchr>:

char*
strchr(const char *s, char c)
{
    4ae2:	1141                	addi	sp,sp,-16
    4ae4:	e422                	sd	s0,8(sp)
    4ae6:	0800                	addi	s0,sp,16
  for(; *s; s++)
    4ae8:	00054783          	lbu	a5,0(a0)
    4aec:	cb99                	beqz	a5,4b02 <strchr+0x20>
    if(*s == c)
    4aee:	00f58763          	beq	a1,a5,4afc <strchr+0x1a>
  for(; *s; s++)
    4af2:	0505                	addi	a0,a0,1
    4af4:	00054783          	lbu	a5,0(a0)
    4af8:	fbfd                	bnez	a5,4aee <strchr+0xc>
      return (char*)s;
  return 0;
    4afa:	4501                	li	a0,0
}
    4afc:	6422                	ld	s0,8(sp)
    4afe:	0141                	addi	sp,sp,16
    4b00:	8082                	ret
  return 0;
    4b02:	4501                	li	a0,0
    4b04:	bfe5                	j	4afc <strchr+0x1a>

0000000000004b06 <gets>:

char*
gets(char *buf, int max)
{
    4b06:	711d                	addi	sp,sp,-96
    4b08:	ec86                	sd	ra,88(sp)
    4b0a:	e8a2                	sd	s0,80(sp)
    4b0c:	e4a6                	sd	s1,72(sp)
    4b0e:	e0ca                	sd	s2,64(sp)
    4b10:	fc4e                	sd	s3,56(sp)
    4b12:	f852                	sd	s4,48(sp)
    4b14:	f456                	sd	s5,40(sp)
    4b16:	f05a                	sd	s6,32(sp)
    4b18:	ec5e                	sd	s7,24(sp)
    4b1a:	1080                	addi	s0,sp,96
    4b1c:	8baa                	mv	s7,a0
    4b1e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    4b20:	892a                	mv	s2,a0
    4b22:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
    4b24:	4aa9                	li	s5,10
    4b26:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
    4b28:	89a6                	mv	s3,s1
    4b2a:	2485                	addiw	s1,s1,1
    4b2c:	0344d663          	bge	s1,s4,4b58 <gets+0x52>
    cc = read(0, &c, 1);
    4b30:	4605                	li	a2,1
    4b32:	faf40593          	addi	a1,s0,-81
    4b36:	4501                	li	a0,0
    4b38:	188000ef          	jal	ra,4cc0 <read>
    if(cc < 1)
    4b3c:	00a05e63          	blez	a0,4b58 <gets+0x52>
    buf[i++] = c;
    4b40:	faf44783          	lbu	a5,-81(s0)
    4b44:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
    4b48:	01578763          	beq	a5,s5,4b56 <gets+0x50>
    4b4c:	0905                	addi	s2,s2,1
    4b4e:	fd679de3          	bne	a5,s6,4b28 <gets+0x22>
  for(i=0; i+1 < max; ){
    4b52:	89a6                	mv	s3,s1
    4b54:	a011                	j	4b58 <gets+0x52>
    4b56:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
    4b58:	99de                	add	s3,s3,s7
    4b5a:	00098023          	sb	zero,0(s3)
  return buf;
}
    4b5e:	855e                	mv	a0,s7
    4b60:	60e6                	ld	ra,88(sp)
    4b62:	6446                	ld	s0,80(sp)
    4b64:	64a6                	ld	s1,72(sp)
    4b66:	6906                	ld	s2,64(sp)
    4b68:	79e2                	ld	s3,56(sp)
    4b6a:	7a42                	ld	s4,48(sp)
    4b6c:	7aa2                	ld	s5,40(sp)
    4b6e:	7b02                	ld	s6,32(sp)
    4b70:	6be2                	ld	s7,24(sp)
    4b72:	6125                	addi	sp,sp,96
    4b74:	8082                	ret

0000000000004b76 <stat>:

int
stat(const char *n, struct stat *st)
{
    4b76:	1101                	addi	sp,sp,-32
    4b78:	ec06                	sd	ra,24(sp)
    4b7a:	e822                	sd	s0,16(sp)
    4b7c:	e426                	sd	s1,8(sp)
    4b7e:	e04a                	sd	s2,0(sp)
    4b80:	1000                	addi	s0,sp,32
    4b82:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    4b84:	4581                	li	a1,0
    4b86:	162000ef          	jal	ra,4ce8 <open>
  if(fd < 0)
    4b8a:	02054163          	bltz	a0,4bac <stat+0x36>
    4b8e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
    4b90:	85ca                	mv	a1,s2
    4b92:	16e000ef          	jal	ra,4d00 <fstat>
    4b96:	892a                	mv	s2,a0
  close(fd);
    4b98:	8526                	mv	a0,s1
    4b9a:	136000ef          	jal	ra,4cd0 <close>
  return r;
}
    4b9e:	854a                	mv	a0,s2
    4ba0:	60e2                	ld	ra,24(sp)
    4ba2:	6442                	ld	s0,16(sp)
    4ba4:	64a2                	ld	s1,8(sp)
    4ba6:	6902                	ld	s2,0(sp)
    4ba8:	6105                	addi	sp,sp,32
    4baa:	8082                	ret
    return -1;
    4bac:	597d                	li	s2,-1
    4bae:	bfc5                	j	4b9e <stat+0x28>

0000000000004bb0 <atoi>:

int
atoi(const char *s)
{
    4bb0:	1141                	addi	sp,sp,-16
    4bb2:	e422                	sd	s0,8(sp)
    4bb4:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    4bb6:	00054603          	lbu	a2,0(a0)
    4bba:	fd06079b          	addiw	a5,a2,-48
    4bbe:	0ff7f793          	zext.b	a5,a5
    4bc2:	4725                	li	a4,9
    4bc4:	02f76963          	bltu	a4,a5,4bf6 <atoi+0x46>
    4bc8:	86aa                	mv	a3,a0
  n = 0;
    4bca:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
    4bcc:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
    4bce:	0685                	addi	a3,a3,1
    4bd0:	0025179b          	slliw	a5,a0,0x2
    4bd4:	9fa9                	addw	a5,a5,a0
    4bd6:	0017979b          	slliw	a5,a5,0x1
    4bda:	9fb1                	addw	a5,a5,a2
    4bdc:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
    4be0:	0006c603          	lbu	a2,0(a3)
    4be4:	fd06071b          	addiw	a4,a2,-48
    4be8:	0ff77713          	zext.b	a4,a4
    4bec:	fee5f1e3          	bgeu	a1,a4,4bce <atoi+0x1e>
  return n;
}
    4bf0:	6422                	ld	s0,8(sp)
    4bf2:	0141                	addi	sp,sp,16
    4bf4:	8082                	ret
  n = 0;
    4bf6:	4501                	li	a0,0
    4bf8:	bfe5                	j	4bf0 <atoi+0x40>

0000000000004bfa <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
    4bfa:	1141                	addi	sp,sp,-16
    4bfc:	e422                	sd	s0,8(sp)
    4bfe:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    4c00:	02b57463          	bgeu	a0,a1,4c28 <memmove+0x2e>
    while(n-- > 0)
    4c04:	00c05f63          	blez	a2,4c22 <memmove+0x28>
    4c08:	1602                	slli	a2,a2,0x20
    4c0a:	9201                	srli	a2,a2,0x20
    4c0c:	00c507b3          	add	a5,a0,a2
  dst = vdst;
    4c10:	872a                	mv	a4,a0
      *dst++ = *src++;
    4c12:	0585                	addi	a1,a1,1
    4c14:	0705                	addi	a4,a4,1
    4c16:	fff5c683          	lbu	a3,-1(a1)
    4c1a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    4c1e:	fee79ae3          	bne	a5,a4,4c12 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
    4c22:	6422                	ld	s0,8(sp)
    4c24:	0141                	addi	sp,sp,16
    4c26:	8082                	ret
    dst += n;
    4c28:	00c50733          	add	a4,a0,a2
    src += n;
    4c2c:	95b2                	add	a1,a1,a2
    while(n-- > 0)
    4c2e:	fec05ae3          	blez	a2,4c22 <memmove+0x28>
    4c32:	fff6079b          	addiw	a5,a2,-1
    4c36:	1782                	slli	a5,a5,0x20
    4c38:	9381                	srli	a5,a5,0x20
    4c3a:	fff7c793          	not	a5,a5
    4c3e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
    4c40:	15fd                	addi	a1,a1,-1
    4c42:	177d                	addi	a4,a4,-1
    4c44:	0005c683          	lbu	a3,0(a1)
    4c48:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
    4c4c:	fee79ae3          	bne	a5,a4,4c40 <memmove+0x46>
    4c50:	bfc9                	j	4c22 <memmove+0x28>

0000000000004c52 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
    4c52:	1141                	addi	sp,sp,-16
    4c54:	e422                	sd	s0,8(sp)
    4c56:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    4c58:	ca05                	beqz	a2,4c88 <memcmp+0x36>
    4c5a:	fff6069b          	addiw	a3,a2,-1
    4c5e:	1682                	slli	a3,a3,0x20
    4c60:	9281                	srli	a3,a3,0x20
    4c62:	0685                	addi	a3,a3,1
    4c64:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
    4c66:	00054783          	lbu	a5,0(a0)
    4c6a:	0005c703          	lbu	a4,0(a1)
    4c6e:	00e79863          	bne	a5,a4,4c7e <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
    4c72:	0505                	addi	a0,a0,1
    p2++;
    4c74:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    4c76:	fed518e3          	bne	a0,a3,4c66 <memcmp+0x14>
  }
  return 0;
    4c7a:	4501                	li	a0,0
    4c7c:	a019                	j	4c82 <memcmp+0x30>
      return *p1 - *p2;
    4c7e:	40e7853b          	subw	a0,a5,a4
}
    4c82:	6422                	ld	s0,8(sp)
    4c84:	0141                	addi	sp,sp,16
    4c86:	8082                	ret
  return 0;
    4c88:	4501                	li	a0,0
    4c8a:	bfe5                	j	4c82 <memcmp+0x30>

0000000000004c8c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
    4c8c:	1141                	addi	sp,sp,-16
    4c8e:	e406                	sd	ra,8(sp)
    4c90:	e022                	sd	s0,0(sp)
    4c92:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    4c94:	f67ff0ef          	jal	ra,4bfa <memmove>
}
    4c98:	60a2                	ld	ra,8(sp)
    4c9a:	6402                	ld	s0,0(sp)
    4c9c:	0141                	addi	sp,sp,16
    4c9e:	8082                	ret

0000000000004ca0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
    4ca0:	4885                	li	a7,1
 ecall
    4ca2:	00000073          	ecall
 ret
    4ca6:	8082                	ret

0000000000004ca8 <exit>:
.global exit
exit:
 li a7, SYS_exit
    4ca8:	4889                	li	a7,2
 ecall
    4caa:	00000073          	ecall
 ret
    4cae:	8082                	ret

0000000000004cb0 <wait>:
.global wait
wait:
 li a7, SYS_wait
    4cb0:	488d                	li	a7,3
 ecall
    4cb2:	00000073          	ecall
 ret
    4cb6:	8082                	ret

0000000000004cb8 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
    4cb8:	4891                	li	a7,4
 ecall
    4cba:	00000073          	ecall
 ret
    4cbe:	8082                	ret

0000000000004cc0 <read>:
.global read
read:
 li a7, SYS_read
    4cc0:	4895                	li	a7,5
 ecall
    4cc2:	00000073          	ecall
 ret
    4cc6:	8082                	ret

0000000000004cc8 <write>:
.global write
write:
 li a7, SYS_write
    4cc8:	48c1                	li	a7,16
 ecall
    4cca:	00000073          	ecall
 ret
    4cce:	8082                	ret

0000000000004cd0 <close>:
.global close
close:
 li a7, SYS_close
    4cd0:	48d5                	li	a7,21
 ecall
    4cd2:	00000073          	ecall
 ret
    4cd6:	8082                	ret

0000000000004cd8 <kill>:
.global kill
kill:
 li a7, SYS_kill
    4cd8:	4899                	li	a7,6
 ecall
    4cda:	00000073          	ecall
 ret
    4cde:	8082                	ret

0000000000004ce0 <exec>:
.global exec
exec:
 li a7, SYS_exec
    4ce0:	489d                	li	a7,7
 ecall
    4ce2:	00000073          	ecall
 ret
    4ce6:	8082                	ret

0000000000004ce8 <open>:
.global open
open:
 li a7, SYS_open
    4ce8:	48bd                	li	a7,15
 ecall
    4cea:	00000073          	ecall
 ret
    4cee:	8082                	ret

0000000000004cf0 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
    4cf0:	48c5                	li	a7,17
 ecall
    4cf2:	00000073          	ecall
 ret
    4cf6:	8082                	ret

0000000000004cf8 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
    4cf8:	48c9                	li	a7,18
 ecall
    4cfa:	00000073          	ecall
 ret
    4cfe:	8082                	ret

0000000000004d00 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
    4d00:	48a1                	li	a7,8
 ecall
    4d02:	00000073          	ecall
 ret
    4d06:	8082                	ret

0000000000004d08 <link>:
.global link
link:
 li a7, SYS_link
    4d08:	48cd                	li	a7,19
 ecall
    4d0a:	00000073          	ecall
 ret
    4d0e:	8082                	ret

0000000000004d10 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
    4d10:	48d1                	li	a7,20
 ecall
    4d12:	00000073          	ecall
 ret
    4d16:	8082                	ret

0000000000004d18 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
    4d18:	48a5                	li	a7,9
 ecall
    4d1a:	00000073          	ecall
 ret
    4d1e:	8082                	ret

0000000000004d20 <dup>:
.global dup
dup:
 li a7, SYS_dup
    4d20:	48a9                	li	a7,10
 ecall
    4d22:	00000073          	ecall
 ret
    4d26:	8082                	ret

0000000000004d28 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
    4d28:	48ad                	li	a7,11
 ecall
    4d2a:	00000073          	ecall
 ret
    4d2e:	8082                	ret

0000000000004d30 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
    4d30:	48b1                	li	a7,12
 ecall
    4d32:	00000073          	ecall
 ret
    4d36:	8082                	ret

0000000000004d38 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
    4d38:	48b5                	li	a7,13
 ecall
    4d3a:	00000073          	ecall
 ret
    4d3e:	8082                	ret

0000000000004d40 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    4d40:	48b9                	li	a7,14
 ecall
    4d42:	00000073          	ecall
 ret
    4d46:	8082                	ret

0000000000004d48 <trace>:
.global trace
trace:
 li a7, SYS_trace
    4d48:	48d9                	li	a7,22
 ecall
    4d4a:	00000073          	ecall
 ret
    4d4e:	8082                	ret

0000000000004d50 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    4d50:	1101                	addi	sp,sp,-32
    4d52:	ec06                	sd	ra,24(sp)
    4d54:	e822                	sd	s0,16(sp)
    4d56:	1000                	addi	s0,sp,32
    4d58:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    4d5c:	4605                	li	a2,1
    4d5e:	fef40593          	addi	a1,s0,-17
    4d62:	f67ff0ef          	jal	ra,4cc8 <write>
}
    4d66:	60e2                	ld	ra,24(sp)
    4d68:	6442                	ld	s0,16(sp)
    4d6a:	6105                	addi	sp,sp,32
    4d6c:	8082                	ret

0000000000004d6e <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
    4d6e:	715d                	addi	sp,sp,-80
    4d70:	e486                	sd	ra,72(sp)
    4d72:	e0a2                	sd	s0,64(sp)
    4d74:	fc26                	sd	s1,56(sp)
    4d76:	f84a                	sd	s2,48(sp)
    4d78:	f44e                	sd	s3,40(sp)
    4d7a:	0880                	addi	s0,sp,80
    4d7c:	84aa                	mv	s1,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    4d7e:	c299                	beqz	a3,4d84 <printint+0x16>
    4d80:	0805c663          	bltz	a1,4e0c <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
    4d84:	2581                	sext.w	a1,a1
  neg = 0;
    4d86:	4881                	li	a7,0
    4d88:	fb840693          	addi	a3,s0,-72
  }

  i = 0;
    4d8c:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
    4d8e:	2601                	sext.w	a2,a2
    4d90:	00003517          	auipc	a0,0x3
    4d94:	a4850513          	addi	a0,a0,-1464 # 77d8 <digits>
    4d98:	883a                	mv	a6,a4
    4d9a:	2705                	addiw	a4,a4,1
    4d9c:	02c5f7bb          	remuw	a5,a1,a2
    4da0:	1782                	slli	a5,a5,0x20
    4da2:	9381                	srli	a5,a5,0x20
    4da4:	97aa                	add	a5,a5,a0
    4da6:	0007c783          	lbu	a5,0(a5)
    4daa:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
    4dae:	0005879b          	sext.w	a5,a1
    4db2:	02c5d5bb          	divuw	a1,a1,a2
    4db6:	0685                	addi	a3,a3,1
    4db8:	fec7f0e3          	bgeu	a5,a2,4d98 <printint+0x2a>
  if(neg)
    4dbc:	00088b63          	beqz	a7,4dd2 <printint+0x64>
    buf[i++] = '-';
    4dc0:	fd040793          	addi	a5,s0,-48
    4dc4:	973e                	add	a4,a4,a5
    4dc6:	02d00793          	li	a5,45
    4dca:	fef70423          	sb	a5,-24(a4)
    4dce:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
    4dd2:	02e05663          	blez	a4,4dfe <printint+0x90>
    4dd6:	fb840793          	addi	a5,s0,-72
    4dda:	00e78933          	add	s2,a5,a4
    4dde:	fff78993          	addi	s3,a5,-1
    4de2:	99ba                	add	s3,s3,a4
    4de4:	377d                	addiw	a4,a4,-1
    4de6:	1702                	slli	a4,a4,0x20
    4de8:	9301                	srli	a4,a4,0x20
    4dea:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
    4dee:	fff94583          	lbu	a1,-1(s2)
    4df2:	8526                	mv	a0,s1
    4df4:	f5dff0ef          	jal	ra,4d50 <putc>
  while(--i >= 0)
    4df8:	197d                	addi	s2,s2,-1
    4dfa:	ff391ae3          	bne	s2,s3,4dee <printint+0x80>
}
    4dfe:	60a6                	ld	ra,72(sp)
    4e00:	6406                	ld	s0,64(sp)
    4e02:	74e2                	ld	s1,56(sp)
    4e04:	7942                	ld	s2,48(sp)
    4e06:	79a2                	ld	s3,40(sp)
    4e08:	6161                	addi	sp,sp,80
    4e0a:	8082                	ret
    x = -xx;
    4e0c:	40b005bb          	negw	a1,a1
    neg = 1;
    4e10:	4885                	li	a7,1
    x = -xx;
    4e12:	bf9d                	j	4d88 <printint+0x1a>

0000000000004e14 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    4e14:	7119                	addi	sp,sp,-128
    4e16:	fc86                	sd	ra,120(sp)
    4e18:	f8a2                	sd	s0,112(sp)
    4e1a:	f4a6                	sd	s1,104(sp)
    4e1c:	f0ca                	sd	s2,96(sp)
    4e1e:	ecce                	sd	s3,88(sp)
    4e20:	e8d2                	sd	s4,80(sp)
    4e22:	e4d6                	sd	s5,72(sp)
    4e24:	e0da                	sd	s6,64(sp)
    4e26:	fc5e                	sd	s7,56(sp)
    4e28:	f862                	sd	s8,48(sp)
    4e2a:	f466                	sd	s9,40(sp)
    4e2c:	f06a                	sd	s10,32(sp)
    4e2e:	ec6e                	sd	s11,24(sp)
    4e30:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
    4e32:	0005c903          	lbu	s2,0(a1)
    4e36:	24090c63          	beqz	s2,508e <vprintf+0x27a>
    4e3a:	8b2a                	mv	s6,a0
    4e3c:	8a2e                	mv	s4,a1
    4e3e:	8bb2                	mv	s7,a2
  state = 0;
    4e40:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
    4e42:	4481                	li	s1,0
    4e44:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
    4e46:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
    4e4a:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
    4e4e:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
    4e52:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    4e56:	00003c97          	auipc	s9,0x3
    4e5a:	982c8c93          	addi	s9,s9,-1662 # 77d8 <digits>
    4e5e:	a005                	j	4e7e <vprintf+0x6a>
        putc(fd, c0);
    4e60:	85ca                	mv	a1,s2
    4e62:	855a                	mv	a0,s6
    4e64:	eedff0ef          	jal	ra,4d50 <putc>
    4e68:	a019                	j	4e6e <vprintf+0x5a>
    } else if(state == '%'){
    4e6a:	03598263          	beq	s3,s5,4e8e <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
    4e6e:	2485                	addiw	s1,s1,1
    4e70:	8726                	mv	a4,s1
    4e72:	009a07b3          	add	a5,s4,s1
    4e76:	0007c903          	lbu	s2,0(a5)
    4e7a:	20090a63          	beqz	s2,508e <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
    4e7e:	0009079b          	sext.w	a5,s2
    if(state == 0){
    4e82:	fe0994e3          	bnez	s3,4e6a <vprintf+0x56>
      if(c0 == '%'){
    4e86:	fd579de3          	bne	a5,s5,4e60 <vprintf+0x4c>
        state = '%';
    4e8a:	89be                	mv	s3,a5
    4e8c:	b7cd                	j	4e6e <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
    4e8e:	c3c1                	beqz	a5,4f0e <vprintf+0xfa>
    4e90:	00ea06b3          	add	a3,s4,a4
    4e94:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
    4e98:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
    4e9a:	c681                	beqz	a3,4ea2 <vprintf+0x8e>
    4e9c:	9752                	add	a4,a4,s4
    4e9e:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
    4ea2:	03878e63          	beq	a5,s8,4ede <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
    4ea6:	05a78863          	beq	a5,s10,4ef6 <vprintf+0xe2>
      } else if(c0 == 'u'){
    4eaa:	0db78b63          	beq	a5,s11,4f80 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
    4eae:	07800713          	li	a4,120
    4eb2:	10e78d63          	beq	a5,a4,4fcc <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
    4eb6:	07000713          	li	a4,112
    4eba:	14e78263          	beq	a5,a4,4ffe <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
    4ebe:	06300713          	li	a4,99
    4ec2:	16e78f63          	beq	a5,a4,5040 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
    4ec6:	07300713          	li	a4,115
    4eca:	18e78563          	beq	a5,a4,5054 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
    4ece:	05579063          	bne	a5,s5,4f0e <vprintf+0xfa>
        putc(fd, '%');
    4ed2:	85d6                	mv	a1,s5
    4ed4:	855a                	mv	a0,s6
    4ed6:	e7bff0ef          	jal	ra,4d50 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
    4eda:	4981                	li	s3,0
    4edc:	bf49                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
    4ede:	008b8913          	addi	s2,s7,8
    4ee2:	4685                	li	a3,1
    4ee4:	4629                	li	a2,10
    4ee6:	000ba583          	lw	a1,0(s7)
    4eea:	855a                	mv	a0,s6
    4eec:	e83ff0ef          	jal	ra,4d6e <printint>
    4ef0:	8bca                	mv	s7,s2
      state = 0;
    4ef2:	4981                	li	s3,0
    4ef4:	bfad                	j	4e6e <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
    4ef6:	03868663          	beq	a3,s8,4f22 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    4efa:	05a68163          	beq	a3,s10,4f3c <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
    4efe:	09b68d63          	beq	a3,s11,4f98 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    4f02:	03a68f63          	beq	a3,s10,4f40 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
    4f06:	07800793          	li	a5,120
    4f0a:	0cf68d63          	beq	a3,a5,4fe4 <vprintf+0x1d0>
        putc(fd, '%');
    4f0e:	85d6                	mv	a1,s5
    4f10:	855a                	mv	a0,s6
    4f12:	e3fff0ef          	jal	ra,4d50 <putc>
        putc(fd, c0);
    4f16:	85ca                	mv	a1,s2
    4f18:	855a                	mv	a0,s6
    4f1a:	e37ff0ef          	jal	ra,4d50 <putc>
      state = 0;
    4f1e:	4981                	li	s3,0
    4f20:	b7b9                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
    4f22:	008b8913          	addi	s2,s7,8
    4f26:	4685                	li	a3,1
    4f28:	4629                	li	a2,10
    4f2a:	000bb583          	ld	a1,0(s7)
    4f2e:	855a                	mv	a0,s6
    4f30:	e3fff0ef          	jal	ra,4d6e <printint>
        i += 1;
    4f34:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    4f36:	8bca                	mv	s7,s2
      state = 0;
    4f38:	4981                	li	s3,0
        i += 1;
    4f3a:	bf15                	j	4e6e <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    4f3c:	03860563          	beq	a2,s8,4f66 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    4f40:	07b60963          	beq	a2,s11,4fb2 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    4f44:	07800793          	li	a5,120
    4f48:	fcf613e3          	bne	a2,a5,4f0e <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
    4f4c:	008b8913          	addi	s2,s7,8
    4f50:	4681                	li	a3,0
    4f52:	4641                	li	a2,16
    4f54:	000bb583          	ld	a1,0(s7)
    4f58:	855a                	mv	a0,s6
    4f5a:	e15ff0ef          	jal	ra,4d6e <printint>
        i += 2;
    4f5e:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    4f60:	8bca                	mv	s7,s2
      state = 0;
    4f62:	4981                	li	s3,0
        i += 2;
    4f64:	b729                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
    4f66:	008b8913          	addi	s2,s7,8
    4f6a:	4685                	li	a3,1
    4f6c:	4629                	li	a2,10
    4f6e:	000bb583          	ld	a1,0(s7)
    4f72:	855a                	mv	a0,s6
    4f74:	dfbff0ef          	jal	ra,4d6e <printint>
        i += 2;
    4f78:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    4f7a:	8bca                	mv	s7,s2
      state = 0;
    4f7c:	4981                	li	s3,0
        i += 2;
    4f7e:	bdc5                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
    4f80:	008b8913          	addi	s2,s7,8
    4f84:	4681                	li	a3,0
    4f86:	4629                	li	a2,10
    4f88:	000be583          	lwu	a1,0(s7)
    4f8c:	855a                	mv	a0,s6
    4f8e:	de1ff0ef          	jal	ra,4d6e <printint>
    4f92:	8bca                	mv	s7,s2
      state = 0;
    4f94:	4981                	li	s3,0
    4f96:	bde1                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
    4f98:	008b8913          	addi	s2,s7,8
    4f9c:	4681                	li	a3,0
    4f9e:	4629                	li	a2,10
    4fa0:	000bb583          	ld	a1,0(s7)
    4fa4:	855a                	mv	a0,s6
    4fa6:	dc9ff0ef          	jal	ra,4d6e <printint>
        i += 1;
    4faa:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    4fac:	8bca                	mv	s7,s2
      state = 0;
    4fae:	4981                	li	s3,0
        i += 1;
    4fb0:	bd7d                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
    4fb2:	008b8913          	addi	s2,s7,8
    4fb6:	4681                	li	a3,0
    4fb8:	4629                	li	a2,10
    4fba:	000bb583          	ld	a1,0(s7)
    4fbe:	855a                	mv	a0,s6
    4fc0:	dafff0ef          	jal	ra,4d6e <printint>
        i += 2;
    4fc4:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    4fc6:	8bca                	mv	s7,s2
      state = 0;
    4fc8:	4981                	li	s3,0
        i += 2;
    4fca:	b555                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
    4fcc:	008b8913          	addi	s2,s7,8
    4fd0:	4681                	li	a3,0
    4fd2:	4641                	li	a2,16
    4fd4:	000be583          	lwu	a1,0(s7)
    4fd8:	855a                	mv	a0,s6
    4fda:	d95ff0ef          	jal	ra,4d6e <printint>
    4fde:	8bca                	mv	s7,s2
      state = 0;
    4fe0:	4981                	li	s3,0
    4fe2:	b571                	j	4e6e <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
    4fe4:	008b8913          	addi	s2,s7,8
    4fe8:	4681                	li	a3,0
    4fea:	4641                	li	a2,16
    4fec:	000bb583          	ld	a1,0(s7)
    4ff0:	855a                	mv	a0,s6
    4ff2:	d7dff0ef          	jal	ra,4d6e <printint>
        i += 1;
    4ff6:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    4ff8:	8bca                	mv	s7,s2
      state = 0;
    4ffa:	4981                	li	s3,0
        i += 1;
    4ffc:	bd8d                	j	4e6e <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
    4ffe:	008b8793          	addi	a5,s7,8
    5002:	f8f43423          	sd	a5,-120(s0)
    5006:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    500a:	03000593          	li	a1,48
    500e:	855a                	mv	a0,s6
    5010:	d41ff0ef          	jal	ra,4d50 <putc>
  putc(fd, 'x');
    5014:	07800593          	li	a1,120
    5018:	855a                	mv	a0,s6
    501a:	d37ff0ef          	jal	ra,4d50 <putc>
    501e:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    5020:	03c9d793          	srli	a5,s3,0x3c
    5024:	97e6                	add	a5,a5,s9
    5026:	0007c583          	lbu	a1,0(a5)
    502a:	855a                	mv	a0,s6
    502c:	d25ff0ef          	jal	ra,4d50 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    5030:	0992                	slli	s3,s3,0x4
    5032:	397d                	addiw	s2,s2,-1
    5034:	fe0916e3          	bnez	s2,5020 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
    5038:	f8843b83          	ld	s7,-120(s0)
      state = 0;
    503c:	4981                	li	s3,0
    503e:	bd05                	j	4e6e <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
    5040:	008b8913          	addi	s2,s7,8
    5044:	000bc583          	lbu	a1,0(s7)
    5048:	855a                	mv	a0,s6
    504a:	d07ff0ef          	jal	ra,4d50 <putc>
    504e:	8bca                	mv	s7,s2
      state = 0;
    5050:	4981                	li	s3,0
    5052:	bd31                	j	4e6e <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
    5054:	008b8993          	addi	s3,s7,8
    5058:	000bb903          	ld	s2,0(s7)
    505c:	00090f63          	beqz	s2,507a <vprintf+0x266>
        for(; *s; s++)
    5060:	00094583          	lbu	a1,0(s2)
    5064:	c195                	beqz	a1,5088 <vprintf+0x274>
          putc(fd, *s);
    5066:	855a                	mv	a0,s6
    5068:	ce9ff0ef          	jal	ra,4d50 <putc>
        for(; *s; s++)
    506c:	0905                	addi	s2,s2,1
    506e:	00094583          	lbu	a1,0(s2)
    5072:	f9f5                	bnez	a1,5066 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
    5074:	8bce                	mv	s7,s3
      state = 0;
    5076:	4981                	li	s3,0
    5078:	bbdd                	j	4e6e <vprintf+0x5a>
          s = "(null)";
    507a:	00002917          	auipc	s2,0x2
    507e:	75690913          	addi	s2,s2,1878 # 77d0 <malloc+0x2640>
        for(; *s; s++)
    5082:	02800593          	li	a1,40
    5086:	b7c5                	j	5066 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
    5088:	8bce                	mv	s7,s3
      state = 0;
    508a:	4981                	li	s3,0
    508c:	b3cd                	j	4e6e <vprintf+0x5a>
    }
  }
}
    508e:	70e6                	ld	ra,120(sp)
    5090:	7446                	ld	s0,112(sp)
    5092:	74a6                	ld	s1,104(sp)
    5094:	7906                	ld	s2,96(sp)
    5096:	69e6                	ld	s3,88(sp)
    5098:	6a46                	ld	s4,80(sp)
    509a:	6aa6                	ld	s5,72(sp)
    509c:	6b06                	ld	s6,64(sp)
    509e:	7be2                	ld	s7,56(sp)
    50a0:	7c42                	ld	s8,48(sp)
    50a2:	7ca2                	ld	s9,40(sp)
    50a4:	7d02                	ld	s10,32(sp)
    50a6:	6de2                	ld	s11,24(sp)
    50a8:	6109                	addi	sp,sp,128
    50aa:	8082                	ret

00000000000050ac <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    50ac:	715d                	addi	sp,sp,-80
    50ae:	ec06                	sd	ra,24(sp)
    50b0:	e822                	sd	s0,16(sp)
    50b2:	1000                	addi	s0,sp,32
    50b4:	e010                	sd	a2,0(s0)
    50b6:	e414                	sd	a3,8(s0)
    50b8:	e818                	sd	a4,16(s0)
    50ba:	ec1c                	sd	a5,24(s0)
    50bc:	03043023          	sd	a6,32(s0)
    50c0:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    50c4:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    50c8:	8622                	mv	a2,s0
    50ca:	d4bff0ef          	jal	ra,4e14 <vprintf>
}
    50ce:	60e2                	ld	ra,24(sp)
    50d0:	6442                	ld	s0,16(sp)
    50d2:	6161                	addi	sp,sp,80
    50d4:	8082                	ret

00000000000050d6 <printf>:

void
printf(const char *fmt, ...)
{
    50d6:	711d                	addi	sp,sp,-96
    50d8:	ec06                	sd	ra,24(sp)
    50da:	e822                	sd	s0,16(sp)
    50dc:	1000                	addi	s0,sp,32
    50de:	e40c                	sd	a1,8(s0)
    50e0:	e810                	sd	a2,16(s0)
    50e2:	ec14                	sd	a3,24(s0)
    50e4:	f018                	sd	a4,32(s0)
    50e6:	f41c                	sd	a5,40(s0)
    50e8:	03043823          	sd	a6,48(s0)
    50ec:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    50f0:	00840613          	addi	a2,s0,8
    50f4:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    50f8:	85aa                	mv	a1,a0
    50fa:	4505                	li	a0,1
    50fc:	d19ff0ef          	jal	ra,4e14 <vprintf>
}
    5100:	60e2                	ld	ra,24(sp)
    5102:	6442                	ld	s0,16(sp)
    5104:	6125                	addi	sp,sp,96
    5106:	8082                	ret

0000000000005108 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    5108:	1141                	addi	sp,sp,-16
    510a:	e422                	sd	s0,8(sp)
    510c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    510e:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    5112:	00003797          	auipc	a5,0x3
    5116:	36e7b783          	ld	a5,878(a5) # 8480 <freep>
    511a:	a805                	j	514a <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
    511c:	4618                	lw	a4,8(a2)
    511e:	9db9                	addw	a1,a1,a4
    5120:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    5124:	6398                	ld	a4,0(a5)
    5126:	6318                	ld	a4,0(a4)
    5128:	fee53823          	sd	a4,-16(a0)
    512c:	a091                	j	5170 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
    512e:	ff852703          	lw	a4,-8(a0)
    5132:	9e39                	addw	a2,a2,a4
    5134:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
    5136:	ff053703          	ld	a4,-16(a0)
    513a:	e398                	sd	a4,0(a5)
    513c:	a099                	j	5182 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    513e:	6398                	ld	a4,0(a5)
    5140:	00e7e463          	bltu	a5,a4,5148 <free+0x40>
    5144:	00e6ea63          	bltu	a3,a4,5158 <free+0x50>
{
    5148:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    514a:	fed7fae3          	bgeu	a5,a3,513e <free+0x36>
    514e:	6398                	ld	a4,0(a5)
    5150:	00e6e463          	bltu	a3,a4,5158 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    5154:	fee7eae3          	bltu	a5,a4,5148 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
    5158:	ff852583          	lw	a1,-8(a0)
    515c:	6390                	ld	a2,0(a5)
    515e:	02059813          	slli	a6,a1,0x20
    5162:	01c85713          	srli	a4,a6,0x1c
    5166:	9736                	add	a4,a4,a3
    5168:	fae60ae3          	beq	a2,a4,511c <free+0x14>
    bp->s.ptr = p->s.ptr;
    516c:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
    5170:	4790                	lw	a2,8(a5)
    5172:	02061593          	slli	a1,a2,0x20
    5176:	01c5d713          	srli	a4,a1,0x1c
    517a:	973e                	add	a4,a4,a5
    517c:	fae689e3          	beq	a3,a4,512e <free+0x26>
  } else
    p->s.ptr = bp;
    5180:	e394                	sd	a3,0(a5)
  freep = p;
    5182:	00003717          	auipc	a4,0x3
    5186:	2ef73f23          	sd	a5,766(a4) # 8480 <freep>
}
    518a:	6422                	ld	s0,8(sp)
    518c:	0141                	addi	sp,sp,16
    518e:	8082                	ret

0000000000005190 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    5190:	7139                	addi	sp,sp,-64
    5192:	fc06                	sd	ra,56(sp)
    5194:	f822                	sd	s0,48(sp)
    5196:	f426                	sd	s1,40(sp)
    5198:	f04a                	sd	s2,32(sp)
    519a:	ec4e                	sd	s3,24(sp)
    519c:	e852                	sd	s4,16(sp)
    519e:	e456                	sd	s5,8(sp)
    51a0:	e05a                	sd	s6,0(sp)
    51a2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    51a4:	02051493          	slli	s1,a0,0x20
    51a8:	9081                	srli	s1,s1,0x20
    51aa:	04bd                	addi	s1,s1,15
    51ac:	8091                	srli	s1,s1,0x4
    51ae:	0014899b          	addiw	s3,s1,1
    51b2:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
    51b4:	00003517          	auipc	a0,0x3
    51b8:	2cc53503          	ld	a0,716(a0) # 8480 <freep>
    51bc:	c515                	beqz	a0,51e8 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    51be:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    51c0:	4798                	lw	a4,8(a5)
    51c2:	02977f63          	bgeu	a4,s1,5200 <malloc+0x70>
    51c6:	8a4e                	mv	s4,s3
    51c8:	0009871b          	sext.w	a4,s3
    51cc:	6685                	lui	a3,0x1
    51ce:	00d77363          	bgeu	a4,a3,51d4 <malloc+0x44>
    51d2:	6a05                	lui	s4,0x1
    51d4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    51d8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    51dc:	00003917          	auipc	s2,0x3
    51e0:	2a490913          	addi	s2,s2,676 # 8480 <freep>
  if(p == (char*)-1)
    51e4:	5afd                	li	s5,-1
    51e6:	a885                	j	5256 <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
    51e8:	0000a797          	auipc	a5,0xa
    51ec:	ac078793          	addi	a5,a5,-1344 # eca8 <base>
    51f0:	00003717          	auipc	a4,0x3
    51f4:	28f73823          	sd	a5,656(a4) # 8480 <freep>
    51f8:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    51fa:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    51fe:	b7e1                	j	51c6 <malloc+0x36>
      if(p->s.size == nunits)
    5200:	02e48c63          	beq	s1,a4,5238 <malloc+0xa8>
        p->s.size -= nunits;
    5204:	4137073b          	subw	a4,a4,s3
    5208:	c798                	sw	a4,8(a5)
        p += p->s.size;
    520a:	02071693          	slli	a3,a4,0x20
    520e:	01c6d713          	srli	a4,a3,0x1c
    5212:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    5214:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    5218:	00003717          	auipc	a4,0x3
    521c:	26a73423          	sd	a0,616(a4) # 8480 <freep>
      return (void*)(p + 1);
    5220:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
    5224:	70e2                	ld	ra,56(sp)
    5226:	7442                	ld	s0,48(sp)
    5228:	74a2                	ld	s1,40(sp)
    522a:	7902                	ld	s2,32(sp)
    522c:	69e2                	ld	s3,24(sp)
    522e:	6a42                	ld	s4,16(sp)
    5230:	6aa2                	ld	s5,8(sp)
    5232:	6b02                	ld	s6,0(sp)
    5234:	6121                	addi	sp,sp,64
    5236:	8082                	ret
        prevp->s.ptr = p->s.ptr;
    5238:	6398                	ld	a4,0(a5)
    523a:	e118                	sd	a4,0(a0)
    523c:	bff1                	j	5218 <malloc+0x88>
  hp->s.size = nu;
    523e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    5242:	0541                	addi	a0,a0,16
    5244:	ec5ff0ef          	jal	ra,5108 <free>
  return freep;
    5248:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
    524c:	dd61                	beqz	a0,5224 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    524e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    5250:	4798                	lw	a4,8(a5)
    5252:	fa9777e3          	bgeu	a4,s1,5200 <malloc+0x70>
    if(p == freep)
    5256:	00093703          	ld	a4,0(s2)
    525a:	853e                	mv	a0,a5
    525c:	fef719e3          	bne	a4,a5,524e <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
    5260:	8552                	mv	a0,s4
    5262:	acfff0ef          	jal	ra,4d30 <sbrk>
  if(p == (char*)-1)
    5266:	fd551ce3          	bne	a0,s5,523e <malloc+0xae>
        return 0;
    526a:	4501                	li	a0,0
    526c:	bf65                	j	5224 <malloc+0x94>
