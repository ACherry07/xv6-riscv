
user/_HelloWorld:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
   0:	4505                	li	a0,1
   2:	00001597          	auipc	a1,0x1
   6:	ffe58593          	addi	a1,a1,-2 # 1000 <helloworld>
   a:	02300613          	li	a2,35
   e:	48c1                	li	a7,16
  10:	00000073          	ecall
  14:	4889                	li	a7,2
  16:	00000073          	ecall

000000000000001a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  1a:	1141                	addi	sp,sp,-16
  1c:	e406                	sd	ra,8(sp)
  1e:	e022                	sd	s0,0(sp)
  20:	0800                	addi	s0,sp,16
  extern int main();
  main();
  22:	fdfff0ef          	jal	ra,0 <main>
  exit(0);
  26:	4501                	li	a0,0
  28:	25e000ef          	jal	ra,286 <exit>

000000000000002c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  2c:	1141                	addi	sp,sp,-16
  2e:	e422                	sd	s0,8(sp)
  30:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  32:	87aa                	mv	a5,a0
  34:	0585                	addi	a1,a1,1
  36:	0785                	addi	a5,a5,1
  38:	fff5c703          	lbu	a4,-1(a1)
  3c:	fee78fa3          	sb	a4,-1(a5)
  40:	fb75                	bnez	a4,34 <strcpy+0x8>
    ;
  return os;
}
  42:	6422                	ld	s0,8(sp)
  44:	0141                	addi	sp,sp,16
  46:	8082                	ret

0000000000000048 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  48:	1141                	addi	sp,sp,-16
  4a:	e422                	sd	s0,8(sp)
  4c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  4e:	00054783          	lbu	a5,0(a0)
  52:	cb91                	beqz	a5,66 <strcmp+0x1e>
  54:	0005c703          	lbu	a4,0(a1)
  58:	00f71763          	bne	a4,a5,66 <strcmp+0x1e>
    p++, q++;
  5c:	0505                	addi	a0,a0,1
  5e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  60:	00054783          	lbu	a5,0(a0)
  64:	fbe5                	bnez	a5,54 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
  66:	0005c503          	lbu	a0,0(a1)
}
  6a:	40a7853b          	subw	a0,a5,a0
  6e:	6422                	ld	s0,8(sp)
  70:	0141                	addi	sp,sp,16
  72:	8082                	ret

0000000000000074 <strlen>:

uint
strlen(const char *s)
{
  74:	1141                	addi	sp,sp,-16
  76:	e422                	sd	s0,8(sp)
  78:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  7a:	00054783          	lbu	a5,0(a0)
  7e:	cf91                	beqz	a5,9a <strlen+0x26>
  80:	0505                	addi	a0,a0,1
  82:	87aa                	mv	a5,a0
  84:	4685                	li	a3,1
  86:	9e89                	subw	a3,a3,a0
  88:	00f6853b          	addw	a0,a3,a5
  8c:	0785                	addi	a5,a5,1
  8e:	fff7c703          	lbu	a4,-1(a5)
  92:	fb7d                	bnez	a4,88 <strlen+0x14>
    ;
  return n;
}
  94:	6422                	ld	s0,8(sp)
  96:	0141                	addi	sp,sp,16
  98:	8082                	ret
  for(n = 0; s[n]; n++)
  9a:	4501                	li	a0,0
  9c:	bfe5                	j	94 <strlen+0x20>

000000000000009e <memset>:

void*
memset(void *dst, int c, uint n)
{
  9e:	1141                	addi	sp,sp,-16
  a0:	e422                	sd	s0,8(sp)
  a2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  a4:	ca19                	beqz	a2,ba <memset+0x1c>
  a6:	87aa                	mv	a5,a0
  a8:	1602                	slli	a2,a2,0x20
  aa:	9201                	srli	a2,a2,0x20
  ac:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  b0:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  b4:	0785                	addi	a5,a5,1
  b6:	fee79de3          	bne	a5,a4,b0 <memset+0x12>
  }
  return dst;
}
  ba:	6422                	ld	s0,8(sp)
  bc:	0141                	addi	sp,sp,16
  be:	8082                	ret

00000000000000c0 <strchr>:

char*
strchr(const char *s, char c)
{
  c0:	1141                	addi	sp,sp,-16
  c2:	e422                	sd	s0,8(sp)
  c4:	0800                	addi	s0,sp,16
  for(; *s; s++)
  c6:	00054783          	lbu	a5,0(a0)
  ca:	cb99                	beqz	a5,e0 <strchr+0x20>
    if(*s == c)
  cc:	00f58763          	beq	a1,a5,da <strchr+0x1a>
  for(; *s; s++)
  d0:	0505                	addi	a0,a0,1
  d2:	00054783          	lbu	a5,0(a0)
  d6:	fbfd                	bnez	a5,cc <strchr+0xc>
      return (char*)s;
  return 0;
  d8:	4501                	li	a0,0
}
  da:	6422                	ld	s0,8(sp)
  dc:	0141                	addi	sp,sp,16
  de:	8082                	ret
  return 0;
  e0:	4501                	li	a0,0
  e2:	bfe5                	j	da <strchr+0x1a>

00000000000000e4 <gets>:

char*
gets(char *buf, int max)
{
  e4:	711d                	addi	sp,sp,-96
  e6:	ec86                	sd	ra,88(sp)
  e8:	e8a2                	sd	s0,80(sp)
  ea:	e4a6                	sd	s1,72(sp)
  ec:	e0ca                	sd	s2,64(sp)
  ee:	fc4e                	sd	s3,56(sp)
  f0:	f852                	sd	s4,48(sp)
  f2:	f456                	sd	s5,40(sp)
  f4:	f05a                	sd	s6,32(sp)
  f6:	ec5e                	sd	s7,24(sp)
  f8:	1080                	addi	s0,sp,96
  fa:	8baa                	mv	s7,a0
  fc:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
  fe:	892a                	mv	s2,a0
 100:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 102:	4aa9                	li	s5,10
 104:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 106:	89a6                	mv	s3,s1
 108:	2485                	addiw	s1,s1,1
 10a:	0344d663          	bge	s1,s4,136 <gets+0x52>
    cc = read(0, &c, 1);
 10e:	4605                	li	a2,1
 110:	faf40593          	addi	a1,s0,-81
 114:	4501                	li	a0,0
 116:	188000ef          	jal	ra,29e <read>
    if(cc < 1)
 11a:	00a05e63          	blez	a0,136 <gets+0x52>
    buf[i++] = c;
 11e:	faf44783          	lbu	a5,-81(s0)
 122:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 126:	01578763          	beq	a5,s5,134 <gets+0x50>
 12a:	0905                	addi	s2,s2,1
 12c:	fd679de3          	bne	a5,s6,106 <gets+0x22>
  for(i=0; i+1 < max; ){
 130:	89a6                	mv	s3,s1
 132:	a011                	j	136 <gets+0x52>
 134:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 136:	99de                	add	s3,s3,s7
 138:	00098023          	sb	zero,0(s3)
  return buf;
}
 13c:	855e                	mv	a0,s7
 13e:	60e6                	ld	ra,88(sp)
 140:	6446                	ld	s0,80(sp)
 142:	64a6                	ld	s1,72(sp)
 144:	6906                	ld	s2,64(sp)
 146:	79e2                	ld	s3,56(sp)
 148:	7a42                	ld	s4,48(sp)
 14a:	7aa2                	ld	s5,40(sp)
 14c:	7b02                	ld	s6,32(sp)
 14e:	6be2                	ld	s7,24(sp)
 150:	6125                	addi	sp,sp,96
 152:	8082                	ret

0000000000000154 <stat>:

int
stat(const char *n, struct stat *st)
{
 154:	1101                	addi	sp,sp,-32
 156:	ec06                	sd	ra,24(sp)
 158:	e822                	sd	s0,16(sp)
 15a:	e426                	sd	s1,8(sp)
 15c:	e04a                	sd	s2,0(sp)
 15e:	1000                	addi	s0,sp,32
 160:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 162:	4581                	li	a1,0
 164:	162000ef          	jal	ra,2c6 <open>
  if(fd < 0)
 168:	02054163          	bltz	a0,18a <stat+0x36>
 16c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 16e:	85ca                	mv	a1,s2
 170:	16e000ef          	jal	ra,2de <fstat>
 174:	892a                	mv	s2,a0
  close(fd);
 176:	8526                	mv	a0,s1
 178:	136000ef          	jal	ra,2ae <close>
  return r;
}
 17c:	854a                	mv	a0,s2
 17e:	60e2                	ld	ra,24(sp)
 180:	6442                	ld	s0,16(sp)
 182:	64a2                	ld	s1,8(sp)
 184:	6902                	ld	s2,0(sp)
 186:	6105                	addi	sp,sp,32
 188:	8082                	ret
    return -1;
 18a:	597d                	li	s2,-1
 18c:	bfc5                	j	17c <stat+0x28>

000000000000018e <atoi>:

int
atoi(const char *s)
{
 18e:	1141                	addi	sp,sp,-16
 190:	e422                	sd	s0,8(sp)
 192:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 194:	00054603          	lbu	a2,0(a0)
 198:	fd06079b          	addiw	a5,a2,-48
 19c:	0ff7f793          	zext.b	a5,a5
 1a0:	4725                	li	a4,9
 1a2:	02f76963          	bltu	a4,a5,1d4 <atoi+0x46>
 1a6:	86aa                	mv	a3,a0
  n = 0;
 1a8:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 1aa:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 1ac:	0685                	addi	a3,a3,1
 1ae:	0025179b          	slliw	a5,a0,0x2
 1b2:	9fa9                	addw	a5,a5,a0
 1b4:	0017979b          	slliw	a5,a5,0x1
 1b8:	9fb1                	addw	a5,a5,a2
 1ba:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1be:	0006c603          	lbu	a2,0(a3)
 1c2:	fd06071b          	addiw	a4,a2,-48
 1c6:	0ff77713          	zext.b	a4,a4
 1ca:	fee5f1e3          	bgeu	a1,a4,1ac <atoi+0x1e>
  return n;
}
 1ce:	6422                	ld	s0,8(sp)
 1d0:	0141                	addi	sp,sp,16
 1d2:	8082                	ret
  n = 0;
 1d4:	4501                	li	a0,0
 1d6:	bfe5                	j	1ce <atoi+0x40>

00000000000001d8 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1d8:	1141                	addi	sp,sp,-16
 1da:	e422                	sd	s0,8(sp)
 1dc:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 1de:	02b57463          	bgeu	a0,a1,206 <memmove+0x2e>
    while(n-- > 0)
 1e2:	00c05f63          	blez	a2,200 <memmove+0x28>
 1e6:	1602                	slli	a2,a2,0x20
 1e8:	9201                	srli	a2,a2,0x20
 1ea:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 1ee:	872a                	mv	a4,a0
      *dst++ = *src++;
 1f0:	0585                	addi	a1,a1,1
 1f2:	0705                	addi	a4,a4,1
 1f4:	fff5c683          	lbu	a3,-1(a1)
 1f8:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 1fc:	fee79ae3          	bne	a5,a4,1f0 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 200:	6422                	ld	s0,8(sp)
 202:	0141                	addi	sp,sp,16
 204:	8082                	ret
    dst += n;
 206:	00c50733          	add	a4,a0,a2
    src += n;
 20a:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 20c:	fec05ae3          	blez	a2,200 <memmove+0x28>
 210:	fff6079b          	addiw	a5,a2,-1
 214:	1782                	slli	a5,a5,0x20
 216:	9381                	srli	a5,a5,0x20
 218:	fff7c793          	not	a5,a5
 21c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 21e:	15fd                	addi	a1,a1,-1
 220:	177d                	addi	a4,a4,-1
 222:	0005c683          	lbu	a3,0(a1)
 226:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 22a:	fee79ae3          	bne	a5,a4,21e <memmove+0x46>
 22e:	bfc9                	j	200 <memmove+0x28>

0000000000000230 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 230:	1141                	addi	sp,sp,-16
 232:	e422                	sd	s0,8(sp)
 234:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 236:	ca05                	beqz	a2,266 <memcmp+0x36>
 238:	fff6069b          	addiw	a3,a2,-1
 23c:	1682                	slli	a3,a3,0x20
 23e:	9281                	srli	a3,a3,0x20
 240:	0685                	addi	a3,a3,1
 242:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 244:	00054783          	lbu	a5,0(a0)
 248:	0005c703          	lbu	a4,0(a1)
 24c:	00e79863          	bne	a5,a4,25c <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 250:	0505                	addi	a0,a0,1
    p2++;
 252:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 254:	fed518e3          	bne	a0,a3,244 <memcmp+0x14>
  }
  return 0;
 258:	4501                	li	a0,0
 25a:	a019                	j	260 <memcmp+0x30>
      return *p1 - *p2;
 25c:	40e7853b          	subw	a0,a5,a4
}
 260:	6422                	ld	s0,8(sp)
 262:	0141                	addi	sp,sp,16
 264:	8082                	ret
  return 0;
 266:	4501                	li	a0,0
 268:	bfe5                	j	260 <memcmp+0x30>

000000000000026a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 26a:	1141                	addi	sp,sp,-16
 26c:	e406                	sd	ra,8(sp)
 26e:	e022                	sd	s0,0(sp)
 270:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 272:	f67ff0ef          	jal	ra,1d8 <memmove>
}
 276:	60a2                	ld	ra,8(sp)
 278:	6402                	ld	s0,0(sp)
 27a:	0141                	addi	sp,sp,16
 27c:	8082                	ret

000000000000027e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 27e:	4885                	li	a7,1
 ecall
 280:	00000073          	ecall
 ret
 284:	8082                	ret

0000000000000286 <exit>:
.global exit
exit:
 li a7, SYS_exit
 286:	4889                	li	a7,2
 ecall
 288:	00000073          	ecall
 ret
 28c:	8082                	ret

000000000000028e <wait>:
.global wait
wait:
 li a7, SYS_wait
 28e:	488d                	li	a7,3
 ecall
 290:	00000073          	ecall
 ret
 294:	8082                	ret

0000000000000296 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 296:	4891                	li	a7,4
 ecall
 298:	00000073          	ecall
 ret
 29c:	8082                	ret

000000000000029e <read>:
.global read
read:
 li a7, SYS_read
 29e:	4895                	li	a7,5
 ecall
 2a0:	00000073          	ecall
 ret
 2a4:	8082                	ret

00000000000002a6 <write>:
.global write
write:
 li a7, SYS_write
 2a6:	48c1                	li	a7,16
 ecall
 2a8:	00000073          	ecall
 ret
 2ac:	8082                	ret

00000000000002ae <close>:
.global close
close:
 li a7, SYS_close
 2ae:	48d5                	li	a7,21
 ecall
 2b0:	00000073          	ecall
 ret
 2b4:	8082                	ret

00000000000002b6 <kill>:
.global kill
kill:
 li a7, SYS_kill
 2b6:	4899                	li	a7,6
 ecall
 2b8:	00000073          	ecall
 ret
 2bc:	8082                	ret

00000000000002be <exec>:
.global exec
exec:
 li a7, SYS_exec
 2be:	489d                	li	a7,7
 ecall
 2c0:	00000073          	ecall
 ret
 2c4:	8082                	ret

00000000000002c6 <open>:
.global open
open:
 li a7, SYS_open
 2c6:	48bd                	li	a7,15
 ecall
 2c8:	00000073          	ecall
 ret
 2cc:	8082                	ret

00000000000002ce <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 2ce:	48c5                	li	a7,17
 ecall
 2d0:	00000073          	ecall
 ret
 2d4:	8082                	ret

00000000000002d6 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 2d6:	48c9                	li	a7,18
 ecall
 2d8:	00000073          	ecall
 ret
 2dc:	8082                	ret

00000000000002de <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 2de:	48a1                	li	a7,8
 ecall
 2e0:	00000073          	ecall
 ret
 2e4:	8082                	ret

00000000000002e6 <link>:
.global link
link:
 li a7, SYS_link
 2e6:	48cd                	li	a7,19
 ecall
 2e8:	00000073          	ecall
 ret
 2ec:	8082                	ret

00000000000002ee <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 2ee:	48d1                	li	a7,20
 ecall
 2f0:	00000073          	ecall
 ret
 2f4:	8082                	ret

00000000000002f6 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 2f6:	48a5                	li	a7,9
 ecall
 2f8:	00000073          	ecall
 ret
 2fc:	8082                	ret

00000000000002fe <dup>:
.global dup
dup:
 li a7, SYS_dup
 2fe:	48a9                	li	a7,10
 ecall
 300:	00000073          	ecall
 ret
 304:	8082                	ret

0000000000000306 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 306:	48ad                	li	a7,11
 ecall
 308:	00000073          	ecall
 ret
 30c:	8082                	ret

000000000000030e <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 30e:	48b1                	li	a7,12
 ecall
 310:	00000073          	ecall
 ret
 314:	8082                	ret

0000000000000316 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 316:	48b5                	li	a7,13
 ecall
 318:	00000073          	ecall
 ret
 31c:	8082                	ret

000000000000031e <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 31e:	48b9                	li	a7,14
 ecall
 320:	00000073          	ecall
 ret
 324:	8082                	ret

0000000000000326 <trace>:
.global trace
trace:
 li a7, SYS_trace
 326:	48d9                	li	a7,22
 ecall
 328:	00000073          	ecall
 ret
 32c:	8082                	ret

000000000000032e <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 32e:	1101                	addi	sp,sp,-32
 330:	ec06                	sd	ra,24(sp)
 332:	e822                	sd	s0,16(sp)
 334:	1000                	addi	s0,sp,32
 336:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 33a:	4605                	li	a2,1
 33c:	fef40593          	addi	a1,s0,-17
 340:	f67ff0ef          	jal	ra,2a6 <write>
}
 344:	60e2                	ld	ra,24(sp)
 346:	6442                	ld	s0,16(sp)
 348:	6105                	addi	sp,sp,32
 34a:	8082                	ret

000000000000034c <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 34c:	715d                	addi	sp,sp,-80
 34e:	e486                	sd	ra,72(sp)
 350:	e0a2                	sd	s0,64(sp)
 352:	fc26                	sd	s1,56(sp)
 354:	f84a                	sd	s2,48(sp)
 356:	f44e                	sd	s3,40(sp)
 358:	0880                	addi	s0,sp,80
 35a:	84aa                	mv	s1,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 35c:	c299                	beqz	a3,362 <printint+0x16>
 35e:	0805c663          	bltz	a1,3ea <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 362:	2581                	sext.w	a1,a1
  neg = 0;
 364:	4881                	li	a7,0
 366:	fb840693          	addi	a3,s0,-72
  }

  i = 0;
 36a:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 36c:	2601                	sext.w	a2,a2
 36e:	00000517          	auipc	a0,0x0
 372:	4ea50513          	addi	a0,a0,1258 # 858 <digits>
 376:	883a                	mv	a6,a4
 378:	2705                	addiw	a4,a4,1
 37a:	02c5f7bb          	remuw	a5,a1,a2
 37e:	1782                	slli	a5,a5,0x20
 380:	9381                	srli	a5,a5,0x20
 382:	97aa                	add	a5,a5,a0
 384:	0007c783          	lbu	a5,0(a5)
 388:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 38c:	0005879b          	sext.w	a5,a1
 390:	02c5d5bb          	divuw	a1,a1,a2
 394:	0685                	addi	a3,a3,1
 396:	fec7f0e3          	bgeu	a5,a2,376 <printint+0x2a>
  if(neg)
 39a:	00088b63          	beqz	a7,3b0 <printint+0x64>
    buf[i++] = '-';
 39e:	fd040793          	addi	a5,s0,-48
 3a2:	973e                	add	a4,a4,a5
 3a4:	02d00793          	li	a5,45
 3a8:	fef70423          	sb	a5,-24(a4)
 3ac:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 3b0:	02e05663          	blez	a4,3dc <printint+0x90>
 3b4:	fb840793          	addi	a5,s0,-72
 3b8:	00e78933          	add	s2,a5,a4
 3bc:	fff78993          	addi	s3,a5,-1
 3c0:	99ba                	add	s3,s3,a4
 3c2:	377d                	addiw	a4,a4,-1
 3c4:	1702                	slli	a4,a4,0x20
 3c6:	9301                	srli	a4,a4,0x20
 3c8:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 3cc:	fff94583          	lbu	a1,-1(s2)
 3d0:	8526                	mv	a0,s1
 3d2:	f5dff0ef          	jal	ra,32e <putc>
  while(--i >= 0)
 3d6:	197d                	addi	s2,s2,-1
 3d8:	ff391ae3          	bne	s2,s3,3cc <printint+0x80>
}
 3dc:	60a6                	ld	ra,72(sp)
 3de:	6406                	ld	s0,64(sp)
 3e0:	74e2                	ld	s1,56(sp)
 3e2:	7942                	ld	s2,48(sp)
 3e4:	79a2                	ld	s3,40(sp)
 3e6:	6161                	addi	sp,sp,80
 3e8:	8082                	ret
    x = -xx;
 3ea:	40b005bb          	negw	a1,a1
    neg = 1;
 3ee:	4885                	li	a7,1
    x = -xx;
 3f0:	bf9d                	j	366 <printint+0x1a>

00000000000003f2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 3f2:	7119                	addi	sp,sp,-128
 3f4:	fc86                	sd	ra,120(sp)
 3f6:	f8a2                	sd	s0,112(sp)
 3f8:	f4a6                	sd	s1,104(sp)
 3fa:	f0ca                	sd	s2,96(sp)
 3fc:	ecce                	sd	s3,88(sp)
 3fe:	e8d2                	sd	s4,80(sp)
 400:	e4d6                	sd	s5,72(sp)
 402:	e0da                	sd	s6,64(sp)
 404:	fc5e                	sd	s7,56(sp)
 406:	f862                	sd	s8,48(sp)
 408:	f466                	sd	s9,40(sp)
 40a:	f06a                	sd	s10,32(sp)
 40c:	ec6e                	sd	s11,24(sp)
 40e:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 410:	0005c903          	lbu	s2,0(a1)
 414:	24090c63          	beqz	s2,66c <vprintf+0x27a>
 418:	8b2a                	mv	s6,a0
 41a:	8a2e                	mv	s4,a1
 41c:	8bb2                	mv	s7,a2
  state = 0;
 41e:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 420:	4481                	li	s1,0
 422:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 424:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 428:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 42c:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 430:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 434:	00000c97          	auipc	s9,0x0
 438:	424c8c93          	addi	s9,s9,1060 # 858 <digits>
 43c:	a005                	j	45c <vprintf+0x6a>
        putc(fd, c0);
 43e:	85ca                	mv	a1,s2
 440:	855a                	mv	a0,s6
 442:	eedff0ef          	jal	ra,32e <putc>
 446:	a019                	j	44c <vprintf+0x5a>
    } else if(state == '%'){
 448:	03598263          	beq	s3,s5,46c <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 44c:	2485                	addiw	s1,s1,1
 44e:	8726                	mv	a4,s1
 450:	009a07b3          	add	a5,s4,s1
 454:	0007c903          	lbu	s2,0(a5)
 458:	20090a63          	beqz	s2,66c <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 45c:	0009079b          	sext.w	a5,s2
    if(state == 0){
 460:	fe0994e3          	bnez	s3,448 <vprintf+0x56>
      if(c0 == '%'){
 464:	fd579de3          	bne	a5,s5,43e <vprintf+0x4c>
        state = '%';
 468:	89be                	mv	s3,a5
 46a:	b7cd                	j	44c <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 46c:	c3c1                	beqz	a5,4ec <vprintf+0xfa>
 46e:	00ea06b3          	add	a3,s4,a4
 472:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 476:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 478:	c681                	beqz	a3,480 <vprintf+0x8e>
 47a:	9752                	add	a4,a4,s4
 47c:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 480:	03878e63          	beq	a5,s8,4bc <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 484:	05a78863          	beq	a5,s10,4d4 <vprintf+0xe2>
      } else if(c0 == 'u'){
 488:	0db78b63          	beq	a5,s11,55e <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 48c:	07800713          	li	a4,120
 490:	10e78d63          	beq	a5,a4,5aa <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 494:	07000713          	li	a4,112
 498:	14e78263          	beq	a5,a4,5dc <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 49c:	06300713          	li	a4,99
 4a0:	16e78f63          	beq	a5,a4,61e <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 4a4:	07300713          	li	a4,115
 4a8:	18e78563          	beq	a5,a4,632 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 4ac:	05579063          	bne	a5,s5,4ec <vprintf+0xfa>
        putc(fd, '%');
 4b0:	85d6                	mv	a1,s5
 4b2:	855a                	mv	a0,s6
 4b4:	e7bff0ef          	jal	ra,32e <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 4b8:	4981                	li	s3,0
 4ba:	bf49                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 4bc:	008b8913          	addi	s2,s7,8
 4c0:	4685                	li	a3,1
 4c2:	4629                	li	a2,10
 4c4:	000ba583          	lw	a1,0(s7)
 4c8:	855a                	mv	a0,s6
 4ca:	e83ff0ef          	jal	ra,34c <printint>
 4ce:	8bca                	mv	s7,s2
      state = 0;
 4d0:	4981                	li	s3,0
 4d2:	bfad                	j	44c <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 4d4:	03868663          	beq	a3,s8,500 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4d8:	05a68163          	beq	a3,s10,51a <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 4dc:	09b68d63          	beq	a3,s11,576 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 4e0:	03a68f63          	beq	a3,s10,51e <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 4e4:	07800793          	li	a5,120
 4e8:	0cf68d63          	beq	a3,a5,5c2 <vprintf+0x1d0>
        putc(fd, '%');
 4ec:	85d6                	mv	a1,s5
 4ee:	855a                	mv	a0,s6
 4f0:	e3fff0ef          	jal	ra,32e <putc>
        putc(fd, c0);
 4f4:	85ca                	mv	a1,s2
 4f6:	855a                	mv	a0,s6
 4f8:	e37ff0ef          	jal	ra,32e <putc>
      state = 0;
 4fc:	4981                	li	s3,0
 4fe:	b7b9                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 500:	008b8913          	addi	s2,s7,8
 504:	4685                	li	a3,1
 506:	4629                	li	a2,10
 508:	000bb583          	ld	a1,0(s7)
 50c:	855a                	mv	a0,s6
 50e:	e3fff0ef          	jal	ra,34c <printint>
        i += 1;
 512:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 514:	8bca                	mv	s7,s2
      state = 0;
 516:	4981                	li	s3,0
        i += 1;
 518:	bf15                	j	44c <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 51a:	03860563          	beq	a2,s8,544 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 51e:	07b60963          	beq	a2,s11,590 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 522:	07800793          	li	a5,120
 526:	fcf613e3          	bne	a2,a5,4ec <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 52a:	008b8913          	addi	s2,s7,8
 52e:	4681                	li	a3,0
 530:	4641                	li	a2,16
 532:	000bb583          	ld	a1,0(s7)
 536:	855a                	mv	a0,s6
 538:	e15ff0ef          	jal	ra,34c <printint>
        i += 2;
 53c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 53e:	8bca                	mv	s7,s2
      state = 0;
 540:	4981                	li	s3,0
        i += 2;
 542:	b729                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 544:	008b8913          	addi	s2,s7,8
 548:	4685                	li	a3,1
 54a:	4629                	li	a2,10
 54c:	000bb583          	ld	a1,0(s7)
 550:	855a                	mv	a0,s6
 552:	dfbff0ef          	jal	ra,34c <printint>
        i += 2;
 556:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 558:	8bca                	mv	s7,s2
      state = 0;
 55a:	4981                	li	s3,0
        i += 2;
 55c:	bdc5                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 55e:	008b8913          	addi	s2,s7,8
 562:	4681                	li	a3,0
 564:	4629                	li	a2,10
 566:	000be583          	lwu	a1,0(s7)
 56a:	855a                	mv	a0,s6
 56c:	de1ff0ef          	jal	ra,34c <printint>
 570:	8bca                	mv	s7,s2
      state = 0;
 572:	4981                	li	s3,0
 574:	bde1                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 576:	008b8913          	addi	s2,s7,8
 57a:	4681                	li	a3,0
 57c:	4629                	li	a2,10
 57e:	000bb583          	ld	a1,0(s7)
 582:	855a                	mv	a0,s6
 584:	dc9ff0ef          	jal	ra,34c <printint>
        i += 1;
 588:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 58a:	8bca                	mv	s7,s2
      state = 0;
 58c:	4981                	li	s3,0
        i += 1;
 58e:	bd7d                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 590:	008b8913          	addi	s2,s7,8
 594:	4681                	li	a3,0
 596:	4629                	li	a2,10
 598:	000bb583          	ld	a1,0(s7)
 59c:	855a                	mv	a0,s6
 59e:	dafff0ef          	jal	ra,34c <printint>
        i += 2;
 5a2:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5a4:	8bca                	mv	s7,s2
      state = 0;
 5a6:	4981                	li	s3,0
        i += 2;
 5a8:	b555                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 5aa:	008b8913          	addi	s2,s7,8
 5ae:	4681                	li	a3,0
 5b0:	4641                	li	a2,16
 5b2:	000be583          	lwu	a1,0(s7)
 5b6:	855a                	mv	a0,s6
 5b8:	d95ff0ef          	jal	ra,34c <printint>
 5bc:	8bca                	mv	s7,s2
      state = 0;
 5be:	4981                	li	s3,0
 5c0:	b571                	j	44c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5c2:	008b8913          	addi	s2,s7,8
 5c6:	4681                	li	a3,0
 5c8:	4641                	li	a2,16
 5ca:	000bb583          	ld	a1,0(s7)
 5ce:	855a                	mv	a0,s6
 5d0:	d7dff0ef          	jal	ra,34c <printint>
        i += 1;
 5d4:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5d6:	8bca                	mv	s7,s2
      state = 0;
 5d8:	4981                	li	s3,0
        i += 1;
 5da:	bd8d                	j	44c <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 5dc:	008b8793          	addi	a5,s7,8
 5e0:	f8f43423          	sd	a5,-120(s0)
 5e4:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5e8:	03000593          	li	a1,48
 5ec:	855a                	mv	a0,s6
 5ee:	d41ff0ef          	jal	ra,32e <putc>
  putc(fd, 'x');
 5f2:	07800593          	li	a1,120
 5f6:	855a                	mv	a0,s6
 5f8:	d37ff0ef          	jal	ra,32e <putc>
 5fc:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5fe:	03c9d793          	srli	a5,s3,0x3c
 602:	97e6                	add	a5,a5,s9
 604:	0007c583          	lbu	a1,0(a5)
 608:	855a                	mv	a0,s6
 60a:	d25ff0ef          	jal	ra,32e <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 60e:	0992                	slli	s3,s3,0x4
 610:	397d                	addiw	s2,s2,-1
 612:	fe0916e3          	bnez	s2,5fe <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 616:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 61a:	4981                	li	s3,0
 61c:	bd05                	j	44c <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 61e:	008b8913          	addi	s2,s7,8
 622:	000bc583          	lbu	a1,0(s7)
 626:	855a                	mv	a0,s6
 628:	d07ff0ef          	jal	ra,32e <putc>
 62c:	8bca                	mv	s7,s2
      state = 0;
 62e:	4981                	li	s3,0
 630:	bd31                	j	44c <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 632:	008b8993          	addi	s3,s7,8
 636:	000bb903          	ld	s2,0(s7)
 63a:	00090f63          	beqz	s2,658 <vprintf+0x266>
        for(; *s; s++)
 63e:	00094583          	lbu	a1,0(s2)
 642:	c195                	beqz	a1,666 <vprintf+0x274>
          putc(fd, *s);
 644:	855a                	mv	a0,s6
 646:	ce9ff0ef          	jal	ra,32e <putc>
        for(; *s; s++)
 64a:	0905                	addi	s2,s2,1
 64c:	00094583          	lbu	a1,0(s2)
 650:	f9f5                	bnez	a1,644 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 652:	8bce                	mv	s7,s3
      state = 0;
 654:	4981                	li	s3,0
 656:	bbdd                	j	44c <vprintf+0x5a>
          s = "(null)";
 658:	00000917          	auipc	s2,0x0
 65c:	1f890913          	addi	s2,s2,504 # 850 <malloc+0xe2>
        for(; *s; s++)
 660:	02800593          	li	a1,40
 664:	b7c5                	j	644 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 666:	8bce                	mv	s7,s3
      state = 0;
 668:	4981                	li	s3,0
 66a:	b3cd                	j	44c <vprintf+0x5a>
    }
  }
}
 66c:	70e6                	ld	ra,120(sp)
 66e:	7446                	ld	s0,112(sp)
 670:	74a6                	ld	s1,104(sp)
 672:	7906                	ld	s2,96(sp)
 674:	69e6                	ld	s3,88(sp)
 676:	6a46                	ld	s4,80(sp)
 678:	6aa6                	ld	s5,72(sp)
 67a:	6b06                	ld	s6,64(sp)
 67c:	7be2                	ld	s7,56(sp)
 67e:	7c42                	ld	s8,48(sp)
 680:	7ca2                	ld	s9,40(sp)
 682:	7d02                	ld	s10,32(sp)
 684:	6de2                	ld	s11,24(sp)
 686:	6109                	addi	sp,sp,128
 688:	8082                	ret

000000000000068a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 68a:	715d                	addi	sp,sp,-80
 68c:	ec06                	sd	ra,24(sp)
 68e:	e822                	sd	s0,16(sp)
 690:	1000                	addi	s0,sp,32
 692:	e010                	sd	a2,0(s0)
 694:	e414                	sd	a3,8(s0)
 696:	e818                	sd	a4,16(s0)
 698:	ec1c                	sd	a5,24(s0)
 69a:	03043023          	sd	a6,32(s0)
 69e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6a2:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6a6:	8622                	mv	a2,s0
 6a8:	d4bff0ef          	jal	ra,3f2 <vprintf>
}
 6ac:	60e2                	ld	ra,24(sp)
 6ae:	6442                	ld	s0,16(sp)
 6b0:	6161                	addi	sp,sp,80
 6b2:	8082                	ret

00000000000006b4 <printf>:

void
printf(const char *fmt, ...)
{
 6b4:	711d                	addi	sp,sp,-96
 6b6:	ec06                	sd	ra,24(sp)
 6b8:	e822                	sd	s0,16(sp)
 6ba:	1000                	addi	s0,sp,32
 6bc:	e40c                	sd	a1,8(s0)
 6be:	e810                	sd	a2,16(s0)
 6c0:	ec14                	sd	a3,24(s0)
 6c2:	f018                	sd	a4,32(s0)
 6c4:	f41c                	sd	a5,40(s0)
 6c6:	03043823          	sd	a6,48(s0)
 6ca:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 6ce:	00840613          	addi	a2,s0,8
 6d2:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 6d6:	85aa                	mv	a1,a0
 6d8:	4505                	li	a0,1
 6da:	d19ff0ef          	jal	ra,3f2 <vprintf>
}
 6de:	60e2                	ld	ra,24(sp)
 6e0:	6442                	ld	s0,16(sp)
 6e2:	6125                	addi	sp,sp,96
 6e4:	8082                	ret

00000000000006e6 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 6e6:	1141                	addi	sp,sp,-16
 6e8:	e422                	sd	s0,8(sp)
 6ea:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 6ec:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 6f0:	00001797          	auipc	a5,0x1
 6f4:	9407b783          	ld	a5,-1728(a5) # 1030 <freep>
 6f8:	a805                	j	728 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 6fa:	4618                	lw	a4,8(a2)
 6fc:	9db9                	addw	a1,a1,a4
 6fe:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 702:	6398                	ld	a4,0(a5)
 704:	6318                	ld	a4,0(a4)
 706:	fee53823          	sd	a4,-16(a0)
 70a:	a091                	j	74e <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 70c:	ff852703          	lw	a4,-8(a0)
 710:	9e39                	addw	a2,a2,a4
 712:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 714:	ff053703          	ld	a4,-16(a0)
 718:	e398                	sd	a4,0(a5)
 71a:	a099                	j	760 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 71c:	6398                	ld	a4,0(a5)
 71e:	00e7e463          	bltu	a5,a4,726 <free+0x40>
 722:	00e6ea63          	bltu	a3,a4,736 <free+0x50>
{
 726:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 728:	fed7fae3          	bgeu	a5,a3,71c <free+0x36>
 72c:	6398                	ld	a4,0(a5)
 72e:	00e6e463          	bltu	a3,a4,736 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 732:	fee7eae3          	bltu	a5,a4,726 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 736:	ff852583          	lw	a1,-8(a0)
 73a:	6390                	ld	a2,0(a5)
 73c:	02059813          	slli	a6,a1,0x20
 740:	01c85713          	srli	a4,a6,0x1c
 744:	9736                	add	a4,a4,a3
 746:	fae60ae3          	beq	a2,a4,6fa <free+0x14>
    bp->s.ptr = p->s.ptr;
 74a:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 74e:	4790                	lw	a2,8(a5)
 750:	02061593          	slli	a1,a2,0x20
 754:	01c5d713          	srli	a4,a1,0x1c
 758:	973e                	add	a4,a4,a5
 75a:	fae689e3          	beq	a3,a4,70c <free+0x26>
  } else
    p->s.ptr = bp;
 75e:	e394                	sd	a3,0(a5)
  freep = p;
 760:	00001717          	auipc	a4,0x1
 764:	8cf73823          	sd	a5,-1840(a4) # 1030 <freep>
}
 768:	6422                	ld	s0,8(sp)
 76a:	0141                	addi	sp,sp,16
 76c:	8082                	ret

000000000000076e <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 76e:	7139                	addi	sp,sp,-64
 770:	fc06                	sd	ra,56(sp)
 772:	f822                	sd	s0,48(sp)
 774:	f426                	sd	s1,40(sp)
 776:	f04a                	sd	s2,32(sp)
 778:	ec4e                	sd	s3,24(sp)
 77a:	e852                	sd	s4,16(sp)
 77c:	e456                	sd	s5,8(sp)
 77e:	e05a                	sd	s6,0(sp)
 780:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 782:	02051493          	slli	s1,a0,0x20
 786:	9081                	srli	s1,s1,0x20
 788:	04bd                	addi	s1,s1,15
 78a:	8091                	srli	s1,s1,0x4
 78c:	0014899b          	addiw	s3,s1,1
 790:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 792:	00001517          	auipc	a0,0x1
 796:	89e53503          	ld	a0,-1890(a0) # 1030 <freep>
 79a:	c515                	beqz	a0,7c6 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 79c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 79e:	4798                	lw	a4,8(a5)
 7a0:	02977f63          	bgeu	a4,s1,7de <malloc+0x70>
 7a4:	8a4e                	mv	s4,s3
 7a6:	0009871b          	sext.w	a4,s3
 7aa:	6685                	lui	a3,0x1
 7ac:	00d77363          	bgeu	a4,a3,7b2 <malloc+0x44>
 7b0:	6a05                	lui	s4,0x1
 7b2:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 7b6:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7ba:	00001917          	auipc	s2,0x1
 7be:	87690913          	addi	s2,s2,-1930 # 1030 <freep>
  if(p == (char*)-1)
 7c2:	5afd                	li	s5,-1
 7c4:	a885                	j	834 <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 7c6:	00001797          	auipc	a5,0x1
 7ca:	87a78793          	addi	a5,a5,-1926 # 1040 <base>
 7ce:	00001717          	auipc	a4,0x1
 7d2:	86f73123          	sd	a5,-1950(a4) # 1030 <freep>
 7d6:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 7d8:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 7dc:	b7e1                	j	7a4 <malloc+0x36>
      if(p->s.size == nunits)
 7de:	02e48c63          	beq	s1,a4,816 <malloc+0xa8>
        p->s.size -= nunits;
 7e2:	4137073b          	subw	a4,a4,s3
 7e6:	c798                	sw	a4,8(a5)
        p += p->s.size;
 7e8:	02071693          	slli	a3,a4,0x20
 7ec:	01c6d713          	srli	a4,a3,0x1c
 7f0:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 7f2:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 7f6:	00001717          	auipc	a4,0x1
 7fa:	82a73d23          	sd	a0,-1990(a4) # 1030 <freep>
      return (void*)(p + 1);
 7fe:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 802:	70e2                	ld	ra,56(sp)
 804:	7442                	ld	s0,48(sp)
 806:	74a2                	ld	s1,40(sp)
 808:	7902                	ld	s2,32(sp)
 80a:	69e2                	ld	s3,24(sp)
 80c:	6a42                	ld	s4,16(sp)
 80e:	6aa2                	ld	s5,8(sp)
 810:	6b02                	ld	s6,0(sp)
 812:	6121                	addi	sp,sp,64
 814:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 816:	6398                	ld	a4,0(a5)
 818:	e118                	sd	a4,0(a0)
 81a:	bff1                	j	7f6 <malloc+0x88>
  hp->s.size = nu;
 81c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 820:	0541                	addi	a0,a0,16
 822:	ec5ff0ef          	jal	ra,6e6 <free>
  return freep;
 826:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 82a:	dd61                	beqz	a0,802 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 82c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 82e:	4798                	lw	a4,8(a5)
 830:	fa9777e3          	bgeu	a4,s1,7de <malloc+0x70>
    if(p == freep)
 834:	00093703          	ld	a4,0(s2)
 838:	853e                	mv	a0,a5
 83a:	fef719e3          	bne	a4,a5,82c <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 83e:	8552                	mv	a0,s4
 840:	acfff0ef          	jal	ra,30e <sbrk>
  if(p == (char*)-1)
 844:	fd551ce3          	bne	a0,s5,81c <malloc+0xae>
        return 0;
 848:	4501                	li	a0,0
 84a:	bf65                	j	802 <malloc+0x94>
