
user/_bttest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
// user/bttest.c
#include "kernel/types.h"
#include "user/user.h"
int
main(int argc, char *argv[])
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
    // Call sleep(1) so sys_sleep() runs in kernel and triggers backtrace()
    sleep(1);
   8:	4505                	li	a0,1
   a:	312000ef          	jal	ra,31c <sleep>
    printf("bttest: returned from sleep\n");
   e:	00001517          	auipc	a0,0x1
  12:	85250513          	addi	a0,a0,-1966 # 860 <malloc+0xec>
  16:	6a4000ef          	jal	ra,6ba <printf>
    exit(0);
  1a:	4501                	li	a0,0
  1c:	270000ef          	jal	ra,28c <exit>

0000000000000020 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  20:	1141                	addi	sp,sp,-16
  22:	e406                	sd	ra,8(sp)
  24:	e022                	sd	s0,0(sp)
  26:	0800                	addi	s0,sp,16
  extern int main();
  main();
  28:	fd9ff0ef          	jal	ra,0 <main>
  exit(0);
  2c:	4501                	li	a0,0
  2e:	25e000ef          	jal	ra,28c <exit>

0000000000000032 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  32:	1141                	addi	sp,sp,-16
  34:	e422                	sd	s0,8(sp)
  36:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  38:	87aa                	mv	a5,a0
  3a:	0585                	addi	a1,a1,1
  3c:	0785                	addi	a5,a5,1
  3e:	fff5c703          	lbu	a4,-1(a1)
  42:	fee78fa3          	sb	a4,-1(a5)
  46:	fb75                	bnez	a4,3a <strcpy+0x8>
    ;
  return os;
}
  48:	6422                	ld	s0,8(sp)
  4a:	0141                	addi	sp,sp,16
  4c:	8082                	ret

000000000000004e <strcmp>:

int
strcmp(const char *p, const char *q)
{
  4e:	1141                	addi	sp,sp,-16
  50:	e422                	sd	s0,8(sp)
  52:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  54:	00054783          	lbu	a5,0(a0)
  58:	cb91                	beqz	a5,6c <strcmp+0x1e>
  5a:	0005c703          	lbu	a4,0(a1)
  5e:	00f71763          	bne	a4,a5,6c <strcmp+0x1e>
    p++, q++;
  62:	0505                	addi	a0,a0,1
  64:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  66:	00054783          	lbu	a5,0(a0)
  6a:	fbe5                	bnez	a5,5a <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
  6c:	0005c503          	lbu	a0,0(a1)
}
  70:	40a7853b          	subw	a0,a5,a0
  74:	6422                	ld	s0,8(sp)
  76:	0141                	addi	sp,sp,16
  78:	8082                	ret

000000000000007a <strlen>:

uint
strlen(const char *s)
{
  7a:	1141                	addi	sp,sp,-16
  7c:	e422                	sd	s0,8(sp)
  7e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  80:	00054783          	lbu	a5,0(a0)
  84:	cf91                	beqz	a5,a0 <strlen+0x26>
  86:	0505                	addi	a0,a0,1
  88:	87aa                	mv	a5,a0
  8a:	4685                	li	a3,1
  8c:	9e89                	subw	a3,a3,a0
  8e:	00f6853b          	addw	a0,a3,a5
  92:	0785                	addi	a5,a5,1
  94:	fff7c703          	lbu	a4,-1(a5)
  98:	fb7d                	bnez	a4,8e <strlen+0x14>
    ;
  return n;
}
  9a:	6422                	ld	s0,8(sp)
  9c:	0141                	addi	sp,sp,16
  9e:	8082                	ret
  for(n = 0; s[n]; n++)
  a0:	4501                	li	a0,0
  a2:	bfe5                	j	9a <strlen+0x20>

00000000000000a4 <memset>:

void*
memset(void *dst, int c, uint n)
{
  a4:	1141                	addi	sp,sp,-16
  a6:	e422                	sd	s0,8(sp)
  a8:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  aa:	ca19                	beqz	a2,c0 <memset+0x1c>
  ac:	87aa                	mv	a5,a0
  ae:	1602                	slli	a2,a2,0x20
  b0:	9201                	srli	a2,a2,0x20
  b2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  b6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  ba:	0785                	addi	a5,a5,1
  bc:	fee79de3          	bne	a5,a4,b6 <memset+0x12>
  }
  return dst;
}
  c0:	6422                	ld	s0,8(sp)
  c2:	0141                	addi	sp,sp,16
  c4:	8082                	ret

00000000000000c6 <strchr>:

char*
strchr(const char *s, char c)
{
  c6:	1141                	addi	sp,sp,-16
  c8:	e422                	sd	s0,8(sp)
  ca:	0800                	addi	s0,sp,16
  for(; *s; s++)
  cc:	00054783          	lbu	a5,0(a0)
  d0:	cb99                	beqz	a5,e6 <strchr+0x20>
    if(*s == c)
  d2:	00f58763          	beq	a1,a5,e0 <strchr+0x1a>
  for(; *s; s++)
  d6:	0505                	addi	a0,a0,1
  d8:	00054783          	lbu	a5,0(a0)
  dc:	fbfd                	bnez	a5,d2 <strchr+0xc>
      return (char*)s;
  return 0;
  de:	4501                	li	a0,0
}
  e0:	6422                	ld	s0,8(sp)
  e2:	0141                	addi	sp,sp,16
  e4:	8082                	ret
  return 0;
  e6:	4501                	li	a0,0
  e8:	bfe5                	j	e0 <strchr+0x1a>

00000000000000ea <gets>:

char*
gets(char *buf, int max)
{
  ea:	711d                	addi	sp,sp,-96
  ec:	ec86                	sd	ra,88(sp)
  ee:	e8a2                	sd	s0,80(sp)
  f0:	e4a6                	sd	s1,72(sp)
  f2:	e0ca                	sd	s2,64(sp)
  f4:	fc4e                	sd	s3,56(sp)
  f6:	f852                	sd	s4,48(sp)
  f8:	f456                	sd	s5,40(sp)
  fa:	f05a                	sd	s6,32(sp)
  fc:	ec5e                	sd	s7,24(sp)
  fe:	1080                	addi	s0,sp,96
 100:	8baa                	mv	s7,a0
 102:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 104:	892a                	mv	s2,a0
 106:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 108:	4aa9                	li	s5,10
 10a:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 10c:	89a6                	mv	s3,s1
 10e:	2485                	addiw	s1,s1,1
 110:	0344d663          	bge	s1,s4,13c <gets+0x52>
    cc = read(0, &c, 1);
 114:	4605                	li	a2,1
 116:	faf40593          	addi	a1,s0,-81
 11a:	4501                	li	a0,0
 11c:	188000ef          	jal	ra,2a4 <read>
    if(cc < 1)
 120:	00a05e63          	blez	a0,13c <gets+0x52>
    buf[i++] = c;
 124:	faf44783          	lbu	a5,-81(s0)
 128:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 12c:	01578763          	beq	a5,s5,13a <gets+0x50>
 130:	0905                	addi	s2,s2,1
 132:	fd679de3          	bne	a5,s6,10c <gets+0x22>
  for(i=0; i+1 < max; ){
 136:	89a6                	mv	s3,s1
 138:	a011                	j	13c <gets+0x52>
 13a:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 13c:	99de                	add	s3,s3,s7
 13e:	00098023          	sb	zero,0(s3)
  return buf;
}
 142:	855e                	mv	a0,s7
 144:	60e6                	ld	ra,88(sp)
 146:	6446                	ld	s0,80(sp)
 148:	64a6                	ld	s1,72(sp)
 14a:	6906                	ld	s2,64(sp)
 14c:	79e2                	ld	s3,56(sp)
 14e:	7a42                	ld	s4,48(sp)
 150:	7aa2                	ld	s5,40(sp)
 152:	7b02                	ld	s6,32(sp)
 154:	6be2                	ld	s7,24(sp)
 156:	6125                	addi	sp,sp,96
 158:	8082                	ret

000000000000015a <stat>:

int
stat(const char *n, struct stat *st)
{
 15a:	1101                	addi	sp,sp,-32
 15c:	ec06                	sd	ra,24(sp)
 15e:	e822                	sd	s0,16(sp)
 160:	e426                	sd	s1,8(sp)
 162:	e04a                	sd	s2,0(sp)
 164:	1000                	addi	s0,sp,32
 166:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 168:	4581                	li	a1,0
 16a:	162000ef          	jal	ra,2cc <open>
  if(fd < 0)
 16e:	02054163          	bltz	a0,190 <stat+0x36>
 172:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 174:	85ca                	mv	a1,s2
 176:	16e000ef          	jal	ra,2e4 <fstat>
 17a:	892a                	mv	s2,a0
  close(fd);
 17c:	8526                	mv	a0,s1
 17e:	136000ef          	jal	ra,2b4 <close>
  return r;
}
 182:	854a                	mv	a0,s2
 184:	60e2                	ld	ra,24(sp)
 186:	6442                	ld	s0,16(sp)
 188:	64a2                	ld	s1,8(sp)
 18a:	6902                	ld	s2,0(sp)
 18c:	6105                	addi	sp,sp,32
 18e:	8082                	ret
    return -1;
 190:	597d                	li	s2,-1
 192:	bfc5                	j	182 <stat+0x28>

0000000000000194 <atoi>:

int
atoi(const char *s)
{
 194:	1141                	addi	sp,sp,-16
 196:	e422                	sd	s0,8(sp)
 198:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 19a:	00054603          	lbu	a2,0(a0)
 19e:	fd06079b          	addiw	a5,a2,-48
 1a2:	0ff7f793          	zext.b	a5,a5
 1a6:	4725                	li	a4,9
 1a8:	02f76963          	bltu	a4,a5,1da <atoi+0x46>
 1ac:	86aa                	mv	a3,a0
  n = 0;
 1ae:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 1b0:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 1b2:	0685                	addi	a3,a3,1
 1b4:	0025179b          	slliw	a5,a0,0x2
 1b8:	9fa9                	addw	a5,a5,a0
 1ba:	0017979b          	slliw	a5,a5,0x1
 1be:	9fb1                	addw	a5,a5,a2
 1c0:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1c4:	0006c603          	lbu	a2,0(a3)
 1c8:	fd06071b          	addiw	a4,a2,-48
 1cc:	0ff77713          	zext.b	a4,a4
 1d0:	fee5f1e3          	bgeu	a1,a4,1b2 <atoi+0x1e>
  return n;
}
 1d4:	6422                	ld	s0,8(sp)
 1d6:	0141                	addi	sp,sp,16
 1d8:	8082                	ret
  n = 0;
 1da:	4501                	li	a0,0
 1dc:	bfe5                	j	1d4 <atoi+0x40>

00000000000001de <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1de:	1141                	addi	sp,sp,-16
 1e0:	e422                	sd	s0,8(sp)
 1e2:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 1e4:	02b57463          	bgeu	a0,a1,20c <memmove+0x2e>
    while(n-- > 0)
 1e8:	00c05f63          	blez	a2,206 <memmove+0x28>
 1ec:	1602                	slli	a2,a2,0x20
 1ee:	9201                	srli	a2,a2,0x20
 1f0:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 1f4:	872a                	mv	a4,a0
      *dst++ = *src++;
 1f6:	0585                	addi	a1,a1,1
 1f8:	0705                	addi	a4,a4,1
 1fa:	fff5c683          	lbu	a3,-1(a1)
 1fe:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 202:	fee79ae3          	bne	a5,a4,1f6 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 206:	6422                	ld	s0,8(sp)
 208:	0141                	addi	sp,sp,16
 20a:	8082                	ret
    dst += n;
 20c:	00c50733          	add	a4,a0,a2
    src += n;
 210:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 212:	fec05ae3          	blez	a2,206 <memmove+0x28>
 216:	fff6079b          	addiw	a5,a2,-1
 21a:	1782                	slli	a5,a5,0x20
 21c:	9381                	srli	a5,a5,0x20
 21e:	fff7c793          	not	a5,a5
 222:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 224:	15fd                	addi	a1,a1,-1
 226:	177d                	addi	a4,a4,-1
 228:	0005c683          	lbu	a3,0(a1)
 22c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 230:	fee79ae3          	bne	a5,a4,224 <memmove+0x46>
 234:	bfc9                	j	206 <memmove+0x28>

0000000000000236 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 236:	1141                	addi	sp,sp,-16
 238:	e422                	sd	s0,8(sp)
 23a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 23c:	ca05                	beqz	a2,26c <memcmp+0x36>
 23e:	fff6069b          	addiw	a3,a2,-1
 242:	1682                	slli	a3,a3,0x20
 244:	9281                	srli	a3,a3,0x20
 246:	0685                	addi	a3,a3,1
 248:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 24a:	00054783          	lbu	a5,0(a0)
 24e:	0005c703          	lbu	a4,0(a1)
 252:	00e79863          	bne	a5,a4,262 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 256:	0505                	addi	a0,a0,1
    p2++;
 258:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 25a:	fed518e3          	bne	a0,a3,24a <memcmp+0x14>
  }
  return 0;
 25e:	4501                	li	a0,0
 260:	a019                	j	266 <memcmp+0x30>
      return *p1 - *p2;
 262:	40e7853b          	subw	a0,a5,a4
}
 266:	6422                	ld	s0,8(sp)
 268:	0141                	addi	sp,sp,16
 26a:	8082                	ret
  return 0;
 26c:	4501                	li	a0,0
 26e:	bfe5                	j	266 <memcmp+0x30>

0000000000000270 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 270:	1141                	addi	sp,sp,-16
 272:	e406                	sd	ra,8(sp)
 274:	e022                	sd	s0,0(sp)
 276:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 278:	f67ff0ef          	jal	ra,1de <memmove>
}
 27c:	60a2                	ld	ra,8(sp)
 27e:	6402                	ld	s0,0(sp)
 280:	0141                	addi	sp,sp,16
 282:	8082                	ret

0000000000000284 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 284:	4885                	li	a7,1
 ecall
 286:	00000073          	ecall
 ret
 28a:	8082                	ret

000000000000028c <exit>:
.global exit
exit:
 li a7, SYS_exit
 28c:	4889                	li	a7,2
 ecall
 28e:	00000073          	ecall
 ret
 292:	8082                	ret

0000000000000294 <wait>:
.global wait
wait:
 li a7, SYS_wait
 294:	488d                	li	a7,3
 ecall
 296:	00000073          	ecall
 ret
 29a:	8082                	ret

000000000000029c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 29c:	4891                	li	a7,4
 ecall
 29e:	00000073          	ecall
 ret
 2a2:	8082                	ret

00000000000002a4 <read>:
.global read
read:
 li a7, SYS_read
 2a4:	4895                	li	a7,5
 ecall
 2a6:	00000073          	ecall
 ret
 2aa:	8082                	ret

00000000000002ac <write>:
.global write
write:
 li a7, SYS_write
 2ac:	48c1                	li	a7,16
 ecall
 2ae:	00000073          	ecall
 ret
 2b2:	8082                	ret

00000000000002b4 <close>:
.global close
close:
 li a7, SYS_close
 2b4:	48d5                	li	a7,21
 ecall
 2b6:	00000073          	ecall
 ret
 2ba:	8082                	ret

00000000000002bc <kill>:
.global kill
kill:
 li a7, SYS_kill
 2bc:	4899                	li	a7,6
 ecall
 2be:	00000073          	ecall
 ret
 2c2:	8082                	ret

00000000000002c4 <exec>:
.global exec
exec:
 li a7, SYS_exec
 2c4:	489d                	li	a7,7
 ecall
 2c6:	00000073          	ecall
 ret
 2ca:	8082                	ret

00000000000002cc <open>:
.global open
open:
 li a7, SYS_open
 2cc:	48bd                	li	a7,15
 ecall
 2ce:	00000073          	ecall
 ret
 2d2:	8082                	ret

00000000000002d4 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 2d4:	48c5                	li	a7,17
 ecall
 2d6:	00000073          	ecall
 ret
 2da:	8082                	ret

00000000000002dc <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 2dc:	48c9                	li	a7,18
 ecall
 2de:	00000073          	ecall
 ret
 2e2:	8082                	ret

00000000000002e4 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 2e4:	48a1                	li	a7,8
 ecall
 2e6:	00000073          	ecall
 ret
 2ea:	8082                	ret

00000000000002ec <link>:
.global link
link:
 li a7, SYS_link
 2ec:	48cd                	li	a7,19
 ecall
 2ee:	00000073          	ecall
 ret
 2f2:	8082                	ret

00000000000002f4 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 2f4:	48d1                	li	a7,20
 ecall
 2f6:	00000073          	ecall
 ret
 2fa:	8082                	ret

00000000000002fc <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 2fc:	48a5                	li	a7,9
 ecall
 2fe:	00000073          	ecall
 ret
 302:	8082                	ret

0000000000000304 <dup>:
.global dup
dup:
 li a7, SYS_dup
 304:	48a9                	li	a7,10
 ecall
 306:	00000073          	ecall
 ret
 30a:	8082                	ret

000000000000030c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 30c:	48ad                	li	a7,11
 ecall
 30e:	00000073          	ecall
 ret
 312:	8082                	ret

0000000000000314 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 314:	48b1                	li	a7,12
 ecall
 316:	00000073          	ecall
 ret
 31a:	8082                	ret

000000000000031c <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 31c:	48b5                	li	a7,13
 ecall
 31e:	00000073          	ecall
 ret
 322:	8082                	ret

0000000000000324 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 324:	48b9                	li	a7,14
 ecall
 326:	00000073          	ecall
 ret
 32a:	8082                	ret

000000000000032c <trace>:
.global trace
trace:
 li a7, SYS_trace
 32c:	48d9                	li	a7,22
 ecall
 32e:	00000073          	ecall
 ret
 332:	8082                	ret

0000000000000334 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 334:	1101                	addi	sp,sp,-32
 336:	ec06                	sd	ra,24(sp)
 338:	e822                	sd	s0,16(sp)
 33a:	1000                	addi	s0,sp,32
 33c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 340:	4605                	li	a2,1
 342:	fef40593          	addi	a1,s0,-17
 346:	f67ff0ef          	jal	ra,2ac <write>
}
 34a:	60e2                	ld	ra,24(sp)
 34c:	6442                	ld	s0,16(sp)
 34e:	6105                	addi	sp,sp,32
 350:	8082                	ret

0000000000000352 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 352:	715d                	addi	sp,sp,-80
 354:	e486                	sd	ra,72(sp)
 356:	e0a2                	sd	s0,64(sp)
 358:	fc26                	sd	s1,56(sp)
 35a:	f84a                	sd	s2,48(sp)
 35c:	f44e                	sd	s3,40(sp)
 35e:	0880                	addi	s0,sp,80
 360:	84aa                	mv	s1,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 362:	c299                	beqz	a3,368 <printint+0x16>
 364:	0805c663          	bltz	a1,3f0 <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 368:	2581                	sext.w	a1,a1
  neg = 0;
 36a:	4881                	li	a7,0
 36c:	fb840693          	addi	a3,s0,-72
  }

  i = 0;
 370:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 372:	2601                	sext.w	a2,a2
 374:	00000517          	auipc	a0,0x0
 378:	51450513          	addi	a0,a0,1300 # 888 <digits>
 37c:	883a                	mv	a6,a4
 37e:	2705                	addiw	a4,a4,1
 380:	02c5f7bb          	remuw	a5,a1,a2
 384:	1782                	slli	a5,a5,0x20
 386:	9381                	srli	a5,a5,0x20
 388:	97aa                	add	a5,a5,a0
 38a:	0007c783          	lbu	a5,0(a5)
 38e:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 392:	0005879b          	sext.w	a5,a1
 396:	02c5d5bb          	divuw	a1,a1,a2
 39a:	0685                	addi	a3,a3,1
 39c:	fec7f0e3          	bgeu	a5,a2,37c <printint+0x2a>
  if(neg)
 3a0:	00088b63          	beqz	a7,3b6 <printint+0x64>
    buf[i++] = '-';
 3a4:	fd040793          	addi	a5,s0,-48
 3a8:	973e                	add	a4,a4,a5
 3aa:	02d00793          	li	a5,45
 3ae:	fef70423          	sb	a5,-24(a4)
 3b2:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 3b6:	02e05663          	blez	a4,3e2 <printint+0x90>
 3ba:	fb840793          	addi	a5,s0,-72
 3be:	00e78933          	add	s2,a5,a4
 3c2:	fff78993          	addi	s3,a5,-1
 3c6:	99ba                	add	s3,s3,a4
 3c8:	377d                	addiw	a4,a4,-1
 3ca:	1702                	slli	a4,a4,0x20
 3cc:	9301                	srli	a4,a4,0x20
 3ce:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 3d2:	fff94583          	lbu	a1,-1(s2)
 3d6:	8526                	mv	a0,s1
 3d8:	f5dff0ef          	jal	ra,334 <putc>
  while(--i >= 0)
 3dc:	197d                	addi	s2,s2,-1
 3de:	ff391ae3          	bne	s2,s3,3d2 <printint+0x80>
}
 3e2:	60a6                	ld	ra,72(sp)
 3e4:	6406                	ld	s0,64(sp)
 3e6:	74e2                	ld	s1,56(sp)
 3e8:	7942                	ld	s2,48(sp)
 3ea:	79a2                	ld	s3,40(sp)
 3ec:	6161                	addi	sp,sp,80
 3ee:	8082                	ret
    x = -xx;
 3f0:	40b005bb          	negw	a1,a1
    neg = 1;
 3f4:	4885                	li	a7,1
    x = -xx;
 3f6:	bf9d                	j	36c <printint+0x1a>

00000000000003f8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 3f8:	7119                	addi	sp,sp,-128
 3fa:	fc86                	sd	ra,120(sp)
 3fc:	f8a2                	sd	s0,112(sp)
 3fe:	f4a6                	sd	s1,104(sp)
 400:	f0ca                	sd	s2,96(sp)
 402:	ecce                	sd	s3,88(sp)
 404:	e8d2                	sd	s4,80(sp)
 406:	e4d6                	sd	s5,72(sp)
 408:	e0da                	sd	s6,64(sp)
 40a:	fc5e                	sd	s7,56(sp)
 40c:	f862                	sd	s8,48(sp)
 40e:	f466                	sd	s9,40(sp)
 410:	f06a                	sd	s10,32(sp)
 412:	ec6e                	sd	s11,24(sp)
 414:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 416:	0005c903          	lbu	s2,0(a1)
 41a:	24090c63          	beqz	s2,672 <vprintf+0x27a>
 41e:	8b2a                	mv	s6,a0
 420:	8a2e                	mv	s4,a1
 422:	8bb2                	mv	s7,a2
  state = 0;
 424:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 426:	4481                	li	s1,0
 428:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 42a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 42e:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 432:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 436:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 43a:	00000c97          	auipc	s9,0x0
 43e:	44ec8c93          	addi	s9,s9,1102 # 888 <digits>
 442:	a005                	j	462 <vprintf+0x6a>
        putc(fd, c0);
 444:	85ca                	mv	a1,s2
 446:	855a                	mv	a0,s6
 448:	eedff0ef          	jal	ra,334 <putc>
 44c:	a019                	j	452 <vprintf+0x5a>
    } else if(state == '%'){
 44e:	03598263          	beq	s3,s5,472 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 452:	2485                	addiw	s1,s1,1
 454:	8726                	mv	a4,s1
 456:	009a07b3          	add	a5,s4,s1
 45a:	0007c903          	lbu	s2,0(a5)
 45e:	20090a63          	beqz	s2,672 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 462:	0009079b          	sext.w	a5,s2
    if(state == 0){
 466:	fe0994e3          	bnez	s3,44e <vprintf+0x56>
      if(c0 == '%'){
 46a:	fd579de3          	bne	a5,s5,444 <vprintf+0x4c>
        state = '%';
 46e:	89be                	mv	s3,a5
 470:	b7cd                	j	452 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 472:	c3c1                	beqz	a5,4f2 <vprintf+0xfa>
 474:	00ea06b3          	add	a3,s4,a4
 478:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 47c:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 47e:	c681                	beqz	a3,486 <vprintf+0x8e>
 480:	9752                	add	a4,a4,s4
 482:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 486:	03878e63          	beq	a5,s8,4c2 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 48a:	05a78863          	beq	a5,s10,4da <vprintf+0xe2>
      } else if(c0 == 'u'){
 48e:	0db78b63          	beq	a5,s11,564 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 492:	07800713          	li	a4,120
 496:	10e78d63          	beq	a5,a4,5b0 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 49a:	07000713          	li	a4,112
 49e:	14e78263          	beq	a5,a4,5e2 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 4a2:	06300713          	li	a4,99
 4a6:	16e78f63          	beq	a5,a4,624 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 4aa:	07300713          	li	a4,115
 4ae:	18e78563          	beq	a5,a4,638 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 4b2:	05579063          	bne	a5,s5,4f2 <vprintf+0xfa>
        putc(fd, '%');
 4b6:	85d6                	mv	a1,s5
 4b8:	855a                	mv	a0,s6
 4ba:	e7bff0ef          	jal	ra,334 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 4be:	4981                	li	s3,0
 4c0:	bf49                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 4c2:	008b8913          	addi	s2,s7,8
 4c6:	4685                	li	a3,1
 4c8:	4629                	li	a2,10
 4ca:	000ba583          	lw	a1,0(s7)
 4ce:	855a                	mv	a0,s6
 4d0:	e83ff0ef          	jal	ra,352 <printint>
 4d4:	8bca                	mv	s7,s2
      state = 0;
 4d6:	4981                	li	s3,0
 4d8:	bfad                	j	452 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 4da:	03868663          	beq	a3,s8,506 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4de:	05a68163          	beq	a3,s10,520 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 4e2:	09b68d63          	beq	a3,s11,57c <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 4e6:	03a68f63          	beq	a3,s10,524 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 4ea:	07800793          	li	a5,120
 4ee:	0cf68d63          	beq	a3,a5,5c8 <vprintf+0x1d0>
        putc(fd, '%');
 4f2:	85d6                	mv	a1,s5
 4f4:	855a                	mv	a0,s6
 4f6:	e3fff0ef          	jal	ra,334 <putc>
        putc(fd, c0);
 4fa:	85ca                	mv	a1,s2
 4fc:	855a                	mv	a0,s6
 4fe:	e37ff0ef          	jal	ra,334 <putc>
      state = 0;
 502:	4981                	li	s3,0
 504:	b7b9                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 506:	008b8913          	addi	s2,s7,8
 50a:	4685                	li	a3,1
 50c:	4629                	li	a2,10
 50e:	000bb583          	ld	a1,0(s7)
 512:	855a                	mv	a0,s6
 514:	e3fff0ef          	jal	ra,352 <printint>
        i += 1;
 518:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 51a:	8bca                	mv	s7,s2
      state = 0;
 51c:	4981                	li	s3,0
        i += 1;
 51e:	bf15                	j	452 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 520:	03860563          	beq	a2,s8,54a <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 524:	07b60963          	beq	a2,s11,596 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 528:	07800793          	li	a5,120
 52c:	fcf613e3          	bne	a2,a5,4f2 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 530:	008b8913          	addi	s2,s7,8
 534:	4681                	li	a3,0
 536:	4641                	li	a2,16
 538:	000bb583          	ld	a1,0(s7)
 53c:	855a                	mv	a0,s6
 53e:	e15ff0ef          	jal	ra,352 <printint>
        i += 2;
 542:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 544:	8bca                	mv	s7,s2
      state = 0;
 546:	4981                	li	s3,0
        i += 2;
 548:	b729                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 54a:	008b8913          	addi	s2,s7,8
 54e:	4685                	li	a3,1
 550:	4629                	li	a2,10
 552:	000bb583          	ld	a1,0(s7)
 556:	855a                	mv	a0,s6
 558:	dfbff0ef          	jal	ra,352 <printint>
        i += 2;
 55c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 55e:	8bca                	mv	s7,s2
      state = 0;
 560:	4981                	li	s3,0
        i += 2;
 562:	bdc5                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 564:	008b8913          	addi	s2,s7,8
 568:	4681                	li	a3,0
 56a:	4629                	li	a2,10
 56c:	000be583          	lwu	a1,0(s7)
 570:	855a                	mv	a0,s6
 572:	de1ff0ef          	jal	ra,352 <printint>
 576:	8bca                	mv	s7,s2
      state = 0;
 578:	4981                	li	s3,0
 57a:	bde1                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 57c:	008b8913          	addi	s2,s7,8
 580:	4681                	li	a3,0
 582:	4629                	li	a2,10
 584:	000bb583          	ld	a1,0(s7)
 588:	855a                	mv	a0,s6
 58a:	dc9ff0ef          	jal	ra,352 <printint>
        i += 1;
 58e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 590:	8bca                	mv	s7,s2
      state = 0;
 592:	4981                	li	s3,0
        i += 1;
 594:	bd7d                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 596:	008b8913          	addi	s2,s7,8
 59a:	4681                	li	a3,0
 59c:	4629                	li	a2,10
 59e:	000bb583          	ld	a1,0(s7)
 5a2:	855a                	mv	a0,s6
 5a4:	dafff0ef          	jal	ra,352 <printint>
        i += 2;
 5a8:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5aa:	8bca                	mv	s7,s2
      state = 0;
 5ac:	4981                	li	s3,0
        i += 2;
 5ae:	b555                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 5b0:	008b8913          	addi	s2,s7,8
 5b4:	4681                	li	a3,0
 5b6:	4641                	li	a2,16
 5b8:	000be583          	lwu	a1,0(s7)
 5bc:	855a                	mv	a0,s6
 5be:	d95ff0ef          	jal	ra,352 <printint>
 5c2:	8bca                	mv	s7,s2
      state = 0;
 5c4:	4981                	li	s3,0
 5c6:	b571                	j	452 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5c8:	008b8913          	addi	s2,s7,8
 5cc:	4681                	li	a3,0
 5ce:	4641                	li	a2,16
 5d0:	000bb583          	ld	a1,0(s7)
 5d4:	855a                	mv	a0,s6
 5d6:	d7dff0ef          	jal	ra,352 <printint>
        i += 1;
 5da:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5dc:	8bca                	mv	s7,s2
      state = 0;
 5de:	4981                	li	s3,0
        i += 1;
 5e0:	bd8d                	j	452 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 5e2:	008b8793          	addi	a5,s7,8
 5e6:	f8f43423          	sd	a5,-120(s0)
 5ea:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5ee:	03000593          	li	a1,48
 5f2:	855a                	mv	a0,s6
 5f4:	d41ff0ef          	jal	ra,334 <putc>
  putc(fd, 'x');
 5f8:	07800593          	li	a1,120
 5fc:	855a                	mv	a0,s6
 5fe:	d37ff0ef          	jal	ra,334 <putc>
 602:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 604:	03c9d793          	srli	a5,s3,0x3c
 608:	97e6                	add	a5,a5,s9
 60a:	0007c583          	lbu	a1,0(a5)
 60e:	855a                	mv	a0,s6
 610:	d25ff0ef          	jal	ra,334 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 614:	0992                	slli	s3,s3,0x4
 616:	397d                	addiw	s2,s2,-1
 618:	fe0916e3          	bnez	s2,604 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 61c:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 620:	4981                	li	s3,0
 622:	bd05                	j	452 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 624:	008b8913          	addi	s2,s7,8
 628:	000bc583          	lbu	a1,0(s7)
 62c:	855a                	mv	a0,s6
 62e:	d07ff0ef          	jal	ra,334 <putc>
 632:	8bca                	mv	s7,s2
      state = 0;
 634:	4981                	li	s3,0
 636:	bd31                	j	452 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 638:	008b8993          	addi	s3,s7,8
 63c:	000bb903          	ld	s2,0(s7)
 640:	00090f63          	beqz	s2,65e <vprintf+0x266>
        for(; *s; s++)
 644:	00094583          	lbu	a1,0(s2)
 648:	c195                	beqz	a1,66c <vprintf+0x274>
          putc(fd, *s);
 64a:	855a                	mv	a0,s6
 64c:	ce9ff0ef          	jal	ra,334 <putc>
        for(; *s; s++)
 650:	0905                	addi	s2,s2,1
 652:	00094583          	lbu	a1,0(s2)
 656:	f9f5                	bnez	a1,64a <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 658:	8bce                	mv	s7,s3
      state = 0;
 65a:	4981                	li	s3,0
 65c:	bbdd                	j	452 <vprintf+0x5a>
          s = "(null)";
 65e:	00000917          	auipc	s2,0x0
 662:	22290913          	addi	s2,s2,546 # 880 <malloc+0x10c>
        for(; *s; s++)
 666:	02800593          	li	a1,40
 66a:	b7c5                	j	64a <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 66c:	8bce                	mv	s7,s3
      state = 0;
 66e:	4981                	li	s3,0
 670:	b3cd                	j	452 <vprintf+0x5a>
    }
  }
}
 672:	70e6                	ld	ra,120(sp)
 674:	7446                	ld	s0,112(sp)
 676:	74a6                	ld	s1,104(sp)
 678:	7906                	ld	s2,96(sp)
 67a:	69e6                	ld	s3,88(sp)
 67c:	6a46                	ld	s4,80(sp)
 67e:	6aa6                	ld	s5,72(sp)
 680:	6b06                	ld	s6,64(sp)
 682:	7be2                	ld	s7,56(sp)
 684:	7c42                	ld	s8,48(sp)
 686:	7ca2                	ld	s9,40(sp)
 688:	7d02                	ld	s10,32(sp)
 68a:	6de2                	ld	s11,24(sp)
 68c:	6109                	addi	sp,sp,128
 68e:	8082                	ret

0000000000000690 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 690:	715d                	addi	sp,sp,-80
 692:	ec06                	sd	ra,24(sp)
 694:	e822                	sd	s0,16(sp)
 696:	1000                	addi	s0,sp,32
 698:	e010                	sd	a2,0(s0)
 69a:	e414                	sd	a3,8(s0)
 69c:	e818                	sd	a4,16(s0)
 69e:	ec1c                	sd	a5,24(s0)
 6a0:	03043023          	sd	a6,32(s0)
 6a4:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6a8:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6ac:	8622                	mv	a2,s0
 6ae:	d4bff0ef          	jal	ra,3f8 <vprintf>
}
 6b2:	60e2                	ld	ra,24(sp)
 6b4:	6442                	ld	s0,16(sp)
 6b6:	6161                	addi	sp,sp,80
 6b8:	8082                	ret

00000000000006ba <printf>:

void
printf(const char *fmt, ...)
{
 6ba:	711d                	addi	sp,sp,-96
 6bc:	ec06                	sd	ra,24(sp)
 6be:	e822                	sd	s0,16(sp)
 6c0:	1000                	addi	s0,sp,32
 6c2:	e40c                	sd	a1,8(s0)
 6c4:	e810                	sd	a2,16(s0)
 6c6:	ec14                	sd	a3,24(s0)
 6c8:	f018                	sd	a4,32(s0)
 6ca:	f41c                	sd	a5,40(s0)
 6cc:	03043823          	sd	a6,48(s0)
 6d0:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 6d4:	00840613          	addi	a2,s0,8
 6d8:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 6dc:	85aa                	mv	a1,a0
 6de:	4505                	li	a0,1
 6e0:	d19ff0ef          	jal	ra,3f8 <vprintf>
}
 6e4:	60e2                	ld	ra,24(sp)
 6e6:	6442                	ld	s0,16(sp)
 6e8:	6125                	addi	sp,sp,96
 6ea:	8082                	ret

00000000000006ec <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 6ec:	1141                	addi	sp,sp,-16
 6ee:	e422                	sd	s0,8(sp)
 6f0:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 6f2:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 6f6:	00001797          	auipc	a5,0x1
 6fa:	90a7b783          	ld	a5,-1782(a5) # 1000 <freep>
 6fe:	a805                	j	72e <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 700:	4618                	lw	a4,8(a2)
 702:	9db9                	addw	a1,a1,a4
 704:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 708:	6398                	ld	a4,0(a5)
 70a:	6318                	ld	a4,0(a4)
 70c:	fee53823          	sd	a4,-16(a0)
 710:	a091                	j	754 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 712:	ff852703          	lw	a4,-8(a0)
 716:	9e39                	addw	a2,a2,a4
 718:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 71a:	ff053703          	ld	a4,-16(a0)
 71e:	e398                	sd	a4,0(a5)
 720:	a099                	j	766 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 722:	6398                	ld	a4,0(a5)
 724:	00e7e463          	bltu	a5,a4,72c <free+0x40>
 728:	00e6ea63          	bltu	a3,a4,73c <free+0x50>
{
 72c:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 72e:	fed7fae3          	bgeu	a5,a3,722 <free+0x36>
 732:	6398                	ld	a4,0(a5)
 734:	00e6e463          	bltu	a3,a4,73c <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 738:	fee7eae3          	bltu	a5,a4,72c <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 73c:	ff852583          	lw	a1,-8(a0)
 740:	6390                	ld	a2,0(a5)
 742:	02059813          	slli	a6,a1,0x20
 746:	01c85713          	srli	a4,a6,0x1c
 74a:	9736                	add	a4,a4,a3
 74c:	fae60ae3          	beq	a2,a4,700 <free+0x14>
    bp->s.ptr = p->s.ptr;
 750:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 754:	4790                	lw	a2,8(a5)
 756:	02061593          	slli	a1,a2,0x20
 75a:	01c5d713          	srli	a4,a1,0x1c
 75e:	973e                	add	a4,a4,a5
 760:	fae689e3          	beq	a3,a4,712 <free+0x26>
  } else
    p->s.ptr = bp;
 764:	e394                	sd	a3,0(a5)
  freep = p;
 766:	00001717          	auipc	a4,0x1
 76a:	88f73d23          	sd	a5,-1894(a4) # 1000 <freep>
}
 76e:	6422                	ld	s0,8(sp)
 770:	0141                	addi	sp,sp,16
 772:	8082                	ret

0000000000000774 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 774:	7139                	addi	sp,sp,-64
 776:	fc06                	sd	ra,56(sp)
 778:	f822                	sd	s0,48(sp)
 77a:	f426                	sd	s1,40(sp)
 77c:	f04a                	sd	s2,32(sp)
 77e:	ec4e                	sd	s3,24(sp)
 780:	e852                	sd	s4,16(sp)
 782:	e456                	sd	s5,8(sp)
 784:	e05a                	sd	s6,0(sp)
 786:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 788:	02051493          	slli	s1,a0,0x20
 78c:	9081                	srli	s1,s1,0x20
 78e:	04bd                	addi	s1,s1,15
 790:	8091                	srli	s1,s1,0x4
 792:	0014899b          	addiw	s3,s1,1
 796:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 798:	00001517          	auipc	a0,0x1
 79c:	86853503          	ld	a0,-1944(a0) # 1000 <freep>
 7a0:	c515                	beqz	a0,7cc <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7a2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7a4:	4798                	lw	a4,8(a5)
 7a6:	02977f63          	bgeu	a4,s1,7e4 <malloc+0x70>
 7aa:	8a4e                	mv	s4,s3
 7ac:	0009871b          	sext.w	a4,s3
 7b0:	6685                	lui	a3,0x1
 7b2:	00d77363          	bgeu	a4,a3,7b8 <malloc+0x44>
 7b6:	6a05                	lui	s4,0x1
 7b8:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 7bc:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7c0:	00001917          	auipc	s2,0x1
 7c4:	84090913          	addi	s2,s2,-1984 # 1000 <freep>
  if(p == (char*)-1)
 7c8:	5afd                	li	s5,-1
 7ca:	a885                	j	83a <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 7cc:	00001797          	auipc	a5,0x1
 7d0:	84478793          	addi	a5,a5,-1980 # 1010 <base>
 7d4:	00001717          	auipc	a4,0x1
 7d8:	82f73623          	sd	a5,-2004(a4) # 1000 <freep>
 7dc:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 7de:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 7e2:	b7e1                	j	7aa <malloc+0x36>
      if(p->s.size == nunits)
 7e4:	02e48c63          	beq	s1,a4,81c <malloc+0xa8>
        p->s.size -= nunits;
 7e8:	4137073b          	subw	a4,a4,s3
 7ec:	c798                	sw	a4,8(a5)
        p += p->s.size;
 7ee:	02071693          	slli	a3,a4,0x20
 7f2:	01c6d713          	srli	a4,a3,0x1c
 7f6:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 7f8:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 7fc:	00001717          	auipc	a4,0x1
 800:	80a73223          	sd	a0,-2044(a4) # 1000 <freep>
      return (void*)(p + 1);
 804:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 808:	70e2                	ld	ra,56(sp)
 80a:	7442                	ld	s0,48(sp)
 80c:	74a2                	ld	s1,40(sp)
 80e:	7902                	ld	s2,32(sp)
 810:	69e2                	ld	s3,24(sp)
 812:	6a42                	ld	s4,16(sp)
 814:	6aa2                	ld	s5,8(sp)
 816:	6b02                	ld	s6,0(sp)
 818:	6121                	addi	sp,sp,64
 81a:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 81c:	6398                	ld	a4,0(a5)
 81e:	e118                	sd	a4,0(a0)
 820:	bff1                	j	7fc <malloc+0x88>
  hp->s.size = nu;
 822:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 826:	0541                	addi	a0,a0,16
 828:	ec5ff0ef          	jal	ra,6ec <free>
  return freep;
 82c:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 830:	dd61                	beqz	a0,808 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 832:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 834:	4798                	lw	a4,8(a5)
 836:	fa9777e3          	bgeu	a4,s1,7e4 <malloc+0x70>
    if(p == freep)
 83a:	00093703          	ld	a4,0(s2)
 83e:	853e                	mv	a0,a5
 840:	fef719e3          	bne	a4,a5,832 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 844:	8552                	mv	a0,s4
 846:	acfff0ef          	jal	ra,314 <sbrk>
  if(p == (char*)-1)
 84a:	fd551ce3          	bne	a0,s5,822 <malloc+0xae>
        return 0;
 84e:	4501                	li	a0,0
 850:	bf65                	j	808 <malloc+0x94>
